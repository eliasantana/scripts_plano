
package br.com.mv.soul.mvsaude.forms.Guia.services;

import static morphis.foundations.core.appsupportlib.Globals.getGlobal;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.setBlockInsertAllowed;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.setBlockUpdateAllowed;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.getItemEnabled;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.getItemValue;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemEnabled;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemInsertAllowed;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemNavigable;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemRequired;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemUpdateAllowed;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemValue;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.getMode;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.getRecordStatus;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.getTaskParameter;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.setTaskParameter;

import br.com.mv.soul.common.libs.DbUtils.XmlParameterFactory;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaProrrogacaoAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaProAdapter;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.data.IDataCommand;
import morphis.foundations.core.appsupportlib.util.XmlTypeParameter;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NClob;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;

public class PkgMvsGuia {

	public static void pIWviGNrGuiaTem() {

		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_I_WVI_G_NR_GUIA_TEM", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("GUIA.CD_MATRICULA", getItemValue("GUIA.CD_MATRICULA"));
		xml.setField("GUIA.NR_GUIA", getItemValue("GUIA.NR_GUIA"));
		xml.setField("GUIA.NR_GUIA_TEM", getItemValue("GUIA.NR_GUIA_TEM"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA.CD_MATRICULA", xml.getField("GUIA.CD_MATRICULA", NNumber.class));
		setItemValue("GUIA.NR_GUIA", xml.getField("GUIA.NR_GUIA", NString.class));
		setItemValue("GUIA.NR_GUIA_TEM", xml.getField("GUIA.NR_GUIA_TEM", NNumber.class));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pHabilitaCampos() {

		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_HABILITA_CAMPOS", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setItemProperty("GUIA.CD_PRESTADOR", "ENABLED", getItemEnabled("GUIA.CD_PRESTADOR"));
		xml.setItemProperty("GUIA.NR_GUIA_TEM", "ENABLED", getItemEnabled("GUIA.NR_GUIA_TEM"));
		xml.setItemProperty("GUIA.DT_EMISSAO", "ENABLED", getItemEnabled("GUIA.DT_EMISSAO"));
		xml.setItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "ENABLED", getItemEnabled("GUIA.CD_PRESTADOR_SOLICITANTE"));
		xml.setItemProperty("GUIA.CD_TIP_ACOMODACAO", "ENABLED", getItemEnabled("GUIA.CD_TIP_ACOMODACAO"));
		xml.setItemProperty("ITGUIA.CD_PROCEDIMENTO", "ENABLED", getItemEnabled("ITGUIA.CD_PROCEDIMENTO"));
		xml.setItemProperty("GUIA.NM_CONTATO", "ENABLED", getItemEnabled("GUIA.NM_CONTATO"));
		xml.setItemProperty("GUIA.DS_OBSERVACAO", "ENABLED", getItemEnabled("GUIA.DS_OBSERVACAO"));
		xml.setItemProperty("GUIA.SN_VALIDA_REST_CARENCIA", "ENABLED", getItemEnabled("GUIA.SN_VALIDA_REST_CARENCIA"));
		xml.setItemProperty("ITGUIA.QT_SOLICITADO", "ENABLED", getItemEnabled("ITGUIA.QT_SOLICITADO"));
		xml.setItemProperty("GUIA.CD_TIPO_ATENDIMENTO", "ENABLED", getItemEnabled("GUIA.CD_TIPO_ATENDIMENTO"));
		xml.setItemProperty("GUIA.DT_PREV_EXECUCAO", "ENABLED", getItemEnabled("GUIA.DT_PREV_EXECUCAO"));
		xml.setItemProperty("GUIA.CD_PRESTADOR_EXECUTOR_PF", "ENABLED", getItemEnabled("GUIA.CD_PRESTADOR_EXECUTOR_PF"));
		xml.setItemProperty("GUIA.CD_PRESTADOR_EXECUTOR", "ENABLED", getItemEnabled("GUIA.CD_PRESTADOR_EXECUTOR"));
		xml.setItemProperty("GUIA.CD_ESPECIALIDADE", "ENABLED", getItemEnabled("GUIA.CD_ESPECIALIDADE"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		if (xml.hasItemProperty("GUIA.CD_TIPO_ATENDIMENTO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_TIPO_ATENDIMENTO", xml.getItemProperty("GUIA.CD_TIPO_ATENDIMENTO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_TIP_ACOMODACAO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_TIP_ACOMODACAO", xml.getItemProperty("GUIA.CD_TIP_ACOMODACAO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.NM_CONTATO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.NM_CONTATO", xml.getItemProperty("GUIA.NM_CONTATO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("ITGUIA.QT_SOLICITADO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("ITGUIA.QT_SOLICITADO", xml.getItemProperty("ITGUIA.QT_SOLICITADO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_PRESTADOR_SOLICITANTE", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_EXECUTOR", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_PRESTADOR_EXECUTOR", xml.getItemProperty("GUIA.CD_PRESTADOR_EXECUTOR", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_PRESTADOR", xml.getItemProperty("GUIA.CD_PRESTADOR", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasBlockProperty("ITGUIA", "INSERT_ALLOWED"))
			setBlockInsertAllowed("ITGUIA", xml.getBlockProperty("ITGUIA", "INSERT_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.SN_VALIDA_REST_CARENCIA", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.SN_VALIDA_REST_CARENCIA", xml.getItemProperty("GUIA.SN_VALIDA_REST_CARENCIA", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.NR_GUIA_TEM", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.NR_GUIA_TEM", xml.getItemProperty("GUIA.NR_GUIA_TEM", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("ITGUIA.CD_PROCEDIMENTO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("ITGUIA.CD_PROCEDIMENTO", xml.getItemProperty("ITGUIA.CD_PROCEDIMENTO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasBlockProperty("ITGUIA", "UPDATE_ALLOWED"))
			setBlockUpdateAllowed("ITGUIA", xml.getBlockProperty("ITGUIA", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.DS_OBSERVACAO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.DS_OBSERVACAO", xml.getItemProperty("GUIA.DS_OBSERVACAO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_ESPECIALIDADE", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_ESPECIALIDADE", xml.getItemProperty("GUIA.CD_ESPECIALIDADE", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_EXECUTOR_PF", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_PRESTADOR_EXECUTOR_PF", xml.getItemProperty("GUIA.CD_PRESTADOR_EXECUTOR_PF", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.DT_EMISSAO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.DT_EMISSAO", xml.getItemProperty("GUIA.DT_EMISSAO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasBlockProperty("GUIA", "UPDATE_ALLOWED"))
			setBlockUpdateAllowed("GUIA", xml.getBlockProperty("GUIA", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.DT_PREV_EXECUCAO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.DT_PREV_EXECUCAO", xml.getItemProperty("GUIA.DT_PREV_EXECUCAO", "UPDATE_ALLOWED", Boolean.class));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pCheckGuia() {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_CHECK_GUIA", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("GUIA.DT_BAIXADO", getItemValue("GUIA.DT_BAIXADO"));
		xml.setField("GUIA.NR_GUIA", getItemValue("GUIA.NR_GUIA"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA.DT_BAIXADO", xml.getField("GUIA.DT_BAIXADO", NDate.class));
		setItemValue("GUIA.NR_GUIA", xml.getField("GUIA.NR_GUIA", NString.class));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pProcedimento(NString pcdProcedimento, NString psnProrrogacao) {

		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_PROCEDIMENTO", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("PCD_PROCEDIMENTO", pcdProcedimento);
		xml.setField("PSN_PRORROGACAO", psnProrrogacao);
		xml.setField("GUIA.CD_TIPO_ATENDIMENTO", getItemValue("GUIA.CD_TIPO_ATENDIMENTO"));
		xml.setField("GUIA.DSP_NR_NIVEL_AUTORIZACAO", getItemValue("GUIA.DSP_NR_NIVEL_AUTORIZACAO"));
		xml.setField("GUIA.DSP_TP_SEXO", getItemValue("GUIA.DSP_TP_SEXO"));
		xml.setField("GUIA.NR_GUIA", getItemValue("GUIA.NR_GUIA"));
		xml.setField("GUIA.CD_MATRICULA", getItemValue("GUIA.CD_MATRICULA"));
		xml.setField("GUIA.CD_PRESTADOR_EXECUTOR", getItemValue("GUIA.CD_PRESTADOR_EXECUTOR"));
		xml.setField("GUIA.DT_EMISSAO", getItemValue("GUIA.DT_EMISSAO"));
		xml.setField("ITGUIA.DSP_DS_PROCEDIMENTO", getItemValue("ITGUIA.DSP_DS_PROCEDIMENTO"));
		xml.setField("ITGUIA.DSP_CD_GRU_CARENCIA", getItemValue("ITGUIA.DSP_CD_GRU_CARENCIA"));
		xml.setField("ITGUIA.DSP_CD_GRU_DIREITO", getItemValue("ITGUIA.DSP_CD_GRU_DIREITO"));
		xml.setField("ITGUIA.DSP_NR_DIAS_INTERNACAO", getItemValue("ITGUIA.DSP_NR_DIAS_INTERNACAO"));
		xml.setField("ITGUIA.DSP_NR_NIVEL_AUTORIZACAO", getItemValue("ITGUIA.DSP_NR_NIVEL_AUTORIZACAO"));
		xml.setField("ITGUIA.DSP_CD_PROCEDIMENTO_AUXILIAR", getItemValue("ITGUIA.DSP_CD_PROCEDIMENTO_AUXILIAR"));
		xml.setField("ITGUIA.DSP_QT_MAXIMA_SOLIC", getItemValue("ITGUIA.DSP_QT_MAXIMA_SOLIC"));
		xml.setField("ITGUIA.CD_TABELA_FATURAMENTO", getItemValue("ITGUIA.CD_TABELA_FATURAMENTO"));
		xml.setField("ITGUIA_PRO.DSP_DS_PROCEDIMENTO", getItemValue("ITGUIA_PRO.DSP_DS_PROCEDIMENTO"));
		xml.setField("ITGUIA_PRO.DSP_CD_GRU_CARENCIA", getItemValue("ITGUIA_PRO.DSP_CD_GRU_CARENCIA"));
		xml.setField("ITGUIA_PRO.DSP_CD_GRU_DIREITO", getItemValue("ITGUIA_PRO.DSP_CD_GRU_DIREITO"));
		xml.setField("ITGUIA_PRO.DSP_NR_DIAS_INTERNACAO", getItemValue("ITGUIA_PRO.DSP_NR_DIAS_INTERNACAO"));
		xml.setField("ITGUIA_PRO.DSP_NR_NIVEL_AUTORIZACAO", getItemValue("ITGUIA_PRO.DSP_NR_NIVEL_AUTORIZACAO"));
		xml.setField("ITGUIA_PRO.DSP_CD_PROCEDIMENTO_AUXILIAR", getItemValue("ITGUIA_PRO.DSP_CD_PROCEDIMENTO_AUXILIAR"));
		xml.setField("ITGUIA_PRO.DSP_QT_MAXIMA_SOLIC", getItemValue("ITGUIA_PRO.DSP_QT_MAXIMA_SOLIC"));
		xml.setField("ITGUIA_PRO.CD_TABELA_FATURAMENTO", getItemValue("ITGUIA_PRO.CD_TABELA_FATURAMENTO"));
		xml.setField("PARAMETER.CD_MULTI_EMPRESA", getTaskParameter("CD_MULTI_EMPRESA"));
		xml.setField("PARAMETER.CD_USUARIO", getTaskParameter("CD_USUARIO"));
		xml.setField("FSV_MODE", getMode());
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA.CD_TIPO_ATENDIMENTO", xml.getField("GUIA.CD_TIPO_ATENDIMENTO", NNumber.class));
		setItemValue("GUIA.DSP_NR_NIVEL_AUTORIZACAO", xml.getField("GUIA.DSP_NR_NIVEL_AUTORIZACAO", NNumber.class));
		setItemValue("GUIA.DSP_TP_SEXO", xml.getField("GUIA.DSP_TP_SEXO", NString.class));
		setItemValue("GUIA.NR_GUIA", xml.getField("GUIA.NR_GUIA", NString.class));
		setItemValue("GUIA.CD_MATRICULA", xml.getField("GUIA.CD_MATRICULA", NNumber.class));
		setItemValue("GUIA.CD_PRESTADOR_EXECUTOR", xml.getField("GUIA.CD_PRESTADOR_EXECUTOR", NNumber.class));
		setItemValue("GUIA.DT_EMISSAO", xml.getField("GUIA.DT_EMISSAO", NDate.class));
		setItemValue("ITGUIA.DSP_DS_PROCEDIMENTO", xml.getField("ITGUIA.DSP_DS_PROCEDIMENTO", NString.class));
		setItemValue("ITGUIA.DSP_CD_GRU_CARENCIA", xml.getField("ITGUIA.DSP_CD_GRU_CARENCIA", NNumber.class));
		setItemValue("ITGUIA.DSP_CD_GRU_DIREITO", xml.getField("ITGUIA.DSP_CD_GRU_DIREITO", NNumber.class));
		setItemValue("ITGUIA.DSP_NR_DIAS_INTERNACAO", xml.getField("ITGUIA.DSP_NR_DIAS_INTERNACAO", NNumber.class));
		setItemValue("ITGUIA.DSP_NR_NIVEL_AUTORIZACAO", xml.getField("ITGUIA.DSP_NR_NIVEL_AUTORIZACAO", NNumber.class));
		setItemValue("ITGUIA.DSP_CD_PROCEDIMENTO_AUXILIAR", xml.getField("ITGUIA.DSP_CD_PROCEDIMENTO_AUXILIAR", NString.class));
		setItemValue("ITGUIA.DSP_QT_MAXIMA_SOLIC", xml.getField("ITGUIA.DSP_QT_MAXIMA_SOLIC", NNumber.class));
		setItemValue("ITGUIA.CD_TABELA_FATURAMENTO", xml.getField("ITGUIA.CD_TABELA_FATURAMENTO", NNumber.class));
		setItemValue("ITGUIA_PRO.DSP_DS_PROCEDIMENTO", xml.getField("ITGUIA_PRO.DSP_DS_PROCEDIMENTO", NString.class));
		setItemValue("ITGUIA_PRO.DSP_CD_GRU_CARENCIA", xml.getField("ITGUIA_PRO.DSP_CD_GRU_CARENCIA", NNumber.class));
		setItemValue("ITGUIA_PRO.DSP_CD_GRU_DIREITO", xml.getField("ITGUIA_PRO.DSP_CD_GRU_DIREITO", NNumber.class));
		setItemValue("ITGUIA_PRO.DSP_NR_DIAS_INTERNACAO", xml.getField("ITGUIA_PRO.DSP_NR_DIAS_INTERNACAO", NNumber.class));
		setItemValue("ITGUIA_PRO.DSP_NR_NIVEL_AUTORIZACAO", xml.getField("ITGUIA_PRO.DSP_NR_NIVEL_AUTORIZACAO", NNumber.class));
		setItemValue("ITGUIA_PRO.DSP_CD_PROCEDIMENTO_AUXILIAR", xml.getField("ITGUIA_PRO.DSP_CD_PROCEDIMENTO_AUXILIAR", NString.class));
		setItemValue("ITGUIA_PRO.DSP_QT_MAXIMA_SOLIC", xml.getField("ITGUIA_PRO.DSP_QT_MAXIMA_SOLIC", NNumber.class));
		setItemValue("ITGUIA_PRO.CD_TABELA_FATURAMENTO", xml.getField("ITGUIA_PRO.CD_TABELA_FATURAMENTO", NNumber.class));
		setTaskParameter("CD_MULTI_EMPRESA", xml.getField("PARAMETER.CD_MULTI_EMPRESA"));
		setTaskParameter("CD_USUARIO", xml.getField("PARAMETER.CD_USUARIO"));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pIWviAgCdPrestadorExec() {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_I_WVI_AG_CD_PRESTADOR_EXEC", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("GUIA.CD_ESPECIALIDADE", getItemValue("GUIA.CD_ESPECIALIDADE"));
		xml.setField("ALTERACAO_GUIA.CD_PRESTADOR_EXECUTOR_NOVO", getItemValue("ALTERACAO_GUIA.CD_PRESTADOR_EXECUTOR_NOVO"));
		xml.setField("ALTERACAO_GUIA.DSP_NM_PRESTADOR_EXECUTOR_NOVO", getItemValue("ALTERACAO_GUIA.DSP_NM_PRESTADOR_EXECUTOR_NOVO"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA.CD_ESPECIALIDADE", xml.getField("GUIA.CD_ESPECIALIDADE", NNumber.class));
		setItemValue("ALTERACAO_GUIA.CD_PRESTADOR_EXECUTOR_NOVO", xml.getField("ALTERACAO_GUIA.CD_PRESTADOR_EXECUTOR_NOVO", NNumber.class));
		setItemValue("ALTERACAO_GUIA.DSP_NM_PRESTADOR_EXECUTOR_NOVO", xml.getField("ALTERACAO_GUIA.DSP_NM_PRESTADOR_EXECUTOR_NOVO", NString.class));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pPrestadorExecutor(NBool pRaise) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_PRESTADOR_EXECUTOR", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("P_RAISE", pRaise);
		xml.setField("GUIA.DSP_ESPECIALIDADE_SOLICITANTE", getItemValue("GUIA.DSP_ESPECIALIDADE_SOLICITANTE"));
		xml.setField("GUIA.CD_PRESTADOR_EXECUTOR", getItemValue("GUIA.CD_PRESTADOR_EXECUTOR"));
		xml.setField("GUIA.CD_ESPECIALIDADE", getItemValue("GUIA.CD_ESPECIALIDADE"));
		xml.setField("GUIA.DSP_NM_EXECUTOR", getItemValue("GUIA.DSP_NM_EXECUTOR"));
		xml.setField("PARAMETER.CD_MULTI_EMPRESA", getTaskParameter("CD_MULTI_EMPRESA"));
		xml.setField("PARAMETER.CD_USUARIO", getTaskParameter("CD_USUARIO"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA.DSP_ESPECIALIDADE_SOLICITANTE", xml.getField("GUIA.DSP_ESPECIALIDADE_SOLICITANTE", NString.class));
		setItemValue("GUIA.CD_PRESTADOR_EXECUTOR", xml.getField("GUIA.CD_PRESTADOR_EXECUTOR", NNumber.class));
		setItemValue("GUIA.CD_ESPECIALIDADE", xml.getField("GUIA.CD_ESPECIALIDADE", NNumber.class));
		setItemValue("GUIA.DSP_NM_EXECUTOR", xml.getField("GUIA.DSP_NM_EXECUTOR", NString.class));
		setTaskParameter("CD_MULTI_EMPRESA", xml.getField("PARAMETER.CD_MULTI_EMPRESA"));
		setTaskParameter("CD_USUARIO", xml.getField("PARAMETER.CD_USUARIO"));
		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_EXECUTOR_PF", "REQUIRED"))
			setItemRequired("GUIA.CD_PRESTADOR_EXECUTOR_PF", xml.getItemProperty("GUIA.CD_PRESTADOR_EXECUTOR_PF", "REQUIRED", Boolean.class));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pTipAcomodacao(NString psnProrrogacao, NBool pRaise) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_TIP_ACOMODACAO", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("PSN_PRORROGACAO", psnProrrogacao);
		xml.setField("P_RAISE", pRaise);
		xml.setField("GUIA.CD_TIP_ACOMODACAO", getItemValue("GUIA.CD_TIP_ACOMODACAO"));
		xml.setField("GUIA.DSP_CD_PLANO", getItemValue("GUIA.DSP_CD_PLANO"));
		xml.setField("GUIA.DSP_DS_TIP_ACOMODACAO", getItemValue("GUIA.DSP_DS_TIP_ACOMODACAO"));
		xml.setField("GUIA_PRORROGACAO.CD_TIP_ACOMODACAO", getItemValue("GUIA_PRORROGACAO.CD_TIP_ACOMODACAO"));
		xml.setField("GUIA_PRORROGACAO.DSP_TIP_ACOMODACAO", getItemValue("GUIA_PRORROGACAO.DSP_TIP_ACOMODACAO"));
		xml.setField("PARAMETER.CD_MULTI_EMPRESA", getTaskParameter("CD_MULTI_EMPRESA"));
		xml.setField("PARAMETER.CD_USUARIO", getTaskParameter("CD_USUARIO"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA.CD_TIP_ACOMODACAO", xml.getField("GUIA.CD_TIP_ACOMODACAO", NNumber.class));
		setItemValue("GUIA.DSP_CD_PLANO", xml.getField("GUIA.DSP_CD_PLANO", NNumber.class));
		setItemValue("GUIA.DSP_DS_TIP_ACOMODACAO", xml.getField("GUIA.DSP_DS_TIP_ACOMODACAO", NString.class));
		setItemValue("GUIA_PRORROGACAO.CD_TIP_ACOMODACAO", xml.getField("GUIA_PRORROGACAO.CD_TIP_ACOMODACAO", NNumber.class));
		setItemValue("GUIA_PRORROGACAO.DSP_TIP_ACOMODACAO", xml.getField("GUIA_PRORROGACAO.DSP_TIP_ACOMODACAO", NString.class));
		setTaskParameter("CD_MULTI_EMPRESA", xml.getField("PARAMETER.CD_MULTI_EMPRESA"));
		setTaskParameter("CD_USUARIO", xml.getField("PARAMETER.CD_USUARIO"));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pBOcdmItguiaPro(ItguiaProAdapter itguiaProElement) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_B_OCDM_ITGUIA_PRO", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("ITGUIA_PRO.NR_GUIA", itguiaProElement.getNrGuia());
		xml.setField("ITGUIA_PRO.CD_PROCEDIMENTO", itguiaProElement.getCdProcedimento());
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("ITGUIA_PRO.NR_GUIA", xml.getField("ITGUIA_PRO.NR_GUIA", NNumber.class));
		setItemValue("ITGUIA_PRO.CD_PROCEDIMENTO", xml.getField("ITGUIA_PRO.CD_PROCEDIMENTO", NString.class));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pBPdItguia(ItguiaAdapter itguiaElement) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_B_PD_ITGUIA", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("GUIA.SN_VALIDA_REST_CARENCIA", getItemValue("GUIA.SN_VALIDA_REST_CARENCIA"));
		xml.setField("GUIA.DT_AUTORIZACAO", getItemValue("GUIA.DT_AUTORIZACAO"));
		xml.setField("ITGUIA.CD_ITGUIA", itguiaElement.getCdItguia());
		xml.setField("PARAMETER.SN_ANALISE_EXECUTADA", getTaskParameter("SN_ANALISE_EXECUTADA"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA.SN_VALIDA_REST_CARENCIA", xml.getField("GUIA.SN_VALIDA_REST_CARENCIA", NString.class));
		setItemValue("GUIA.DT_AUTORIZACAO", xml.getField("GUIA.DT_AUTORIZACAO", NDate.class));
		setItemValue("ITGUIA.CD_ITGUIA", xml.getField("ITGUIA.CD_ITGUIA", NNumber.class));
		setItemValue("ITGUIA.TP_SITUACAO_ANALISA", xml.getField("PARAMETER.SN_ANALISE_EXECUTADA").equals("S") ? 2 : 0);

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pIWviGCdPrestadorExec() {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_I_WVI_G_CD_PRESTADOR_EXEC", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("GUIA.CD_ESPECIALIDADE", getItemValue("GUIA.CD_ESPECIALIDADE"));
		xml.setField("GUIA.CD_PRESTADOR_EXECUTOR", getItemValue("GUIA.CD_PRESTADOR_EXECUTOR"));
		xml.setField("GUIA.DSP_ESPECIALIDADE_SOLICITANTE", getItemValue("GUIA.DSP_ESPECIALIDADE_SOLICITANTE"));
		xml.setField("GUIA.DSP_NM_EXECUTOR", getItemValue("GUIA.DSP_NM_EXECUTOR"));
		xml.setField("PARAMETER.CD_MULTI_EMPRESA", getTaskParameter("CD_MULTI_EMPRESA"));
		xml.setField("PARAMETER.CD_USUARIO", getTaskParameter("CD_USUARIO"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA.CD_ESPECIALIDADE", xml.getField("GUIA.CD_ESPECIALIDADE", NNumber.class));
		setItemValue("GUIA.CD_PRESTADOR_EXECUTOR", xml.getField("GUIA.CD_PRESTADOR_EXECUTOR", NNumber.class));
		// setItemValue("GUIA.DSP_ESPECIALIDADE_SOLICITANTE",
		// xml.getField("GUIA.DSP_ESPECIALIDADE_SOLICITANTE", OraString.class));
		setItemValue("GUIA.DSP_NM_EXECUTOR", xml.getField("GUIA.DSP_NM_EXECUTOR", NString.class));
		setTaskParameter("CD_MULTI_EMPRESA", xml.getField("PARAMETER.CD_MULTI_EMPRESA"));
		setTaskParameter("CD_USUARIO", xml.getField("PARAMETER.CD_USUARIO"));
		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_EXECUTOR_PF", "REQUIRED"))
			setItemRequired("GUIA.CD_PRESTADOR_EXECUTOR_PF", xml.getItemProperty("GUIA.CD_PRESTADOR_EXECUTOR_PF", "REQUIRED", Boolean.class));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	/**
	 * Reescrever essa função depois
	 * @param guiaAdapterElement
	 */
	public static void pIWviGCdTpAtendimento() {

		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_I_WVI_G_CD_TP_ATENDIMENTO", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros
		xml.setField("GUIA.DSP_TP_GUIA", getItemValue("GUIA.DSP_TP_GUIA"));
		if (!getItemValue("GUIA.DSP_TP_GUIA").equals("C")) {			
			xml.setField("GUIA.CD_TIPO_CONSULTA", getItemValue("GUIA.CD_TIPO_CONSULTA"));
		}
		xml.setField("GUIA.DSP_SN_TP_INTERNACAO", getItemValue("GUIA.DSP_SN_TP_INTERNACAO"));
		xml.setField("GUIA.CD_TIP_ACOMODACAO", getItemValue("GUIA.CD_TIP_ACOMODACAO"));
		xml.setField("GUIA.DSP_DS_TIP_ACOMODACAO", getItemValue("GUIA.DSP_DS_TIP_ACOMODACAO"));
		xml.setField("GUIA.CD_PRESTADOR_SOLICITADO", getItemValue("GUIA.CD_PRESTADOR_SOLICITADO"));
		xml.setField("GUIA.NM_PRESTADOR_SOLICITADO", getItemValue("GUIA.NM_PRESTADOR_SOLICITADO"));
		xml.setField("GUIA.TP_INTERNACAO", getItemValue("GUIA.TP_INTERNACAO"));
		xml.setField("GUIA.CD_REGIME_INTERNACAO", getItemValue("GUIA.CD_REGIME_INTERNACAO"));
		xml.setField("GUIA.NR_DIAS_SOLICITACAO", getItemValue("GUIA.NR_DIAS_SOLICITACAO"));
		xml.setField("GUIA.CD_TIPO_ATENDIMENTO_TISS", getItemValue("GUIA.CD_TIPO_ATENDIMENTO_TISS"));
		xml.setField("GUIA.CD_TIPO_SAIDA_GUIA_SADT", getItemValue("GUIA.CD_TIPO_SAIDA_GUIA_SADT"));
		xml.setField("GUIA.DSP_SN_PRESTADOR", getItemValue("GUIA.DSP_SN_PRESTADOR"));
		xml.setField("GUIA.CD_PRESTADOR", getItemValue("GUIA.CD_PRESTADOR"));
		
		xml.setField("GUIA.CD_PRESTADOR_SOLICITANTE", getItemValue("GUIA.CD_PRESTADOR_SOLICITANTE"));
		xml.setField("GUIA.DSP_NM_SOLICITANTE", getItemValue("GUIA.DSP_NM_SOLICITANTE"));
		xml.setField("GUIA.DSP_SN_DS_SENHA_AUTORIZACAO", getItemValue("GUIA.DSP_SN_DS_SENHA_AUTORIZACAO"));
		xml.setField("GUIA.DS_SENHA_AUTORIZADOR", getItemValue("GUIA.DS_SENHA_AUTORIZADOR"));
		xml.setField("GUIA.DSP_SN_NR_DIAS_AUTORIZACAO", getItemValue("GUIA.DSP_SN_NR_DIAS_AUTORIZACAO"));
		xml.setField("GUIA.NR_DIAS_AUTORIZACAO", getItemValue("GUIA.NR_DIAS_AUTORIZACAO"));
		xml.setField("GUIA.DSP_CD_PLANO", getItemValue("GUIA.DSP_CD_PLANO"));
		xml.setField("GUIA.DSP_DS_TIPO_ATENDIMENTO", getItemValue("GUIA.DSP_DS_TIPO_ATENDIMENTO"));
		xml.setField("GUIA.DSP_DS_PROGRAMA_DA_GUIA", getItemValue("GUIA.DSP_DS_PROGRAMA_DA_GUIA"));
		xml.setField("GUIA.CD_TIPO_ATENDIMENTO", getItemValue("GUIA.CD_TIPO_ATENDIMENTO"));
		xml.setField("PARAMETER.PERMITE_ALT", getTaskParameter("PERMITE_ALT"));
		xml.setField("PARAMETER.CD_MULTI_EMPRESA", getTaskParameter("CD_MULTI_EMPRESA"));
		xml.setField("PARAMETER.CD_USUARIO", getTaskParameter("CD_USUARIO"));
		xml.setField("FSV_MODE", getMode());
		xml.setField("FSV_RECORD_STATUS", getRecordStatus());

		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida
		setItemValue("GUIA.DSP_TP_GUIA", xml.getField("GUIA.DSP_TP_GUIA", NString.class));
		if (!xml.getField("GUIA.DSP_TP_GUIA", NString.class).equals("C")) {
			setItemValue("GUIA.CD_TIPO_CONSULTA", xml.getField("GUIA.CD_TIPO_CONSULTA", NNumber.class));
		}
		setItemValue("GUIA.DSP_SN_TP_INTERNACAO", xml.getField("GUIA.DSP_SN_TP_INTERNACAO", NString.class));
		setItemValue("GUIA.CD_TIP_ACOMODACAO", xml.getField("GUIA.CD_TIP_ACOMODACAO", NNumber.class));
		setItemValue("GUIA.DSP_DS_TIP_ACOMODACAO", xml.getField("GUIA.DSP_DS_TIP_ACOMODACAO", NString.class));
		setItemValue("GUIA.CD_PRESTADOR_SOLICITADO", xml.getField("GUIA.CD_PRESTADOR_SOLICITADO", NNumber.class));
		setItemValue("GUIA.NM_PRESTADOR_SOLICITADO", xml.getField("GUIA.NM_PRESTADOR_SOLICITADO", NString.class));
		setItemValue("GUIA.TP_INTERNACAO", xml.getField("GUIA.TP_INTERNACAO", NString.class));
		setItemValue("GUIA.CD_REGIME_INTERNACAO", xml.getField("GUIA.CD_REGIME_INTERNACAO", NNumber.class));
		setItemValue("GUIA.NR_DIAS_SOLICITACAO", xml.getField("GUIA.NR_DIAS_SOLICITACAO", NNumber.class));
		setItemValue("GUIA.CD_TIPO_ATENDIMENTO_TISS", xml.getField("GUIA.CD_TIPO_ATENDIMENTO_TISS", NNumber.class));
		setItemValue("GUIA.CD_TIPO_SAIDA_GUIA_SADT", xml.getField("GUIA.CD_TIPO_SAIDA_GUIA_SADT", NNumber.class));
		setItemValue("GUIA.DSP_SN_PRESTADOR", xml.getField("GUIA.DSP_SN_PRESTADOR", NString.class));
		setItemValue("GUIA.CD_PRESTADOR", xml.getField("GUIA.CD_PRESTADOR", NNumber.class));
		
		if(((NNumber)(getItemValue("GUIA.CD_PRESTADOR"))).isNull()){
			setItemValue("GUIA.NM_PRESTADOR", xml.getField("GUIA.NM_PRESTADOR", NString.class));
		}
		
		setItemValue("GUIA.CD_PRESTADOR_SOLICITANTE", xml.getField("GUIA.CD_PRESTADOR_SOLICITANTE", NNumber.class));
		setItemValue("GUIA.DSP_NM_SOLICITANTE", xml.getField("GUIA.DSP_NM_SOLICITANTE", NString.class));
		setItemValue("GUIA.DSP_SN_DS_SENHA_AUTORIZACAO", xml.getField("GUIA.DSP_SN_DS_SENHA_AUTORIZACAO", NString.class));
		setItemValue("GUIA.DS_SENHA_AUTORIZADOR", xml.getField("GUIA.DS_SENHA_AUTORIZADOR", NString.class));
		setItemValue("GUIA.DSP_SN_NR_DIAS_AUTORIZACAO", xml.getField("GUIA.DSP_SN_NR_DIAS_AUTORIZACAO", NString.class));
		setItemValue("GUIA.NR_DIAS_AUTORIZACAO", xml.getField("GUIA.NR_DIAS_AUTORIZACAO", NNumber.class));
		setItemValue("GUIA.DSP_CD_PLANO", xml.getField("GUIA.DSP_CD_PLANO", NNumber.class));
		setItemValue("GUIA.DSP_DS_TIPO_ATENDIMENTO", xml.getField("GUIA.DSP_DS_TIPO_ATENDIMENTO", NString.class));
		setItemValue("GUIA.DSP_DS_PROGRAMA_DA_GUIA", xml.getField("GUIA.DSP_DS_PROGRAMA_DA_GUIA", NString.class));
		setItemValue("GUIA.CD_TIPO_ATENDIMENTO", xml.getField("GUIA.CD_TIPO_ATENDIMENTO", NNumber.class));

		setTaskParameter("PERMITE_ALT", xml.getField("PARAMETER.PERMITE_ALT"));
		setTaskParameter("CD_MULTI_EMPRESA", xml.getField("PARAMETER.CD_MULTI_EMPRESA"));
		setTaskParameter("CD_USUARIO", xml.getField("PARAMETER.CD_USUARIO"));

		// DS_SENHA_AUTORIZADOR
		if (xml.hasItemProperty("GUIA.DS_SENHA_AUTORIZADOR", "NAVIGABLE")){
			setItemNavigable("GUIA.DS_SENHA_AUTORIZADOR", xml.getItemProperty("GUIA.DS_SENHA_AUTORIZADOR", "NAVIGABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.DS_SENHA_AUTORIZADOR", "UPDATEABLE")){
			setItemUpdateAllowed("GUIA.DS_SENHA_AUTORIZADOR", xml.getItemProperty("GUIA.DS_SENHA_AUTORIZADOR", "UPDATEABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.DS_SENHA_AUTORIZADOR", "INSERT_ALLOWED")){
			setItemInsertAllowed("GUIA.DS_SENHA_AUTORIZADOR", xml.getItemProperty("GUIA.DS_SENHA_AUTORIZADOR", "INSERT_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.DS_SENHA_AUTORIZADOR", "ENABLED")){
			setItemEnabled("GUIA.DS_SENHA_AUTORIZADOR", xml.getItemProperty("GUIA.DS_SENHA_AUTORIZADOR", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.DS_SENHA_AUTORIZADOR", "REQUIRED")){
			setItemRequired("GUIA.DS_SENHA_AUTORIZADOR", xml.getItemProperty("GUIA.DS_SENHA_AUTORIZADOR", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIPO_SAIDA_GUIA_SADT", "INSERT_ALLOWED")){
			setItemInsertAllowed("GUIA.CD_TIPO_SAIDA_GUIA_SADT", xml.getItemProperty("GUIA.CD_TIPO_SAIDA_GUIA_SADT", "INSERT_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "UPDATE_ALLOWED")){
			setItemUpdateAllowed("GUIA.CD_PRESTADOR_SOLICITANTE", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "UPDATE_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.NR_DIAS_SOLICITACAO", "NAVIGABLE")){
			setItemNavigable("GUIA.NR_DIAS_SOLICITACAO", xml.getItemProperty("GUIA.NR_DIAS_SOLICITACAO", "NAVIGABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIP_ACOMODACAO", "ENABLED")){
			setItemEnabled("GUIA.CD_TIP_ACOMODACAO", xml.getItemProperty("GUIA.CD_TIP_ACOMODACAO", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIP_ACOMODACAO", "REQUIRED")){
			setItemRequired("GUIA.CD_TIP_ACOMODACAO", xml.getItemProperty("GUIA.CD_TIP_ACOMODACAO", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIPO_ATENDIMENTO_TISS", "INSERT_ALLOWED")){
			setItemInsertAllowed("GUIA.CD_TIPO_ATENDIMENTO_TISS", xml.getItemProperty("GUIA.CD_TIPO_ATENDIMENTO_TISS", "INSERT_ALLOWED", Boolean.class));
		}
		
		if (xml.hasItemProperty("GUIA.TP_CARATER_SOLIC_INTER", "UPDATE_ALLOWED")){
			setItemUpdateAllowed("GUIA.TP_CARATER_SOLIC_INTER", xml.getItemProperty("GUIA.TP_CARATER_SOLIC_INTER", "UPDATE_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIPO_SAIDA_GUIA_SADT", "NAVIGABLE")){
			setItemNavigable("GUIA.CD_TIPO_SAIDA_GUIA_SADT", xml.getItemProperty("GUIA.CD_TIPO_SAIDA_GUIA_SADT", "NAVIGABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "REQUIRED")){
			setItemRequired("GUIA.CD_PRESTADOR_SOLICITANTE", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR", "ENABLED")){
			setItemEnabled("GUIA.CD_PRESTADOR", xml.getItemProperty("GUIA.CD_PRESTADOR", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIPO_CONSULTA", "REQUIRED")){
			setItemRequired("GUIA.CD_TIPO_CONSULTA", xml.getItemProperty("GUIA.CD_TIPO_CONSULTA", "REQUIRED", Boolean.class));
		}
		
		if (xml.hasItemProperty("GUIA.CD_TIP_ACOMODACAO", "INSERT_ALLOWED")){
			setItemInsertAllowed("GUIA.CD_TIP_ACOMODACAO", xml.getItemProperty("GUIA.CD_TIP_ACOMODACAO", "INSERT_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR", "INSERT_ALLOWED")){
			setItemInsertAllowed("GUIA.CD_PRESTADOR", xml.getItemProperty("GUIA.CD_PRESTADOR", "INSERT_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIPO_SAIDA_GUIA_SADT", "ENABLED")){
			setItemEnabled("GUIA.CD_TIPO_SAIDA_GUIA_SADT", xml.getItemProperty("GUIA.CD_TIPO_SAIDA_GUIA_SADT", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIPO_SAIDA_GUIA_SADT", "REQUIRED")){
			setItemRequired("GUIA.CD_TIPO_SAIDA_GUIA_SADT", xml.getItemProperty("GUIA.CD_TIPO_SAIDA_GUIA_SADT", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.TP_INTERNACAO", "NAVIGABLE")){
			setItemNavigable("GUIA.TP_INTERNACAO", xml.getItemProperty("GUIA.TP_INTERNACAO", "NAVIGABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.TP_INTERNACAO", "INSERT_ALLOWED")){
			setItemInsertAllowed("GUIA.TP_INTERNACAO", xml.getItemProperty("GUIA.TP_INTERNACAO", "INSERT_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.NR_DIAS_AUTORIZACAO", "REQUIRED")){
			setItemRequired("GUIA.NR_DIAS_AUTORIZACAO", xml.getItemProperty("GUIA.NR_DIAS_AUTORIZACAO", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.BTN_CD_CID3", "ENABLED")){
			setItemEnabled("GUIA.BTN_CD_CID3", xml.getItemProperty("GUIA.BTN_CD_CID3", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.BTN_CD_CID3", "REQUIRED")){
			setItemRequired("GUIA.BTN_CD_CID3", xml.getItemProperty("GUIA.BTN_CD_CID3", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.BTN_CD_CID4", "ENABLED")){
			setItemEnabled("GUIA.BTN_CD_CID4", xml.getItemProperty("GUIA.BTN_CD_CID4", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.BTN_CD_CID4", "REQUIRED")){
			setItemRequired("GUIA.BTN_CD_CID4", xml.getItemProperty("GUIA.BTN_CD_CID4", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.NR_DIAS_AUTORIZACAO", "INSERT_ALLOWED")){
			setItemInsertAllowed("GUIA.NR_DIAS_AUTORIZACAO", xml.getItemProperty("GUIA.NR_DIAS_AUTORIZACAO", "INSERT_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE2", "ENABLED")){
			setItemEnabled("GUIA.CD_PRESTADOR_SOLICITANTE2", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE2", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE2", "REQUIRED")){
			setItemRequired("GUIA.CD_PRESTADOR_SOLICITANTE2", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE2", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "NAVIGABLE")){
			setItemNavigable("GUIA.CD_PRESTADOR_SOLICITANTE", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "NAVIGABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITADO2", "ENABLED")){
			setItemEnabled("GUIA.CD_PRESTADOR_SOLICITADO2", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITADO2", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITADO2", "REQUIRED")){
			setItemRequired("GUIA.CD_PRESTADOR_SOLICITADO2", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITADO2", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.NR_DIAS_AUTORIZACAO", "REQUIRED")){
			setItemRequired("GUIA.NR_DIAS_AUTORIZACAO", xml.getItemProperty("GUIA.NR_DIAS_AUTORIZACAO", "REQUIRED", Boolean.class));
		}
		
		if (xml.hasItemProperty("GUIA.CD_TIPO_CONSULTA", "NAVIGABLE")){
			setItemNavigable("GUIA.CD_TIPO_CONSULTA", xml.getItemProperty("GUIA.CD_TIPO_CONSULTA", "NAVIGABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIPO_ATENDIMENTO_TISS", "ENABLED")){
			setItemEnabled("GUIA.CD_TIPO_ATENDIMENTO_TISS", xml.getItemProperty("GUIA.CD_TIPO_ATENDIMENTO_TISS", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIPO_ATENDIMENTO_TISS", "REQUIRED")){
			setItemRequired("GUIA.CD_TIPO_ATENDIMENTO_TISS", xml.getItemProperty("GUIA.CD_TIPO_ATENDIMENTO_TISS", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.TP_INTERNACAO", "UPDATE_ALLOWED")){
			setItemUpdateAllowed("GUIA.TP_INTERNACAO", xml.getItemProperty("GUIA.TP_INTERNACAO", "UPDATE_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "INSERT_ALLOWED")){
			setItemInsertAllowed("GUIA.CD_PRESTADOR_SOLICITANTE", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "INSERT_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.TP_INTERNACAO", "ENABLED")){
			setItemEnabled("GUIA.TP_INTERNACAO", xml.getItemProperty("GUIA.TP_INTERNACAO", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.TP_INTERNACAO", "REQUIRED")){
			setItemRequired("GUIA.TP_INTERNACAO", xml.getItemProperty("GUIA.TP_INTERNACAO", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIPO_ATENDIMENTO_TISS", "NAVIGABLE")){
			setItemNavigable("GUIA.CD_TIPO_ATENDIMENTO_TISS", xml.getItemProperty("GUIA.CD_TIPO_ATENDIMENTO_TISS", "NAVIGABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITADO", "ENABLED")){
			setItemEnabled("GUIA.CD_PRESTADOR_SOLICITADO", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITADO", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITADO", "REQUIRED")){
			setItemRequired("GUIA.CD_PRESTADOR_SOLICITADO", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITADO", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIP_ACOMODACAO", "UPDATE_ALLOWED")){
			setItemUpdateAllowed("GUIA.CD_TIP_ACOMODACAO", xml.getItemProperty("GUIA.CD_TIP_ACOMODACAO", "UPDATE_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITADO", "INSERT_ALLOWED")){
			setItemInsertAllowed("GUIA.CD_PRESTADOR_SOLICITADO", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITADO", "INSERT_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITADO", "NAVIGABLE")){
			setItemNavigable("GUIA.CD_PRESTADOR_SOLICITADO", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITADO", "NAVIGABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.BTN_PRORROGACAO", "ENABLED")){
			setItemEnabled("GUIA.BTN_PRORROGACAO", xml.getItemProperty("GUIA.BTN_PRORROGACAO", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.BTN_PRORROGACAO", "REQUIRED")){
			setItemRequired("GUIA.BTN_PRORROGACAO", xml.getItemProperty("GUIA.BTN_PRORROGACAO", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIP_ACOMODACAO", "NAVIGABLE")){
			setItemNavigable("GUIA.CD_TIP_ACOMODACAO", xml.getItemProperty("GUIA.CD_TIP_ACOMODACAO", "NAVIGABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.BTN_CD_CID2", "ENABLED")){
			setItemEnabled("GUIA.BTN_CD_CID2", xml.getItemProperty("GUIA.BTN_CD_CID2", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.BTN_CD_CID2", "REQUIRED")){
			setItemRequired("GUIA.BTN_CD_CID2", xml.getItemProperty("GUIA.BTN_CD_CID2", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_REGIME_INTERNACAO", "INSERT_ALLOWED")){
			setItemInsertAllowed("GUIA.CD_REGIME_INTERNACAO", xml.getItemProperty("GUIA.CD_REGIME_INTERNACAO", "INSERT_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIPO_CONSULTA", "UPDATE_ALLOWED")){
			setItemUpdateAllowed("GUIA.CD_TIPO_CONSULTA", xml.getItemProperty("GUIA.CD_TIPO_CONSULTA", "UPDATE_ALLOWED", Boolean.class));
		}
		
		if (xml.hasItemProperty("GUIA.CD_PRESTADOR", "NAVIGABLE")){
			setItemNavigable("GUIA.CD_PRESTADOR", xml.getItemProperty("GUIA.CD_PRESTADOR", "NAVIGABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.NR_DIAS_AUTORIZACAO", "UPDATEABLE")){
			setItemUpdateAllowed("GUIA.NR_DIAS_AUTORIZACAO", xml.getItemProperty("GUIA.NR_DIAS_AUTORIZACAO", "UPDATEABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIPO_CONSULTA", "INSERT_ALLOWED")){
			setItemInsertAllowed("GUIA.CD_TIPO_CONSULTA", xml.getItemProperty("GUIA.CD_TIPO_CONSULTA", "INSERT_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_REGIME_INTERNACAO", "NAVIGABLE")){
			setItemNavigable("GUIA.CD_REGIME_INTERNACAO", xml.getItemProperty("GUIA.CD_REGIME_INTERNACAO", "NAVIGABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.NR_DIAS_AUTORIZACAO", "NAVIGABLE")){
			setItemNavigable("GUIA.NR_DIAS_AUTORIZACAO", xml.getItemProperty("GUIA.NR_DIAS_AUTORIZACAO", "NAVIGABLE", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.NR_DIAS_SOLICITACAO", "ENABLED")){
			setItemEnabled("GUIA.NR_DIAS_SOLICITACAO", xml.getItemProperty("GUIA.NR_DIAS_SOLICITACAO", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.NR_DIAS_SOLICITACAO", "REQUIRED")){
			setItemRequired("GUIA.NR_DIAS_SOLICITACAO", xml.getItemProperty("GUIA.NR_DIAS_SOLICITACAO", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR2", "ENABLED")){
			setItemEnabled("GUIA.CD_PRESTADOR2", xml.getItemProperty("GUIA.CD_PRESTADOR2", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR2", "REQUIRED")){
			setItemRequired("GUIA.CD_PRESTADOR2", xml.getItemProperty("GUIA.CD_PRESTADOR2", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_REGIME_INTERNACAO", "ENABLED")){
			setItemEnabled("GUIA.CD_REGIME_INTERNACAO", xml.getItemProperty("GUIA.CD_REGIME_INTERNACAO", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_REGIME_INTERNACAO", "REQUIRED")){
			setItemRequired("GUIA.CD_REGIME_INTERNACAO", xml.getItemProperty("GUIA.CD_REGIME_INTERNACAO", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "ENABLED")){
			setItemEnabled("GUIA.CD_PRESTADOR_SOLICITANTE", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "ENABLED")){
			setItemEnabled("GUIA.NM_PROFISSIONAL_SOLICITANTE", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "REQUIRED")){
			setItemRequired("GUIA.CD_PRESTADOR_SOLICITANTE", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "REQUIRED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR", "UPDATE_ALLOWED")){
			setItemUpdateAllowed("GUIA.CD_PRESTADOR", xml.getItemProperty("GUIA.CD_PRESTADOR", "UPDATE_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.NR_DIAS_SOLICITACAO", "INSERT_ALLOWED")){
			setItemInsertAllowed("GUIA.NR_DIAS_SOLICITACAO", xml.getItemProperty("GUIA.NR_DIAS_SOLICITACAO", "INSERT_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.NR_DIAS_SOLICITACAO", "UPDATE_ALLOWED")){
			setItemUpdateAllowed("GUIA.NR_DIAS_SOLICITACAO", xml.getItemProperty("GUIA.NR_DIAS_SOLICITACAO", "UPDATE_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITADO", "UPDATE_ALLOWED")){
			setItemUpdateAllowed("GUIA.CD_PRESTADOR_SOLICITADO", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITADO", "UPDATE_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_REGIME_INTERNACAO", "UPDATE_ALLOWED")){
			setItemUpdateAllowed("GUIA.CD_REGIME_INTERNACAO", xml.getItemProperty("GUIA.CD_REGIME_INTERNACAO", "UPDATE_ALLOWED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIPO_ATENDIMENTO", "ENABLED")){
			setItemEnabled("GUIA.CD_TIPO_ATENDIMENTO", xml.getItemProperty("GUIA.CD_TIPO_ATENDIMENTO", "ENABLED", Boolean.class));
		}

		if (xml.hasItemProperty("GUIA.CD_TIPO_ATENDIMENTO", "REQUIRED")){
			setItemRequired("GUIA.CD_TIPO_ATENDIMENTO", xml.getItemProperty("GUIA.CD_TIPO_ATENDIMENTO", "REQUIRED", Boolean.class));
		}

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pDesabilitaCampos() {

		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_DESABILITA_CAMPOS", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setItemProperty("GUIA.CD_PRESTADOR", "ENABLED", getItemEnabled("GUIA.CD_PRESTADOR"));
		xml.setItemProperty("GUIA.NR_GUIA_TEM", "ENABLED", getItemEnabled("GUIA.NR_GUIA_TEM"));
		xml.setItemProperty("GUIA.DT_EMISSAO", "ENABLED", getItemEnabled("GUIA.DT_EMISSAO"));
		xml.setItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "ENABLED", getItemEnabled("GUIA.CD_PRESTADOR_SOLICITANTE"));
		xml.setItemProperty("GUIA.CD_TIP_ACOMODACAO", "ENABLED", getItemEnabled("GUIA.CD_TIP_ACOMODACAO"));
		xml.setItemProperty("ITGUIA.CD_PROCEDIMENTO", "ENABLED", getItemEnabled("ITGUIA.CD_PROCEDIMENTO"));
		xml.setItemProperty("GUIA.NM_CONTATO", "ENABLED", getItemEnabled("GUIA.NM_CONTATO"));
		xml.setItemProperty("GUIA.DS_OBSERVACAO", "ENABLED", getItemEnabled("GUIA.DS_OBSERVACAO"));
		xml.setItemProperty("GUIA.SN_VALIDA_REST_CARENCIA", "ENABLED", getItemEnabled("GUIA.SN_VALIDA_REST_CARENCIA"));
		xml.setItemProperty("ITGUIA.QT_SOLICITADO", "ENABLED", getItemEnabled("ITGUIA.QT_SOLICITADO"));
		xml.setItemProperty("GUIA.CD_TIPO_ATENDIMENTO", "ENABLED", getItemEnabled("GUIA.CD_TIPO_ATENDIMENTO"));
		xml.setItemProperty("GUIA.DT_PREV_EXECUCAO", "ENABLED", getItemEnabled("GUIA.DT_PREV_EXECUCAO"));
		xml.setItemProperty("GUIA.CD_PRESTADOR_EXECUTOR_PF", "ENABLED", getItemEnabled("GUIA.CD_PRESTADOR_EXECUTOR_PF"));
		xml.setItemProperty("GUIA.CD_PRESTADOR_EXECUTOR", "ENABLED", getItemEnabled("GUIA.CD_PRESTADOR_EXECUTOR"));
		xml.setItemProperty("GUIA.CD_ESPECIALIDADE", "ENABLED", getItemEnabled("GUIA.CD_ESPECIALIDADE"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		if (xml.hasItemProperty("GUIA.CD_TIPO_ATENDIMENTO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_TIPO_ATENDIMENTO", xml.getItemProperty("GUIA.CD_TIPO_ATENDIMENTO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_TIP_ACOMODACAO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_TIP_ACOMODACAO", xml.getItemProperty("GUIA.CD_TIP_ACOMODACAO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.NM_CONTATO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.NM_CONTATO", xml.getItemProperty("GUIA.NM_CONTATO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("ITGUIA.QT_SOLICITADO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("ITGUIA.QT_SOLICITADO", xml.getItemProperty("ITGUIA.QT_SOLICITADO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_PRESTADOR_SOLICITANTE", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_EXECUTOR", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_PRESTADOR_EXECUTOR", xml.getItemProperty("GUIA.CD_PRESTADOR_EXECUTOR", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_PRESTADOR", xml.getItemProperty("GUIA.CD_PRESTADOR", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasBlockProperty("ITGUIA", "INSERT_ALLOWED"))
			setBlockInsertAllowed("ITGUIA", xml.getBlockProperty("ITGUIA", "INSERT_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.SN_VALIDA_REST_CARENCIA", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.SN_VALIDA_REST_CARENCIA", xml.getItemProperty("GUIA.SN_VALIDA_REST_CARENCIA", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.NR_GUIA_TEM", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.NR_GUIA_TEM", xml.getItemProperty("GUIA.NR_GUIA_TEM", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("ITGUIA.CD_PROCEDIMENTO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("ITGUIA.CD_PROCEDIMENTO", xml.getItemProperty("ITGUIA.CD_PROCEDIMENTO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasBlockProperty("ITGUIA", "UPDATE_ALLOWED"))
			setBlockUpdateAllowed("ITGUIA", xml.getBlockProperty("ITGUIA", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.DS_OBSERVACAO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.DS_OBSERVACAO", xml.getItemProperty("GUIA.DS_OBSERVACAO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_ESPECIALIDADE", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_ESPECIALIDADE", xml.getItemProperty("GUIA.CD_ESPECIALIDADE", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_EXECUTOR_PF", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_PRESTADOR_EXECUTOR_PF", xml.getItemProperty("GUIA.CD_PRESTADOR_EXECUTOR_PF", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.DT_EMISSAO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.DT_EMISSAO", xml.getItemProperty("GUIA.DT_EMISSAO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasBlockProperty("GUIA", "UPDATE_ALLOWED"))
			setBlockUpdateAllowed("GUIA", xml.getBlockProperty("GUIA", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.DT_PREV_EXECUCAO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.DT_PREV_EXECUCAO", xml.getItemProperty("GUIA.DT_PREV_EXECUCAO", "UPDATE_ALLOWED", Boolean.class));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pBOcdmGuiaProrrogacao(GuiaProrrogacaoAdapter guiaProrrogacaoElement) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_B_OCDM_GUIA_PRORROGACAO", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("GUIA_PRORROGACAO.NR_GUIA", guiaProrrogacaoElement.getNrGuia());
		xml.setField("GUIA_PRORROGACAO.SQ_GUIA_PRORROGACAO", guiaProrrogacaoElement.getSqGuiaProrrogacao());
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA_PRORROGACAO.NR_GUIA", xml.getField("GUIA_PRORROGACAO.NR_GUIA", NNumber.class));
		setItemValue("GUIA_PRORROGACAO.SQ_GUIA_PRORROGACAO", xml.getField("GUIA_PRORROGACAO.SQ_GUIA_PRORROGACAO", NNumber.class));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pSetaEspecialidadeSolic() {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_SETA_ESPECIALIDADE_SOLIC", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("GUIA.CD_PRESTADOR_SOLICITANTE", getItemValue("GUIA.CD_PRESTADOR_SOLICITANTE"));
		xml.setField("GUIA.CD_PRESTADOR", getItemValue("GUIA.CD_PRESTADOR"));
		xml.setField("GUIA.DSP_ESPECIALIDADE_SOLICITANTE", getItemValue("GUIA.DSP_ESPECIALIDADE_SOLICITANTE"));
		xml.setField("GUIA.CD_ESPECIALIDADE_SOLICITANTE", getItemValue("GUIA.CD_ESPECIALIDADE_SOLICITANTE"));
		xml.setField("PARAMETER.CD_MULTI_EMPRESA", getTaskParameter("CD_MULTI_EMPRESA"));
		xml.setField("PARAMETER.CD_USUARIO", getTaskParameter("CD_USUARIO"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA.CD_PRESTADOR_SOLICITANTE", xml.getField("GUIA.CD_PRESTADOR_SOLICITANTE", NNumber.class));
		setItemValue("GUIA.CD_PRESTADOR", xml.getField("GUIA.CD_PRESTADOR", NNumber.class));
		setItemValue("GUIA.DSP_ESPECIALIDADE_SOLICITANTE", xml.getField("GUIA.DSP_ESPECIALIDADE_SOLICITANTE", NString.class));
		setItemValue("GUIA.CD_ESPECIALIDADE_SOLICITANTE", xml.getField("GUIA.CD_ESPECIALIDADE_SOLICITANTE", NNumber.class));
		setTaskParameter("CD_MULTI_EMPRESA", xml.getField("PARAMETER.CD_MULTI_EMPRESA"));
		setTaskParameter("CD_USUARIO", xml.getField("PARAMETER.CD_USUARIO"));
		if (xml.hasItemProperty("GUIA.CD_ESPECIALIDADE_SOLICITANTE", "INSERT_ALLOWED"))
			setItemInsertAllowed("GUIA.CD_ESPECIALIDADE_SOLICITANTE", xml.getItemProperty("GUIA.CD_ESPECIALIDADE_SOLICITANTE", "INSERT_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.BTN_CD_ESPECIALIDADE_SOLICITAN", "ENABLED"))
			setItemEnabled("GUIA.BTN_CD_ESPECIALIDADE_SOLICITAN", xml.getItemProperty("GUIA.BTN_CD_ESPECIALIDADE_SOLICITAN", "ENABLED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_ESPECIALIDADE_SOLICITANTE", "ENABLED"))
			setItemEnabled("GUIA.CD_ESPECIALIDADE_SOLICITANTE", xml.getItemProperty("GUIA.CD_ESPECIALIDADE_SOLICITANTE", "ENABLED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_ESPECIALIDADE_SOLICITANTE", "NAVIGABLE"))
			setItemNavigable("GUIA.CD_ESPECIALIDADE_SOLICITANTE", xml.getItemProperty("GUIA.CD_ESPECIALIDADE_SOLICITANTE", "NAVIGABLE", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_ESPECIALIDADE_SOLICITANTE", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_ESPECIALIDADE_SOLICITANTE", xml.getItemProperty("GUIA.CD_ESPECIALIDADE_SOLICITANTE", "UPDATE_ALLOWED", Boolean.class));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static NString fPrestadorAssociado(NNumber pcdPrestador, NNumber pcdPrestadorAssociado, NBool pmostramensagem) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.F_PRESTADOR_ASSOCIADO", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("pCD_PRESTADOR", pcdPrestador);
		xml.setField("pCD_PRESTADOR_ASSOCIADO", pcdPrestadorAssociado);
		xml.setField("pMostraMensagem", pmostramensagem);
		xml.setField("PARAMETER.CD_MULTI_EMPRESA", getTaskParameter("CD_MULTI_EMPRESA"));
		xml.setField("PARAMETER.CD_USUARIO", getTaskParameter("CD_USUARIO"));
		cmd.addReturnParameter(NString.class);
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setTaskParameter("CD_MULTI_EMPRESA", xml.getField("PARAMETER.CD_MULTI_EMPRESA"));
		setTaskParameter("CD_USUARIO", xml.getField("PARAMETER.CD_USUARIO"));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

		return cmd.getReturnValue(NString.class);

	}

	public static void pTipoAtendimento(NBool pRaise) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_TIPO_ATENDIMENTO", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("P_RAISE", pRaise);
		xml.setField("GUIA.DSP_DS_TIPO_ATENDIMENTO", getItemValue("GUIA.DSP_DS_TIPO_ATENDIMENTO"));
		xml.setField("GUIA.DSP_SN_PRESTADOR", getItemValue("GUIA.DSP_SN_PRESTADOR"));
		xml.setField("GUIA.DSP_SN_TP_INTERNACAO", getItemValue("GUIA.DSP_SN_TP_INTERNACAO"));
		xml.setField("GUIA.DSP_SN_DS_SENHA_AUTORIZACAO", getItemValue("GUIA.DSP_SN_DS_SENHA_AUTORIZACAO"));
		xml.setField("GUIA.DSP_SN_NR_DIAS_AUTORIZACAO", getItemValue("GUIA.DSP_SN_NR_DIAS_AUTORIZACAO"));
		xml.setField("GUIA.DSP_DS_PROGRAMA_DA_GUIA", getItemValue("GUIA.DSP_DS_PROGRAMA_DA_GUIA"));
		xml.setField("GUIA.DSP_TP_GUIA", getItemValue("GUIA.DSP_TP_GUIA"));
		xml.setField("GUIA.CD_TIPO_ATENDIMENTO", getItemValue("GUIA.CD_TIPO_ATENDIMENTO"));
		xml.setField("PARAMETER.CD_MULTI_EMPRESA", getTaskParameter("CD_MULTI_EMPRESA"));
		xml.setField("PARAMETER.CD_USUARIO", getTaskParameter("CD_USUARIO"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA.DSP_DS_TIPO_ATENDIMENTO", xml.getField("GUIA.DSP_DS_TIPO_ATENDIMENTO", NString.class));
		setItemValue("GUIA.DSP_SN_PRESTADOR", xml.getField("GUIA.DSP_SN_PRESTADOR", NString.class));
		setItemValue("GUIA.DSP_SN_TP_INTERNACAO", xml.getField("GUIA.DSP_SN_TP_INTERNACAO", NString.class));
		setItemValue("GUIA.DSP_SN_DS_SENHA_AUTORIZACAO", xml.getField("GUIA.DSP_SN_DS_SENHA_AUTORIZACAO", NString.class));
		setItemValue("GUIA.DSP_SN_NR_DIAS_AUTORIZACAO", xml.getField("GUIA.DSP_SN_NR_DIAS_AUTORIZACAO", NString.class));
		setItemValue("GUIA.DSP_DS_PROGRAMA_DA_GUIA", xml.getField("GUIA.DSP_DS_PROGRAMA_DA_GUIA", NString.class));
		setItemValue("GUIA.DSP_TP_GUIA", xml.getField("GUIA.DSP_TP_GUIA", NString.class));
		setItemValue("GUIA.CD_TIPO_ATENDIMENTO", xml.getField("GUIA.CD_TIPO_ATENDIMENTO", NNumber.class));
		setTaskParameter("CD_MULTI_EMPRESA", xml.getField("PARAMETER.CD_MULTI_EMPRESA"));
		setTaskParameter("CD_USUARIO", xml.getField("PARAMETER.CD_USUARIO"));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	/**
	 * Removido para executar via cursor no GuiaServices
	 * 
	 * @OP 5859
	 * @author Diego.Nobre
	 * @since 25/04/2013
	 * @param pRaise
	 * @return void
	 */
	@Deprecated
	public static void pAutorizador(NBool pRaise) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_AUTORIZADOR", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros
		xml.setField("P_RAISE", pRaise);
		xml.setField("GUIA.DSP_NM_AUTORIZADOR", getItemValue("GUIA.DSP_NM_AUTORIZADOR"));
		xml.setField("GUIA.DSP_NR_NIVEL", getItemValue("GUIA.DSP_NR_NIVEL"));
		xml.setField("GUIA.DSP_DS_SENHA", getItemValue("GUIA.DSP_DS_SENHA"));
		xml.setField("GUIA.CD_AUTORIZADOR", getItemValue("GUIA.CD_AUTORIZADOR"));
		xml.setField("PARAMETER.CD_MULTI_EMPRESA", getTaskParameter("CD_MULTI_EMPRESA"));
		xml.setField("PARAMETER.CD_USUARIO", getTaskParameter("CD_USUARIO"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida
		setItemValue("GUIA.DSP_NM_AUTORIZADOR", xml.getField("GUIA.DSP_NM_AUTORIZADOR", NString.class));
		setItemValue("GUIA.DSP_NR_NIVEL", xml.getField("GUIA.DSP_NR_NIVEL", NNumber.class));
		setItemValue("GUIA.DSP_DS_SENHA", xml.getField("GUIA.DSP_DS_SENHA", NString.class));
		setItemValue("GUIA.CD_AUTORIZADOR", xml.getField("GUIA.CD_AUTORIZADOR", NNumber.class));
		setTaskParameter("CD_MULTI_EMPRESA", xml.getField("PARAMETER.CD_MULTI_EMPRESA"));
		setTaskParameter("CD_USUARIO", xml.getField("PARAMETER.CD_USUARIO"));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();
	}

	public static void pIWviGDsSenhaAutor() {

		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_I_WVI_G_DS_SENHA_AUTOR", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("GUIA.CD_AUTORIZADOR", getItemValue("GUIA.CD_AUTORIZADOR"));
		xml.setField("GUIA.DS_SENHA_AUTORIZADOR", getItemValue("GUIA.DS_SENHA_AUTORIZADOR"));
		xml.setField("GUIA.DSP_DS_SENHA", getItemValue("GUIA.DSP_DS_SENHA"));
		xml.setField("GUIA.FLEG_AUTORIZADOR", getItemValue("GUIA.FLEG_AUTORIZADOR"));
		xml.setField("GUIA.DSP_NM_AUTORIZADOR", getItemValue("GUIA.DSP_NM_AUTORIZADOR"));
		xml.setField("GUIA.DSP_NR_NIVEL", getItemValue("GUIA.DSP_NR_NIVEL"));
		xml.setField("PARAMETER.CD_MULTI_EMPRESA", getTaskParameter("CD_MULTI_EMPRESA"));
		xml.setField("PARAMETER.CD_USUARIO", getTaskParameter("CD_USUARIO"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA.CD_AUTORIZADOR", xml.getField("GUIA.CD_AUTORIZADOR", NNumber.class));
		setItemValue("GUIA.DS_SENHA_AUTORIZADOR", xml.getField("GUIA.DS_SENHA_AUTORIZADOR", NString.class));
		setItemValue("GUIA.DSP_DS_SENHA", xml.getField("GUIA.DSP_DS_SENHA", NString.class));
		setItemValue("GUIA.FLEG_AUTORIZADOR", xml.getField("GUIA.FLEG_AUTORIZADOR", NString.class));
		setItemValue("GUIA.DSP_NM_AUTORIZADOR", xml.getField("GUIA.DSP_NM_AUTORIZADOR", NString.class));
		setItemValue("GUIA.DSP_NR_NIVEL", xml.getField("GUIA.DSP_NR_NIVEL", NNumber.class));
		setTaskParameter("CD_MULTI_EMPRESA", xml.getField("PARAMETER.CD_MULTI_EMPRESA"));
		setTaskParameter("CD_USUARIO", xml.getField("PARAMETER.CD_USUARIO"));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pBPdGuia(GuiaAdapter guiaElement) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_B_PD_GUIA", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("GUIA.NR_GUIA", guiaElement.getNrGuia());
		xml.setField("GUIA.DT_BAIXADO", guiaElement.getDtBaixado());
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA.NR_GUIA", xml.getField("GUIA.NR_GUIA", NString.class));
		setItemValue("GUIA.DT_BAIXADO", xml.getField("GUIA.DT_BAIXADO", NDate.class));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pBPdItguiaPro(ItguiaProAdapter itguiaProElement) {

		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_B_PD_ITGUIA_PRO", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("ITGUIA_PRO.CD_ITGUIA", itguiaProElement.getCdItguia());
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("ITGUIA_PRO.CD_ITGUIA", xml.getField("ITGUIA_PRO.CD_ITGUIA", NNumber.class));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

	public static void pCheckGuiaAltera() {

		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("dbaps.Pkg_MVS_GUIA.P_CHECK_GUIA_ALTERA", DbManager.getDataBaseFactory());

		XmlTypeParameter xml = XmlParameterFactory.CreateParameter();

		// adiciona parametros usuarios e multiEmpresa
		xml.setField("usuario", getGlobal("USUARIO"));
		xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));

		// adiciona restantes parametros

		xml.setField("GUIA.NR_GUIA", getItemValue("GUIA.NR_GUIA"));
		xml.setField("GUIA.VALIDARPRESTADOREXE", getItemValue("GUIA.VALIDARPRESTADOREXE"));
		xml.setField("PARAMETER.CD_MULTI_EMPRESA", getTaskParameter("CD_MULTI_EMPRESA"));
		xml.setField("PARAMETER.CD_USUARIO", getTaskParameter("CD_USUARIO"));
		xml.setField("PARAMETER.PERMITE_ALT", getTaskParameter("PERMITE_ALT"));
		xml.setItemProperty("GUIA.CD_PRESTADOR", "ENABLED", getItemEnabled("GUIA.CD_PRESTADOR"));
		xml.setItemProperty("GUIA.NR_GUIA_TEM", "ENABLED", getItemEnabled("GUIA.NR_GUIA_TEM"));
		xml.setItemProperty("GUIA.DT_EMISSAO", "ENABLED", getItemEnabled("GUIA.DT_EMISSAO"));
		xml.setItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "ENABLED", getItemEnabled("GUIA.CD_PRESTADOR_SOLICITANTE"));
		xml.setItemProperty("GUIA.CD_TIP_ACOMODACAO", "ENABLED", getItemEnabled("GUIA.CD_TIP_ACOMODACAO"));
		xml.setItemProperty("ITGUIA.CD_PROCEDIMENTO", "ENABLED", getItemEnabled("ITGUIA.CD_PROCEDIMENTO"));
		xml.setItemProperty("GUIA.NM_CONTATO", "ENABLED", getItemEnabled("GUIA.NM_CONTATO"));
		xml.setItemProperty("GUIA.DS_OBSERVACAO", "ENABLED", getItemEnabled("GUIA.DS_OBSERVACAO"));
		xml.setItemProperty("GUIA.SN_VALIDA_REST_CARENCIA", "ENABLED", getItemEnabled("GUIA.SN_VALIDA_REST_CARENCIA"));
		xml.setItemProperty("ITGUIA.QT_SOLICITADO", "ENABLED", getItemEnabled("ITGUIA.QT_SOLICITADO"));
		xml.setItemProperty("GUIA.CD_TIPO_ATENDIMENTO", "ENABLED", getItemEnabled("GUIA.CD_TIPO_ATENDIMENTO"));
		xml.setItemProperty("GUIA.DT_PREV_EXECUCAO", "ENABLED", getItemEnabled("GUIA.DT_PREV_EXECUCAO"));
		xml.setItemProperty("GUIA.CD_PRESTADOR_EXECUTOR_PF", "ENABLED", getItemEnabled("GUIA.CD_PRESTADOR_EXECUTOR_PF"));
		xml.setItemProperty("GUIA.CD_PRESTADOR_EXECUTOR", "ENABLED", getItemEnabled("GUIA.CD_PRESTADOR_EXECUTOR"));
		xml.setItemProperty("GUIA.CD_ESPECIALIDADE", "ENABLED", getItemEnabled("GUIA.CD_ESPECIALIDADE"));
		// call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);

		// executa rotina no banco
		cmd.execute();

		// extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob(outParams);

		// extrai parametros de saida

		setItemValue("GUIA.NR_GUIA", xml.getField("GUIA.NR_GUIA", NString.class));
		setItemValue("GUIA.VALIDARPRESTADOREXE", xml.getField("GUIA.VALIDARPRESTADOREXE", NString.class));
		setTaskParameter("CD_MULTI_EMPRESA", xml.getField("PARAMETER.CD_MULTI_EMPRESA"));
		setTaskParameter("CD_USUARIO", xml.getField("PARAMETER.CD_USUARIO"));
		setTaskParameter("PERMITE_ALT", xml.getField("PARAMETER.PERMITE_ALT"));
		if (xml.hasItemProperty("GUIA.CD_TIPO_ATENDIMENTO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_TIPO_ATENDIMENTO", xml.getItemProperty("GUIA.CD_TIPO_ATENDIMENTO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_TIP_ACOMODACAO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_TIP_ACOMODACAO", xml.getItemProperty("GUIA.CD_TIP_ACOMODACAO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.NM_CONTATO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.NM_CONTATO", xml.getItemProperty("GUIA.NM_CONTATO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("ITGUIA.QT_SOLICITADO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("ITGUIA.QT_SOLICITADO", xml.getItemProperty("ITGUIA.QT_SOLICITADO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_PRESTADOR_SOLICITANTE", xml.getItemProperty("GUIA.CD_PRESTADOR_SOLICITANTE", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_EXECUTOR", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_PRESTADOR_EXECUTOR", xml.getItemProperty("GUIA.CD_PRESTADOR_EXECUTOR", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_PRESTADOR", xml.getItemProperty("GUIA.CD_PRESTADOR", "UPDATE_ALLOWED", Boolean.class));

		// if(xml.hasBlockProperty("ITGUIA", "INSERT_ALLOWED"))
		// setBlockInsertAllowed("ITGUIA", xml.getBlockProperty("ITGUIA",
		// "INSERT_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.SN_VALIDA_REST_CARENCIA", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.SN_VALIDA_REST_CARENCIA", xml.getItemProperty("GUIA.SN_VALIDA_REST_CARENCIA", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.NR_GUIA_TEM", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.NR_GUIA_TEM", xml.getItemProperty("GUIA.NR_GUIA_TEM", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("ITGUIA.CD_PROCEDIMENTO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("ITGUIA.CD_PROCEDIMENTO", xml.getItemProperty("ITGUIA.CD_PROCEDIMENTO", "UPDATE_ALLOWED", Boolean.class));

		// if(xml.hasBlockProperty("ITGUIA", "UPDATE_ALLOWED"))
		// setBlockUpdateAllowed("ITGUIA", xml.getBlockProperty("ITGUIA",
		// "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.DS_OBSERVACAO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.DS_OBSERVACAO", xml.getItemProperty("GUIA.DS_OBSERVACAO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_ESPECIALIDADE", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_ESPECIALIDADE", xml.getItemProperty("GUIA.CD_ESPECIALIDADE", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.CD_PRESTADOR_EXECUTOR_PF", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.CD_PRESTADOR_EXECUTOR_PF", xml.getItemProperty("GUIA.CD_PRESTADOR_EXECUTOR_PF", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.DT_EMISSAO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.DT_EMISSAO", xml.getItemProperty("GUIA.DT_EMISSAO", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasBlockProperty("GUIA", "UPDATE_ALLOWED"))
			setBlockUpdateAllowed("GUIA", xml.getBlockProperty("GUIA", "UPDATE_ALLOWED", Boolean.class));

		if (xml.hasItemProperty("GUIA.DT_PREV_EXECUCAO", "UPDATE_ALLOWED"))
			setItemUpdateAllowed("GUIA.DT_PREV_EXECUCAO", xml.getItemProperty("GUIA.DT_PREV_EXECUCAO", "UPDATE_ALLOWED", Boolean.class));

		// trata mensagens
		xml.HandleMessages();

		// trata erros
		xml.HandleExceptions();

	}

}

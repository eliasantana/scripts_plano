package br.com.mv.soul.mvsaude.forms.Guia.services;

import morphis.foundations.core.appsupportlib.runtime.AbstractSupportCodeObject;
import morphis.foundations.core.appsupportlib.runtime.ISupportCodeContainer;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class Var extends AbstractSupportCodeObject {
	

	public Var(ISupportCodeContainer container) {
		super(container);
	}

	public GuiaTask  getTask() {
		return (GuiaTask )super.getContainer();
	}

	
	public br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel getFormModel() {
		 return getTask().getModel();
	}
	
	//Original PL/SQL code for Package Prog Unit (SPEC) VAR
	/*
	 PACKAGE var IS
  nvl_procedimento            number;
  cd_procedimento             varchar2(12);

  v_sn_paga                   varchar2(1);
  v_vl_pago                   number;
  v_nr_ano                    varchar2(4);
  v_nr_mes                    varchar2(2);
  fl_valida                   varchar2(1);
END;
	*/
			public NNumber nvlProcedimento= NNumber.getNull();
		public NString cdProcedimento= NString.getNull();
		public NString vSnPaga= NString.getNull();
		public NNumber vVlPago= NNumber.getNull();
		public NString vNrAno= NString.getNull();
		public NString vNrMes= NString.getNull();
		public NString flValida= NString.getNull();

			
	
	
}

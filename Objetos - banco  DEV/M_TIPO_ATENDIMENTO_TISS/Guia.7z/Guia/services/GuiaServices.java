package br.com.mv.soul.mvsaude.forms.Guia.services;

import static morphis.foundations.core.appsupportlib.Lib.chr;
import static morphis.foundations.core.appsupportlib.Lib.in;
import static morphis.foundations.core.appsupportlib.Lib.isNull;
import static morphis.foundations.core.appsupportlib.Lib.ltrim;
import static morphis.foundations.core.appsupportlib.Lib.rtrim;
import static morphis.foundations.core.appsupportlib.Lib.toChar;
import static morphis.foundations.core.appsupportlib.Lib.toDate;
import static morphis.foundations.core.appsupportlib.Lib.trunc;
import static morphis.foundations.core.appsupportlib.Lib.upper;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemEnabled;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemNavigable;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemRequired;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.addListElement;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.clearList;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.createParameterList;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.getCurrentItem;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.getParameterList;
import static morphis.foundations.core.types.Types.toBool;
import static morphis.foundations.core.types.Types.toNumber;
import static morphis.foundations.core.types.Types.toStr;
import static morphis.foundations.core.util.globals.Globals.setGlobal;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import br.com.mv.soul.common.dbservices.PkgMv2000;
import br.com.mv.soul.common.dbservices.StoredProcedures;
import br.com.mv.soul.common.libs.DbUtils.DataList;
import br.com.mv.soul.common.localization.ResourceManager;
import br.com.mv.soul.common.services.extensions.ViewServicesExtensions;
import br.com.mv.soul.mvsaude.dbservices.PackSgps;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.controller.GuiaController;
import br.com.mv.soul.mvsaude.forms.Guia.model.EnviarEmailAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAnexoAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaHonorarioAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaProrrogacaoAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaOculosAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.MensContratoAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.ProcedRegulacaoAdapter;
import br.com.mv.soul.mvsaude.libs.Services;
import br.com.mv.soul.mvsaude.libs.Alerta.Alerta;
import br.com.mv.soul.mvsaude.libs.WebService.Zenvia.v2.ZenviaClient;
import br.com.mv.soul.mvsaude.libs.WebService.Zenvia.v2.enums.CallbackOption;
import br.com.mv.soul.mvsaude.libs.WebService.Zenvia.v2.request.SingleMessageSms;
import br.com.mv.soul.mvsaude.libs.WebService.Zenvia.v2.response.SendSmsResponse;
import morphis.foundations.core.appdatalayer.data.DataCommand;
import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.data.IDataCommand;
import morphis.foundations.core.appdatalayer.data.NoDataFoundException;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appdatalayer.data.TableRow;
import morphis.foundations.core.appsupportlib.Globals;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import morphis.foundations.core.appsupportlib.runtime.AbstractSupportCodeObject;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.ISupportCodeContainer;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.ViewServices;
import morphis.foundations.core.appsupportlib.ui.InteractionBlockMode;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.types.Types;
import morphis.foundations.core.util.Ref;
import morphis.foundations.core.util.logging.ILogger;
import morphis.foundations.core.util.logging.LogTraceEvent;
import morphis.foundations.core.util.logging.LogTraceEvent.LEVEL;
import morphis.foundations.core.util.logging.LogTraceMessage;
import morphis.foundations.core.util.logging.LoggerFactory;
	

public class GuiaServices extends AbstractSupportCodeObject {
	
	protected static ILogger logger = LoggerFactory.getInstance(GuiaServices.class);

	@SuppressWarnings("unused")
	private Ref<NNumber> ncd_contrato_ref = new Ref<NNumber>(NNumber.getNull());
	private Ref<NString> ptp_grupo_franquia_ref = new Ref<NString>(NString.getNull());
	public HashMap<String, NString> mapaMultiEmpresaMvSaude = new HashMap<String, NString>();
	{
		mapaMultiEmpresaMvSaude = new HashMap<String, NString>();
		mapaMultiEmpresaMvSaude.put("SN_LIBERA_GUIA_SEM_PAGAMENTO", new NString("N"));
		mapaMultiEmpresaMvSaude.put("SN_OBRIGAR_CID", new NString("N"));
		mapaMultiEmpresaMvSaude.put("DS_SERVIDOR_EMAIL", NString.getEmpty());
		mapaMultiEmpresaMvSaude.put("SN_RECIPROCIDADE", new NString("N"));
		mapaMultiEmpresaMvSaude.put("SN_OPERADORA_UNIMED", new NString("N"));
		mapaMultiEmpresaMvSaude.put("CD_UNIMED", NString.getEmpty());
		mapaMultiEmpresaMvSaude.put("SN_GUIA_AUTORIZA_AUTOMATICO", new NString("N"));
		mapaMultiEmpresaMvSaude.put("ATEND_GUIA_OBG_LOCAL", new NString("N"));
		mapaMultiEmpresaMvSaude.put("SN_GUIA_AVULSA", new NString("N"));
		mapaMultiEmpresaMvSaude.put("NR_DIAS_VENCIMENTO_DA_GUIA", new NString("0"));
		mapaMultiEmpresaMvSaude.put("SN_ENVIO_AUTO_SMS_LIBERA_GUIA", new NString("N"));
		mapaMultiEmpresaMvSaude.put("SN_EXIBE_VALOR_PROCED", new NString("N"));
	}

	public GuiaServices(ISupportCodeContainer container) {
		super(container);
	}

	public GuiaTask getTask() {

		return (GuiaTask) super.getContainer();
	}

	public br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel getFormModel() {

		return getTask().getModel();
	}

	public GuiaAdapter getGuiaElement() {

		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}

	public ItguiaAdapter getItguiaElement() {

		return (ItguiaAdapter) this.getFormModel().getItguia().getRowAdapter(true);
	}

	public GuiaProrrogacaoAdapter getGuiaProrrogacaoElement() {

		return (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
	}

	public EnviarEmailAdapter getEnviarEmailElement() {

		return (EnviarEmailAdapter) this.getFormModel().getEnviarEmail().getRowAdapter(true);
	}

	public void prcPrestadorExecutor(NBool pRaise) {

		PkgMvsGuia.pPrestadorExecutor(pRaise);
	}

	public GuiaHonorarioAdapter getGuiaHonorarioElement() {

		return (GuiaHonorarioAdapter) this.getFormModel().getGuiaHonorario().getRowAdapter(true);
	}

	/**
	 * Realiza a validação dos dados do beneficiário.
	 * 
	 * @param guiaElement
	 * @param pRaise
	 */
	@SuppressWarnings("unused")
	public void prcUsuario(GuiaAdapter guiaElement, NBool pRaise) {
		int rowCount = 0;
		NNumber cdMultiEmpresa = PkgMv2000.leEmpresa();
		NString cdUsuario = NString.parse(DbManager.getUser()); 
		NDate ddtDesligamento = NDate.getNull();
		NString cfaltapagamento = NString.getNull();
		Ref<DataList> vlstParamret = new Ref<DataList>(new DataList());
		Ref<DataList> vlstParamret1 = new Ref<DataList>(new DataList());
		Ref<DataList> vlstParamret2 = new Ref<DataList>(new DataList());
		NString ctpusuario = NString.getNull();
		NNumber ncdgrupofranquia = NNumber.getNull();
		NNumber ncdplano = NNumber.getNull();
		NDate ddtnascimento = NDate.getNull();
		NString ctpsexo = NString.getNull();
		NString ctpcontrato = NString.getNull();
		NNumber ncdcontrato = NNumber.getNull();
		Ref<DataList> vlstParamret3 = new Ref<DataList>(new DataList());
		Ref<DataList> vlstParamret4 = new Ref<DataList>(new DataList());
		ncdgrupofranquia = toNumber(null);
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"), "N");

		if (!guiaElement.getCdMatricula().isNull()) {
			
			String sql =  " SELECT U.TP_USUARIO                                                                            "
					+ "     ,U.NM_SEGURADO                                                                                 "
					+ "     ,U.CD_MATRICULA_TEM                                                                            "
					+ "     ,U.CD_MAT_ALTERNATIVA                                                                          "
					+ "     ,U.CD_EMPRESA                                                                                  "
					+ "     ,U.SN_ATIVO                                                                                    "
					+ "     ,U.CD_PLANO                                                                                    "
					+ "     ,U.DT_NASCIMENTO                                                                               "
					+ "     ,U.TP_SEXO                                                                                     "
					+ "     ,U.CD_CONTRATO                                                                                 "
					+ "     ,U.CD_UNIMED                                                                                   "
					+ "     ,U.DT_CADASTRO																				   "
					+ "		,U.DT_SUSPENSAO																				   "
					+ "     ,U.dt_desligamento_programada                                                                  "
					+ "     ,DECODE(P.SN_ADAPTADO, 'S', 'ADAPTADO', DECODE(TP_PERIODO_IMPLANTACAO, 1, 'NÃO REGULAMENTADO', 2, 'REGULAMENTADO')) DS_PERIODO_IMPLANTACAO "
					+ "     ,DECODE(U.CD_EMPRESA, NULL, '',U.CD_EMPRESA || ' - ' ||E.DS_EMPRESA) DS_EMPRESA                                               "
					+ "     ,P.CD_TIP_ACOMODACAO || ' - '|| TA.DS_TIP_ACOMODACAO DS_TIP_ACOMODACAO                         "
					+ "     ,DBAPS.PACK_SGPS_2.RETORNA_IDADE( U.DT_NASCIMENTO , SYSDATE ) DS_IDADE                         "
					+ "      FROM DBAPS.USUARIO U                                                                          "
					+ "         , DBAPS.PLANO P                                                                            "
					+ "         , DBAPS.EMPRESA E                                                                          "
					+ "         , DBAPS.TIP_ACOMODACAO TA                                                                  "
					+ "      WHERE U.CD_MATRICULA = :CD_MATRICULA                                                          "
					+ "         AND U.CD_PLANO = P.CD_PLANO(+)                                                             "
					+ "         AND U.CD_EMPRESA = E.CD_EMPRESA (+)                                                        "
					+ "         AND P.CD_TIP_ACOMODACAO = TA.CD_TIP_ACOMODACAO(+)                                          "
					+ "         AND U.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA                                       ";
			
			DataCursor cCursor = new DataCursor(sql);
			cCursor.addParameter("CD_MATRICULA", guiaElement.getCdMatricula());
			cCursor.addParameter("P_EMPRESA", cdMultiEmpresa);
			cCursor.open();
			ResultSet rCursor = cCursor.fetchInto();
			if (rCursor != null) {
				ctpusuario = rCursor.getStr("TP_USUARIO");
				guiaElement.setDspNmSegurado(rCursor.getStr("NM_SEGURADO"));
				if (!rCursor.getStr("CD_MAT_ALTERNATIVA").equals(guiaElement.getCdMatAlternativa())) {
					ItemServices.setItemIsValid("GUIA.CD_MAT_ALTERNATIVA", true);
					guiaElement.setCdMatAlternativa(rCursor.getStr("CD_MAT_ALTERNATIVA"));
				}
				guiaElement.setDspCdMatriculaTem(rCursor.getNumber("CD_MATRICULA_TEM"));
				guiaElement.setDspCdEmpresa(rCursor.getNumber("CD_EMPRESA"));
				guiaElement.setDspSnAtivo(rCursor.getStr("SN_ATIVO"));
				guiaElement.setDspDtDesligamentoProgramada(rCursor.getDate("DT_DESLIGAMENTO_PROGRAMADA"));
				guiaElement.setDspDsEmpresa(rCursor.getStr("DS_EMPRESA"));
				guiaElement.setDspDsPeriodoImplantacao(rCursor.getStr("DS_PERIODO_IMPLANTACAO"));
				guiaElement.setDsTipAcomodacao(rCursor.getStr("DS_TIP_ACOMODACAO"));
				guiaElement.setDspDtInclusaoBeneficiario(rCursor.getDate("DT_CADASTRO"));
				
				ncdplano = rCursor.getNumber("CD_PLANO");
				ddtnascimento = rCursor.getDate("DT_NASCIMENTO");
				ctpsexo = rCursor.getStr("TP_SEXO");
				ncdcontrato = rCursor.getNumber("CD_CONTRATO");
				guiaElement.setDsIdade(rCursor.getStr("DS_IDADE"));
				
				if (pRaise.isTrue()) {
					
					if (!rCursor.getDate("DT_SUSPENSAO").isNull()) {
						if (!(getTask().getMv2000().msgAlertSn(Types.toStr("O usuário está suspenso desde ").append(toChar(rCursor.getDate("DT_SUSPENSAO"), "dd/mm/yyyy")).append(".").append(chr(10)).append("Deseja continuar?"), Types.toStr("W"), Types.toStr("Sim/Não"))).toBoolean()) {
							getTask().getMv2000().msgAlert(NString.toStr("")
									.append("Operação inválida!")
									.append(Lib.chr(10))
									.append("Motivo..: Usuário não está ativo.")
									.append(Lib.chr(10))
									.append("Ação....: Informe um usuário ativo.").toString(),
									"W", /*W = Atenção, I = Informação, E = Erro */
									NBool.True /*bloquear/travar?*/);
						}
					}
					
					if (snOperadoraUnimed.equals("S")) {
						if (!rCursor.getStr("CD_UNIMED").isNull()) {
							if (!getGuiaElement().getCdUnimedOrigem().equals(rCursor.getStr("CD_UNIMED"))) {
								guiaElement.setCdUnimedOrigem(rCursor.getStr("CD_UNIMED"));
								((GuiaController) this.getTask().getFormController().getBlockController("GUIA")).cd_unimed_origem_validation();
							}
						} else {
							if (getGuiaElement().getCdMatAlternativa().getLength() == 16) {
								NString nrCarteiraBeneficiario = NString.toStr(getGuiaElement().getCdMatAlternativa().substring(0, 3));
								if (!getGuiaElement().getCdUnimedOrigem().equals(nrCarteiraBeneficiario)) {
									getGuiaElement().setCdUnimedOrigem(nrCarteiraBeneficiario);
									((GuiaController) this.getTask().getFormController().getBlockController("GUIA")).cd_unimed_origem_validation();
								}
							} else if (getGuiaElement().getCdMatAlternativa().getLength() <= 15) {
								getTask().getMv2000().msgAlert(NString.toStr("").append("Operação inválida!").append(Lib.chr(10)).append("Motivo..: A código informado da carteira não tem o tamanho correto de 16 dígitos.").toString(), "W", /*
								                                                                                                                                                                                                                  * W
								                                                                                                                                                                                                                  * =
								                                                                                                                                                                                                                  * Atenção,
								                                                                                                                                                                                                                  * I
								                                                                                                                                                                                                                  * =
								                                                                                                                                                                                                                  * Informação,
								                                                                                                                                                                                                                  * E
								                                                                                                                                                                                                                  * =
								                                                                                                                                                                                                                  * Erro
								                                                                                                                                                                                                                  */
								        NBool.True /* bloquear/travar? */);
							}
						}
					}
				}
			} else {
				getTask().getMv2000().msgAlert(toStr("Beneficiário não Cadastrado!"), toStr("E"), pRaise);
			}

			if (!ncdcontrato.isNull() && !ncdplano.isNull()) {

				String sqlcFranquia = "SELECT CD_GRUPO_FRANQUIA FROM DBAPS.PLANO_CONTRATO WHERE CD_CONTRATO = :P_CD_CONTRATO AND CD_PLANO = :P_CD_PLANO";
				DataCursor dcFranquia = new DataCursor(sqlcFranquia);
				dcFranquia.addParameter("P_CD_CONTRATO", ncdcontrato);
				dcFranquia.addParameter("P_CD_PLANO", ncdplano);
				ResultSet rsFranquia = null;

				try {
					dcFranquia.open();
					rsFranquia = dcFranquia.fetchInto();

					if (rsFranquia != null && !rsFranquia.getNumber(0).isNull()) {
						ncdgrupofranquia = rsFranquia.getNumber(0);
					}
					dcFranquia.close();
				} finally {

					if (dcFranquia != null) {
						try {
							dcFranquia.close();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}

			if (ncdgrupofranquia.isNull() && !ncdplano.isNull()) {
				getTask().getMPkgMvsPlano().getMPkgMvsPlano().pRetornaDados(ncdplano, cdMultiEmpresa, cdUsuario, pRaise, pRaise, vlstParamret4);
				ncdgrupofranquia = vlstParamret4.val.getNumber("CD_GRUPO_FRANQUIA", NBool.False);
			}

			if (ctpusuario.equals("I")) {
				ddtDesligamento = toDate(null);
				ddtDesligamento = getTask().getMPkgMvsUsuario().getMPkgMvsUsuario().fRetornaDtDesligamento(guiaElement.getCdMatricula());
				if (pRaise.toBoolean() && ddtDesligamento.isNull()) {
					getTask().getMv2000().chamaMensagem(toStr("Atenção"), toStr("Este Usuário é um Titular não Usuário do Plano!"), toBool(NBool.True));
				}
			}
			
			if (!guiaElement.getDspCdMatriculaTem().isNull()) {
				guiaElement.setDspNmSegurado2(getTask().getMPkgMvsUsuario().getMPkgMvsUsuario().fRetornaDescricao(guiaElement.getDspCdMatriculaTem(), cdMultiEmpresa, cdUsuario, pRaise, pRaise));
			}

			if (guiaElement.getNrGuia().isNull()) {
				guiaElement.setDspCdGrupoFranquiaUsuario(StoredProcedures.fncRetornaGrupoFranquia(guiaElement.getCdMatricula(), ptp_grupo_franquia_ref));
				if (guiaElement.getCdGrupoFranquia().isNull() || getCurrentItem().equals("CD_MATRICULA")) {
					guiaElement.setCdGrupoFranquia(guiaElement.getDspCdGrupoFranquiaUsuario());
				}

				if (!guiaElement.getCdGrupoFranquia().isNull()) {
					guiaElement.setDspDsGrupoFranquia(getTask().getMPkgMvsGrupoFranquia().getMPkgMvsGrupoFranquia().fRetornaDescricao(ncdgrupofranquia, cdMultiEmpresa, cdUsuario, pRaise, pRaise));
					/*
					 * aciona validate do cd_grupo_franquia para validar a flag
					 * SN_AVISTA
					 * @author diego.nobre
					 * @since 12/07/2013
					 */
					NString tpChamada = (pRaise.isTrue()) ? toStr("V") : toStr("A");
					this.prcGrupoFranquia(guiaElement, toBool(NBool.True), tpChamada);
				} else {
					guiaElement.setDspDsGrupoFranquia(toStr(null));
				}
			}

			if (!guiaElement.getCdGrupoFranquia().isNull()) {
				getTask().getMPkgMvsGrupoFranquia().getMPkgMvsGrupoFranquia().pRetornaDados(guiaElement.getCdGrupoFranquia(), cdMultiEmpresa, cdUsuario, pRaise, pRaise, vlstParamret1);

				guiaElement.setDspTpGrupoFranquia(vlstParamret1.val.getStr("TP_GRUPO", NBool.True));

				if (guiaElement.getNrGuia().isNull() && guiaElement.getDspCdGrupoFranquiaUsuario().equals(guiaElement.getCdGrupoFranquia())) {
					if (!isNull(guiaElement.getDspTpGrupoFranquia(), "0").equals("1")) {
						this.getFormModel().setParam("SN_FORMA_PGTO_ORIGINAL", "N");
						guiaElement.setSnAvista(toStr("N"));
						setItemEnabled("GUIA.SN_AVISTA", true);
						if (isNull(guiaElement.getDspTpGrupoFranquia(), "0").equals("2")) {
							this.getFormModel().setParam("SN_FORMA_PGTO_ORIGINAL", "S");
							guiaElement.setSnAvista(toStr("S"));
						}
					} else {
						this.getFormModel().setParam("SN_FORMA_PGTO_ORIGINAL", "N");
						guiaElement.setSnAvista(toStr("N"));
						setItemEnabled("GUIA.SN_AVISTA", false);
					}
				} else if (!guiaElement.getNrGuia().isNull()) {
					if (isNull(guiaElement.getDspTpGrupoFranquia(), "0").equals("2")) {
						setItemEnabled("GUIA.SN_AVISTA", true);
					} else {
						setItemEnabled("GUIA.SN_AVISTA", false);
					}
				}

				guiaElement.setDspSnAvista(guiaElement.getSnAvista());
				guiaElement.setDspCdGrupoFranquia(guiaElement.getCdGrupoFranquia());
				guiaElement.setDspSnAvista(guiaElement.getSnAvista());
				guiaElement.setDspTpGrupoFranquia(guiaElement.getDspTpGrupoFranquia());
			} else {
				guiaElement.setDspCdGrupoFranquia(toNumber(null));
				guiaElement.setDspCdGrupoFranquiaUsuario(toNumber(null));
				guiaElement.setDspSnAvista(toStr(null));
				guiaElement.setDspTpGrupoFranquia(toStr(null));
			}

			if (guiaElement.getCdPlano().isNull()) {
				guiaElement.setCdPlano(ncdplano);
				guiaElement.setDspCdPlano(ncdplano);
				guiaElement.setDspDsPlano(getTask().getMPkgMvsPlano().getMPkgMvsPlano().fRetornaDescricao(ncdplano, cdMultiEmpresa, cdUsuario, pRaise, pRaise));
			}
			guiaElement.setDspDtNascimento(ddtnascimento);
			guiaElement.setDspTpSexo(ctpsexo);

			guiaElement.setDspCdContrato(ncdcontrato);
			if (!guiaElement.getDspCdContrato().isNull()) {
				getTask().getMPkgMvsContrato().getMPkgMvsContrato().pRetornaDados(guiaElement.getDspCdContrato(), cdMultiEmpresa, cdUsuario, pRaise, pRaise, vlstParamret2);
				guiaElement.setDspTpMensalidade(vlstParamret2.val.getStr("TP_MENSALIDADE", NBool.False));
				ctpcontrato = vlstParamret2.val.getStr("TP_CONTRATO", NBool.True);
				if (ctpcontrato.equals("E")) {
					guiaElement.setDspTpContrato(toStr("EMPRESA"));
				} else if (ctpcontrato.equals("I")) {
					guiaElement.setDspTpContrato(toStr("INDIVIDUAL"));
				} else if (ctpcontrato.equals("F")) {
					guiaElement.setDspTpContrato(toStr("FAMILIAR"));
				} else {
					guiaElement.setDspTpContrato(toStr("COLETIVO POR ADESÃO"));
				}
			} else {
				if (pRaise.toBoolean()) {
					getTask().getMv2000().chamaMensagem(toStr("Atenção"), toStr("Este Usuário está sem contrato!"), toBool(NBool.True));
				}
			}
			if (guiaElement.getNrGuia().isNull() && !in(upper(guiaElement.getDspTpContrato()), "EMPRESA").getValue()) {
				{
					/**
					 * PDA 509940 - Alterado o processo de verificação de
					 * Inadimplência do beneficiario
					 */
					String sqlc = "SELECT mc.nr_mes || '/' || mc.nr_ano nr_anomes " 
								+ ",mc.dt_vencimento dt_vencimento " 
								+ " FROM dbaps.mens_contrato mc " 
								+ " ,dbaps.mens_usuario mu " 
								+ " ,dbaps.contrato ct " 
								+ " ,dbaps.plano_de_saude pds " 
								+ " WHERE mc.cd_mens_contrato = mu.cd_mens_contrato " 
								+ " AND mc.nr_ano||mc.nr_mes = mu.nr_ano||mu.nr_mes " 
								+ " AND mc.cd_contrato = ct.cd_contrato " 
								+ " AND mc.tp_receita = 'M' " 
								+ " AND mu.cd_matricula = :P_CD_MATRICULA " 
								+ " AND mc.cd_contrato =  :GUIA_DSP_CD_CONTRATO " 
								+ " AND mc.dt_cancelamento IS NULL " +
					/**
					 * PDA 522410 - Comentado o trecho abaixo para retornar
					 * todas as mensalidades que estão em aberto e não somente a
					 * que está em aberto no periodo da data atual.
					 */
					        " AND mc.cd_multi_empresa = DBAMV.PKG_MV2000.LE_EMPRESA " 
					      + " AND Trunc(mc.dt_vencimento + pds.nr_dias_de_atraso_permitido) < Trunc(SYSDATE) "
							+ " AND pds.id = 1 " + " AND mc.TP_QUITACAO <> 'Q' " 
					      + " ORDER BY mc.nr_ano||mc.nr_mes DESC";
					DataCursor c = new DataCursor(sqlc);
					NNumber ndias = NNumber.getNull();
					NNumber ncount = NNumber.getNull();
					NString ccompetencias = NString.getNull();
					NBool bvencido = NBool.getNull();
					TableRow r = null;

					if (!guiaElement.getCdGrupoFranquia().isNull()) {
						if (guiaElement.getSnAvista().equals("N")) {
							String sqlcGrupoFranquia = "SELECT GRUPO_FRANQUIA.TP_GRUPO " 
													 + "FROM DBAPS.GRUPO_FRANQUIA GRUPO_FRANQUIA " 
													 + "WHERE GRUPO_FRANQUIA.CD_GRUPO_FRANQUIA = :P_CD_GRUPO_FRANQUIA";

							DataCursor cGrupoFranquia = new DataCursor(sqlcGrupoFranquia);
							cGrupoFranquia.addParameter("P_CD_GRUPO_FRANQUIA", guiaElement.getCdGrupoFranquia());
							cGrupoFranquia.open();
							ResultSet rGrupoFranquia = cGrupoFranquia.fetchInto();
							if (rGrupoFranquia != null) {
								if (!isNull(rGrupoFranquia.getNumber(0), "0").equals("1")) {
									this.getFormModel().setParam("SN_FORMA_PGTO_ORIGINAL", "N");
									guiaElement.setSnAvista(toStr("N"));
									setItemEnabled("GUIA.SN_AVISTA", true);
									if (isNull(rGrupoFranquia.getNumber(0), "0").equals("2")) {
										this.getFormModel().setParam("SN_FORMA_PGTO_ORIGINAL", "S");
										guiaElement.setSnAvista(toStr("S"));
									}
								} else {
									this.getFormModel().setParam("SN_FORMA_PGTO_ORIGINAL", "N");
									guiaElement.setSnAvista(toStr("N"));
									setItemEnabled("GUIA.SN_AVISTA", false);
								}
							}
							if (cGrupoFranquia != null && cGrupoFranquia.isOpen()) {
								cGrupoFranquia.close();
							}
						}
					}

					try {
						ncount = toNumber(0);
						ccompetencias = toStr("");
						c.addParameter("P_CD_MATRICULA", guiaElement.getCdMatricula());
						c.addParameter("GUIA_DSP_CD_CONTRATO", guiaElement.getDspCdContrato());
						c.open();
						while (true) {
							r = c.fetchRow();
							if (c.found()) {
								bvencido = toBool(NBool.False);
								ndias = toNumber(0);
								if (!PackSgps.veFeriado(r.getDate("DT_VENCIMENTO")).isNull()) {
									if (toChar(r.getDate("DT_VENCIMENTO"), "D").equals("6")) {
										if (trunc(DbManager.getDBDate()).greater(trunc(((r.getDate("DT_VENCIMENTO").add(3)))))) {
											ndias = trunc(DbManager.getDBDate().subtract((r.getDate("DT_VENCIMENTO"))));
											bvencido = toBool(NBool.True);
										} else {
											ndias = toNumber(0);
										}
									} else if (toChar(r.getDate("DT_VENCIMENTO"), "D").equals("7")) {
										if (trunc(DbManager.getDBDate()).greater(trunc(((r.getDate("DT_VENCIMENTO").add(2)))))) {
											ndias = trunc(DbManager.getDBDate().subtract((r.getDate("DT_VENCIMENTO"))));
											bvencido = toBool(NBool.True);
										} else {
											ndias = toNumber(0);
										}
									} else {
										if (trunc(DbManager.getDBDate()).greater(trunc(((r.getDate("DT_VENCIMENTO").add(1)))))) {
											ndias = trunc(DbManager.getDBDate().subtract((r.getDate("DT_VENCIMENTO"))));
											bvencido = toBool(NBool.True);
										} else {
											ndias = toNumber(0);
										}
									}
								} else if (toChar(r.getDate("DT_VENCIMENTO"), "D").equals("7")) {
									if (trunc(DbManager.getDBDate()).greater(trunc(((r.getDate("DT_VENCIMENTO").add(2)))))) {
										ndias = trunc(DbManager.getDBDate().subtract((r.getDate("DT_VENCIMENTO"))));
										bvencido = toBool(NBool.True);
									} else {
										ndias = toNumber(0);
									}
								} else if (toChar(r.getDate("DT_VENCIMENTO"), "D").equals("1")) {
									if (trunc(DbManager.getDBDate()).greater(trunc(((r.getDate("DT_VENCIMENTO").add(1)))))) {
										ndias = trunc(DbManager.getDBDate().subtract((r.getDate("DT_VENCIMENTO"))));
										bvencido = toBool(NBool.True);
									} else {
										ndias = toNumber(0);
									}
									if ((toChar(r.getDate("DT_VENCIMENTO"), "D").equals("6") && ndias.greater(3)) || (toChar(r.getDate("DT_VENCIMENTO"), "D").equals("7") && ndias.greater(2)) || (toChar(r.getDate("DT_VENCIMENTO"), "D").notEquals("6") && toChar(r.getDate("DT_VENCIMENTO"), "D").notEquals("7") && ndias.greater(1))) {
										bvencido = toBool(NBool.True);
									}
								} else {
									ndias = trunc(DbManager.getDBDate().subtract(r.getDate("DT_VENCIMENTO")));
									if ((toChar(r.getDate("DT_VENCIMENTO"), "D").notEquals("7") && toChar(r.getDate("DT_VENCIMENTO"), "D").notEquals("1") && ndias.greater(0))) {
										bvencido = toBool(NBool.True);
									} else if ((toChar(r.getDate("DT_VENCIMENTO"), "D").equals("7") && ndias.greater(2)) || (toChar(r.getDate("DT_VENCIMENTO"), "D").equals("1") && ndias.greater(1))) {
										bvencido = toBool(NBool.True);
									}
								}
								if (bvencido.toBoolean()) {
									ccompetencias = ccompetencias.append(r.getStr("NR_ANOMES")).append(" ");
									ncount = ncount.add(1);
								}
							} else {
								break;
							}
						}
						c.close();
						if (ncount.greater(0)) {
							if (getTask().getMv2000().msgAlertSn(toStr("ATENÇÃO! Existe(m) ").append(toChar(ncount)).append(" mensalidade(s) (").append(ltrim(rtrim(ccompetencias))).append(") vencida(s) do contrato ").append(toChar(guiaElement.getDspCdContrato())).append(". Deseja continuar processo de autorização ?"), toStr("I"), toStr("Não/Sim")).toBoolean()) {
								throw new ApplicationException();
							}
						}
					} finally {
						c.close();
					}
				}
			}
			cCursor.close();
		}
	}

	public void prcProcedimento(NString pcdProcedimento, NString psnProrrogacao) {
		PkgMvsGuia.pProcedimento(pcdProcedimento, psnProrrogacao);
	}

	public void prcCheckGuia() {
		PkgMvsGuia.pCheckGuia();
	}

	public void prcTipAcomodacao(NString psnProrrogacao, NBool pRaise) {
		PkgMvsGuia.pTipAcomodacao(psnProrrogacao, pRaise);
	}

	public void habilitaCampos() {
		PkgMvsGuia.pHabilitaCampos();
	}

	public void desabilitaCampos() {
		PkgMvsGuia.pDesabilitaCampos();
	}

	public void prcCheckGuiaAltera() {
		PkgMvsGuia.pCheckGuiaAltera();
	}

	public NString retornaNomeRelatorio(NNumber cdTipoAtendimento, NString cdVersaoTiss) {
		NString relatorio = NString.getNull();

		String sqlcTiss = "SELECT ITEM_TIPO_ATENDIMENTO.DS_PROGRAMA_DA_GUIA " + "            FROM DBAPS.TIPO_ATENDIMENTO, " + "                 DBAPS.ITEM_TIPO_ATENDIMENTO " + "           WHERE TIPO_ATENDIMENTO.CD_TIPO_ATENDIMENTO = ITEM_TIPO_ATENDIMENTO.CD_TIPO_ATENDIMENTO " + "             AND TIPO_ATENDIMENTO.CD_TIPO_ATENDIMENTO = :P_CD_TIPO_ATENDIMENTO " + "             AND ITEM_TIPO_ATENDIMENTO.CD_VERSAO_TISS = NVL(:P_CD_VERSAO_TISS,'2.02.03')";
		DataCursor dcTiss = new DataCursor(sqlcTiss);

		dcTiss.addParameter("P_CD_TIPO_ATENDIMENTO", cdTipoAtendimento);
		dcTiss.addParameter("P_CD_VERSAO_TISS", cdVersaoTiss);

		try {

			dcTiss.open();

			ResultSet rsTiss = dcTiss.fetchInto();

			if (rsTiss != null) {
				relatorio = rsTiss.getStr("DS_PROGRAMA_DA_GUIA");
			} else {
				getTask().getMv2000().msgAlert(NString.toStr("").append("Operação inválida!").append(Lib.chr(10)).append("Motivo..: Não foi possível encontrar a \"versão tiss / emissão da guia\" para o tipo de guia informado.").append(Lib.chr(10)).append("Ação....: Realizar configuração na tela \"Tipos de Guia\".").toString(), "W", NBool.True);
			}

		} finally {
			dcTiss.close();
		}
		return toStr("/mvsaude/").append(toStr(relatorio.replace(".REP", "")));
	}

	public void prcEmiteGuia(GuiaAdapter guiaElement) {
		// se guia não está autorizada e não foi cancelada
		if (guiaElement.getSnValidaRestCarencia().equals("N") && guiaElement.getCdMotCancelamentoGuia().isNull()) {
			getTask().getMv2000().msgAlert(toStr("Atenção: Guia não autorizada. Impressão não permitida!"), toStr("E"), toBool(NBool.True));
		}

		getTask().getModal().getPkgImprime().parametro(toStr("DESNAME"), toStr(null));

		NString rep = NString.getNull();
		boolean imprimiu = false;

		if (Services.exist("GUIA", "NR_GUIA_TEM = " + guiaElement.getNrGuia(), false)) {
			if (getTask().getMv2000().msgAlertSn(NString.toStr("Existem guias associadas! Deseja imprimi-las também?"), NString.toStr("I"), NString.toStr("Sim/Não")).toBoolean()) {

				imprimiu = true;

				rep = this.retornaNomeRelatorio(guiaElement.getCdTipoAtendimento(), guiaElement.getCdVersaoTiss());
				if (!rep.isNull()) {
					this.setDtGuiaImpressa(guiaElement.getNrGuia());
					insertLog(guiaElement.getNrGuia(), NString.toStr("EMISSÃO DE GUIA"), NNumber.getNull(), NString.getNull(), NString.getNull(), NString.getNull());
					getTask().getModal().getPkgImprime().parametro(toStr("P_NR_GUIA"), toChar(guiaElement.getNrGuia()));
					getTask().getModal().getPkgImprime().abrir(toStr("Emissão da Guia"), rep, toStr(null), toBool(NBool.True));
				}

				String sql = " SELECT NR_GUIA, " + "            CD_TIPO_ATENDIMENTO, " + "            CD_VERSAO_TISS " + "       FROM DBAPS.GUIA " + "      WHERE NR_GUIA_TEM = :P_NR_GUIA";
				DataCursor cCursor = new DataCursor(sql);

				try {

					cCursor.addParameter("P_NR_GUIA", guiaElement.getNrGuia());
					cCursor.open();

					TableRow tr = cCursor.fetchRow();

					while (cCursor.found()) {

						rep = this.retornaNomeRelatorio(tr.getNumber("CD_TIPO_ATENDIMENTO"), tr.getStr("CD_VERSAO_TISS"));
						if (!rep.isNull()) {
							this.setDtGuiaImpressa(NNumber.toNumber(tr.getStr("NR_GUIA")));
							insertLog(guiaElement.getNrGuia(), NString.toStr("EMISSÃO DE GUIA"), NNumber.getNull(), NString.getNull(), NString.getNull(), NString.getNull());
							getTask().getModal().getPkgImprime().parametro(toStr("P_NR_GUIA"), toChar(tr.getStr("NR_GUIA")));
							getTask().getModal().getPkgImprime().abrir(toStr("Emissão da Guia"), rep, toStr(null), toBool(NBool.True));
						}

						tr = cCursor.fetchRow();
					}

				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					cCursor.close();
				}
			}
		}

		if (!imprimiu) {
			rep = this.retornaNomeRelatorio(guiaElement.getCdTipoAtendimento(), guiaElement.getCdVersaoTiss());
			if (!rep.isNull()) {
				this.setDtGuiaImpressa(guiaElement.getNrGuia());
				insertLog(guiaElement.getNrGuia(), NString.toStr("EMISSÃO DE GUIA"), NNumber.getNull(), NString.getNull(), NString.getNull(), NString.getNull());
				getTask().getModal().getPkgImprime().parametro(toStr("P_NR_GUIA"), toChar(guiaElement.getNrGuia()));
				getTask().getModal().getPkgImprime().abrir(toStr("Emissão de Guia"), rep, toStr(null), toBool(NBool.False), toBool(NBool.True), toBool(NBool.False));
			}
		}
	}

	/*
	 * pChamada = A (AfterQuery) e V (Validate).
	 */
	public void prcGrupoFranquia(GuiaAdapter guiaElement, NBool pRaise, NString pChamada) {
 		NNumber cdMultiEmpresa = PkgMv2000.leEmpresa();
 		NString cdUsuario = NString.parse(DbManager.getUser());
		NString ctpgrupo = NString.getNull();
		NNumber ncdmatricula = NNumber.getNull();
		Ref<DataList> vlstParamret = new Ref<DataList>(new DataList());

		if (guiaElement.getCdGrupoFranquia().isNull()) {
			guiaElement.setDspDsGrupoFranquia(toStr(null));

			if (!pChamada.equals(toStr("A"))) {
				guiaElement.setSnAvista(toStr("N"));
			}

			setItemEnabled("GUIA.SN_AVISTA", false);
		} else {
			getTask().getMPkgMvsGrupoFranquia().getMPkgMvsGrupoFranquia().pRetornaDados(guiaElement.getCdGrupoFranquia(), cdMultiEmpresa, cdUsuario, pRaise, pRaise, vlstParamret);
			guiaElement.setDspDsGrupoFranquia(vlstParamret.val.getStr("DS_GRUPO_FRANQUIA", NBool.True));
			ctpgrupo = vlstParamret.val.getStr("TP_GRUPO", NBool.True);
			guiaElement.setTpGrupoFranquia(ctpgrupo);
			ncdmatricula = vlstParamret.val.getNumber("CD_MATRICULA", NBool.False);
			if (isNull(ncdmatricula, guiaElement.getCdMatricula()).notEquals(guiaElement.getCdMatricula())) {
				getTask().getMv2000().chamaMensagem(toStr("Atenção"), toStr("Grupo não pode ser utilizado para este beneficiário!").append(chr(10)).append("Ação.: Selecionar outro grupo."), toBool(NBool.True));
			}
			if (ctpgrupo.equals("1") && guiaElement.getCdGrupoFranquia().isNull() && pRaise.toBoolean()) {
				getTask().getMv2000().chamaMensagem(toStr("Atenção"), toStr("Selecione um grupo referente a custo operacional!").append(chr(10)).append("Ação.: Selecionar grupo."), toBool(NBool.True));
			}

			/*
			 * Se a chamada for do validate, atribuir o SN_AVISTA.
			 */
			if (pChamada.equals("V")) {
				/*
				 * O campo só deve estar desabilitado para Co-Participação(tipo
				 * 1)
				 * @author elton.soares
				 * @since 15/08/2013
				 */
				if (!isNull(ctpgrupo, "0").equals("1")) {
					this.getFormModel().setParam("SN_FORMA_PGTO_ORIGINAL", "N");
					guiaElement.setSnAvista(toStr("N"));
					setItemEnabled("GUIA.SN_AVISTA", true);
					if (isNull(ctpgrupo, "0").equals("2")) {
						this.getFormModel().setParam("SN_FORMA_PGTO_ORIGINAL", "S");
						guiaElement.setSnAvista(toStr("S"));
					}
				} else {
					this.getFormModel().setParam("SN_FORMA_PGTO_ORIGINAL", "N");
					guiaElement.setSnAvista(toStr("N"));
					setItemEnabled("GUIA.SN_AVISTA", false);
				}
			} else {
				if (!isNull(ctpgrupo, "0").equals("1")) {
					setItemEnabled("GUIA.SN_AVISTA", true);
				} else {
					setItemEnabled("GUIA.SN_AVISTA", false);
				}
			}
		}
	}

	public void prcHabilitaBotoes(GuiaProrrogacaoAdapter guiaProrrogacaoElement, GuiaAdapter guiaElement) {
		prcHabilitaBotoes(guiaProrrogacaoElement, guiaElement, toStr("N"));
	}

	public void prcHabilitaBotoes(GuiaProrrogacaoAdapter guiaProrrogacaoElement, GuiaAdapter guiaElement, NString psnProrrogacao) {
		if (psnProrrogacao.equals("N")) {
			if (guiaElement.getNrGuia().isNull()) {
				ItemServices.setItemEnabled("GUIA.BTN_ANALISAR", false);
				ItemServices.setItemEnabled("GUIA.BTN_CANCELAR", false);
				ItemServices.setItemEnabled("GUIA.BTN_TP_STATUS", false);
				ItemServices.setItemEnabled("ALTERACAO_GUIA.BTN_ALTERACAO", false);
				ItemServices.setItemEnabled("GUIA.BTN_SENHA", false);
				ItemServices.setItemEnabled("GUIA.BTN_PRORROGACAO", false);
				ItemServices.setItemEnabled("GUIA.BTN_FINANCEIRO", false);
				BlockServices.setBlockInsertAllowed("GUIA", true);
				BlockServices.setBlockUpdateAllowed("GUIA", true);
				ativarItGuia(true);
			} else {
				if (guiaElement.getSnValidaRestCarencia().equals("N") || !guiaElement.getCdMotCancelamentoGuia().isNull()) {
					ItemServices.setItemEnabled("GUIA.BTN_ANALISAR", true);
					// Habilitar botão de impressão para guias canceladas
					// (guia será impressa com a marca d'agua CANCELADA)
					ItemServices.setItemEnabled("GUIA.BTN_EMISSAO_DA_GUIA", true);
					ItemServices.setItemEnabled("GUIA.BTN_TP_STATUS", true);
					ItemServices.setItemEnabled("ALTERACAO_GUIA.BTN_ALTERACAO", false);
					ItemServices.setItemEnabled("GUIA.BTN_FINANCEIRO", true);
					if (!guiaElement.getCdMotCancelamentoGuia().isNull()) {
						ItemServices.setItemEnabled("GUIA.BTN_ANALISAR", false);
						ItemServices.setItemEnabled("GUIA.BTN_CANCELAR", false);
						ItemServices.setItemEnabled("GUIA.BTN_SENHA", false);
						ItemServices.setItemEnabled("GUIA.BTN_FINANCEIRO", false);
					} else {
						setItemEnabled("GUIA.BTN_CANCELAR", true);
						if (guiaElement.getSnAvista().equals("S") && !guiaElement.getCdMensContrato().isNull()) {
							ItemServices.setItemEnabled("GUIA.BTN_FINANCEIRO", true);
						} else {
							ItemServices.setItemEnabled("GUIA.BTN_FINANCEIRO", false);
						}
						ItemServices.setItemEnabled("GUIA.BTN_SENHA", true);
						setGlobal("BTN_SENHA", toStr("N"));
					}
					ItemServices.setItemEnabled("GUIA.BTN_PRORROGACAO", false);

					/*
					 * Cleber Kellmane - Devido a incompatibilidade da versão 16
					 * do framework publicada em 12/09/2012, foi necessário
					 * criar um campo virtual para que possamos não exibir o
					 * numero da guia quando a mesma não estiver autorizada.
					 */

					if (guiaElement.getCdMotCancelamentoGuia().isNull()) {
						BlockServices.setBlockUpdateAllowed("GUIA", true);
						ativarItGuia(true);
					} else {
						BlockServices.setBlockUpdateAllowed("GUIA", false);
						ativarItGuia(false);
					}
				} else {
					ItemServices.setItemEnabled("GUIA.BTN_ANALISAR", false);
					ItemServices.setItemEnabled("GUIA.BTN_EMISSAO_DA_GUIA", true);
					ItemServices.setItemEnabled("GUIA.BTN_CANCELAR", true);
					ItemServices.setItemEnabled("GUIA.BTN_TP_STATUS", false);
					ItemServices.setItemEnabled("GUIA.BTN_SENHA", false);
					if (guiaElement.getSnAvista().equals("S")) {
						ItemServices.setItemEnabled("GUIA.BTN_FINANCEIRO", true);
					}
					ItemServices.setItemEnabled("ALTERACAO_GUIA.BTN_ALTERACAO", true);
					if (guiaElement.getDspSnTpInternacao().equals("S")) {
						ItemServices.setItemEnabled("GUIA.BTN_PRORROGACAO", true);
					}

					/*
					 * Cleber Kellmane - Devido a incompatibilidade da versão 16
					 * do framework publicada em 12/09/2012, foi necessário
					 * criar um campo virtual para que possamos não exibir o
					 * numero da guia quando a mesma não estiver autorizada.
					 */

					BlockServices.setBlockUpdateAllowed("GUIA", false);
					BlockServices.setBlockDeleteAllowed("GUIA", false);
					ativarItGuia(false);
				}
			}
		} else {

			if (Services.exist("ITGUIA", " NR_GUIA = " + guiaProrrogacaoElement.getNrGuia() + " AND SQ_GUIA_PRORROGACAO = " + guiaProrrogacaoElement.getSqGuiaProrrogacao(), false)) {
				ItemServices.setItemEnabled("GUIA_PRORROGACAO.BTN_ANALISAR", true);
			} else {
				ItemServices.setItemEnabled("GUIA_PRORROGACAO.BTN_ANALISAR", false);
			}
		}
	}

	public void setaEspecialidadeSolicitante(GuiaAdapter guiaElement) {
		if (!guiaElement.getCdPrestador().isNull()) {

			ItemServices.setItemEnabled("GUIA.CD_ESPECIALIDADE_SOLICITANTE", true);
			ItemServices.setItemNavigable("GUIA.CD_ESPECIALIDADE_SOLICITANTE", true);
			ItemServices.setItemInsertAllowed("GUIA.CD_ESPECIALIDADE_SOLICITANTE", true);
			ItemServices.setItemUpdateAllowed("GUIA.CD_ESPECIALIDADE_SOLICITANTE", true);

			String sql = " SELECT CD_ESPECIALIDADE " + " FROM dbaps.ESPECIALIDADE_PRESTADOR ESP_PRE " + " WHERE CD_PRESTADOR =  NVL(:P_CD_PRESTADOR_SOLICITANTE, :P_CD_PRESTADOR) " + " AND EXISTS (SELECT 1 FROM DBAPS.PRESTADOR WHERE CD_PRESTADOR = ESP_PRE.CD_PRESTADOR AND CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA)";

			DataCursor dataCursor = new DataCursor(sql);
			dataCursor.addParameter("P_CD_PRESTADOR_SOLICITANTE", guiaElement.getCdPrestadorSolicitado());
			dataCursor.addParameter("P_CD_PRESTADOR", guiaElement.getCdPrestador());
			try {
				dataCursor.open();
				ResultSet resultado = dataCursor.fetchInto();
				int count = dataCursor.getRowCount();
				if (resultado != null) {
					if (count == 1) {
						ItemServices.setItemEnabled("GUIA.CD_ESPECIALIDADE_SOLICITANTE", true);
						ItemServices.setItemNavigable("GUIA.CD_ESPECIALIDADE_SOLICITANTE", true);
						ItemServices.setItemInsertAllowed("GUIA.CD_ESPECIALIDADE_SOLICITANTE", true);
						ItemServices.setItemUpdateAllowed("GUIA.CD_ESPECIALIDADE_SOLICITANTE", true);
					}
				}
			} finally {
				dataCursor.close();
			}
		}
	}
	
	public void setaConselho(GuiaAdapter guiaElement){

		if(!guiaElement.getCdPrestadorSolicitante().isNull()){

			String sqlCursor =  " SELECT CP.CD_TISS,"     +   
			        "   CP.DS_SIGLA,   "  +
					"   P.UF_CONSELHO,"     +                                   
					"   P.DS_COD_CONSELHO, "  +    
					"   CF.NM_UF " +
					" FROM dbaps.PRESTADOR P," +                                          
					" dbaps.CONSELHO_PROFISSIONAL CP, " + 
					" dbaps.CEP_UF CF" +
					" WHERE P.CD_CONSELHO_PROFISSIONAL = CP.CD_CONSELHO_PROFISSIONAL " +  
					" AND P.UF_CONSELHO = CF.CD_UF " +
					" AND  P.cd_prestador = NVL(:P_CD_PRESTADOR_SOLICITANTE, :P_CD_PRESTADOR) ";

			DataCursor dataCursor = new DataCursor(sqlCursor);

			dataCursor.addParameter("P_CD_PRESTADOR_SOLICITANTE", guiaElement.getCdPrestadorSolicitante());
			dataCursor.addParameter("P_CD_PRESTADOR", guiaElement.getCdPrestador());

			try {
				dataCursor.open();
				ResultSet dataCursorResults = dataCursor.fetchInto();
				if (dataCursorResults != null) {

					guiaElement.setCdTissConselhoProfSol(dataCursorResults.getStr("CD_TISS"));
					guiaElement.setDspDsSiglaConselhoProfissionalTiss(dataCursorResults.getStr("DS_SIGLA"));
					guiaElement.setNrRegConselhoProfSolic(dataCursorResults.getStr("DS_COD_CONSELHO"));
					guiaElement.setUfConselhoProfSolc(dataCursorResults.getStr("UF_CONSELHO"));
					guiaElement.setDspNmUf(dataCursorResults.getStr("NM_UF"));
				}

			} finally {
				dataCursor.close();
			}
		} 

	}

	public void limpaEspecialidadeSolicitant(GuiaAdapter guiaElement) {
		guiaElement.setCdEspecialidadeSolicitante(toNumber(null));
		guiaElement.setDspEspecialidadeSolicitante(toStr(null));
	}

	public void prcAutorizaItens(GuiaAdapter guiaElement,NString snOperadoraUnimed) {
		String sqlCommand = ""; 
		
		if (snOperadoraUnimed.equals("S")) {
			sqlCommand = "UPDATE DBAPS.ITGUIA SET TP_STATUS = '4', NR_SENHA = :NR_GUIA WHERE NR_GUIA = :NR_GUIA AND TP_STATUS IN ('0', '1', '2')";
		}else{
			sqlCommand ="UPDATE DBAPS.ITGUIA SET TP_STATUS = '4', NR_SENHA = :NR_GUIA WHERE NR_GUIA = :NR_GUIA AND TP_STATUS = '0'";
		}
		
		DataCommand command = new DataCommand(sqlCommand);
		command.addParameter("NR_GUIA", guiaElement.getNrGuia());
		command.execute();
	}

	@SuppressWarnings("unused")
	public void prcLbRegimeInternacao() {
		int rowCount = 0;
		String sqlcdp = " SELECT CD_TISS || '-' || INITCAP(DS_REGIME_INTERNACAO) DS_REGIME_INTERNACAO, CD_REGIME_INTERNACAO " + " FROM DBAPS.REGIME_INTERNACAO " + " ORDER BY CD_TISS DESC";
		DataCursor cdp = new DataCursor(sqlcdp);
		NNumber ni = NNumber.getNull();
		NString idItem = (toStr("GUIA.CD_REGIME_INTERNACAO"));
		clearList(idItem);
		ni = toNumber(1);
		try {
			cdp.open();
			while (true) {
				TableRow rdp = cdp.fetchRow();
				if (cdp.notFound())
					break;
				ni.add(1);
				addListElement(idItem, ni.toInt32(), rdp.getStr("DS_REGIME_INTERNACAO"), toStr(rdp.getNumber("CD_REGIME_INTERNACAO")));
			}
		} finally {
			cdp.close();
		}
	}

	@SuppressWarnings("unused")
	public void prcLbTipoDoenca() {
		int rowCount = 0;
		String sqlctipodoenca = " SELECT CD_TIPO_DOENCA, CD_TISS || '-' || INITCAP(DS_TIPO_DOENCA) DS_TIPO_DOENCA " + " FROM DBAPS.TIPO_DOENCA " + " ORDER BY CD_TISS DESC";
		DataCursor ctipodoenca = new DataCursor(sqlctipodoenca);
		NNumber ni = NNumber.getNull();
		NString idItem = (toStr("GUIA.CD_TIPO_DOENCA"));
		clearList(idItem);
		ni = toNumber(1);
		try {
			ctipodoenca.open();
			while (true) {
				TableRow rtipodoenca = ctipodoenca.fetchRow();
				if (ctipodoenca.notFound())
					break;
				ni.add(1);
				addListElement(idItem, ni.toInt32(), rtipodoenca.getStr("DS_TIPO_DOENCA"), toStr(rtipodoenca.getNumber("CD_TIPO_DOENCA")));
			}
		} finally {
			ctipodoenca.close();
		}
	}

	@SuppressWarnings("unused")
	public void prcLbUnidadeTempoDoenca() {
		int rowCount = 0;
		String sqlcunidadetempodoenca = "SELECT CD_UNIDADE_TEMPO_DOENCA, CD_TISS || '-' || INITCAP(DS_UNIDADE_TEMPO_DOENCA) DS_UNIDADE_TEMPO_DOENCA " + " FROM DBAPS.UNIDADE_TEMPO_DOENCA " + " ORDER BY CD_TISS DESC";
		DataCursor cunidadetempodoenca = new DataCursor(sqlcunidadetempodoenca);
		NNumber ni = NNumber.getNull();
		NString idItem = (toStr("GUIA.CD_UNIDADE_TEMPO_DOENCA"));
		clearList(idItem);
		ni = toNumber(1);
		try {
			cunidadetempodoenca.open();
			while (true) {
				TableRow runidadetempodoenca = cunidadetempodoenca.fetchRow();
				if (cunidadetempodoenca.notFound())
					break;
				ni.add(1);
				addListElement(idItem, ni.toInt32(), runidadetempodoenca.getStr("DS_UNIDADE_TEMPO_DOENCA"), toStr(runidadetempodoenca.getNumber("CD_UNIDADE_TEMPO_DOENCA")));
			}
		} finally {
			cunidadetempodoenca.close();
		}
	}

	@SuppressWarnings("unused")
	public void prcLbIndicadorAcidente() {
		int rowCount = 0;
		String sqlcindicadoracidente = "SELECT CD_INDICADOR_ACIDENTE, CD_TISS || '-' || INITCAP(DS_INDICADOR_ACIDENTE) DS_INDICADOR_ACIDENTE " + " FROM DBAPS.INDICADOR_ACIDENTE " + " ORDER BY CD_TISS DESC";
		DataCursor cindicadoracidente = new DataCursor(sqlcindicadoracidente);
		NNumber ni = NNumber.getNull();
		NString idItem = (toStr("GUIA.CD_INDICADOR_ACIDENTE"));
		clearList(idItem);
		ni = toNumber(1);
		try {
			cindicadoracidente.open();
			while (true) {
				TableRow rindicadoracidente = cindicadoracidente.fetchRow();
				if (cindicadoracidente.notFound())
					break;
				ni.add(1);
				addListElement(idItem, ni.toInt32(), rindicadoracidente.getStr("DS_INDICADOR_ACIDENTE"), toStr(rindicadoracidente.getNumber("CD_INDICADOR_ACIDENTE")));
			}
		} finally {
			cindicadoracidente.close();
		}
	}

	@SuppressWarnings("unused")
	public void prcLbTipoAtendimentoTiss() {
		int rowCount = 0;
		String sqlctipoatendimentotiss = "SELECT CD_TIPO_ATENDIMENTO, CD_TISS || '-' || INITCAP(DS_TIPO_ATENDIMENTO) DS_TIPO_ATENDIMENTO " + " FROM DBAPS.TIPO_ATENDIMENTO_TISS  WHERE DT_INICIO_VIGENCIA <= To_Date(To_Char(SYSDATE,'dd.mm.yyyy'),'dd.mm.yyyy') AND DT_FIM_VIGENCIA >= To_Date(To_Char(SYSDATE,'dd.mm.yyyy'),'dd.mm.yyyy')" + " ORDER BY CD_TISS DESC";
		DataCursor ctipoatendimentotiss = new DataCursor(sqlctipoatendimentotiss);
		NNumber ni = NNumber.getNull();
		NString idItem = (toStr("GUIA.CD_TIPO_ATENDIMENTO_TISS"));
		clearList(idItem);
		ni = toNumber(1);
		try {
			ctipoatendimentotiss.open();
			while (true) {
				TableRow rtipoatendimentotiss = ctipoatendimentotiss.fetchRow();
				if (ctipoatendimentotiss.notFound()) break;
				ni.add(1);
				addListElement(idItem, ni.toInt32(), rtipoatendimentotiss.getStr("DS_TIPO_ATENDIMENTO"), toStr(rtipoatendimentotiss.getNumber("CD_TIPO_ATENDIMENTO")));
			}
		} finally {
			ctipoatendimentotiss.close();
		}
	}

	@SuppressWarnings("unused")
	public void prcLbTipoSaidaGuiaSadt() {
		int rowCount = 0;
		String sqlctiposaidaguiasadt = "SELECT CD_TIPO_SAIDA_GUIA_SADT, CD_TISS || '-' || INITCAP(DS_TIPO_SAIDA_GUIA_SADT) DS_TIPO_SAIDA_GUIA_SADT " + " FROM DBAPS.TIPO_SAIDA_GUIA_SADT " + " ORDER BY CD_TISS DESC";
		DataCursor ctiposaidaguiasadt = new DataCursor(sqlctiposaidaguiasadt);
		NNumber ni = NNumber.getNull();
		NString idItem = (toStr("GUIA.CD_TIPO_SAIDA_GUIA_SADT"));
		clearList(idItem);
		ni = toNumber(1);
		try {
			ctiposaidaguiasadt.open();
			while (true) {
				TableRow rtiposaidaguiasadt = ctiposaidaguiasadt.fetchRow();
				if (ctiposaidaguiasadt.notFound())
					break;
				ni.add(1);
				addListElement(idItem, ni.toInt32(), rtiposaidaguiasadt.getStr("DS_TIPO_SAIDA_GUIA_SADT"), toStr(rtiposaidaguiasadt.getNumber("CD_TIPO_SAIDA_GUIA_SADT")));
			}
		} finally {
			ctiposaidaguiasadt.close();
		}
	}

	@SuppressWarnings("unused")
	public void prcLbTipoConsulta() {
		int rowCount = 0;
		String sqlcdp = "SELECT CD_TISS || '-' || INITCAP(DS_TIPO_CONSULTA) DS_TIPO_CONSULTA, CD_TIPO_CONSULTA " + " FROM DBAPS.TIPO_CONSULTA " + " ORDER BY CD_TISS DESC";
		DataCursor cdp = new DataCursor(sqlcdp);
		NNumber ni = NNumber.getNull();
		NString idItem = (toStr("GUIA.CD_TIPO_CONSULTA"));
		clearList(idItem);
		ni = toNumber(1);
		try {
			cdp.open();
			while (true) {
				TableRow rdp = cdp.fetchRow();
				if (cdp.notFound())
					break;
				ni.add(1);
				addListElement(idItem, ni.toInt32(), rdp.getStr("DS_TIPO_CONSULTA"), toStr(rdp.getNumber("CD_TIPO_CONSULTA")));
			}
		} finally {
			cdp.close();
		}
	}

	public void prcTipoAtendimento(NBool pRaise) {
		PkgMvsGuia.pTipoAtendimento(pRaise);
	}

	/**
	 * Valida e retorna dados do autorizador informado
	 * 
	 * @OP 5859
	 * @author Diego.Nobre
	 * @since 25/04/2013
	 * @param guiaElement
	 * @param pRaise
	 * @return void
	 */
	public void prcAutorizador(GuiaAdapter guiaElement, NBool pRaise) {
		if (guiaElement.getCdAutorizador().isNull()) {
			guiaElement.setDspNmAutorizador(NString.getNull());
			guiaElement.setDspNrNivel(NNumber.getNull());
			guiaElement.setDspDsSenha(NString.getNull());
		} else {
			NString tpAutorizador = NString.getNull();

			DataCursor cursor = null;
			TableRow result = null;
			String sql = "";

			sql = " SELECT autoriz.cd_autorizador cd_autorizador " + "       ,autoriz.nm_autorizador dsp_nm_autorizador " + "       ,autoriz.nr_nivel dsp_nr_nivel " + "       ,autoriz.ds_senha dsp_ds_senha " + "       ,autoriz.tp_autorizador " + "       ,autoriz.sn_modifica_franquia " + "   FROM dbaps.autorizador autoriz " + "       ,dbaps.me_autorizador me_aut " + "  WHERE autoriz.cd_autorizador = me_aut.cd_autorizador " + "    AND me_aut.cd_multi_empresa = DBAMV.PKG_MV2000.LE_EMPRESA " + "    AND autoriz.cd_autorizador = :P_CD_AUTORIZADOR ";
			try {
				cursor = new DataCursor(sql);
				cursor.addParameter("P_CD_AUTORIZADOR", guiaElement.getCdAutorizador());
				cursor.open();
				if (cursor.getRowCount() > 0) {
					while (true) {
						result = cursor.fetchRow();
						if (cursor.notFound()) {
							break;
						}
						guiaElement.setDspNmAutorizador(result.getStr("dsp_nm_autorizador"));
						guiaElement.setDspNrNivel(result.getNumber("dsp_nr_nivel"));
						guiaElement.setDspDsSenha(result.getStr("dsp_ds_senha"));
						guiaElement.setDspSnModificaFranquia(result.getStr("sn_modifica_franquia"));
						tpAutorizador = toStr(result.getStr("tp_autorizador"));
					}
				} else {
					guiaElement.setDspNmAutorizador(NString.getNull());
					guiaElement.setDspNrNivel(NNumber.getNull());
					guiaElement.setDspDsSenha(NString.getNull());
					if (pRaise.toBoolean()) {
						getTask().getMv2000().msgAlert("Não foi possível identificar autorizador com este código!", "W", NBool.True);
					}
				}
			} finally {
				if (cursor != null) {
					try {
						cursor.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
					cursor = null;
				}
			}

			/*
			 * Apenas no validate deve verificar o o tipo de autorizador é
			 * FUNCIONÁRIO Pelo portal pode ser cadastrada guia com autorizador
			 * do tipo PRESTADOR Pelo MVS só pode ser cadastrada guia com
			 * autorizador do tipo FUNCIONÁRIO
			 * @author diego.nobre
			 * @since 25/04/2013
			 * @comment Orientação de Andresson Rocha Mota
			 */
			if (tpAutorizador.equals(toStr("P")) && pRaise.toBoolean()) {
				throw new ApplicationException("Autorizador inválido. Informe um autorizador do tipo FUNCIONÁRIO.");
			}
		}
	}

	public void prcPrestador(GuiaAdapter guiaElement, NBool pRaise) {
		guiaElement.setDspTpPrestador(toStr(null));
		if (guiaElement.getCdPrestador().isNull() && guiaElement.getDspSnPrestador().equals("N")) {
			return;
		} else {
			if (!guiaElement.getCdPrestador().isNull()) {
				String sqlcPrestador = "SELECT NM_PRESTADOR, TP_PRESTADOR, CD_INTERNO " + "FROM DBAPS.PRESTADOR " + "WHERE CD_PRESTADOR = :P_CD_PRESTADOR " + "AND CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA";

				DataCursor dcPrestador = new DataCursor(sqlcPrestador);
				dcPrestador.addParameter("P_CD_PRESTADOR", guiaElement.getCdPrestador());

				try {
					dcPrestador.open();
					ResultSet rsPrestador = dcPrestador.fetchInto();

					if (rsPrestador != null) {
						if (pRaise.isTrue()) {
							guiaElement.setNmPrestador(rsPrestador.getStr("nm_prestador"));
							guiaElement.setDspCdPrestadorInterno(rsPrestador.getStr("cd_interno"));
						}
						guiaElement.setDspTpPrestador(rsPrestador.getStr("tp_prestador"));
					} else {
						String msg = ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("GUIA.CD_PRESTADOR"));
						getTask().getMv2000().msgAlert(msg, "E", NBool.True);
					}
				} finally {
					dcPrestador.close();
				}
			}
			if (isNull(guiaElement.getDspTpPrestador(), toStr("P")).equals("F")) {
				setItemRequired("GUIA.CD_PRESTADOR_SOLICITANTE", false);
			}
		}
	}

	public NString fncPrestadorAssociado(NNumber pcdPrestador, NNumber pcdPrestadorAssociado, NBool pmostramensagem) {
		return PkgMvsGuia.fPrestadorAssociado(pcdPrestador, pcdPrestadorAssociado, pmostramensagem);
	}

	/**
	 * Se o tipo de Contratado Executante (CD_PRESTADOR_EXECUTOR) for pessoa
	 * física desabilita o campo Profissional Executante
	 * (CD_PRESTADOR_EXECUTOR_PF)
	 * 
	 * @author diego.nobre
	 * @since 2012-02-14
	 * @param cdPrestadorExecutor
	 */
	public void verificaTipoPessoaPrestadorExecutor(NNumber cdPrestadorExecutor) {
		String sql = " SELECT TP_PRESTADOR FROM DBAPS.PRESTADOR WHERE CD_PRESTADOR = :P_CD_PRESTADOR ";
		DataCommand command = null;
		ResultSet result = null;
		try {
			command = new DataCommand(sql);
			command.addParameter("P_CD_PRESTADOR", cdPrestadorExecutor);
			result = command.executeQuery();
			if (result.hasData()) {
				if (result.getString("tp_prestador").equals("F")) {
					setItemEnabled("CD_PRESTADOR_EXECUTOR_PF", false);
					setItemNavigable("CD_PRESTADOR_EXECUTOR_PF", false);
				} else {
					setItemEnabled("CD_PRESTADOR_EXECUTOR_PF", true);
					setItemNavigable("CD_PRESTADOR_EXECUTOR_PF", true);
				}
			}
			result.close();

		} catch (NoDataFoundException e) {
			e.printStackTrace();
		} finally {
			if (result != null) {
				try {
					result.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
				result = null;
			}
		}
	}

	/**
	 * Retorna se permite alterar o valor do procedimento
	 * 
	 * @param pCdProcedimento
	 * @return boolean
	 */
	public boolean permiteAlterarValor(NString pCdProcedimento, NNumber tpTabela) {
		boolean retorno = false;
		
		StringBuilder sqlConsulta = new StringBuilder();
		sqlConsulta.append("SELECT CD_GRUPO_PROCEDIMENTO, SN_PROCED_UNIVERSAL ");
		sqlConsulta.append("FROM DBAPS.PROCEDIMENTO ");
		sqlConsulta.append("WHERE CD_PROCEDIMENTO = :PCD_PROCEDIMENTO");

		DataCursor cCursor = new DataCursor(sqlConsulta.toString());
		try {
			cCursor.addParameter("PCD_PROCEDIMENTO", pCdProcedimento);
			cCursor.open();
			if (cCursor.found()) {
				ResultSet rs = cCursor.fetchInto();
				retorno = validarAlterarValorProcedimento(tpTabela, pCdProcedimento, rs.getStr("CD_GRUPO_PROCEDIMENTO"),
						rs.getStr("SN_PROCED_UNIVERSAL"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cCursor.close();
		}
		return retorno;
	}

	/**
	 * 
	 * @param itGuiaElement
	 */
	public void permiteAcessoCampo(ItguiaAdapter itGuiaElement, NNumber tpTabela) {
		if (permiteAlterarValor(getItguiaElement().getCdProcedimento(), tpTabela) && getGuiaElement().getDtBaixado().isNull()) {
			ItemServices.setItemUpdateAllowed("ITGUIA.VL_PROCEDIMENTO", true);
			ItemServices.setItemInsertAllowed("ITGUIA.VL_PROCEDIMENTO", true);
		} else {
			ItemServices.setItemUpdateAllowed("ITGUIA.VL_PROCEDIMENTO", false);
			ItemServices.setItemInsertAllowed("ITGUIA.VL_PROCEDIMENTO", false);
		}
	}

	public void ativarItGuia(boolean ativar) {
		NString snCortesia = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"), "N");

		if (ativar || (snCortesia.equals("S") && snOperadoraUnimed.equals("S") && !getGuiaElement().getCdPtuMensagemOrigem().isNull())) {
			ItemServices.setItemUpdateAllowed("ITGUIA.CD_PROCEDIMENTO", true);
			ItemServices.setItemInsertAllowed("ITGUIA.CD_PROCEDIMENTO", true);
			ItemServices.setItemUpdateAllowed("ITGUIA.QT_SOLIC_PREST", true);
			ItemServices.setItemInsertAllowed("ITGUIA.QT_SOLIC_PREST", true);
			ItemServices.setItemUpdateAllowed("ITGUIA.QT_SOLICITADO", true);
			ItemServices.setItemInsertAllowed("ITGUIA.QT_SOLICITADO", true);
			ItemServices.setItemUpdateAllowed("ITGUIA.NR_SENHA", true);
			ItemServices.setItemInsertAllowed("ITGUIA.NR_SENHA", true);
			ItemServices.setItemUpdateAllowed("ITGUIA.TP_STATUS", true);
			ItemServices.setItemInsertAllowed("ITGUIA.TP_STATUS", true);
			ItemServices.setItemUpdateAllowed("ITGUIA.QT_FRANQUIA", true);
			ItemServices.setItemInsertAllowed("ITGUIA.QT_FRANQUIA", true);
		} else {
			ItemServices.setItemUpdateAllowed("ITGUIA.CD_PROCEDIMENTO", false);
			ItemServices.setItemInsertAllowed("ITGUIA.CD_PROCEDIMENTO", false);
			ItemServices.setItemUpdateAllowed("ITGUIA.QT_SOLIC_PREST", false);
			ItemServices.setItemInsertAllowed("ITGUIA.QT_SOLIC_PREST", false);
			ItemServices.setItemUpdateAllowed("ITGUIA.QT_SOLICITADO", false);
			ItemServices.setItemInsertAllowed("ITGUIA.QT_SOLICITADO", false);
			ItemServices.setItemUpdateAllowed("ITGUIA.NR_SENHA", false);
			ItemServices.setItemInsertAllowed("ITGUIA.NR_SENHA", false);
			ItemServices.setItemUpdateAllowed("ITGUIA.TP_STATUS", false);
			ItemServices.setItemInsertAllowed("ITGUIA.TP_STATUS", false);
			ItemServices.setItemUpdateAllowed("ITGUIA.QT_FRANQUIA", false);
			ItemServices.setItemInsertAllowed("ITGUIA.QT_FRANQUIA", false);
		}
	}

	/**
	 * 
	 * @author Dellanio Alencar <francisco.alencar@mv.com.br>
	 * @since 04/12/2012
	 * @return void
	 */
	@SuppressWarnings("unused")
	public void enviarGuiaEmail() {
		String url = "http://simulacao.mv.proasa.org.br/mvautorizadorguias/ServletEmailGuia";
		String charset = "UTF-8";

		String nrGuia = "33019";
		String tpAtendimento = "1";
		String emailPrestador = "diego.nobre@mv.com.br";
		String empresa = "2";

		String query;
		URLConnection connection;
		try {
			query = String.format("nrGuia=%s&tpAtendimento=%s&emailPrestador=%s&empresa=%s", URLEncoder.encode(nrGuia, charset), URLEncoder.encode(tpAtendimento, charset), URLEncoder.encode(emailPrestador, charset), URLEncoder.encode(empresa, charset));

			connection = new URL(url + "?" + query).openConnection();
			connection.setRequestProperty("Accept-Charset", charset);
			InputStream response = connection.getInputStream();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void setDspEmailPrestador(GuiaAdapter guiaElement, EnviarEmailAdapter enviarEmail) {
		DataCursor cursor = null;
		TableRow result = null;
		String sql = " SELECT ds_email " + " FROM dbaps.prestador " + " WHERE cd_prestador = :P_CD_PRESTADOR " + "   AND ds_email IS NOT NULL ";
		try {
			cursor = new DataCursor(sql);
			cursor.addParameter("P_CD_PRESTADOR", Lib.isNull(guiaElement.getCdPrestadorExecutor(), guiaElement.getCdPrestador()));
			cursor.open();
			if (cursor.getRowCount() > 0) { // se o cursor trouxer mais do que
			                                // zero resultados, fetchInto();
				while (true) { // enquanto houver dados faz alguma coisa
					result = cursor.fetchRow();
					if (cursor.notFound()) {
						break;
					}
					enviarEmail.setDspEmailPrestador(toStr(result.getStr("ds_email")));
				}
			}
		} catch (Exception e) { // trata erro no sistema
			getTask().getMv2000().msgAlert("Atenção! Houve um erro ao tentar atualizar dados dos dependentes do titular informado. Por favor entre em contato com o suporte informando o erro: " + e.getMessage(), "E", NBool.True);
		} finally {
			if (cursor != null) {
				try {
					cursor.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
				cursor = null;
			}
		}
	}

	/**
	 * Rotina que verifica se o botão de negativa de guia deve ser habilitado ou
	 * não
	 *
	 * @author Dellanio Alencar <francisco.alencar@mv.com.br>
	 * @since 16/04/2013
	 * @return void
	 */
	public void desabilitarBotaoGuiaNegativa(GuiaAdapter guiaElement) {
		ItemServices.setItemEnabled("GUIA.BTN_NEGATIVA_GUIA", false);
		
		if (!guiaElement.getCdMotCancelamentoGuia().isNull() 
				|| ( guiaElement.getSnValidaRestCarencia().equals("S") && !guiaElement.getNrGuia().isNull()
							&& Services.exist("ITGUIA", "TP_STATUS IN (3,5) AND NR_GUIA = " .concat(guiaElement.getNrGuia().toString()), false) 
							) ) {
			ItemServices.setItemEnabled("GUIA.BTN_NEGATIVA_GUIA", true);
		}
	}

	/**
	 * Refactoring do código para gerar ponto único de verificação para
	 * habilitação do botão
	 * 
	 * @author Dellanio Alencar <francisco.alencar@mv.com.br>
	 * @since 16/04/2013
	 * @return void
	 */
	public void verificaBotaoEmailGuia() {
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (guiaElement.getSnValidaRestCarencia().equals("S") && guiaElement.getCdMotCancelamentoGuia().isNull()) {
			setItemEnabled("GUIA.BTN_ENVIAR_GUIA_EMAIL", true);
		} else {
			setItemEnabled("GUIA.BTN_ENVIAR_GUIA_EMAIL", false);
		}
	}

	/**
	 * Verifica se deve habilitar o botão para envio de sms
	 * 
	 * @author anderson.santos
	 * @since 12/12/2016
	 * 
	 */
	public void verificaBotaoSms() {
		if (getGuiaElement().getSnValidaRestCarencia().equals("S") && getGuiaElement().getCdMotCancelamentoGuia().isNull()) {
			setItemEnabled("CG$CTRL.BTN_ENVIO_SMS", true);
		} else {
			setItemEnabled("CG$CTRL.BTN_ENVIO_SMS", false);
		}
	}

	/**
	 * Verifica se deve habilitar o campo observação do cancelamento na aba
	 * Outros
	 * 
	 * @author anderson.santos
	 * @since 12/12/2016
	 * 
	 */
	public void verificaDsCancelamentoGuia() {
		ItemServices.setItemEnabled("GUIA.DS_OBSERVACAO_CANCELAMENTO", getGuiaElement().getCdMotCancelamentoGuia().isNull());
	}

	/**
	 * Preenche descrição da especialidade informada
	 * 
	 * @OP 5857
	 * @author diego.nobre
	 * @param element GuiaAdapter
	 * @param chamador Informa se a chamada ao método partiu do AfterQuery (A)
	 * ou Validate (V)
	 */
	public void getLovDsEspecialidade(GuiaAdapter element, String chamador) {
		if (element.getCdEspecialidade().isNull()) {
			element.setDspDsEspecialidade(NString.getNull());
		} else {
			String sql = " SELECT ds_especialidade " + "        FROM dbaps.especialidade " + "       WHERE cd_especialidade = :P_CD_CODIGO  ";

			DataCommand commandLov = null;
			try {
				commandLov = new DataCommand(sql);
				commandLov.addParameter("P_CD_CODIGO", element.getCdEspecialidade());
				ResultSet rsLov = commandLov.executeQuery();
				if (rsLov.hasData()) {
					element.setDspDsEspecialidade(rsLov.getStr("ds_especialidade"));
				}
				rsLov.close();
			} catch (NoDataFoundException ndf) {
				if (chamador.equals("V"))
					getTask().getMv2000().msgAlert("Atenção! Não existe especialidade cadastrada com este código ou a mesma não está ativa.", "W", NBool.True);
			} catch (Exception e) {
				if (chamador.equals("V"))
					getTask().getMv2000().msgAlert("Atenção! Houve um erro ao tentar preencher a descrição da especialidade. Por favor entre em contato com o suporte informando o erro: " + e.getMessage(), "E", NBool.True);
			}
		}
	}

	/**
	 * Não permitir selecionar procedimento inativo ou inexistente
	 */
	@SuppressWarnings("unused")
	public void prcValidaProcedimentoInativo(NString pcdProcedimento) {
		String sqlc = "select dt_inativacao " + " from dbaps.procedimento " + " WHERE CD_PROCEDIMENTO = :P_CD_PROCEDIMENTO";
		DataCursor c2 = new DataCursor(sqlc);
		
		NDate dtInativacao = NDate.getNull();
		try {
			// Setting query parameters
			c2.addParameter("P_CD_PROCEDIMENTO", pcdProcedimento);
			c2.open();
			ResultSet cResults = c2.fetchInto();
			if (cResults != null) {
				dtInativacao = cResults.getDate(0);
			} else {
				getTask().getMv2000().msgAlert(toStr("Erro: Procedimento informado não existe."), toStr("E"), NBool.True);
			}
			c2.close();
		} finally {
			c2.close();
		}
	}

	/*
	 * Se tiver con_rec não permitir alterar nada na tela
	 */
	public void verificarConRec() {
		MensContratoAdapter mensContratoElement = (MensContratoAdapter) this.getFormModel().getMensContrato().getRowAdapter(true);

		NString snCortesia = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");

		if ((mensContratoElement != null && !mensContratoElement.getCdConRec().isNull()) || (getGuiaElement() != null && getGuiaElement().getSnValidaRestCarencia().equals("S"))) {
			BlockServices.setBlockUpdateAllowed("GUIA", false);
			BlockServices.setBlockDeleteAllowed("GUIA", false);
			setItemEnabled("GUIA.BTN_CD_MATRICULA", false);

			BlockServices.setBlockInsertAllowed("ITGUIA", false);
			BlockServices.setBlockUpdateAllowed("ITGUIA", false);
			BlockServices.setBlockDeleteAllowed("ITGUIA", false);

			BlockServices.setBlockDeleteAllowed("ITGUIA_PRO", false);

			BlockServices.setBlockInsertAllowed("IMP_GUIA", false);
			BlockServices.setBlockUpdateAllowed("IMP_GUIA", false);
			BlockServices.setBlockDeleteAllowed("IMP_GUIA", false);

			BlockServices.setBlockDeleteAllowed("GUIA_PRORROGACAO", false);

			BlockServices.setBlockInsertAllowed("ITGUIA_ERROS_PRO", false);
			BlockServices.setBlockUpdateAllowed("ITGUIA_ERROS_PRO", false);
			BlockServices.setBlockDeleteAllowed("ITGUIA_ERROS_PRO", false);

			if (!mensContratoElement.getCdConRec().isNull()) {
				BlockServices.setBlockInsertAllowed("ALTERACAO_GUIA", false);
				BlockServices.setBlockUpdateAllowed("ALTERACAO_GUIA", false);
				BlockServices.setBlockDeleteAllowed("ALTERACAO_GUIA", false);
			} else {
				BlockServices.setBlockInsertAllowed("ALTERACAO_GUIA", true);
				BlockServices.setBlockUpdateAllowed("ALTERACAO_GUIA", true);
				BlockServices.setBlockDeleteAllowed("ALTERACAO_GUIA", true);
			}
		} else {
			if (!isNull(getGuiaElement().getTpGrupoFranquia(), "0").equals("1") && getGuiaElement() != null && getGuiaElement().getSnValidaRestCarencia().equals("N") && isNull(snCortesia, "N").equals("S") && !getGuiaElement().getCdMatricula().isNull() && !getGuiaElement().getCdGrupoFranquia().isNull()) {
				setItemEnabled("GUIA.SN_AVISTA", true);
			} else {
				if (!isNull(getGuiaElement().getTpGrupoFranquia(), "0").equals("1") && isNull(snCortesia, "N").equals("N") && getGuiaElement() != null && getGuiaElement().getSnValidaRestCarencia().equals("N") && !getGuiaElement().getCdMatricula().isNull() && !getGuiaElement().getCdGrupoFranquia().isNull()) {
					setItemEnabled("GUIA.SN_AVISTA", true);
				} else {
					setItemEnabled("GUIA.SN_AVISTA", false);
				}
			}

			BlockServices.setBlockInsertAllowed("GUIA", true);
			BlockServices.setBlockUpdateAllowed("GUIA", true);
			if (snCortesia.equals("S")) {
				setItemEnabled("GUIA.BTN_CD_MATRICULA", false);
				setItemEnabled("GUIA.BTN_LEITOR_MAGNETO", false);
			} else {
				setItemEnabled("GUIA.BTN_CD_MATRICULA", true);
				setItemEnabled("GUIA.BTN_LEITOR_MAGNETO", true);
			}

			BlockServices.setBlockDeleteAllowed("GUIA", true);

			BlockServices.setBlockInsertAllowed("ITGUIA", true);
			BlockServices.setBlockUpdateAllowed("ITGUIA", true);
			BlockServices.setBlockDeleteAllowed("ITGUIA", true);

			BlockServices.setBlockInsertAllowed("ITGUIA_PRO", true);
			BlockServices.setBlockUpdateAllowed("ITGUIA_PRO", true);
			BlockServices.setBlockDeleteAllowed("ITGUIA_PRO", true);

			BlockServices.setBlockInsertAllowed("IMP_GUIA", true);
			BlockServices.setBlockUpdateAllowed("IMP_GUIA", true);
			BlockServices.setBlockDeleteAllowed("IMP_GUIA", true);

			BlockServices.setBlockInsertAllowed("GUIA_PRORROGACAO", true);
			BlockServices.setBlockUpdateAllowed("GUIA_PRORROGACAO", true);
			BlockServices.setBlockDeleteAllowed("GUIA_PRORROGACAO", true);

			BlockServices.setBlockInsertAllowed("ITGUIA_ERROS_PRO", true);
			BlockServices.setBlockUpdateAllowed("ITGUIA_ERROS_PRO", true);
			BlockServices.setBlockDeleteAllowed("ITGUIA_ERROS_PRO", true);

			BlockServices.setBlockInsertAllowed("ALTERACAO_GUIA", true);
			BlockServices.setBlockUpdateAllowed("ALTERACAO_GUIA", true);
			BlockServices.setBlockDeleteAllowed("ALTERACAO_GUIA", true);
		}
	}

	/**
	 * Retorna dados do autorizador logado
	 * 
	 * @author raphael.chaves
	 * @since 22/10/2013
	 * @param guiaElement
	 * @param pRaise
	 * @return void
	 */
	public void prcGetAutorizador(GuiaAdapter guiaElement) {
		String sqlcAut = "SELECT autoriz.CD_AUTORIZADOR FROM dbaps.autorizador autoriz, dbaps.me_autorizador me_aut " + "WHERE autoriz.cd_usuario = USER " + "and autoriz.cd_autorizador = me_aut.cd_autorizador " + "AND me_aut.cd_multi_empresa = DBAMV.PKG_MV2000.LE_EMPRESA";
		DataCursor dcAut = new DataCursor(sqlcAut);
		try {
			dcAut.open();
			ResultSet rsAut = dcAut.fetchInto();

			if (rsAut != null) {
				guiaElement.setCdAutorizador(rsAut.getNumber("CD_AUTORIZADOR"));
				this.prcAutorizador(guiaElement, NBool.False);
			}
		} finally {
			dcAut.close();
		}
	}

	/**
	 * Se a guia for de honorário individual e possuir guia pai, buscar dados
	 * dos prestadores
	 * 
	 * @author raphael.chaves
	 * @since 26/10/2013
	 * @param guiaElement
	 * @param pRaise
	 * @return void
	 */
	public void verificarGuiaHonorarioIndividual(GuiaAdapter guiaElement) {
		String sqlcHonorario = "SELECT 1 FROM dbaps.tipo_atendimento " + "WHERE TP_GUIA = 'H' " + "and cd_tipo_atendimento = :P_CD_TIPO_ATENDIMENTO";
		DataCursor dcHonorario = new DataCursor(sqlcHonorario);
		dcHonorario.addParameter("P_CD_TIPO_ATENDIMENTO", guiaElement.getCdTipoAtendimento());

		try {
			dcHonorario.open();
			if (dcHonorario.found()) {
				String sqlcGuiaTem = "select CD_ESPECIALIDADE, CD_PRESTADOR_EXECUTOR, CD_PRESTADOR_ENDERECO " + "from dbaps.guia " + "where nr_guia = :P_NR_GUIA_TEM";
				DataCursor dcGuiaTem = new DataCursor(sqlcGuiaTem);
				dcGuiaTem.addParameter("P_NR_GUIA_TEM", guiaElement.getNrGuiaTem());

				try {
					dcGuiaTem.open();
					ResultSet rsGuiaTem = dcGuiaTem.fetchInto();

					if (rsGuiaTem != null) {
						guiaElement.setCdEspecialidade(rsGuiaTem.getNumber(0));
						getLovDsEspecialidade(guiaElement, "A");
						guiaElement.setCdPrestadorExecutor(rsGuiaTem.getNumber(1));
						prestadorExecutor(guiaElement);
						guiaElement.setCdPrestadorEndereco(rsGuiaTem.getNumber(2));
						if (!guiaElement.getCdPrestadorEndereco().isNull()) {
							prestadorEndereco(guiaElement);
						}
					}
				} finally {
					dcGuiaTem.close();
				}
				setItemRequired("GUIA.SN_ATENDIMENTO_RECEM_NATO", true);
			} else {
				setItemRequired("GUIA.SN_ATENDIMENTO_RECEM_NATO", false);

				setItemEnabled("GUIA.CD_ESPECIALIDADE", true);
				setItemEnabled("GUIA.CD_PRESTADOR_EXECUTOR", true);
				setItemEnabled("GUIA.CD_PRESTADOR_ENDERECO", true);
			}
		} finally {
			dcHonorario.close();
		}
	}

	/**
	 * Validação do endereço do prestador
	 * 
	 * @author raphael.chaves
	 * @since 26/10/2013
	 * @param guiaElement
	 * @param pRaise
	 * @return void
	 */
	public void prestadorEndereco(GuiaAdapter guiaElement) {
		String sEnderecoPrestador = " SELECT PE.CD_PRESTADOR_ENDERECO, PE.DS_ENDERECO || ' Nº ' ||  " + "        PE.NR_ENDERECO ||  ' '  || PE.DS_COMPLEMENTO || ' - '  || " + "        PE.DS_BAIRRO   || ' - ' || PE.DS_MUNICIPIO   || ' - '  || PE.CD_UF DS_ENDERECO" + "   FROM DBAPS.PRESTADOR_ENDERECO PE,                           " + "        DBAPS.PRESTADOR_ENDERECO_ESPL PEE                      " + "  WHERE PE.CD_PRESTADOR_ENDERECO = PEE.CD_PRESTADOR_ENDERECO   " + "    AND PE.CD_PRESTADOR      = :CD_PRESTADOR_EXECUTOR          " + "    AND (PEE.CD_ESPECIALIDADE = :CD_ESPECIALIDADE OR :CD_ESPECIALIDADE IS NULL ) " + "    AND PE.CD_PRESTADOR_ENDERECO = :CD_PRESTADOR_ENDERECO      ";
		DataCursor cEnderecoPrestador = new DataCursor(sEnderecoPrestador);

		if (!guiaElement.getCdPrestadorEndereco().isNull()) {
			try {
				cEnderecoPrestador.addParameter("CD_PRESTADOR_EXECUTOR", guiaElement.getCdPrestadorExecutor());
				cEnderecoPrestador.addParameter("CD_ESPECIALIDADE", guiaElement.getCdEspecialidade());
				cEnderecoPrestador.addParameter("CD_PRESTADOR_ENDERECO", guiaElement.getCdPrestadorEndereco());

				cEnderecoPrestador.open();
				if (cEnderecoPrestador.hasData()) {
					ResultSet rEnderecoPrestador = cEnderecoPrestador.fetchInto();

					guiaElement.setDsEndereco(rEnderecoPrestador.getStr("DS_ENDERECO"));

					if (mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED") != null && mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED").equals("S")) {
						ItemServices.setItemIsValid("GUIA.CD_REDE_REFERENCIADA", true);
						this.getRedeReferenciadaPrestador(guiaElement.getCdPrestadorEndereco(), NNumber.getNull(), false);
					}
				} else {
					getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0115"), "E", NBool.True);
				}
			} catch (Exception e) {
				getTask().getMv2000().msgAlert("Erro: " + e.getMessage(), "E", toBool(NBool.True));
			} finally {
				cEnderecoPrestador.close();
			}

		} else {
			guiaElement.setDsEndereco(NString.getNull());
		}
	}

	/**
	 * Validação do prestador executor
	 * 
	 * @author raphael.chaves
	 * @since 24/10/2013
	 * @param guiaElement
	 * @param pRaise
	 * @return void
	 */
	public void prestadorExecutor(GuiaAdapter guiaElement) {
		if (guiaElement.getCdPrestadorExecutor().isNull()) {
			guiaElement.setDspNmExecutor(NString.getNull());
			guiaElement.setCdPrestadorEndereco(NNumber.getNull());
			guiaElement.setDsEndereco(NString.getNull());
			setItemEnabled("CD_PRESTADOR_EXECUTOR_PF", false);
			setItemNavigable("CD_PRESTADOR_EXECUTOR_PF", false);
			setItemRequired("GUIA.CD_PRESTADOR_EXECUTOR_PF", false);
		} else {
			NString emiteGuiaRetroPrest = obterValorChaveEmiteGuiaRetroPrest();
			
			//guiaElement.setCdPrestadorExecutorPf(new NNumber());
			//guiaElement.setDspNmPrestadorExecutorPf(new NString());
			//guiaElement.setDspCdPrestadorExecutorPfInterno(NString.getNull());

			StringBuilder sPrestadorEspecialidade = new StringBuilder();
			sPrestadorEspecialidade.append("SELECT DISTINCT PRESTADOR1.CD_PRESTADOR, PRESTADOR1.NM_PRESTADOR, ");
			sPrestadorEspecialidade.append("PRESTADOR1.SN_OBRIGA_MEDICO_PF_GUIA, PRESTADOR1.SN_EXECUTOR, ");
			sPrestadorEspecialidade.append("PRESTADOR1.TP_PRESTADOR, PRESTADOR1.CD_INTERNO ");
			sPrestadorEspecialidade.append("FROM DBAPS.PRESTADOR PRESTADOR1, ");
			sPrestadorEspecialidade.append("DBAPS.ESPECIALIDADE_PRESTADOR ESP_PRE, ");
			sPrestadorEspecialidade.append("DBAPS.PLANO_DE_SAUDE PLA_SAU ");
			sPrestadorEspecialidade.append("WHERE ESP_PRE.CD_PRESTADOR = PRESTADOR1.CD_PRESTADOR ");
			sPrestadorEspecialidade.append("AND PLA_SAU.ID = 1 ");
			sPrestadorEspecialidade.append("AND (ESP_PRE.CD_ESPECIALIDADE = :PCD_ESPECIALIDADE OR :PCD_ESPECIALIDADE IS NULL) ");
			sPrestadorEspecialidade.append("AND PRESTADOR1.SN_EXECUTOR = 'S' ");
			sPrestadorEspecialidade.append("AND ((PRESTADOR1.TP_SITUACAO = 'A' AND :P_CHAVE_GUIA_EMISSAO_RETRO_PREST = 'N') ");
			//PLANO - 8314
			sPrestadorEspecialidade.append("OR ((PRESTADOR1.DT_INATIVACAO > Nvl(:PDT_EMISSAO,SYSDATE) OR PRESTADOR1.DT_INATIVACAO IS NULL) AND :P_CHAVE_GUIA_EMISSAO_RETRO_PREST = 'S')) ");
			sPrestadorEspecialidade.append("AND PRESTADOR1.CD_PRESTADOR = :PCD_PRESTADOR_EXECUTOR ");
			sPrestadorEspecialidade.append("AND PRESTADOR1.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA ");
			sPrestadorEspecialidade.append("AND (NVL(PRESTADOR1.CD_PRESTADOR_TEM, PRESTADOR1.CD_PRESTADOR) = PRESTADOR1.CD_PRESTADOR ");
			sPrestadorEspecialidade.append("AND PLA_SAU.SN_PRESTADOR_PAI_NA_GUIA = 'S' ");
			sPrestadorEspecialidade.append("OR PRESTADOR1.CD_PRESTADOR_TEM IS NOT NULL AND PLA_SAU.SN_PRESTADOR_PAI_NA_GUIA <> 'S' ");
			sPrestadorEspecialidade.append("OR PRESTADOR1.CD_PRESTADOR_TEM IS NULL AND PLA_SAU.SN_PRESTADOR_PAI_NA_GUIA <> 'S') ");
			
			DataCursor cPrestadorEspecialidade = new DataCursor(sPrestadorEspecialidade.toString());

			cPrestadorEspecialidade.addParameter("PCD_ESPECIALIDADE", guiaElement.getCdEspecialidade());
			cPrestadorEspecialidade.addParameter("PCD_PRESTADOR_EXECUTOR", guiaElement.getCdPrestadorExecutor());
			cPrestadorEspecialidade.addParameter("P_CHAVE_GUIA_EMISSAO_RETRO_PREST", emiteGuiaRetroPrest);
			cPrestadorEspecialidade.addParameter("PDT_EMISSAO", guiaElement.getDtEmissao());

			try {

				cPrestadorEspecialidade.open();

				if (!cPrestadorEspecialidade.found()) {
					getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0114"), "W", NBool.True);
				} else {

					ResultSet rPrestadorEspecialidade = cPrestadorEspecialidade.fetchInto();

					guiaElement.setDspNmExecutor(rPrestadorEspecialidade.getStr("NM_PRESTADOR"));
					guiaElement.setDspCdPrestadorExecutorInterno(rPrestadorEspecialidade.getStr("CD_INTERNO"));

					if (rPrestadorEspecialidade.getString("TP_PRESTADOR").equals("F")) {
						setItemEnabled("CD_PRESTADOR_EXECUTOR_PF", false);
						setItemNavigable("CD_PRESTADOR_EXECUTOR_PF", false);
						setItemRequired("GUIA.CD_PRESTADOR_EXECUTOR_PF", false);
					} else {
						setItemEnabled("CD_PRESTADOR_EXECUTOR_PF", true);
						setItemNavigable("CD_PRESTADOR_EXECUTOR_PF", true);

						if (rPrestadorEspecialidade.getStr("SN_OBRIGA_MEDICO_PF_GUIA").equals("S")) {
							setItemRequired("GUIA.CD_PRESTADOR_EXECUTOR_PF", true);
						} else {
							setItemRequired("GUIA.CD_PRESTADOR_EXECUTOR_PF", false);
						}
					}
				}
			} finally {
				cPrestadorEspecialidade.close();
			}
//			cdPrestadorExecutorValidatelimpa(guiaElement);

			String sEnderecoPrestador = " SELECT PE.CD_PRESTADOR_ENDERECO, PE.DS_ENDERECO || ' Nº ' ||  " + "        PE.NR_ENDERECO ||  ' '  || PE.DS_COMPLEMENTO || ' - '  || " + "        PE.DS_BAIRRO   || ' - ' || PE.DS_MUNICIPIO   || ' - '  || PE.CD_UF DS_ENDERECO" + "   FROM DBAPS.PRESTADOR_ENDERECO PE                           " + "  WHERE PE.CD_PRESTADOR      = :CD_PRESTADOR_EXECUTOR          ";
			DataCursor cEnderecoPrestador = new DataCursor(sEnderecoPrestador);

			NNumber cdPrestadorEndereco;
			NString dsEndereco;

			try {
				cEnderecoPrestador.addParameter("CD_PRESTADOR_EXECUTOR", guiaElement.getCdPrestadorExecutor());
				cEnderecoPrestador.open();
				ResultSet rEnderecoPrestador = cEnderecoPrestador.fetchInto();
				int count = 0;
				if (cEnderecoPrestador.hasData()) {
					while (true) {
						cdPrestadorEndereco = rEnderecoPrestador.getNumber("CD_PRESTADOR_ENDERECO");
						dsEndereco = rEnderecoPrestador.getStr("DS_ENDERECO");
						rEnderecoPrestador = cEnderecoPrestador.fetchInto();
						count++;
						if (!cEnderecoPrestador.hasData()) {
							break;
						}
					}
					if (count == 1) {
						guiaElement.setCdPrestadorEndereco(cdPrestadorEndereco);
						guiaElement.setDsEndereco(dsEndereco);
					}
				}
			} catch (Exception e) {
				getTask().getMv2000().msgAlert("Erro: " + e.getMessage(), "E", toBool(NBool.True));
			} finally {
				cEnderecoPrestador.close();
			}
		}
	}

	/**
	 * Limpa os dados influenciados pelo campo CD_PRESTADOR_EXECUTOR
	 * 
	 * @OP 5857
	 * @author Diego Nobre
	 * @since 23/04/2013
	 * @param guiaElement
	 */
	public void cdPrestadorExecutorValidatelimpa(GuiaAdapter guiaElement) {
		if (!(!guiaElement.getNrGuiaTem().isNull() && !guiaElement.getCdTipoAtendimento().isNull() && guiaElement.getDspTpGuia().equals("H"))) {
			guiaElement.setCdPrestadorEndereco(NNumber.getNull());
			guiaElement.setDsEndereco(NString.getNull());

			guiaElement.setCdPrestadorExecutorPf(NNumber.getNull());
			guiaElement.setNmPrestadorExecutorPf(NString.getNull());
			guiaElement.setDspCdPrestadorExecutorPfInterno(NString.getNull());
		}
	}

	/**
	 * Buscar pela descrição do Estadiamento
	 * 
	 * @OP 16468
	 * @author Raphael Chaves
	 * @since 13/02/2014
	 * @param codigo (código do campo)
	 * @param validate (indica se a chamada foi do Validate 'S' ou do afterQuery
	 * 'N')
	 */
	public NString getDescricaoEstadiamento(NNumber codigo, boolean validate) {
		NString descricao = NString.getNull();

		if (!codigo.isNull()) {
			String sqlcTiss = "SELECT est.DS_TIPO_ESTADIAMENTO_TUMOR " + "FROM DBAPS.MVS_TIPO_ESTADIAMENTO_TUMOR est " + "WHERE est.DT_INICIO_VIGENCIA in (SELECT Max(e.DT_INICIO_VIGENCIA) " + "FROM DBAPS.MVS_TIPO_ESTADIAMENTO_TUMOR e " + "where est.CD_TISS = e.CD_TISS " + "AND e.DT_INICIO_VIGENCIA <= sysdate) " + "AND est.CD_TIPO_ESTADIAMENTO_TUMOR = :P_CODIGO";
			DataCursor dcTiss = new DataCursor(sqlcTiss);
			dcTiss.addParameter("P_CODIGO", codigo);

			try {
				dcTiss.open();
				ResultSet rsTiss = dcTiss.fetchInto();

				if (rsTiss != null) {
					descricao = rsTiss.getStr(0);
				} else if (validate) {
					getTask().getMv2000().chamaMensagem(toStr("Atenção"), toStr("Erro...: Código inválido.").append(chr(10)).append("Motivo: O código informado não existe.").append(chr(10)).append("Ação...: Verifique o código informado."), toBool(NBool.True));
				}
			} finally {
				dcTiss.close();
			}
		}
		return descricao;
	}

	/**
	 * Buscar pela descrição do Ecog
	 * 
	 * @OP 16468
	 * @author Raphael Chaves
	 * @since 13/02/2014
	 * @param codigo (código do campo)
	 * @param validate (indica se a chamada foi do Validate 'S' ou do afterQuery
	 * 'N')
	 */
	public NString getDescricaoEcog(NString codigo, boolean validate) {
		NString descricao = NString.getNull();

		if (!codigo.isNull()) {
			StringBuilder sqlcTiss = new StringBuilder();
			sqlcTiss.append("SELECT ecog.DS_TIPO_ECOG ");
			sqlcTiss.append("FROM DBAPS.MVS_TIPO_ECOG ecog ");
			sqlcTiss.append("WHERE ecog.DT_INICIO_VIGENCIA in (SELECT Max(e.DT_INICIO_VIGENCIA) ");
			sqlcTiss.append("FROM DBAPS.MVS_TIPO_ECOG e ");
			sqlcTiss.append("where ecog.CD_TISS = e.CD_TISS ");
			sqlcTiss.append("AND e.DT_INICIO_VIGENCIA <= sysdate) ");
			sqlcTiss.append("AND ecog.CD_TISS = :PCD_TISS ");
			
			DataCursor dcTiss = new DataCursor(sqlcTiss.toString());
			dcTiss.addParameter("PCD_TISS", codigo);

			try {
				dcTiss.open();
				ResultSet rsTiss = dcTiss.fetchInto();

				if (rsTiss != null) {
					descricao = rsTiss.getStr(0);
				} else if (validate) {
					getTask().getMv2000().chamaMensagem(toStr("Atenção"), toStr("Erro...: Código inválido.").append(chr(10)).append("Motivo: O código informado não existe.").append(chr(10)).append("Ação...: Verifique o código informado."), toBool(NBool.True));
				}
			} finally {
				dcTiss.close();
			}
		}
		return descricao;
	}

	/**
	 * Buscar pela descrição da Quimioterapia
	 * 
	 * @OP 16468
	 * @author Raphael Chaves
	 * @since 13/02/2014
	 * @param codigo (código do campo)
	 * @param validate (indica se a chamada foi do Validate 'S' ou do afterQuery
	 * 'N')
	 */
	public NString getDescricaoQuimioterapia(NNumber codigo, boolean validate) {
		NString descricao = NString.getNull();

		if (!codigo.isNull()) {
			String sqlcTiss = "SELECT qui.DS_TIPO_QUIMIOTERAPIA FROM DBAPS.MVS_TIPO_QUIMIOTERAPIA qui " + "WHERE qui.DT_INICIO_VIGENCIA in (SELECT Max(e.DT_INICIO_VIGENCIA) " + "FROM DBAPS.MVS_TIPO_QUIMIOTERAPIA e " + "where qui.CD_TISS = e.CD_TISS " + "AND e.DT_INICIO_VIGENCIA <= sysdate) " + "AND qui.CD_TIPO_QUIMIOTERAPIA = :P_CODIGO";
			DataCursor dcTiss = new DataCursor(sqlcTiss);
			dcTiss.addParameter("P_CODIGO", codigo);

			try {
				dcTiss.open();
				ResultSet rsTiss = dcTiss.fetchInto();

				if (rsTiss != null) {
					descricao = rsTiss.getStr(0);
				} else if (validate) {
					getTask().getMv2000().chamaMensagem(toStr("Atenção"), toStr("Erro...: Código inválido.").append(chr(10)).append("Motivo: O código informado não existe.").append(chr(10)).append("Ação...: Verifique o código informado."), toBool(NBool.True));
				}
			} finally {
				dcTiss.close();
			}
		}
		return descricao;
	}

	/**
	 * Buscar pela descrição do Diagnostico Imagem
	 * 
	 * @OP 16468
	 * @author Raphael Chaves
	 * @since 13/02/2014
	 * @param codigo (código do campo)
	 * @param validate (indica se a chamada foi do Validate 'S' ou do afterQuery
	 * 'N')
	 */
	public NString getDescricaoDiagnostico(NNumber codigo, boolean validate) {
		NString descricao = NString.getNull();

		if (!codigo.isNull()) {
			String sqlcTiss = "SELECT dia.DS_TIPO_DIAGNOSTICO_IMAGEM " + "FROM DBAPS.MVS_TIPO_DIAGNOSTICO_IMAGEM dia " + "WHERE dia.DT_INICIO_VIGENCIA in (SELECT Max(e.DT_INICIO_VIGENCIA) " + "FROM DBAPS.MVS_TIPO_DIAGNOSTICO_IMAGEM e " + "where dia.CD_TISS = e.CD_TISS " + "AND e.DT_INICIO_VIGENCIA <= sysdate) " + "AND dia.CD_TIPO_DIAGNOSTICO_IMAGEM = :P_CODIGO";
			DataCursor dcTiss = new DataCursor(sqlcTiss);
			dcTiss.addParameter("P_CODIGO", codigo);

			try {
				dcTiss.open();
				ResultSet rsTiss = dcTiss.fetchInto();

				if (rsTiss != null) {
					descricao = rsTiss.getStr(0);
				} else if (validate) {
					getTask().getMv2000().chamaMensagem(toStr("Atenção"), toStr("Erro...: Código inválido.").append(chr(10)).append("Motivo: O código informado não existe.").append(chr(10)).append("Ação...: Verifique o código informado."), toBool(NBool.True));
				}
			} finally {
				dcTiss.close();
			}
		}
		return descricao;
	}

	/**
	 * Buscar pela descrição da Finalidade
	 * 
	 * @OP 16468
	 * @author Raphael Chaves
	 * @since 13/02/2014
	 * @param codigo (código do campo)
	 * @param validade (indica se a chamada foi do Validade 'S' ou do afterQuery
	 * 'N')
	 */
	public NString getDescricaoFinalidade(NNumber codigo, boolean validate) {
		NString descricao = NString.getNull();

		if (!codigo.isNull()) {
			String sqlcTiss = "SELECT fin.DS_TIPO_FINALIDADE_TRATAMENTO " + "FROM DBAPS.MVS_TIPO_FINALIDADE_TRATAMENTO fin " + "WHERE fin.DT_INICIO_VIGENCIA in (SELECT Max(e.DT_INICIO_VIGENCIA) " + "FROM DBAPS.MVS_TIPO_FINALIDADE_TRATAMENTO e " + "where fin.CD_TISS = e.CD_TISS " + "AND e.DT_INICIO_VIGENCIA <= sysdate) " + "AND fin.CD_TIPO_FINALIDADE_TRATAMENTO = :P_CODIGO";
			DataCursor dcTiss = new DataCursor(sqlcTiss);
			dcTiss.addParameter("P_CODIGO", codigo);

			try {
				dcTiss.open();
				ResultSet rsTiss = dcTiss.fetchInto();

				if (rsTiss != null) {
					descricao = rsTiss.getStr(0);
				} else if (validate) {
					getTask().getMv2000().chamaMensagem(toStr("Atenção"), toStr("Erro...: Código inválido.").append(chr(10)).append("Motivo: O código informado não existe.").append(chr(10)).append("Ação...: Verifique o código informado."), toBool(NBool.True));
				}
			} finally {
				dcTiss.close();
			}
		}
		return descricao;
	}

	public void prcPrcAssociado(ItguiaAdapter element, GuiaAdapter elementGuia) {
		NString cdprocedimento = NString.getNull();
		cdprocedimento = fncProcedimentoInformado(element.getCdProcedimento(), elementGuia.getCdPrestadorExecutor());

		String sqlCProc = "SELECT 1 " + "FROM DBAPS.PROCEDIMENTO " + "WHERE CD_PROCEDIMENTO = :PCD_PROCEDIMENTO ";
		DataCursor dcProc = new DataCursor(sqlCProc);
		dcProc.addParameter("PCD_PROCEDIMENTO", cdprocedimento);

		try {
			dcProc.open();
			ResultSet rsProc = dcProc.fetchInto();
			if (rsProc == null) {
				cdprocedimento = element.getCdProcedimento();
				if (rsProc == null) {
					cdprocedimento = element.getCdProcedimento();
				}
			}
		} finally {
			dcProc.close();
		}

		if (!Lib.isNull(cdprocedimento, element.getCdProcedimento()).equals(element.getCdProcedimento())) {
			getTask().getMv2000().msgAlert(toStr("Existe um procedimento TUSS associado. O código do procedimento será modificado!"), toStr("I"), toBool(NBool.False));
			element.setCdProcedimento(cdprocedimento);
		}
	}

	public static NString fncProcedimentoInformado(NString pCdProcedimento, NNumber pCdPrestador) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("FNC_PROCEDIMENTO_INFORMADO", DbManager.getDataBaseFactory());

		cmd.addReturnParameter(NString.class);
		cmd.addParameter("@PCD_PROCEDIMENTO", pCdProcedimento);
		cmd.addParameter("@PCD_PRESTADOR", pCdPrestador);

		cmd.execute();
		return cmd.getReturnValue(NString.class);
	}

	public void getDescricaoPrestadorSolicitante(GuiaAdapter guiaElement) {
 		String sql =" SELECT TP_PRESTADOR,                                        " +
					"        CD_PRESTADOR_SOLICITANTE,                            " +
					"        DSP_NM_SOLICITANTE,                                  " +
					"        ATEND_PROFSOLIC_LISTATODOS,                          " +
					"        NR_CPF_CGC,                                          " +
					"        NR_FONE FROM (                                       " +
					" SELECT P.TP_PRESTADOR TP_PRESTADOR,                         " +
					"        P.CD_PRESTADOR CD_PRESTADOR_SOLICITANTE,             " +
					"        P.NM_PRESTADOR DSP_NM_SOLICITANTE,                   " +
					"        P.NR_CPF_CGC,                                        " +
					"        'N' ATEND_PROFSOLIC_LISTATODOS,                      " +
					"        SUBSTR(P.NR_FONE, 0, 20) NR_FONE                     " +
					"   FROM DBAPS.PRESTADOR           P,                         " +
					"        DBAPS.PRESTADOR_ASSOCIADO PA,                        " +
					"        DBAPS.MVS_CONFIGURACAO MC                            " +
					"  WHERE P.CD_PRESTADOR = PA.CD_PRESTADOR                     " +
					"    AND P.SN_EXECUTOR = 'S'                                  " +
					"    AND PA.CD_PRESTADOR_ASSOCIADO = :P_CD_PRESTADOR          " +
					"    AND P.CD_PRESTADOR = :GUIA_CD_PRESTADOR                  " +
					"    AND P.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA     " +
					"    AND P.TP_PRESTADOR = 'F'                                 " +
					"    AND P.CD_MULTI_EMPRESA = MC.CD_MULTI_EMPRESA             " +
					"    AND MC.CHAVE = 'ATEND_PROFSOLIC_LISTATODOS'              " +
					"    AND MC.VALOR = 'N'                                       " +
					" UNION                                                       " +
					" SELECT P.TP_PRESTADOR TP_PRESTADOR,                         " +
					"        P.CD_PRESTADOR CD_PRESTADOR_SOLICITANTE,             " +
					"        P.NM_PRESTADOR DSP_NM_SOLICITANTE,                   " +
					"        P.NR_CPF_CGC,                                        " +
					"        'N' ATEND_PROFSOLIC_LISTATODOS,                      " +
					"        SUBSTR(P.NR_FONE, 0, 20) NR_FONE                     " +
					"   FROM DBAPS.PRESTADOR P                                    " +
					"      , DBAPS.MVS_CONFIGURACAO MC                            " +
					"  WHERE P.CD_PRESTADOR = :GUIA_CD_PRESTADOR                  " +
					"    AND P.CD_PRESTADOR = :P_CD_PRESTADOR                     " +
					"    AND P.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA     " +
					"    AND P.TP_PRESTADOR = 'F'                                 " +
					"    AND P.CD_MULTI_EMPRESA = MC.CD_MULTI_EMPRESA             " +
					"    AND MC.CHAVE = 'ATEND_PROFSOLIC_LISTATODOS'              " +
					"    AND MC.VALOR = 'N'                                       " +
					" UNION ALL                                                   " +
					" SELECT P.TP_PRESTADOR TP_PRESTADOR,                         " +
					"        P.CD_PRESTADOR CD_PRESTADOR_SOLICITANTE,             " +
					"        P.NM_PRESTADOR DSP_NM_SOLICITANTE,                   " +
					"        P.NR_CPF_CGC,                                        " +
					"        'S' ATEND_PROFSOLIC_LISTATODOS,                      " +
					"        SUBSTR(P.NR_FONE, 0, 20) NR_FONE                     " +
					"      FROM DBAPS.PRESTADOR P                                 " +
					"         , DBAPS.MVS_CONFIGURACAO MC                         " +
					"     WHERE P.CD_PRESTADOR = :GUIA_CD_PRESTADOR               " +
					"       AND P.TP_SITUACAO = 'A'                               " +
					"       AND P.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA  " +
					"       AND P.CD_MULTI_EMPRESA = MC.CD_MULTI_EMPRESA          " +
					"       AND MC.CHAVE = 'ATEND_PROFSOLIC_LISTATODOS'           " +
					"       AND P.TP_PRESTADOR = 'F'							  " +
					"       AND MC.VALOR = 'S'                                    " +
					" )                                                           ";

		DataCursor cursor = new DataCursor(sql);

		cursor.addParameter("GUIA_CD_PRESTADOR", guiaElement.getCdPrestadorSolicitante());
		cursor.addParameter("P_CD_PRESTADOR", guiaElement.getCdPrestador());

		try {
			cursor.open();

			if (cursor.found()) {

				ResultSet rCursor = cursor.fetchInto();

				if (!rCursor.getStr("TP_PRESTADOR").equals("F")) {
					getTask().getMv2000().msgAlert("O Profissional solicitante informado não é uma pessoa fisica!", "E", NBool.True);
				}

				guiaElement.setNmProfissionalSolicitante(rCursor.getStr("DSP_NM_SOLICITANTE"));
				guiaElement.setNrTelefoneProfissional(rCursor.getStr("NR_FONE"));

			} else {
				if (!guiaElement.getCdPrestador().isNull()) {
					getTask().getMv2000().msgAlert("O Profissional solicitante deve estar associado ao contratado solicitante!", "E", NBool.True);
				} else {
					getTask().getMv2000().msgAlert("Deve ser informado o contratado solicitante !", "E", NBool.True);
				}
			}
		} finally {
			cursor.close();
		}
	}

	/**
	 * @author Rosemere Mota
	 * @param EnviarEmailAdapter
	 * @since 21/08/2014
	 * 
	 * Responsável por deletar os Anexos das guias e deletar também o arquivo do
	 * diretório. Inseri um log do arquivo excluido.
	 * 
	 */
	public void deletarGuiaAnexo(GuiaAnexoAdapter guiaAnexoElement) {
		// Excluindo o anexo da guia
		String sql = "DELETE FROM DBAPS.GUIA_ANEXO " + "				 WHERE CD_GUIA_ANEXO = :P_CD_GUIA_ANEXO";

		DataCommand dComand = new DataCommand(sql);
		dComand.addParameter("P_CD_GUIA_ANEXO", guiaAnexoElement.getCdGuiaAnexo());

		// Inseri o Log do Anexo que foi Excluido
		String sql1 = "INSERT INTO DBAPS.LOG_AUTORIZA " + "						   (NR_GUIA, DS_FUNCIONALIDADE, NM_USUARIO_ORACLE, DT_ACAO, CD_AUTORIZADOR, CD_LOG_AUTORIZA)" + "					VALUES (:GUIA_NR_GUIA, :P_CMSG, USER, SYSDATE, :CD_AUTORIZADOR, SEQ_LOG_AUTORIZA.NEXTVAL)";

		/**
		 * Alterado a mensagem do log Rosemere Mota 10/06/2016 17:48
		 * 
		 */
		String cmsg = "EXCLUSÃO DO ARQUIVO DE ANEXO DA GUIA [ " + guiaAnexoElement.getDsArquivo().toUpper() + " ] POR [ " + DbManager.getUser() + " ] DATA [ " + DbManager.getDBDateTime() + " ]";// "EXCLUSÃO
		                                                                                                                                                                                          // DO
		                                                                                                                                                                                          // ANEXO
		                                                                                                                                                                                          // DA
		                                                                                                                                                                                          // GUIA
		                                                                                                                                                                                          // :
		                                                                                                                                                                                          // "
		                                                                                                                                                                                          // +
		                                                                                                                                                                                          // guiaAnexoElement.getDsArquivo().toUpper();
		DataCommand dCommand1 = new DataCommand(sql1);
		GuiaAdapter guiaElement = (GuiaAdapter) getFormModel().getGuia().getRowAdapter(true);

		dCommand1.addParameter("GUIA_NR_GUIA", guiaAnexoElement.getNrGuia());
		dCommand1.addParameter("P_CMSG", cmsg);
		dCommand1.addParameter("CD_AUTORIZADOR", guiaElement.getCdAutorizador());

		try {

			// Deleta anexo
			dComand.execute();

			// Inseri Log
			dCommand1.execute();

			// deletar arquivo do diretorio
			String caminho = guiaAnexoElement.getDsCaminho().toString().replace("\\\\", "\\") + "\\" + guiaAnexoElement.getDsArquivo().toString();

			File folder = new File(caminho);

			if (folder.exists()) {
				folder.delete();

				getTask().getMv2000().msgAlert(toStr("Arquivo removido com sucesso! "), toStr("I"), toBool(NBool.False));

				TaskServices.executeQuery("GUIA_ANEXO");
				TaskServices.executeQuery("LOG_AUTORIZA");
			} else {
				getTask().getMv2000().msgAlert(toStr("Arquivo não Existe no Diretorio! "), toStr("W"), toBool(NBool.False));
			}

		} catch (Exception e) {
			getTask().getMv2000().msgAlert(toStr("Erro ao remover a guia anexo, motivo: " + e.getMessage()), toStr("E"), toBool(NBool.True));
		}
	}

	/**
	 * 
	 * Controla o botão de Excluir anexo de acordo com autorização. Se a mesma
	 * estiver autorizada desabilita, e não autorizada desabilita.
	 * 
	 * @author rosemere.mota
	 * @since 28/08/2014
	 * @return void
	 */
	public void verificaBotaoExcluirAnexo() {
		if (getGuiaElement().getSnValidaRestCarencia().equals("S")) {
			setItemEnabled("GUIA_ANEXO.BTN_EXCLUIR_ANEXO", false);
		} else {
			setItemEnabled("GUIA_ANEXO.BTN_EXCLUIR_ANEXO", true);
		}
	}

	public void validaProcedimentoRolAns(NString cdProcedimento) {
		String sqlCommand = "DBAPS.FNC_VALIDA_PROCED_ROL_ANS";
		DataCommand command = new DataCommand(sqlCommand);
		command.addReturnParameter(NString.class);
		command.addParameter("P_CD_PROCEDIMENTO", cdProcedimento);
		command.execute();

		if (command.getReturnValue(NString.class).equals("N")) {
			getTask().getMv2000().msgAlert("Procedimento(" + cdProcedimento + ") não consta no rol da ANS.", "W", NBool.False);
		}
	}

	/**
	 * Retorna email do local de atendimento
	 * 
	 * @author manoel.neto
	 * @since 09/03/2015
	 * @return
	 */
	public NString getLocalAtendimentoEmail() {
		NString retorno = NString.getNull();

		String sql = "SELECT PEC.DS_PRESTADOR_ENDERECO_CONTATO " + "       FROM DBAPS.PRESTADOR_ENDERECO_CONTATO PEC " + "           ,DBAPS.TIPO_CONTATO TC" + "		WHERE PEC.CD_PRESTADOR_ENDERECO = :P_CD_PRESTADOR_ENDERECO " + "         AND PEC.CD_TIPO_CONTATO = TC.CD_TIPO_CONTATO " + "         AND TC.TP_CONTATO = 'E' ";
		DataCursor cCursor = new DataCursor(sql);

		try {
			cCursor.addParameter("P_CD_PRESTADOR_ENDERECO", getGuiaElement().getCdPrestadorEndereco());
			cCursor.open();

			if (cCursor.found()) {
				ResultSet rs = cCursor.fetchInto();
				retorno = rs.getStr("DS_PRESTADOR_ENDERECO_CONTATO");

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cCursor.close();
		}
		return retorno;
	}

	/**
	 * Retorna email do prestador executante
	 * 
	 * @author manoel.neto
	 * @since 09/03/2015
	 * @return
	 */
	public NString getPrestadorExecutanteEmail() {
		NString retorno = NString.getNull();
		NNumber cdPrestador = NNumber.getNull();

		if (!getGuiaElement().getCdPrestadorExecutorPf().isNull()) {
			cdPrestador = getGuiaElement().getCdPrestadorExecutorPf();
		} else {
			cdPrestador = getGuiaElement().getCdPrestadorExecutor();
		}

		String sql = "SELECT DS_EMAIL " + "       FROM DBAPS.PRESTADOR " + "      WHERE CD_PRESTADOR = :P_CD_PRESTADOR";
		DataCursor cCursor = new DataCursor(sql);

		try {
			cCursor.addParameter("P_CD_PRESTADOR", cdPrestador);
			cCursor.open();

			if (cCursor.found()) {
				ResultSet rs = cCursor.fetchInto();
				retorno = rs.getStr("DS_EMAIL");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cCursor.close();
		}
		return retorno;
	}

	/**
	 * Retorna email do prestador solicitante
	 * 
	 * @author manoel.neto
	 * @since 09/03/2015
	 * @return
	 */
	public NString getPrestadorSolicitanteEmail() {
		NString retorno = NString.getNull();

		String sql = "SELECT DS_EMAIL " + "       FROM DBAPS.PRESTADOR " + "      WHERE CD_PRESTADOR = :P_CD_PRESTADOR ";
		DataCursor cCursor = new DataCursor(sql);

		try {
			cCursor.addParameter("P_CD_PRESTADOR", getGuiaElement().getCdPrestador());
			cCursor.open();

			if (cCursor.found()) {
				ResultSet rs = cCursor.fetchInto();
				retorno = rs.getStr("DS_EMAIL");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cCursor.close();
		}
		return retorno;
	}

	/**
	 * Retorna email do beneficiário
	 * 
	 * @author manoel.neto
	 * @since 09/03/2015
	 * @return
	 */
	public NString getBeneficiarioEmail() {
		NString retorno = NString.getNull();
		String sql = "SELECT DS_EMAIL " + "       FROM DBAPS.USUARIO " + "      WHERE CD_MATRICULA = :P_CD_MATRICULA ";
		DataCursor cCursor = new DataCursor(sql);

		try {

			cCursor.addParameter("P_CD_MATRICULA", getGuiaElement().getCdMatricula());
			cCursor.open();

			if (cCursor.found()) {
				ResultSet rs = cCursor.fetchInto();
				retorno = rs.getStr("DS_EMAIL");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cCursor.close();
		}
		return retorno;
	}

	/**
	 * Retorna email do auditor
	 * 
	 * @author manoel.neto
	 * @since 09/03/2015
	 * @return
	 */
	public NString getAuditorEmail() {
		NString retorno = NString.getNull();
		
		String sql = "SELECT U.DS_EMAIL FROM DBAPS.LOG_AUTORIZA LOG, DBAPS.AUTORIZADOR AUT, DBASGU.USUARIOS U WHERE LOG.CD_AUTORIZADOR = AUT.CD_AUTORIZADOR AND U.CD_USUARIO = AUT.CD_USUARIO AND LOG.DS_FUNCIONALIDADE = 'LIBERACAO DE GUIA' AND LOG.NR_GUIA = :P_NR_GUIA AND LOG.DT_ACAO = (SELECT MAX(DT_ACAO) FROM DBAPS.LOG_AUTORIZA WHERE LOG_AUTORIZA.NR_GUIA = :P_NR_GUIA AND LOG_AUTORIZA.DS_FUNCIONALIDADE = 'LIBERACAO DE GUIA' )";
		DataCursor cCursor = new DataCursor(sql);

		String sql2 = "SELECT U.DS_EMAIL FROM DBAPS.GUIA GUI ,DBAPS.AUTORIZADOR AUT ,DBASGU.USUARIOS U WHERE GUI.CD_AUTORIZADOR = AUT.CD_AUTORIZADOR AND U.CD_USUARIO = AUT.CD_USUARIO AND NR_GUIA = :P_NR_GUIA ";
		DataCursor cCursor2 = new DataCursor(sql2);

		try {
			cCursor.addParameter("P_NR_GUIA", getGuiaElement().getNrGuia());
			cCursor.open();
			if (cCursor.found()) {
				ResultSet rs = cCursor.fetchInto();
				retorno = rs.getStr("DS_EMAIL");
			} else {
				cCursor2.addParameter("P_NR_GUIA", getGuiaElement().getNrGuia());
				cCursor2.open();
				if (cCursor2.found()) {
					ResultSet rs2 = cCursor2.fetchInto();
					retorno = rs2.getStr("DS_EMAIL");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
			if (cCursor != null && cCursor.isOpen()) {
				cCursor.close();
			}
			
			if (cCursor2 != null && cCursor2.isOpen()) {
				cCursor2.close();
			}
		}
		return retorno;
	}

	/**
	 * Verifica se existe erro no email
	 * 
	 * @author manoel.neto
	 * @since 09/03/2015
	 * @param email
	 * @return
	 */
	public boolean existeErroEmail(String email) {
		boolean retorno = false;

		Pattern pattern = Pattern.compile("^[\\w-]+(\\.[\\w-]+)*@([\\w-]+\\.)+[a-zA-Z]{2,7}$");
		Matcher m = pattern.matcher(email);

		if (!m.find()) {
			retorno = true;
		}
		return retorno;
	}

	public void setEmails() {
		NString localAtendimentoEmail = this.getLocalAtendimentoEmail();
		NString prestadorExecutanteEmail = this.getPrestadorExecutanteEmail();
		NString prestadorSolicitanteEmail = this.getPrestadorSolicitanteEmail();
		NString beneficiarioEmail = this.getBeneficiarioEmail();
		NString auditorEmail = this.getAuditorEmail();

		// local de atendimento
		if (!localAtendimentoEmail.isNull()) {
			if (!this.getTask().getServices().existeErroEmail(localAtendimentoEmail.toString())) {
				ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_LOCAL_ATENDIMENTO", true);
				getEnviarEmailElement().setDspEmailLocalAtendimento(localAtendimentoEmail);
			} else {
				getEnviarEmailElement().setDspSnLocalAtendimento(NString.toStr("N"));
				ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_LOCAL_ATENDIMENTO", false);
				getEnviarEmailElement().setDspEmailLocalAtendimento(NString.toStr("Email inválido: " + localAtendimentoEmail));
			}
		} else {
			getEnviarEmailElement().setDspSnLocalAtendimento(NString.toStr("N"));
			ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_LOCAL_ATENDIMENTO", false);
			getEnviarEmailElement().setDspEmailLocalAtendimento(NString.getNull());
		}

		// prestador executante
		if (!prestadorExecutanteEmail.isNull()) {
			if (!this.getTask().getServices().existeErroEmail(prestadorExecutanteEmail.toString())) {
				ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_PRESTADOR_EXECUTANTE", true);
				getEnviarEmailElement().setDspEmailPrestadorExecutante(prestadorExecutanteEmail);
			} else {
				getEnviarEmailElement().setDspSnPrestadorExecutante(NString.toStr("N"));
				ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_PRESTADOR_EXECUTANTE", false);
				getEnviarEmailElement().setDspEmailPrestadorExecutante(NString.toStr("Email inválido: " + prestadorExecutanteEmail));
			}
		} else {
			getEnviarEmailElement().setDspSnPrestadorExecutante(NString.toStr("N"));
			ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_PRESTADOR_EXECUTANTE", false);
			getEnviarEmailElement().setDspEmailPrestadorExecutante(NString.getNull());
		}
		
		// prestador solicitante
		if (!prestadorSolicitanteEmail.isNull()) {
			if (!this.getTask().getServices().existeErroEmail(prestadorSolicitanteEmail.toString())) {
				ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_PRESTADOR_SOLICITANTE", true);
				getEnviarEmailElement().setDspEmailPrestadorSolicitante(prestadorSolicitanteEmail);
			} else {
				getEnviarEmailElement().setDspSnPrestadorSolicitante(NString.toStr("N"));
				ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_PRESTADOR_SOLICITANTE", false);
				getEnviarEmailElement().setDspEmailPrestadorSolicitante(NString.toStr("Email inválido: " + prestadorSolicitanteEmail));
			}
		} else {
			getEnviarEmailElement().setDspSnPrestadorSolicitante(NString.toStr("N"));
			ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_PRESTADOR_SOLICITANTE", false);
			getEnviarEmailElement().setDspEmailLocalAtendimento(NString.getNull());
		}

		// beneficiario
		if (!beneficiarioEmail.isNull()) {
			if (!this.getTask().getServices().existeErroEmail(beneficiarioEmail.toString())) {
				ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_BENEFICIARIO", true);
				getEnviarEmailElement().setDspEmailBeneficiario(beneficiarioEmail);
			} else {
				getEnviarEmailElement().setDspSnBeneficiario(NString.toStr("N"));
				ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_BENEFICIARIO", false);
				getEnviarEmailElement().setDspEmailBeneficiario(NString.toStr("Email inválido: " + beneficiarioEmail));
			}
		} else {
			getEnviarEmailElement().setDspSnBeneficiario(NString.toStr("N"));
			ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_BENEFICIARIO", false);
			getEnviarEmailElement().setDspEmailLocalAtendimento(NString.getNull());
		}

		// auditor
		if (!auditorEmail.isNull()) {
			if (!this.getTask().getServices().existeErroEmail(auditorEmail.toString())) {
				ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_AUDITOR", true);
				getEnviarEmailElement().setDspEmailAuditor(auditorEmail);
			} else {
				getEnviarEmailElement().setDspSnAuditor(NString.toStr("N"));
				ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_AUDITOR", false);
				getEnviarEmailElement().setDspEmailAuditor(NString.toStr("Email inválido: " + auditorEmail));
			}
		} else {
			getEnviarEmailElement().setDspSnAuditor(NString.toStr("N"));
			ItemServices.setItemEnabled("ENVIAR_EMAIL.DSP_SN_AUDITOR", false);
			getEnviarEmailElement().setDspEmailLocalAtendimento(NString.getNull());
		}
	}

	public void insereLogEnvioEmail() {
		String sqlCommand = "INSERT INTO DBAPS.LOG_AUTORIZA                " + "                         (NR_GUIA,                        " + "                          DS_FUNCIONALIDADE,              " + "                          NM_USUARIO_ORACLE,              " + "                          DT_ACAO,                        " + "                          CD_AUTORIZADOR,                 " + "                          CD_PROCEDIMENTO,                " + "                          CD_LOG_AUTORIZA)                " + "            VALUES                                        " + "                        (:P_NR_GUIA,                      " + "                         :P_DS_FUNCIONALIDADE,            " + "                         :NM_USUARIO_ORACLE,              " + "                         :P_DT_ACAO,                      " + "                         :P_CD_AUTORIZADOR,               " + "                         NULL,                            " + "                         DBAPS.SEQ_LOG_AUTORIZA.NEXTVAL)  ";
		DataCommand command = new DataCommand(sqlCommand);
		command.addParameter("P_NR_GUIA", getGuiaElement().getNrGuia());
		command.addParameter("P_DS_FUNCIONALIDADE", NString.toStr("ENVIADO GUIA POR EMAIL : " + this.getEmailsEnviados()));
		command.addParameter("NM_USUARIO_ORACLE", TaskServices.getUser());
		command.addParameter("P_DT_ACAO", DbManager.getDBDateTime());
		command.addParameter("P_CD_AUTORIZADOR", getGuiaElement().getCdAutorizador());
		command.execute();
	}

	public NString getEmailsEnviados() {
		NString retorno = NString.getNull();
		String listaEmail = "";

		if (getEnviarEmailElement().getDspSnLocalAtendimento().equals("S")) {
			if (!getEnviarEmailElement().getDspEmailLocalAtendimento().isNull()) {
				listaEmail = listaEmail + Lib.isNull(getEnviarEmailElement().getDspEmailLocalAtendimento(), "");
			}
		}

		if (getEnviarEmailElement().getDspSnPrestadorExecutante().equals("S")) {
			if (!getEnviarEmailElement().getDspEmailPrestadorExecutante().isNull()) {
				if (listaEmail == "") {
					listaEmail = listaEmail + Lib.isNull(getEnviarEmailElement().getDspEmailPrestadorExecutante(), "");
				} else {
					listaEmail = listaEmail + "," + Lib.isNull(getEnviarEmailElement().getDspEmailPrestadorExecutante(), "");
				}
			}
		}

		if (getEnviarEmailElement().getDspSnPrestadorSolicitante().equals("S")) {
			if (!getEnviarEmailElement().getDspEmailPrestadorSolicitante().isNull()) {
				if (listaEmail == "") {
					listaEmail = listaEmail + Lib.isNull(getEnviarEmailElement().getDspEmailPrestadorSolicitante(), "");
				} else {
					listaEmail = listaEmail + "," + Lib.isNull(getEnviarEmailElement().getDspEmailPrestadorSolicitante(), "");
				}
			}
		}

		if (getEnviarEmailElement().getDspSnBeneficiario().equals("S")) {
			if (!getEnviarEmailElement().getDspEmailBeneficiario().isNull()) {
				if (listaEmail == "") {
					listaEmail = listaEmail + Lib.isNull(getEnviarEmailElement().getDspEmailBeneficiario(), "");
				} else {
					listaEmail = listaEmail + "," + Lib.isNull(getEnviarEmailElement().getDspEmailBeneficiario(), "");
				}
			}
		}

		if (getEnviarEmailElement().getDspSnAuditor().equals("S")) {
			if (!getEnviarEmailElement().getDspEmailAuditor().isNull()) {
				if (listaEmail == "") {
					listaEmail = listaEmail + Lib.isNull(getEnviarEmailElement().getDspEmailAuditor(), "");
				} else {
					listaEmail = listaEmail + "," + Lib.isNull(getEnviarEmailElement().getDspEmailAuditor(), "");
				}
			}
		}
		
		if (listaEmail != "" && !getEnviarEmailElement().getDspEmailPrestador().isNull()) {
			listaEmail = "," + listaEmail;
		}

		retorno = NString.toStr(getEnviarEmailElement().getDspEmailPrestador() + listaEmail);
		return retorno;
	}

	/**
	 * Verifica se existe glosa para o procedimento Função:
	 * 
	 * @author: douglas.ramos
	 * @since: 01/04/2015
	 * @params: @param nrGuia
	 * @params: @param cdProcedimento
	 * @params: @return
	 * @return: boolean
	 */
	public boolean existeMotivo(NNumber nrGuia, NString cdProcedimento) {
		boolean retorno = false;

		String sql = "SELECT 1 " + " FROM DBAPS.ITGUIA_ERROS IE" + " WHERE IE.NR_GUIA = :P_NR_GUIA" + "  AND IE.CD_PROCEDIMENTO = :P_CD_PROCEDIMENTO";
		DataCursor cCursor = new DataCursor(sql);

		try {
			cCursor.addParameter("P_NR_GUIA", nrGuia);
			cCursor.addParameter("P_CD_PROCEDIMENTO", cdProcedimento);
			cCursor.open();

			if (cCursor.found()) {
				retorno = true;
			}
		} finally {
			cCursor.close();
		}
		return retorno;
	}

	public void pintarProcedimento(boolean pintar) {
		if (pintar) {
			ItemServices.setItemStyleClass("ITGUIA.DSP_DS_PROCEDIMENTO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "Amarelo");
			ItemServices.setItemStyleClass("ITGUIA.QT_SOLIC_PREST", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "Amarelo");
			ItemServices.setItemStyleClass("ITGUIA.QT_SOLICITADO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "Amarelo");
			ItemServices.setItemStyleClass("ITGUIA.DSP_VL_TOTAL_PROCEDIMENTO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "Amarelo");
			ItemServices.setItemStyleClass("ITGUIA.DSP_VL_TOTAL_FRANQUIA", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "Amarelo");
			ItemServices.setItemStyleClass("ITGUIA.DSP_TP_STATUS", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "Amarelo");
			ItemServices.setItemStyleClass("ITGUIA.NR_SENHA", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "Amarelo");
			ItemServices.setItemStyleClass("ITGUIA.QT_FRANQUIA", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "Amarelo");
			ItemServices.setItemStyleClass("ITGUIA.CD_REGIAO_DENTE", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "Amarelo");
			ItemServices.setItemStyleClass("ITGUIA.CD_FACES_DENTES_ODONTO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "Amarelo");
			ItemServices.setItemStyleClass("ITGUIA.DT_REALIZACAO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "Amarelo");
		} else {
			ItemServices.setItemStyleClass("ITGUIA.DSP_DS_PROCEDIMENTO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "");
			ItemServices.setItemStyleClass("ITGUIA.QT_SOLIC_PREST", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "");
			ItemServices.setItemStyleClass("ITGUIA.QT_SOLICITADO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "");
			ItemServices.setItemStyleClass("ITGUIA.DSP_VL_TOTAL_PROCEDIMENTO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "");
			ItemServices.setItemStyleClass("ITGUIA.DSP_VL_TOTAL_FRANQUIA", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "");
			ItemServices.setItemStyleClass("ITGUIA.DSP_TP_STATUS", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "");
			ItemServices.setItemStyleClass("ITGUIA.NR_SENHA", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "");
			ItemServices.setItemStyleClass("ITGUIA.QT_FRANQUIA", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "");
			ItemServices.setItemStyleClass("ITGUIA.CD_REGIAO_DENTE", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "");
			ItemServices.setItemStyleClass("ITGUIA.CD_FACES_DENTES_ODONTO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "");
			ItemServices.setItemStyleClass("ITGUIA.DT_REALIZACAO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "");
		}
	}

	/**
	 * @autor Rosemere Mota
	 * @since 20/05/2015 10:55
	 * @param cdProcedimento
	 * @param cdContratatoExecutante
	 * 
	 * Verifica se existe pacote para o procedimento selecionado
	 * 
	 */
	public Boolean existePacote(NString cdProcedimento, NNumber cdContratatoExecutante) {
		Boolean retorno = false;

		String sql = " SELECT COUNT(1) QTD                                                     ".concat("   FROM DBAPS.PACOTE PC                                                   ").concat("      , DBAPS.PROCEDIMENTO PRO                                            ").concat("  WHERE PC.CD_PROCEDIMENTO = PRO.CD_PROCEDIMENTO                          ").concat("    AND PC.CD_ITEM_PROCEDIMENTO = :P_CD_PROCEDIMENTO			           ").concat("    AND PRO.SN_PACOTE = 'S'                                               ").concat("    AND EXISTS (SELECT 1                                                  ").concat("                  FROM DBAPS.VALOR_REF_PROC                               ").concat("                 WHERE CD_PRESTADOR = :P_CD_CONTRATADO_EXECUTANTE		   ").concat("                 AND CD_PROCEDIMENTO = :P_CD_PROCEDIMENTO			       ").concat("                 )                                                        ");

		DataCursor cCursor = new DataCursor(sql);

		try {
			cCursor.addParameter("P_CD_PROCEDIMENTO", cdProcedimento);
			cCursor.addParameter("P_CD_CONTRATADO_EXECUTANTE", cdContratatoExecutante);
			cCursor.open();
			ResultSet rCursor = cCursor.fetchInto();

			if (cCursor.found()) {
				if (rCursor.getNumber("qtd").greater(0)) {
					retorno = true;
				}
			}
		} finally {
			cCursor.close();
		}
		return retorno;
	}

	/**
	 * @autor Manoel Neto
	 * @since 15/07/2015
	 * @param cdProcedimento
	 * 
	 * Verifica se existe regulação para o procedimento selecionado
	 * 
	 */
	public Boolean existeRegulacao(NString cdProcedimento) {
		Boolean retorno = false;
		String sql = "SELECT 1  " + "       FROM DBAPS.PROCED_REGULACAO PR " + "      WHERE PR.CD_PROCEDIMENTO = '" + cdProcedimento + "'";

		DataCursor cCursor = new DataCursor(sql);

		try {
			cCursor.open();
			if (cCursor.found()) {
				retorno = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cCursor.close();
		}
		return retorno;
	}

	public void setDspDsProcedTipoRegulacao() {
		ProcedRegulacaoAdapter procedRegulacaoElement = (ProcedRegulacaoAdapter) this.getFormModel().getProcedRegulacao().getRowAdapter(true);

		String sql = "SELECT DS_TIPO_REGULACAO FROM DBAPS.PROCED_TIPO_REGULACAO WHERE CD_PROCED_TIPO_REGULACAO = :P_CD_PROCED_TIPO_REGULACAO";

		DataCursor cursor = new DataCursor(sql);
		cursor.addParameter("P_CD_PROCED_TIPO_REGULACAO", procedRegulacaoElement.getCdProcedTipoRegulacao());

		try {
			cursor.open();

			if (cursor.found()) {
				ResultSet rs = cursor.fetchInto();
				procedRegulacaoElement.setDspDsProcedTipoRegulacao(rs.getStr("DS_TIPO_REGULACAO"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cursor.close();
		}
	}

	public NString getAutorizadorNegacao(NNumber cdAutorizador, boolean isValidade) {
		NString retorno = NString.getNull();

		String sql = " SELECT A.NM_AUTORIZADOR,                                   " + "             A.DS_SENHA,                                         " + "             A.SN_NEGACAO_ITEM                                   " + "        FROM DBAPS.AUTORIZADOR A,                                " + "             DBAPS.ME_AUTORIZADOR MEA                            " + "       WHERE A.CD_AUTORIZADOR = MEA.CD_AUTORIZADOR               " + "         AND MEA.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA  " + "         AND A.CD_AUTORIZADOR = :P_CD_AUTORIZADOR                ";
		DataCursor cCursor = new DataCursor(sql);

		try {
			cCursor.addParameter("P_CD_AUTORIZADOR", cdAutorizador);
			cCursor.open();

			if (cCursor.found()) {
				ResultSet rs = cCursor.fetchInto();
				retorno = rs.getStr("NM_AUTORIZADOR");

				if (rs.getStr("SN_NEGACAO_ITEM").equals("N") && isValidade) {
					getTask().getMv2000().msgAlert("Autorizador não tem permissão para negar o item!", "W", NBool.True);
				}
				
			} else if (isValidade) {
				getTask().getMv2000().msgAlert("Autorizador não encontrado!", "W", NBool.True);
			}

		} finally {
			cCursor.close();
		}
		return retorno;
	}

	public boolean isSenhaAutorizadorValida(NNumber cdAutorizador, NString senha) {
		boolean retorno = true;

		String sql = " SELECT A.DS_SENHA                                          " + "        FROM DBAPS.AUTORIZADOR A,                                " + "             DBAPS.ME_AUTORIZADOR MEA                            " + "       WHERE A.CD_AUTORIZADOR = MEA.CD_AUTORIZADOR               " + "         AND MEA.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA  " + "         AND A.CD_AUTORIZADOR = :P_CD_AUTORIZADOR                ";
		DataCursor cCursor = new DataCursor(sql);

		try {
			cCursor.addParameter("P_CD_AUTORIZADOR", cdAutorizador);
			cCursor.open();

			if (cCursor.found()) {
				ResultSet rs = cCursor.fetchInto();

				if (!rs.getStr("DS_SENHA").equals(senha)) {
					getTask().getMv2000().msgAlert("Senha incorreta!", "W", NBool.False);
					retorno = false;
				}

			} else {
				getTask().getMv2000().msgAlert("Autorizador informado acima não foi encontrado!", "W", NBool.False);
				retorno = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cCursor.close();
		}
		return retorno;
	}

	public void getMotivoGlosa(boolean isValidate) {
		String sql = "SELECT MG.CD_MOTIVO                  " 
				+ "           ,MG.DS_MOTIVO                " 
				+ "           ,MG.CD_GRUPO_MOTIVO_GLOSA    " 
				+ "           ,MG.CD_MOTIVO_PTU_ONLINE     " 
				+ "     FROM DBAPS.MOTIVO_GLOSA MG         " 
				+ "     WHERE MG.CD_MOTIVO = :P_CD_MOTIVO  " 
				+ "       AND SN_GLOSAR = 'S'              " 
				+ "       AND CD_MOTIVO < 9000             ";

		DataCursor cCursor = null;
		cCursor = new DataCursor(sql);

		try {
			cCursor.addParameter("P_CD_MOTIVO", getItguiaElement().getCdMotivo());
			cCursor.open();

			if (cCursor.found()) {
				TableRow rCursor = cCursor.fetchRow();
				getItguiaElement().setDspDsMotivo(rCursor.getStr("DS_MOTIVO"));
				getItguiaElement().setCdMotivoPtuOnline(rCursor.getNumber("CD_MOTIVO_PTU_ONLINE"));

			} else {
				if (isValidate) {
					//MULTI-IDIOMA: MSG_0068 - Erro.....: Motivo de Glosa inválido!%sMotivo..: Motivo de Glosa não está cadastrado no sistema.%sAção....: Informe um Motivo de Glosa válido.
					getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0068", Lib.chr(10), Lib.chr(10)), "W", NBool.True);
				}
			}

		} finally {
			cCursor.close();
		}
	}

	public void insereLogNegacao(boolean negar) {
		String msg = "";
		String valorAnterior = "";
		if (negar) {
			//MULTI-IDIOMA: MSG_0069 - NEGAÇÃO DO ITEM EFETUADA
			msg = ResourceManager.getString("guia.msg0069");
			//MULTI-IDIOMA: MSG_0070 -  ITEM NEGADO%sMOTIVO: %s - %s
			valorAnterior = ResourceManager.getString("guia.msg0070", Lib.chr(10), getItguiaElement().getCdMotivo(), getItguiaElement().getDspDsMotivo());
		} else {
			//MULTI-IDIOMA: MSG_0071 -  NEGAÇÃO DO ITEM CANCELADA
			msg = ResourceManager.getString("guia.msg0071");
			//MULTI-IDIOMA: MSG_0072 - NEGAÇÃO CANCELADA
			valorAnterior = ResourceManager.getString("guia.msg0072");
		}
		this.insertLog(getGuiaElement().getNrGuia(), NString.toStr(msg), this.getFormModel().getNegacaoItem().getDspCdAutorizador(), getItguiaElement().getCdProcedimento(), NString.toStr(valorAnterior), NString.getNull());
	}

	public void verificaObrigatoriedadePrestadorExecutante() {
		NString snObrigaPrestadorExec = NString.toStr("N");

		String sql = "SELECT SN_OBRIGA_PRESTADOR_EXEC " + " FROM DBAPS.TIPO_ATENDIMENTO " + " WHERE CD_TIPO_ATENDIMENTO = :P_TIPO_ATENDIMENTO";
		DataCursor cCursor = new DataCursor(sql);

		try {
			cCursor.addParameter("P_TIPO_ATENDIMENTO", getGuiaElement().getCdTipoAtendimento());
			cCursor.open();

			if (cCursor.found()) {
				ResultSet rs = cCursor.fetchInto();
				snObrigaPrestadorExec = rs.getStr("SN_OBRIGA_PRESTADOR_EXEC");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cCursor.close();
		}

		if (snObrigaPrestadorExec.equals("S") && getGuiaElement().getCdPrestadorExecutor().isNull()) {
			getTask().getMv2000().msgAlert("É obrigatório informar o contratado executante para este tipo de guia.", "W", NBool.True);
		}
	}

	public void validaGuiaConsulta() {
		int qtd = 0;

		String sql = "SELECT COUNT(CD_PROCEDIMENTO) QTD" + "       FROM DBAPS.ITGUIA " + "      WHERE NR_GUIA = :P_NR_GUIA ";
		DataCursor cCursor = new DataCursor(sql);

		try {
			cCursor.addParameter("P_NR_GUIA", getGuiaElement().getNrGuia());
			cCursor.open();

			if (cCursor.found()) {
				ResultSet rs = cCursor.fetchInto();
				qtd = rs.getInt32("QTD");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cCursor.close();
		}

		if (qtd > 1) {
			if (!getTask().getMv2000().msgAlertSn(NString.toStr("Foram encontrados mais de um procedimento para esta guia, conforme padrão TISS \"Guia de Consulta\" só suporta um procedimento. Deseja continuar?"), NString.toStr("W"), NString.toStr("Sim/Não")).toBoolean()) {
				throw new ApplicationException();
			}
		}
	}

	public void exibeAlerta(boolean exibePopup) {
		if (!getGuiaElement().getCdMatricula().isNull() || !getGuiaElement().getCdPrestadorExecutor().isNull() || !getGuiaElement().getCdPrestadorExecutorPf().isNull() || !getGuiaElement().getCdMatAlternativa().isNull()) {

			HashMap<String, String> param = new HashMap<String, String>();

			String prestadores = "";
			String matriculas = "";
			String carteiras = "";

			if (!getGuiaElement().getCdMatricula().isNull()) {
				matriculas = getGuiaElement().getCdMatricula().toString();
			}

			if (!getGuiaElement().getCdMatAlternativa().isNull()) {
				carteiras = getGuiaElement().getCdMatAlternativa().toString();
			}

			if (!getGuiaElement().getCdPrestadorExecutor().isNull()) {
				prestadores = prestadores + getGuiaElement().getCdPrestadorExecutor() + ",";
			}

			if (!getGuiaElement().getCdPrestadorExecutorPf().isNull()) {
				prestadores = prestadores + getGuiaElement().getCdPrestadorExecutorPf() + ",";
			}

			param.put("PRESTADORES", prestadores);
			param.put("MATRICULAS", matriculas);
			param.put("CARTEIRA", carteiras);

			try {

				if (Alerta.existeAlerta(param)) {

					ItemServices.setItemEnabled("GUIA.BTN_ALERTA", true);
					ItemServices.setItemStyleClass("GUIA.BTN_ALERTA", "PiscarAlerta");

					if (this.getFormModel().getParam("P_SN_ALERTA_AUTOMATICO", NString.class).equals("S") && exibePopup) {
						((GuiaController) this.getTask().getFormController().getBlockController("GUIA")).btn_alerta_click();
					}

				} else {
					ItemServices.setItemEnabled("GUIA.BTN_ALERTA", false);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		} else {
			ItemServices.setItemEnabled("GUIA.BTN_ALERTA", false);
		}
	}

	public void abrirTelaGuia(NNumber nrGUia) {
		@SuppressWarnings("rawtypes")
		Hashtable plId = null;

		plId = getParameterList("GUIA");

		if (plId == null) {
			plId = createParameterList("GUIA");
		} else {
			plId.clear();
		}
		
		TaskServices.addParameter(plId, "NR_GUIA", nrGUia);
		TaskServices.addParameter(plId, "P_CD_AUTORIZADOR_CALL", Globals.getGlobal("P_CD_AUTORIZADOR_CALL"));
		TaskServices.addParameter(plId, "P_CD_MATRICULA_CALL", Globals.getGlobal("P_CD_MATRICULA_CALL"));

		NString tipoBeneficiario = this.getTask().getServices().fncRetornaTipoBeneficiario(getGuiaElement().getCdMatricula(),Lib.lpad(getGuiaElement().getCdMatricula(), 16,"0"));

		if (tipoBeneficiario.equals("EV") || tipoBeneficiario.equals("ID") || tipoBeneficiario.equals("RC")) {
			TaskServices.addParameter(plId, "PSN_CORTESIA", "S");
		} else {
			TaskServices.addParameter(plId, "PSN_CORTESIA", "N");
		}

		TaskServices.addParameter(plId, "P_EDITAR", "S");

		TaskServices.callTask("GUIA", TaskServices.HIDE, TaskServices.NO_REPLACE, TaskServices.NO_QUERY_ONLY, plId);
	}

	public void existeGuiaHonorarioAssociada(NNumber nrGuia, NNumber cdPrestadorHonorario) {
		String sql = "SELECT G.NR_GUIA                                                    "
				+ "       FROM DBAPS.GUIA G                                               "
				+ "      WHERE G.CD_MOT_CANCELAMENTO_GUIA IS NULL                         "
				+ "        AND G.CD_TIPO_ATENDIMENTO = (SELECT MIN(CD_TIPO_ATENDIMENTO)   "
				+ "                                       FROM DBAPS.TIPO_ATENDIMENTO     "
				+ "                                      WHERE TP_GUIA = 'H')             "
				+ "        AND G.NR_GUIA_TEM = :P_NR_GUIA                                 "
				+ "        AND G.CD_PRESTADOR_EXECUTOR = :P_CD_PRESTADOR_EXECUTOR       ";
		DataCursor c = new DataCursor(sql);

		try {
			c.addParameter("P_NR_GUIA", nrGuia);
			c.addParameter("P_CD_PRESTADOR_EXECUTOR", cdPrestadorHonorario);
			c.open();

			if (c.found()) {
				ResultSet rs = c.fetchInto();
				getTask().getMv2000().msgAlert(
						NString.toStr("").append("Erro.....: Prestador inválido!").append(Lib.chr(10))
								.append("Motivo..:Já existe uma guia de honorário(" + rs.getStr("NR_GUIA")
										+ ") associada a esta guia(" + nrGuia + ") com este prestador("
										+ cdPrestadorHonorario + ").")
								.append(Lib.chr(10)).append("Ação....: Informe outro prestador ou cancele a guia.")
								.toString(),
						"W", /*
								 * W = Atenção, I = Informação, E = Erro
								 */
						NBool.True /* bloquear/travar? */);
			}

		} finally {
			c.close();
		}
	}

	public void insertTipoAtendimentoHonorarioProcedimento(String cdProcedimento) {
		String insert = "  INSERT INTO DBAPS.PROCED_TIPO_ATENDIMENTO(  " + "             CD_PROCEDIMENTO                          " + "            ,CD_TIPO_ATENDIMENTO                      " + "            ,SN_AUTORIZACAO                           " + "            ,SN_GUIA                                  " + "            ,SN_APLICA_REDUTOR                        " + "            ,CD_NIVEL_HIERARQUICO                     " + "            ,SN_VISIVEL_WEB                           " + "            )VALUES(                                  " + "             :P_CD_PROCEDIMENTO                       " + // CD_PROCEDIMENTO
		        "            ,(SELECT MIN(CD_TIPO_ATENDIMENTO)         " + "                FROM DBAPS.TIPO_ATENDIMENTO           " + "               WHERE TP_GUIA = 'H')                   " + // CD_TIPO_ATENDIMENTO
		        "            ,'N'                                      " + // SN_AUTORIZACAO
		        "            ,'S'                                      " + // SN_GUIA
		        "            ,'N'                                      " + // SN_APLICA_REDUTOR
		        "            ,0                                        " + // CD_NIVEL_HIERARQUICO
		        "            ,'N'                                      " + // SN_VISIVEL_WEB
		        "            )                                         ";
		DataCommand command = new DataCommand(insert);

		try {
			command.addParameter("P_CD_PROCEDIMENTO", cdProcedimento);
			command.execute();
		} catch (Exception e) {
			//MULTI-IDIOMA: MSG_0055 -  %s %s%s %s 
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0055", cdProcedimento, Lib.chr(10), Lib.chr(10), e.getMessage()), "W", NBool.False);
			e.printStackTrace();
		}
	}

	public void updateTipoAtendimentoHonorarioProcedimento(String cdProcedimento) {
		String update = "  UPDATE DBAPS.PROCED_TIPO_ATENDIMENTO SET SN_GUIA = 'S'        " + "           WHERE CD_TIPO_ATENDIMENTO = (SELECT MIN(CD_TIPO_ATENDIMENTO) " + "                                          FROM DBAPS.TIPO_ATENDIMENTO   " + "                                         WHERE TP_GUIA = 'H')           " + "             AND CD_PROCEDIMENTO = :P_CD_PROCEDIMENTO                   ";
		DataCommand command = new DataCommand(update);

		try {
			command.addParameter("P_CD_PROCEDIMENTO", cdProcedimento);
			command.execute();
		} catch (Exception e) {
			//MULTI-IDIOMA: MSG_0055 -  %s %s%s %s 
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0055", cdProcedimento, Lib.chr(10), Lib.chr(10), e.getMessage()), "W", NBool.False);
			e.printStackTrace();
		}
	}

	public void validaProcedimentosHonorarios() {
		String insertProcedimentos = "";
		String updateProcedimentos = "";

		String sql = "       SELECT CD_PROCEDIMENTO,                                                           " + "                   'I' TP_OPERACAO                                                            " + "              FROM DBAPS.ITGUIA                                                               " + "             WHERE NOT EXISTS (SELECT 1                                                       " + "                                 FROM DBAPS.PROCED_TIPO_ATENDIMENTO                           " + "                                WHERE CD_TIPO_ATENDIMENTO = (SELECT MIN(CD_TIPO_ATENDIMENTO)  " + "                                                               FROM DBAPS.TIPO_ATENDIMENTO    " + "                                                              WHERE TP_GUIA = 'H')            " + "                       AND CD_PROCEDIMENTO = ITGUIA.CD_PROCEDIMENTO)                          " + "               AND NR_GUIA = :P_NR_GUIA                                                       " + "            UNION ALL                                                                         " + "            SELECT CD_PROCEDIMENTO,                                                           " + "                   'U' TP_OPERACAO                                                            " + "              FROM DBAPS.ITGUIA                                                               " + "             WHERE EXISTS (SELECT 1                                                           " + "                             FROM DBAPS.PROCED_TIPO_ATENDIMENTO                               " + "                            WHERE CD_TIPO_ATENDIMENTO = (SELECT MIN(CD_TIPO_ATENDIMENTO)      " + "                                                           FROM DBAPS.TIPO_ATENDIMENTO        " + "                                                          WHERE TP_GUIA = 'H')                " + "                              AND CD_PROCEDIMENTO = ITGUIA.CD_PROCEDIMENTO                    " + "                              AND SN_GUIA = 'N')                                              " + "               AND NR_GUIA = :P_NR_GUIA                                                       ";
		DataCursor cCursor = new DataCursor(sql);

		try {
			cCursor.addParameter("P_NR_GUIA", getGuiaElement().getNrGuia());
			cCursor.open();
			TableRow tr = cCursor.fetchRow();

			while (cCursor.found()) {
				if (tr.getStr("TP_OPERACAO").equals("I")) {
					if (insertProcedimentos.length() > 0) {
						insertProcedimentos += ", " + tr.getStr("CD_PROCEDIMENTO");
					} else {
						insertProcedimentos += tr.getStr("CD_PROCEDIMENTO");
					}
				} else if (tr.getStr("TP_OPERACAO").equals("U")) {
					if (updateProcedimentos.length() > 0) {
						updateProcedimentos += ", " + tr.getStr("CD_PROCEDIMENTO");
					} else {
						updateProcedimentos += tr.getStr("CD_PROCEDIMENTO");
					}
				}
				tr = cCursor.fetchRow();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cCursor.close();
		}

		if (insertProcedimentos.length() > 0 || updateProcedimentos.length() > 0) {
			String procedimentos = "";
			if (insertProcedimentos.length() > 0) {
				if (updateProcedimentos.length() > 0) {
					procedimentos = insertProcedimentos + ", " + updateProcedimentos;
				} else {
					procedimentos = insertProcedimentos;
				}
			} else {
				procedimentos = updateProcedimentos;
			}

			//MULTI-IDIOMA: MSG_0056 - Operação inválida! Os procedimentos %s não estão configurados para o tipo de guia honorário.%s%sDeseja associar estes procedimentos ao tipo de guia honorário? 
			String message = ResourceManager.getString("guia.msg0056", procedimentos, Lib.chr(10), Lib.chr(10));
			//MULTI-IDIOMA: MSG_0057 - Sim/Não
			String simNao = ResourceManager.getString("guia.msg0057");

			if (getTask().getMv2000().msgAlertSn(NString.toStr(message), NString.toStr("W"), NString.toStr(simNao)).toBoolean()) {
				if (insertProcedimentos.length() > 0) {
					String[] insertArrayProcedimentos = insertProcedimentos.split(",");
					for (String cdProcedimento : insertArrayProcedimentos) {
						this.getTask().getServices().insertTipoAtendimentoHonorarioProcedimento(Lib.trim(cdProcedimento).toString());
					}
				}

				if (updateProcedimentos.length() > 0) {
					String[] updateArrayProcedimentos = updateProcedimentos.split(",");
					for (String cdProcedimento : updateArrayProcedimentos) {
						this.getTask().getServices().updateTipoAtendimentoHonorarioProcedimento(Lib.trim(cdProcedimento).toString());
					}
				}
			} else {
				throw new ApplicationException();
			}
		}
	}

	public static void prcGeraGuiaAssociada(NNumber pNrGuiaTem, NNumber pCdTipoAtendimento, NNumber pCdPrestadorExecutor, NNumber pCdAtiMed, NNumber pCdEspecialidade) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("DBAPS.PRC_GERA_GUIA_ASSOCIADA", DbManager.getDataBaseFactory());
		cmd.addParameter("@P_NR_GUIA_TEM", pNrGuiaTem);
		cmd.addParameter("@P_CD_TIPO_ATENDIMENTO", pCdTipoAtendimento);
		cmd.addParameter("@P_CD_PRESTADOR_EXECUTOR", pCdPrestadorExecutor);
		cmd.addParameter("@P_CD_ESPECIALIDADE", pCdEspecialidade);
		cmd.addParameter("@P_CD_ATI_MED", pCdAtiMed);
		cmd.execute();
	}

	@SuppressWarnings("unused")
	public void validaGeracaoHonorario() {
		NNumber nrGuia = getGuiaElement().getNrGuia();
		NNumber cdPrestadorGuia = getGuiaElement().getCdPrestadorExecutor();
		NNumber cdTipoAtendimento = NNumber.toNumber(Services.getDescricao("MIN(CD_TIPO_ATENDIMENTO)", "TIPO_ATENDIMENTO", "TP_GUIA = 'H'", false));
		HashMap<NNumber, NNumber> prestadores = new HashMap<NNumber, NNumber>();

		if (cdTipoAtendimento.isNull()) {
			getTask().getMv2000().msgAlert(NString.toStr("").append("Erro.....: Operação inválida!").append(Lib.chr(10)).append("Motivo..: Não existe guia do tipo honorário cadastrada no sistema.").append(Lib.chr(10)).append("Ação....: Cadastre uma guia do tipo honorário.").toString(), "W", /*
			                                                                                                                                                                                                                                                                                           * W
			                                                                                                                                                                                                                                                                                           * =
			                                                                                                                                                                                                                                                                                           * Atenção,
			                                                                                                                                                                                                                                                                                           * I
			                                                                                                                                                                                                                                                                                           * =
			                                                                                                                                                                                                                                                                                           * Informação,
			                                                                                                                                                                                                                                                                                           * E
			                                                                                                                                                                                                                                                                                           * =
			                                                                                                                                                                                                                                                                                           * Erro
			                                                                                                                                                                                                                                                                                           */
			        NBool.True /* bloquear/travar? */);
		}

		TaskServices.goBlock("GUIA_HONORARIO");
		BlockServices.firstRecord();
		while (true) {
			NNumber cdPrestadorHonorario = getGuiaHonorarioElement().getDspCdPrestador();
			NNumber cdAtiMed = getGuiaHonorarioElement().getDspCdAtiMed();

			if (!cdPrestadorHonorario.isNull()) {
				if (!prestadores.containsKey(cdPrestadorHonorario)) {
					this.getTask().getServices().existeGuiaHonorarioAssociada(nrGuia, cdPrestadorHonorario);
					this.getTask().getServices().setPrestadorExecutorHonorario();
					prestadores.put(cdPrestadorHonorario, cdPrestadorHonorario);
				} else {
					getTask().getMv2000().msgAlert(NString.toStr("").append("Erro.....: Operação inválida!").append(Lib.chr(10)).append("Motivo..: O Prestador " + cdPrestadorHonorario + " está duplicado na lista.").append(Lib.chr(10)).append("Ação....: Remova os prestadores duplicados para continuar.").toString(), "W", /*
					                                                                                                                                                                                                                                                                                                                * W
					                                                                                                                                                                                                                                                                                                                * =
					                                                                                                                                                                                                                                                                                                                * Atenção,
					                                                                                                                                                                                                                                                                                                                * I
					                                                                                                                                                                                                                                                                                                                * =
					                                                                                                                                                                                                                                                                                                                * Informação,
					                                                                                                                                                                                                                                                                                                                * E
					                                                                                                                                                                                                                                                                                                                * =
					                                                                                                                                                                                                                                                                                                                * Erro
					                                                                                                                                                                                                                                                                                                                */
					        NBool.True /* bloquear/travar? */);
				}

				// valida a atividade médica
				if (!getGuiaHonorarioElement().getDspCdAtiMed().isNull()) {
					NString dsAtiMed = Services.getDescricao("DS_ATI_MED", "ATI_MED", "CD_ATI_MED = " + cdAtiMed, false);

					if (dsAtiMed.isNull()) {
						getTask().getMv2000().msgAlert(NString.toStr("").append("Erro.....: Operação inválida!").append(Lib.chr(10)).append("Motivo..: A atividade médica " + cdAtiMed + " não existe.").append(Lib.chr(10)).append("Ação....: Informe outra atividade médica.").toString(), "W", /*
						                                                                                                                                                                                                                                                                             * W
						                                                                                                                                                                                                                                                                             * =
						                                                                                                                                                                                                                                                                             * Atenção,
						                                                                                                                                                                                                                                                                             * I
						                                                                                                                                                                                                                                                                             * =
						                                                                                                                                                                                                                                                                             * Informação,
						                                                                                                                                                                                                                                                                             * E
						                                                                                                                                                                                                                                                                             * =
						                                                                                                                                                                                                                                                                             * Erro
						                                                                                                                                                                                                                                                                             */
						        NBool.True /* bloquear/travar? */);
					}
				}

				// valkida a especialidade
				if (!getGuiaHonorarioElement().getDspCdEspecialidade().isNull()) {
					NString dsAtiMed = Services.getDescricao("DS_ESPECIALIDADE", "ESPECIALIDADE", "CD_ESPECIALIDADE = " + getGuiaHonorarioElement().getDspCdEspecialidade(), false);

					if (!dsAtiMed.isNull()) {
						getGuiaHonorarioElement().setDspDsEspecialidade(dsAtiMed);
					} else {
						getTask().getMv2000().msgAlert(NString.toStr("").append("Erro.....: Operação inválida!").append(Lib.chr(10)).append("Motivo..: Esta especialidade não existe.").append(Lib.chr(10)).append("Ação....: Informe outra especialidade.").toString(), "W", /*
						                                                                                                                                                                                                                                                         * W
						                                                                                                                                                                                                                                                         * =
						                                                                                                                                                                                                                                                         * Atenção,
						                                                                                                                                                                                                                                                         * I
						                                                                                                                                                                                                                                                         * =
						                                                                                                                                                                                                                                                         * Informação,
						                                                                                                                                                                                                                                                         * E
						                                                                                                                                                                                                                                                         * =
						                                                                                                                                                                                                                                                         * Erro
						                                                                                                                                                                                                                                                         */
						        NBool.True /* bloquear/travar? */);
					}
				}
			}

			if (BlockServices.isInLastRecord()) {
				break;
			} else {
				BlockServices.nextRecord();
			}
		}

		if (prestadores.isEmpty()) {
			getTask().getMv2000().msgAlert("Informe os prestadores para gerar as guias de honorário.", "W", NBool.True);
		}
	}

	public int autorizaGuia(GuiaAdapter guiaElement){
		String sql = " UPDATE DBAPS.GUIA " 
				+ "SET SN_VALIDA_REST_CARENCIA = 'S'"
				+ ", DT_AUTORIZACAO = SYSDATE "
				+ ", DT_LIBERACAO_GTO        = DECODE(:PTP_GUIA,'D',DECODE(DT_LIBERACAO_GTO, NULL, SYSDATE,DT_LIBERACAO_GTO),NULL) "
				+ " WHERE NR_GUIA = :PNR_GUIA";
		
		DataCommand command = new DataCommand(sql);
		command.addParameter("PNR_GUIA", guiaElement.getNrGuia());
		command.addParameter("PTP_GUIA",guiaElement.getDspTpGuia());
		return command.execute();
	}
	
	@SuppressWarnings("unused")
	public void setPrestadorExecutorHonorario() {
		if (getGuiaHonorarioElement().getDspCdEspecialidade().isNull()) {
			getTask().getMv2000().msgAlert("Informe uma especialidade!", "W", NBool.False);
			getGuiaHonorarioElement().setDspNmPrestador(NString.getNull());
			getGuiaHonorarioElement().setDspCdPrestador(NNumber.getNull());
			ItemServices.goItem("GUIA_HONORARIO.DSP_CD_ESPECIALIDADE");
		} else {
			String msg = "";
			if (getGuiaHonorarioElement().getDspCdPrestador().isNull()) {
				getGuiaHonorarioElement().setDspNmPrestador(NString.getNull());
			} else {
				String sql = " SELECT P.CD_PRESTADOR, P.NM_PRESTADOR                " + "   FROM DBAPS.PRESTADOR               P,                 " + "        DBAPS.ESPECIALIDADE_PRESTADOR E                  " + "  WHERE E.CD_PRESTADOR = P.CD_PRESTADOR                  " + "    AND E.CD_ESPECIALIDADE = :P_CD_ESPECIALIDADE         " + "    AND P.TP_SITUACAO = 'A'                              " + "    AND P.SN_EXECUTOR = 'S'                              " + "    AND P.CD_PRESTADOR = :P_CD_PRESTADOR_EXECUTOR        " + "    AND P.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA ";
				DataCursor cursor = new DataCursor(sql);
				cursor.addParameter("P_CD_ESPECIALIDADE", getGuiaHonorarioElement().getDspCdEspecialidade());
				cursor.addParameter("P_CD_PRESTADOR_EXECUTOR", getGuiaHonorarioElement().getDspCdPrestador());
				try {
					cursor.open();
					
					if (!cursor.found()) {
						throw new ApplicationException("Prestador inválido para a especialidade informada ou não está ativo ou não é executor");
					} else {
						this.getTask().getServices().existeGuiaHonorarioAssociada(getGuiaElement().getNrGuia(), getGuiaHonorarioElement().getDspCdPrestador());
						ResultSet rs = cursor.fetchInto();
						getGuiaHonorarioElement().setDspNmPrestador(rs.getStr("NM_PRESTADOR"));
						;
					}

				} catch (Exception e) {
					e.printStackTrace();
					getTask().getMv2000().msgAlert(e.getMessage(), "W", NBool.True);
				} finally {
					cursor.close();
				}
			}
		}
	}

	/**
	 * Retorna o número de protocolo com padrão ANS da RN395
	 * 
	 * @nome: Anderson Santos <anderson.santos@mv.com.br>
	 * @data: 2016
	 * @param nmModulo
	 * @return
	 */
	public NString fncProtocoloAns(String nmModulo, NNumber nrGuia, NNumber cdMatricula) {
		NString nrProtocolo = NString.getNull();
		String sql = "SELECT DBAPS.FNC_PROTOCOLO_ANS(:PTP_ATENDIMENTO,:PCD_PK,:PCD_MATRICULA,NULL,NULL) FROM DUAL";
		DataCursor dataCursor = new DataCursor(sql);
		ResultSet resultSet = null;
		dataCursor.addParameter("PTP_ATENDIMENTO", nmModulo);
		dataCursor.addParameter("PCD_PK", nrGuia);
		dataCursor.addParameter("PCD_MATRICULA", cdMatricula);
		dataCursor.open();
		if (dataCursor != null && dataCursor.hasData()) {
			resultSet = dataCursor.fetchInto();

			if (resultSet != null && resultSet.hasData()) {

				nrProtocolo = resultSet.getStr(0);
			}
		}
		return nrProtocolo;
	}

	/**
	 * Rosemere Mota
	 * 
	 * @since 12/05/2016 17:56
	 * @param pCodigoEspecialidade
	 * @return
	 */
	public NString getDescricaoEspecialidade(NNumber pCodigoEspecialidade) {
		NString retorno = NString.getNull();
		DataCursor dataCursor = null;
		ResultSet rs = null;

		if (!pCodigoEspecialidade.isNull()) {
			String sql = " SELECT DS_ESPECIALIDADE, CD_ESPECIALIDADE  " + "     FROM DBAPS.ESPECIALIDADE 	" + "    WHERE ((DT_INATIVACAO IS NULL) OR DT_INATIVACAO >= SYSDATE) " + "      AND CD_ESPECIALIDADE = :P_CD_ESPECIALIDADE " + "    ORDER BY DS_ESPECIALIDADE ";
			try {
				dataCursor = new DataCursor(sql);
				dataCursor.addParameter("P_CD_ESPECIALIDADE", pCodigoEspecialidade);
				dataCursor.open();

				rs = dataCursor.fetchInto();
				if (rs != null) {
					if (rs.hasData()) {
						retorno = rs.getStr("DS_ESPECIALIDADE");
					}
					rs.close();
				}

			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				dataCursor.close();
			}
		}
		return retorno;
	}

	/**
	 * Rosemere Mota
	 * 
	 * @since 13/05/2016 09:28
	 * @param pCodigoEspecialidade, pCodigoPrestador Metodo responsavel por
	 * trazer a especialidade de acordo com o Prestador
	 * @return
	 */
	public NString getDescricaoEspecialidadePrestador(NNumber pCodigoEspecialidade, NNumber pCodigoPrestador) {
		NString retorno = NString.getNull();
		DataCursor dataCursor = null;
		ResultSet rs = null;

		if (!pCodigoEspecialidade.isNull()) {
			String sql = " SELECT E.DS_ESPECIALIDADE                                " +
					"   FROM DBAPS.ESPECIALIDADE E                                  " +
					"       ,DBAPS.ESPECIALIDADE_PRESTADOR EP                       " +
					"  WHERE E.CD_ESPECIALIDADE = :P_CD_ESPECIALIDADE               " +
					"    AND E.CD_ESPECIALIDADE = EP.CD_ESPECIALIDADE               " +
					"    AND ((DT_INATIVACAO IS NULL) OR  DT_INATIVACAO >= SYSDATE) " +
					"    AND EP.CD_PRESTADOR = :P_CD_PRESTADOR                      " +
					"    AND :P_CD_PRESTADOR IS NOT NULL                            " +
					"  UNION ALL                                                    " +
					"  SELECT E.DS_ESPECIALIDADE                                    " +
					"   FROM DBAPS.ESPECIALIDADE E                                  " +
					"  WHERE E.CD_ESPECIALIDADE = :P_CD_ESPECIALIDADE               " +
					"    AND :P_CD_PRESTADOR IS NULL                                " ;
			
			try {
				dataCursor = new DataCursor(sql);
				dataCursor.addParameter("P_CD_ESPECIALIDADE", pCodigoEspecialidade);
				dataCursor.addParameter("P_CD_PRESTADOR", pCodigoPrestador);
				dataCursor.open();

				rs = dataCursor.fetchInto();
				if (rs != null) {
					if (rs.hasData()) {

						retorno = rs.getStr("DS_ESPECIALIDADE");
					}
					rs.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				dataCursor.close();
			}
		}
		return retorno;
	}

	/**
	 * PDA : 839526
	 * 
	 * @author rosemere.mota
	 * @since 10/06/2016 16:57 Método que server para inserir Logs
	 * 
	 * @param pNumeroGuia
	 * @param pFuncionalidade
	 * @param pCdAutorizador
	 * @param pCdProcedimento
	 * @param pValorAnterior
	 * @param pValorNovo
	 */
	public void insertLog(NNumber pNumeroGuia, NString pFuncionalidade, NNumber pCdAutorizador, NString pCdProcedimento, NString pValorAnterior, NString pValorNovo) {
		if (!pNumeroGuia.isNull()) {
			String sql = "INSERT INTO DBAPS.LOG_AUTORIZA          		" 
					+ "              (NR_GUIA,                      	" 
					+ "               DS_FUNCIONALIDADE,            	" 
					+ "               NM_USUARIO_ORACLE,            	" 
					+ "               DT_ACAO,                      	" 
					+ "               CD_AUTORIZADOR,               	" 
					+ "               CD_LOG_AUTORIZA,              	" 
					+ "               CD_PROCEDIMENTO,              	" 
					+ "               DS_VALOR_ANTIGO,              	" 
					+ "               DS_VALOR_NOVO)                	" 
					+ "            VALUES                           	" 
					+ "              (:P_NR_GUIA,                   	" 
					+ "               UPPER(:P_MSG),                	" 
					+ "               USER,                         	" 
					+ "               SYSDATE,                      	" 
					+ "               :P_CD_AUTORIZADOR,            	" 
					+ "               DBAPS.SEQ_LOG_AUTORIZA.NEXTVAL, " 
					+ "               :P_CD_PROCEDIMENTO,           	" 
					+ "               :P_VALOR_ANTERIOR,            	" 
					+ "               :P_VALOR_NOVO)                	";

			DataCommand command = new DataCommand(sql);

			command.addParameter("P_NR_GUIA", pNumeroGuia);
			command.addParameter("P_MSG", pFuncionalidade);
			command.addParameter("P_CD_AUTORIZADOR", pCdAutorizador);
			command.addParameter("P_CD_PROCEDIMENTO", pCdProcedimento);
			command.addParameter("P_VALOR_ANTERIOR", pValorAnterior);
			command.addParameter("P_VALOR_NOVO", pValorNovo);

			command.execute();

			TaskServices.executeQuery("LOG_AUTORIZA");
		}
	}

	public NString getTpGuia(GuiaAdapter guiaElement) {
		NString retorno = null;
		StringBuilder sql = new StringBuilder();

		sql.append("SELECT TA.TP_GUIA 									  ");
		sql.append("  FROM DBAPS.GUIA G,                                  ");
		sql.append("       DBAPS.TIPO_ATENDIMENTO TA                      ");
		sql.append("WHERE G.CD_TIPO_ATENDIMENTO = TA.CD_TIPO_ATENDIMENTO  ");
		sql.append("	AND G.NR_GUIA = :P_NR_GUIA                        ");

		DataCursor cCursor = new DataCursor(sql.toString());

		cCursor.addParameter("P_NR_GUIA", guiaElement.getNrGuia());

		try {
			cCursor.open();
			if (cCursor.found()) {
				ResultSet rs = cCursor.fetchInto();
				retorno = rs.getStr("TP_GUIA");
			}
		} finally {
			cCursor.close();
		}
		return retorno;
	}

	public void getMotivoAutorizacao(boolean isValidate) {
		boolean msg = false;
		if (!getGuiaElement().getCdMotivoAutorizacao().isNull()) {
			String sql = " SELECT CD_MOTIVO_AUTORIZACAO, DS_MOTIVO_AUTORIZACAO " + " FROM DBAPS.MOTIVO_AUTORIZACAO WHERE CD_MOTIVO_AUTORIZACAO = :PCD_MOTIVO_AUTORIZACAO ";
			if (isValidate) {
				sql = sql + " AND DT_INATIVACAO IS NULL ";
			}

			DataCursor dataCursor = null;
			ResultSet resultSet = null;
			try {
				dataCursor = new DataCursor(sql);
				dataCursor.addParameter("PCD_MOTIVO_AUTORIZACAO", getGuiaElement().getCdMotivoAutorizacao());
				dataCursor.open();

				if (dataCursor.found()) {
					resultSet = dataCursor.fetchInto();
					getGuiaElement().setDspDsMotivoAutorizacao(resultSet.getStr("DS_MOTIVO_AUTORIZACAO"));
				} else {
					msg = true;
				}

			} catch (Exception ex) {
				ex.printStackTrace();
			} finally {
				if (dataCursor != null)
					dataCursor.close();
			}

			if (msg) {
				getTask().getMv2000().msgAlert(NString.toStr("").append("Operação inválida!").append(Lib.chr(10)).append("Motivo..: O motivo de autorização informação não existe ou está inativo.").append(Lib.chr(10)).append("Ação....: Verifique o motivo de autorização informado..").toString(), "W", /*
				                                                                                                                                                                                                                                                                                               * W
				                                                                                                                                                                                                                                                                                               * =
				                                                                                                                                                                                                                                                                                               * Atenção,
				                                                                                                                                                                                                                                                                                               * I
				                                                                                                                                                                                                                                                                                               * =
				                                                                                                                                                                                                                                                                                               * Informação,
				                                                                                                                                                                                                                                                                                               * E
				                                                                                                                                                                                                                                                                                               * =
				                                                                                                                                                                                                                                                                                               * Erro
				                                                                                                                                                                                                                                                                                               */
				        NBool.True /* bloquear/travar? */);
			}
		} else {
			getGuiaElement().setDspDsMotivoAutorizacao(NString.getNull());
		}
	}
	 
	private void insereLogSMS(String pDsMensagem) {
		
		String sql = "INSERT INTO DBAPS.LOG_AUTORIZA          " +
				"              (NR_GUIA,                      " +
				"               DS_FUNCIONALIDADE,            " +
				"               NM_USUARIO_ORACLE,            " +
				"               DT_ACAO,                      " +
				"               CD_AUTORIZADOR,               " +
				"               CD_LOG_AUTORIZA)              " +
				"            VALUES                           " +
				"              (:P_NR_GUIA,                   " +
				"               :P_MSG,                       " +
				"               USER,                         " +
				"               SYSDATE,                      " +
				"               :P_CD_AUTORIZADOR,            " +
				"               SEQ_LOG_AUTORIZA.NEXTVAL)     ";
		DataCommand command = new DataCommand(sql);

		command.addParameter("P_NR_GUIA", getGuiaElement().getNrGuia());
		command.addParameter("P_MSG", pDsMensagem);
		command.addParameter("P_CD_AUTORIZADOR", Globals.getGlobal("CD_AUTORIZADOR"));
		command.execute();

		TaskServices.executeQuery("LOG_AUTORIZA");		
	}	
	

	/**
	 * 
	 * @param guia NÚMERO DA GUIA
	 * @param dsSmsEnvio DESCRIÇÃO DO ENVIO
	 * @param cdSmsModelo CÓDIGO DO MODELO
	 * @param nrCelular NÚMERO DO TELEFONE QUE SERÁ ENVIADO A MENSAGEM
	 * @param dsMensagem MENSAGEM COMPLETA
	 */
	public void insertSmsEnvio(GuiaAdapter guia, NString dsSmsEnvio, NNumber cdSmsModelo, NString nrCelular, NString dsMensagem) {
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"), "N");
		NString snCortesia = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N"); // Emissão

		int rownum = 0;
		if (nrCelular.isNull()) {
			getTask().getMv2000().msgAlert("Não foi informado um número de telefone.", "W", NBool.True);
		}
		if (Services.ValidaCelular(nrCelular).isFalse()) {
			getTask().getMv2000().msgAlert("O número de celular informado não é um número dos formatos válidos: 5511988888888 / 551188888888 / 11988888888 / 1188888888 " + nrCelular, "E", NBool.True);
		}

		if (dsMensagem.isNull()) {
			getTask().getMv2000().msgAlert("O modelo escolhido não possui mensagem.", "E", NBool.True);
		}
		
		try {
			dsMensagem = NString.toStr(dsMensagem.replace("[CD_GUIA]", Lib.isNull(guia.getNrGuia(), NString.getNull()).toString()));
			dsMensagem = NString.toStr(dsMensagem.replace("[DT_ATEND]", Lib.isNull(Lib.toChar(guia.getDtPrevExecucao(), "DD/MM/YYYY"), NString.getNull()).toString()));
			dsMensagem = NString.toStr(dsMensagem.replace("[DT_AUTORIZACAO]", Lib.isNull(Lib.toChar(guia.getDtAutorizacao(), "DD/MM/YYYY"), NString.getNull()).toString()));
			dsMensagem = NString.toStr(dsMensagem.replace("[NM_EXECUTANTE]", Lib.isNull(guia.getDspNmExecutor(), NString.getNull()).toString()));
			dsMensagem = NString.toStr(dsMensagem.replace("[NM_LOCAL_EXECUCAO]", Lib.isNull(guia.getDsEndereco(), NString.getNull()).toString()));
			dsMensagem = NString.toStr(dsMensagem.replace("[NM_SOLICITANTE]", Lib.isNull(guia.getNmPrestador(), NString.getNull()).toString()));
			dsMensagem = NString.toStr(dsMensagem.replace("[NM_CLIENTE]", Lib.isNull(guia.getDspNmSegurado(), NString.getNull()).toString()));
			dsMensagem = NString.toStr(dsMensagem.replace("[DT_VENCIMENTO]", Lib.isNull(Lib.toChar(getGuiaElement().getDtVencimento(), "DD/MM/YYYY"), NString.getNull()).toString()));

			if (snOperadoraUnimed.equals("S")) {
				if (snCortesia.equals("S")) {
					dsMensagem = NString.toStr(dsMensagem.replace("[CD_CLIENTE]", Lib.isNull(guia.getNrCarteiraBeneficiario(), NString.getNull()).toString()));
				} else {
					dsMensagem = NString.toStr(dsMensagem.replace("[CD_CLIENTE]", Lib.isNull(guia.getCdMatAlternativa(), NString.getNull()).toString()));
				}
			} else {
				dsMensagem = NString.toStr(dsMensagem.replace("[CD_CLIENTE]", Lib.isNull(guia.getCdMatricula(), NString.getNull()).toString()));
			}

			String sql = " INSERT INTO DBAPS.SMS_ENVIO  " 
					   + " (cd_sms_envio                		" 
					   + " ,ds_sms_envio                		" 
					   + " ,cd_sms_modelo               		" 
					   + " ,nr_guia                     		" 
					   + " ,nr_celular                  		" 
					   + " ,ds_mensagem                 		" 
					   + " ,tp_origem                   		" 
					   + " ,cd_usuario_inclusao         		" 
					   + " ,dt_inclusao                 		" 
					   + " ) VALUES                     		" 
					   + " (dbaps.seq_sms_envio.NEXTVAL 		" 
					   + " ,:PDS_SMS_ENVIO              		" 
					   + " ,:PCD_SMS_MODELO             		" 
					   + " ,:PNR_GUIA                   		" 
					   + " ,:PNR_CELULAR                		" 
					   + " ,:PDS_MENSAGEM               		" 
					   + " ,'G'                         		" 
					   + " ,USER                        		" 
					   + " ,SYSDATE                     		" 
					   + " )                            		";

			DataCommand dataCommand = null;

			dataCommand = new DataCommand(sql);
			dataCommand.addParameter("PDS_SMS_ENVIO", dsSmsEnvio);
			dataCommand.addParameter("PCD_SMS_MODELO", cdSmsModelo);
			dataCommand.addParameter("PNR_GUIA", guia.getNrGuia());
			dataCommand.addParameter("PNR_CELULAR", nrCelular);
			if (dsMensagem.getLength() >= 150) {
				dsMensagem = NString.toStr(dsMensagem.substring(0, 150));
			}
			dataCommand.addParameter("PDS_MENSAGEM", dsMensagem);
			rownum = dataCommand.execute();
			
			this.insereLogSMS(dsMensagem.toString());

		} catch (Exception ex) {
			rownum = 0;
			ex.printStackTrace();
			getTask().getMv2000().msgAlert("Não foi possivel fazer o envio da SMS. " + ex.getMessage(), "E", NBool.False);
		}
		if (rownum == 1) {
			String msg = null;
			if (Services.exist("MULTI_EMPRESAS_MV_SAUDE", "DBAMV", "CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA AND DS_SENHA_ZENVIA IS NOT NULL AND DS_LOGIN_ZENVIA IS NOT NULL", false)) {

				ZenviaClient zenviaClient = new ZenviaClient();

				SingleMessageSms singleMessageSms = new SingleMessageSms();

				singleMessageSms.setFrom(""); // FOI COLOCADO VAZIO PORQUE O
				                              // ZENVIA UTILIZA ISSO NA CONTAGEM
				                              // DE CARACTERES E HOJE JÁ TEMOS A
				                              // CHAVE PARA ADICIONAR O NOME DO
				                              // BENEFICIARIO.
				singleMessageSms.setTo("55" + nrCelular);
				singleMessageSms.setSchedule(new Date());
				if (dsMensagem.getLength() >= 150) {
					dsMensagem = NString.toStr(dsMensagem.substring(0, 148));
				}
				singleMessageSms.setMsg(dsMensagem.toString());
				singleMessageSms.setCallbackOption(CallbackOption.NONE);
				singleMessageSms.setAggregatorId(28975);
				singleMessageSms.setId(Services.getDescricao("MAX(CD_SMS_ENVIO) CD_SMS_ENVIO", "SMS_ENVIO", "TP_ORIGEM = 'G' ", false).toString());
				SendSmsResponse sendSmsResponse = null;
				try {
					sendSmsResponse = zenviaClient.sendSms(singleMessageSms);
					//MULTI-IDIOMA: MSG_0030 -  Resposta Zenvia%s Status: %s %s Detalhe: %s
					msg = ResourceManager.getString("guia.msg0030", Lib.chr(10), ZenviaClient.statusCode(Integer.valueOf(sendSmsResponse.getStatusCode())), Lib.chr(10), ZenviaClient.detailCode(Integer.valueOf(sendSmsResponse.getDetailCode())));
				} catch (Exception e) {
					e.printStackTrace();
					//MULTI-IDIOMA: MSG_0030 -  Resposta Zenvia%s Status: %s %s Detalhe: %s
					msg = ResourceManager.getString("guia.msg0030", Lib.chr(10), ZenviaClient.statusCode(Integer.valueOf(10)), Lib.chr(10), ZenviaClient.detailCode(Integer.valueOf(999)));
				}
			}
			//MULTI-IDIOMA: MSG_0054 - Processo de envio realizado com sucesso!
			getTask().getMv2000().msgAlert(NString.toStr(msg).append(Lib.chr(10)).append(ResourceManager.getString("guia.msg0054")).toString(), "I", NBool.False);
		}
	}

	public boolean isProcedimentoUniversal(NString cdProcedimento) {
		NString snProcedimentoUniversal = Services.getDescricao("SN_PROCED_UNIVERSAL", "PROCEDIMENTO", "CD_PROCEDIMENTO = '" + cdProcedimento + "'", false);
		return snProcedimentoUniversal.equals("S");
	}

	public boolean isProcedimentoBaixoRisco(NDate dtEmissao, NString cdProcedimento, NNumber qtProcedimento) {
		boolean retorno = false;

		String sql = " SELECT 1 FROM DBAPS.PROCEDIMENTO_BAIXO_RISCO WHERE :P_DT_EMISSAO BETWEEN DT_VIGENCIA AND NVL(DT_INATIVACAO, :P_DT_EMISSAO) AND CD_PROCEDIMENTO = :P_CD_PROCEDIMENTO AND NR_QUANTIDADE >= :P_QT_PROCEDIMENTO ";
		DataCursor cCursor = new DataCursor(sql);

		try {
			cCursor.addParameter("P_CD_PROCEDIMENTO", cdProcedimento);
			cCursor.addParameter("P_DT_EMISSAO", dtEmissao);
			cCursor.addParameter("P_QT_PROCEDIMENTO", qtProcedimento);
			cCursor.open();

			if (cCursor.found()) {
				ResultSet rs = cCursor.fetchInto();
				if (rs.hasData()) {
					retorno = true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cCursor.close();
		}
		return retorno;
	}

	/**
	 * Carrega o campo da matricula do beneficiário e da unimed do beneficiário
	 * 
	 * @since 20/12/2016
	 * @param cdBeneficiarioTransito
	 */
	public void getBeneficiarioTransito(NNumber cdBeneficiarioTransito) {
		String sql = "" + " SELECT DBAPS.FNC_RETORNA_CARTEIRA_UNIMED(BT.CD_MATRICULA) CD_MATRICULA, " + "   FROM DBAPS.BENEFICIARIO_TRANSITO BT,                                  " + "         DBAPS.PTU_UNIMED PU                                             " + "		  DBAPS.UNIMED U 												   " + "   WHERE BT.CD_UNIMED = PU.CD_UNIMED(+)                                  " + "     AND U.CD_UNIMED = PU.CD_UNIMED									   " + "     AND BT.CD_BENEFICIARIO_TRANSITO = :P_CD_BENEFICIARIO_TRANSITO       ";
		DataCursor dataCursor = null;
		ResultSet resultSet = null;

		try {
			dataCursor = new DataCursor(sql);
			dataCursor.addParameter("P_CD_BENEFICIARIO_TRANSITO", cdBeneficiarioTransito);
			dataCursor.open();

			if (dataCursor.found()) {
				resultSet = dataCursor.fetchInto();
				getGuiaElement().setNrCarteiraBeneficiario(resultSet.getStr("CD_MATRICULA"));
			}
		} finally {
			if (dataCursor != null) {
				dataCursor.close();
			}
			if (resultSet != null) {
				resultSet.close();
			}
		}
	}

	public void getRedeReferenciadaPrestador(NNumber cdPrestadorEndereco, NNumber cdRedeReferenciada, boolean error) {
		if (mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED") != null && mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED").equals("S") && Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N").equals("S")) {
			String sql = "" + " SELECT RR.CD_REDE_REFERENCIADA,RR.DS_REDE_REFERENCIADA           " + "   FROM DBAPS.REDE_REFERENCIADA RR,                               " + "         DBAPS.REST_PRES_END_REDE_REFERENC RPERR                  " + "   WHERE CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA           " + "       AND RR.CD_REDE_REFERENCIADA = RPERR.CD_REDE_REFERENCIADA   " + "       AND RPERR.CD_PRESTADOR_ENDERECO = :P_CD_PRESTADOR_ENDERECO ";
			if (!cdRedeReferenciada.isNull()) {
				sql += "       AND RR.CD_REDE_REFERENCIADA = :P_CD_REDE_REFERENCIADA    ";
			}

			DataCursor dataCursor = null;
			ResultSet resultSet = null;
			try {
				dataCursor = new DataCursor(sql);
				dataCursor.addParameter("P_CD_PRESTADOR_ENDERECO", cdPrestadorEndereco);

				if (!cdPrestadorEndereco.isNull()) {
					dataCursor.addParameter("P_CD_REDE_REFERENCIADA", cdRedeReferenciada);
				}

				dataCursor.open();

				if (dataCursor.found()) {
					if (dataCursor.getRowCount() == 1) {
						resultSet = dataCursor.fetchInto();
						getGuiaElement().setCdRedeReferenciada(resultSet.getNumber("CD_REDE_REFERENCIADA"));
						getGuiaElement().setDspDsRedeReferenciada(resultSet.getStr("DS_REDE_REFERENCIADA"));
					}
				} else {
					if (error) {
						getTask().getMv2000().msgAlert(NString.toStr("").append("Operação inválida!").append(Lib.chr(10)).append("Motivo..: Não foi encontrado rede referenciada para este endereço..").append(Lib.chr(10)).append("Ação....: Verifique o cadastro do prestador.").toString(), "W", /*
						                                                                                                                                                                                                                                                                               * W
						                                                                                                                                                                                                                                                                               * =
						                                                                                                                                                                                                                                                                               * Atenção,
						                                                                                                                                                                                                                                                                               * I
						                                                                                                                                                                                                                                                                               * =
						                                                                                                                                                                                                                                                                               * Informação,
						                                                                                                                                                                                                                                                                               * E
						                                                                                                                                                                                                                                                                               * =
						                                                                                                                                                                                                                                                                               * Erro
						                                                                                                                                                                                                                                                                               */
						        NBool.True /* bloquear/travar? */);
					}
				}
			} finally {
				if (dataCursor != null) {
					dataCursor.close();
				}
				if (resultSet != null) {
					resultSet.close();
				}
			}
		}
	}

	public void getDsEspecialidade(NNumber cdEspecialidade) {
		String sql = " SELECT DS_ESPECIALIDADE FROM DBAPS.ESPECIALIDADE WHERE CD_ESPECIALIDADE = :P_CD_ESPECIALIDADE ";

		DataCursor dc = new DataCursor(sql);
		dc.addParameter("P_CD_ESPECIALIDADE", cdEspecialidade);
		
		try {
			ResultSet rs = dc.fetchInto();
			if (rs != null) {
				getGuiaElement().setDspEspecialidadeSolicitante(rs.getStr("DS_ESPECIALIDADE"));
			}
		} finally {
			dc.close();
		}
	}

	/**
	 * Retorna a consulta para ser utilizada nos validates do tipo de
	 * acomodação.
	 * 
	 * @param pCdTipAcomodacao tipo de acomodação
	 * @param cdPlano plano
	 * @return ResultSet com valores do tipo de acomodação
	 */
	public ResultSet cdTipoAcomodocacao_validate(NNumber pCdTipAcomodacao, NNumber cdPlano) {
		NString sql = NString.toStr(" SELECT TIP_ACOMODACAO.CD_TIP_ACOMODACAO, TIP_ACOMODACAO.DS_TIP_ACOMODACAO ").append(" FROM DBAPS.TIP_ACOMODACAO ").append(" WHERE NVL(TIP_ACOMODACAO.NR_NIVEL, 0) <= ").append(" Nvl((SELECT NVL(TIP_ACO.NR_NIVEL, 0) NR_NIVEL ").append(" FROM DBAPS.TIP_ACOMODACAO TIP_ACO, DBAPS.PLANO ").append(" WHERE PLANO.CD_PLANO = :GUIA_DSP_CD_PLANO ").append(" AND PLANO.CD_TIP_ACOMODACAO = TIP_ACO.CD_TIP_ACOMODACAO ").append(" AND PLANO.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA),99) ").append(" AND TIP_ACOMODACAO.CD_TIP_ACOMODACAO = :P_CD_TIP_ACOMODACAO ").append(" ORDER BY DS_TIP_ACOMODACAO ");

		DataCursor dataCursor = null;
		ResultSet resultSet = null;

		dataCursor = new DataCursor(sql.toString());
		dataCursor.addParameter("P_CD_TIP_ACOMODACAO", pCdTipAcomodacao);
		dataCursor.addParameter("GUIA_DSP_CD_PLANO", cdPlano);
		dataCursor.open();
		if (dataCursor.found()) {
			resultSet = dataCursor.fetchInto();
			dataCursor.close();
		}
		return resultSet;
	}

	/**
	 * Retorna a quantidade de an
	 * 
	 * @param nrGuiaTem
	 * @return
	 */
	public ResultSet getAnexoAssociadaGuiaPrincipal(NNumber nrGuiaTem, NString pTpGuia) {
		ResultSet resultSet = null;
		if (!nrGuiaTem.isNull()) {
			NString sql = NString.toStr("SELECT G.NR_GUIA ")
									 .append(" , G.NR_GUIA_TEM ")
									 .append(" , G.CD_TIPO_ATENDIMENTO ")
									 .append(" , TA.DS_TIPO_ATENDIMENTO ")
									 .append(" FROM DBAPS.GUIA G, DBAPS.TIPO_ATENDIMENTO TA ")
									 .append(" WHERE G.NR_GUIA_TEM IS NOT NULL ")
									 .append(" AND G.CD_TIPO_ATENDIMENTO = TA.CD_TIPO_ATENDIMENTO")
									 .append(" AND TA.TP_GUIA = :P_TP_GUIA ")
									 .append(" AND G.CD_MOT_CANCELAMENTO_GUIA IS NULL")
									 .append(" AND G.NR_GUIA_TEM = :P_NR_GUIA_TEM ");
			
			DataCursor dataCursor = null;
			dataCursor = new DataCursor(sql.toString());
			dataCursor.addParameter("P_NR_GUIA_TEM", nrGuiaTem);
			dataCursor.addParameter("P_TP_GUIA", pTpGuia);
			
			try {
				dataCursor.open();
				
				if (dataCursor.found()) {
					resultSet = dataCursor.fetchInto();
				}
			} catch(Exception e){
				e.printStackTrace();
			} finally {
				dataCursor.close();
			}
		}
		return resultSet;
	}

	/**
	 * O Parametro CHAMA_AUTORIZ pode ser os seguintes valores.
	 * 
	 * L = Liberação de Guia 
	 * C = Cancelamento de Guia 
	 * R = Cancelamento da Guia de Prorrogação 
	 * A = Alteração do Prestador da Guia 
	 * S = Alteração do Status da Guia 
	 * P = Liberacao da Guia de Prorrogação 
	 * V = Alteração do valor do procedimento 
	 * PTU-I = PTU Online Insistência
	 * PTU-AI = PTU Online Comunicação de Internação ou Alta do Beneficiário
	 */
	public void configuraSolicitacaoSenha(NString chamaAutoriz) {
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"), "N");
		this.getFormModel().getCgCtrl().setDspSnAplicarTodos(NString.toStr("N"));
		
		//Status
		ViewServicesExtensions.setVisualAttribute("canvasProcessoCamposAplicarEmTodos", "Visible", chamaAutoriz.equals("S"));
		ItemServices.setItemVisible("CG$CTRL.DSP_SN_APLICAR_TODOS", chamaAutoriz.equals("S"));
		ItemServices.setItemVisible("CG$CTRL.TP_STATUS", chamaAutoriz.equals("S"));
		
		if ( chamaAutoriz.equals("S") && snOperadoraUnimed.equals("S") && getGuiaElement().getTpFluxoPtuWs().equals("CLIENT") && !getGuiaElement().getCdUnimedOrigem().equals(getGuiaElement().getCdUnimedExecutora())) {
			getTask().getMv2000().msgAlert("Não é permitido alterar o status do procedimento.", "W", NBool.True);
		}
		
		//Liberação
		ViewServicesExtensions.setVisualAttribute("canvasProcessoCamposMotivoAutorizacao", "Visible", chamaAutoriz.equals("L"));
		ItemServices.setItemVisible("CG$CTRL.CD_MOTIVO_AUTORIZACAO", chamaAutoriz.equals("L"));
		ItemServices.setItemVisible("CG$CTRL.DSP_DS_MOTIVO_AUTORIZACAO", chamaAutoriz.equals("L"));
		
		//Cancelamento
		ViewServicesExtensions.setVisualAttribute("canvasProcessoCamposNegativa", "Visible", chamaAutoriz.equals("C") || chamaAutoriz.equals("R"));
		ViewServicesExtensions.setVisualAttribute("canvasProcessoCamposNegativaObservacao", "Visible", chamaAutoriz.equals("C") || chamaAutoriz.equals("R"));
		ItemServices.setItemVisible("CG$CTRL.CD_MOT_CANCELAMENTO", chamaAutoriz.equals("C") || chamaAutoriz.equals("R"));
		ItemServices.setItemVisible("CG$CTRL.DSP_DS_MOT_CANCELAMENTO", chamaAutoriz.equals("C") || chamaAutoriz.equals("R"));
		ItemServices.setItemVisible("CG$CTRL.DSP_DS_OBSERVACAO_CANCELAMENTO", chamaAutoriz.equals("C") || chamaAutoriz.equals("R"));
		ItemServices.setItemVisible("CG$CTRL.DSP_TP_MOT_CANCELAMENTO", chamaAutoriz.equals("C") || chamaAutoriz.equals("R"));
		ItemServices.setItemVisible("CG$CTRL.BTN_CD_MOT_CANCELAMENTO", chamaAutoriz.equals("R"));
		
		ViewServicesExtensions.setVisualAttribute("canvasProcessoCamposSnCancelaAutorizacao", "Visible", 
																		(chamaAutoriz.equals("C") && getGuiaElement().getSnValidaRestCarencia().equals("S")) 
																		|| (chamaAutoriz.equals("R") && getGuiaProrrogacaoElement().getSnAutorizado().equals("S")));
		ItemServices.setItemVisible("CG$CTRL.SN_CANCELA_AUTORIZACAO", (chamaAutoriz.equals("C") && getGuiaElement().getSnValidaRestCarencia().equals("S")) 
																		|| (chamaAutoriz.equals("R") && getGuiaProrrogacaoElement().getSnAutorizado().equals("S")));
				
		if (getGuiaElement().getTpFluxoPtuWs().equals("CLIENT") && !getGuiaElement().getCdUnimedOrigem().equals(getGuiaElement().getCdUnimedExecutora())) {
			ItemServices.setItemVisible("CG$CTRL.SN_CANCELA_AUTORIZACAO", false);
			ViewServicesExtensions.setVisualAttribute("canvasProcessoCamposSnCancelaAutorizacao", "Visible",false);
		}
		
		//Pedido de Insistencia
		ViewServicesExtensions.setVisualAttribute("canvasProcessoCamposMensagemLivreInsistencia", "Visible", chamaAutoriz.equals("PTU-I") || chamaAutoriz.equals("PTU-AI"));
		ItemServices.setItemVisible("CG$CTRL.DSP_DS_MENSAGEM_LIVRE", chamaAutoriz.equals("PTU-I") || chamaAutoriz.equals("PTU-AI"));
		
		ItemServices.setItemVisible("CG$CTRL.CD_AUTORIZADOR_OPE", !chamaAutoriz.equals("PTU-I"));
		ItemServices.setItemVisible("CG$CTRL.DSP_NM_AUTORIZADOR_OPE", !chamaAutoriz.equals("PTU-I"));
		ItemServices.setItemVisible("CG$CTRL.DS_SENHA_AUTORIZACAO_SEM_BASE", !chamaAutoriz.equals("PTU-I"));
		
		ViewServicesExtensions.setVisualAttribute("canvasProcessoComunicInternacao", "Visible", chamaAutoriz.equals("PTU-AI"));
		
		if (chamaAutoriz.equals("PTU-AI")) {
			getFormModel().getCgCtrl().setDtPtuEvento(NDate.getNow());
		}
		
		ItemServices.setItemVisible("CG$CTRL.DT_PTU_EVENTO", chamaAutoriz.equals("PTU-AI"));
		
		this.getFormModel().setParam("CHAMA_AUTORIZ", chamaAutoriz);
		ItemServices.goItem("CG$CTRL","BTN_OK");
	}

	@SuppressWarnings("rawtypes")
	public void leitorMagnetico() {
		NString snOperadoraUnimed = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"), "N");
		NString snCortesia = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");

		if (!ItemServices.findItem("GUIA.CD_MATRICULA").getEnabled() && !BlockServices.getBlockMode(BlockServices.findBlock("GUIA")).equals(InteractionBlockMode.Search)) {
			ItemServices.goItem("GUIA.NR_GUIA");
			return;
		}

		SecureRandom random = new SecureRandom();
		NString nomeGlobal = NString.toStr(new BigInteger(130, random).toString(32));

		try {
			Hashtable plId = TaskServices.getParameterList("GUIA");

			if (plId == null) {
				plId = TaskServices.createParameterList("GUIA");
			} else {
				plId.clear();
			}
			TaskServices.addParameter(plId, "P_MATRICULA_HASH", nomeGlobal);
			TaskServices.callTask("O_LEITURA_CARTEIRA_BENEFICIARIO", TaskServices.NO_HIDE, TaskServices.NO_REPLACE, TaskServices.NO_QUERY_ONLY, plId);
		} catch (Exception e) {

		} finally {

		}

		if (Globals.getGlobal(nomeGlobal).isNull()) {
			Globals.removeGlobal(nomeGlobal.toString());
			return;
		}

		NString matriculaTratada = Globals.getGlobal(nomeGlobal);
		Globals.removeGlobal(nomeGlobal.toString());

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (snOperadoraUnimed.equals("S")) {
			if (snCortesia.equals("S")) {
				guiaElement.setNrCarteiraBeneficiario(matriculaTratada);
				((GuiaController) this.getTask().getFormController().getBlockController("GUIA")).nr_carteira_beneficiario_validation();
			} else {
				guiaElement.setCdMatAlternativa(matriculaTratada);
				((GuiaController) this.getTask().getFormController().getBlockController("GUIA")).cd_mat_alternativa_validation();
			}
		} else {
			guiaElement.setCdMatricula(NNumber.toNumber(matriculaTratada));
			((GuiaController) this.getTask().getFormController().getBlockController("GUIA")).cdMatricula_validate();
		}
	}

	public NString fncRetornaTipoBeneficiario(NNumber cdMatricula, NString nrCarteiraBeneficiario) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("DBAPS.FNC_RETORNA_TIPO_BENEFICIARIO", DbManager.getDataBaseFactory());
		cmd.addReturnParameter(NString.class);
		cmd.addParameter("@PCD_MATRICULA", cdMatricula);
		cmd.addParameter("@PNR_CARTEIRA_BENEFICIARIO", nrCarteiraBeneficiario);
		cmd.addParameter("@PDT_REFERENCIA", DbManager.getDBDate());
		cmd.execute();
		return Lib.isNull(cmd.getReturnValue(NString.class), NString.getNull());
	}

	public NString fncStatusGuia(NNumber nrGuia) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("DBAPS.FNC_STATUS_GUIA", DbManager.getDataBaseFactory());
		cmd.addReturnParameter(NString.class);
		cmd.addParameter("@PNR_GUIA", nrGuia);
		cmd.execute();
		NString retorno = cmd.getReturnValue(NString.class);
		if (retorno.getLength() > 4) {
			retorno = NString.toStr(retorno.substring(0, retorno.getLength() - 3));
		}
		return retorno;
	}

	/**
	 * Realiza as validações do PTU de acordo com o tipo de guia e tipo de anexo
	 * <br />
	 * Obs: Somente adicionar as validações do ptu Online Aqui.
	 * 
	 * @param guiaElement
	 * @param itGuiaElement
	 */
	public void validacoesPtuOnline(GuiaAdapter guiaElement, ItguiaAdapter itGuiaElement) {
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"), "N");
		NString tpGuia = guiaElement.getDspTpGuia();

		if ("S".equals(snOperadoraUnimed.toString())) {
			this.getTask().getServices().configurarCampo("ITGUIA.NR_ANVISA", true, false, true);
			this.getTask().getServices().configurarCampo("ITGUIA.CD_MATERIAL_FABRICANTE", true, false, true);
			if ("1".equals(itGuiaElement.getTpIndicadorAnexo().toString())) {
				boolean isQuimio = "Q".equals(tpGuia.toString());
				this.getTask().getServices().configurarCampo("ITGUIA.CD_VIA_ADMINISTRACAO", true, isQuimio);
				this.getTask().getServices().configurarCampo("ITGUIA.DT_PROVAVEL", true, isQuimio);
				this.getTask().getServices().configurarCampo("ITGUIA.QT_SOLICITADO_DIA", true, isQuimio);
				this.getTask().getServices().configurarCampo("ITGUIA.QT_TOTAL_DOSAGEM_CICLO", true);
			} else if ("2".equals(itGuiaElement.getTpIndicadorAnexo().toString())) {
			} else if ("3".equals(itGuiaElement.getTpIndicadorAnexo().toString())) {
			} else if ("9".equals(itGuiaElement.getTpIndicadorAnexo().toString())) {
				this.getTask().getServices().configurarCampo("ITGUIA.CD_VIA_ADMINISTRACAO", true);
				this.getTask().getServices().configurarCampo("ITGUIA.DT_PROVAVEL", true);
				this.getTask().getServices().configurarCampo("ITGUIA.QT_SOLICITADO_DIA", true);
			} else {
			}
		}
	}

	/**
	 * 
	 * Recebe o campo, se vai habilitar por default não coloca o item como
	 * obrigatório.
	 * 
	 * @param campo
	 * @param habilitar
	 */
	public void configurarCampo(String campo, boolean habilitar) {
		configurarCampo(campo, habilitar, false);
	}

	/**
	 * Recebe o campo, se vai habilitar por default não coloca o item como
	 * obrigatório.
	 * @param campo
	 * @param habilitar
	 * @param obrigatorio
	 * @param visible
	 */
	public void configurarCampo(String campo, boolean habilitar, boolean obrigatorio, boolean visible) {
		ItemServices.setItemVisible(campo, visible);
		configurarCampo(campo, habilitar, obrigatorio);
	}

	/**
	 * Recebe o campo, se vai habilitar ou se coloca o item como obrigatório.
	 * 
	 * @param campo
	 * @param habilitar
	 * @param obrigatorio
	 */
	public void configurarCampo(String campo, boolean habilitar, boolean obrigatorio) {
		ItemServices.setItemEnabled(campo, habilitar);
		ItemServices.setItemNavigable(campo, habilitar);
		ItemServices.setItemInsertAllowed(campo, habilitar);
		ItemServices.setItemUpdateAllowed(campo, habilitar);
		ItemServices.setItemRequired(campo, obrigatorio);
	}

	public boolean existeMensagensNaoLidas(NNumber nrGuia, NNumber cdPrestadorExecutante) {
		String sql = " SELECT 1 QTD	    						  " 
			       + "   FROM DBAPS.CHAT          C,                      " 
				   + "        DBAPS.CHAT_MENSAGEM CM                      " 
			       + "  WHERE C.CD_CHAT = CM.CD_CHAT                      " 
				   + "    AND C.NR_GUIA = :PNR_GUIA                       " 
			       + "    AND C.CD_PRESTADOR = :PCD_PRESTADOR_EXECUTANTE  " 
				   + "    AND CM.TP_ORIGEM = 'P'                          " 
			       + "    AND CM.TS_VISUALIZACAO IS NULL                  " 
				   + "    AND CM.TS_CRIACAO = (SELECT MAX(TS_CRIACAO)     " 
			       + "                           FROM DBAPS.CHAT_MENSAGEM " 
				   + "                          WHERE CD_CHAT = C.CD_CHAT " 
			       + "                            AND TP_ORIGEM = 'P')    ";

		DataCursor cCursor = new DataCursor(sql);
		try {
			cCursor.addParameter("PNR_GUIA", nrGuia);
			cCursor.addParameter("PCD_PRESTADOR_EXECUTANTE", cdPrestadorExecutante);
			cCursor.open();

			if (cCursor.found()) {
				return true;
			} else {
				return false;
			}

		} finally {
			cCursor.close();
		}
	}

	/**
	 * Função que retorna a descrição do motivo de negativa da guia para o tipo
	 * informado C - Cancelamento, N - Negar
	 * 
	 * @param cdMotCancelamentoGuia Código do motivo
	 * @param tpNegativa - C ou N
	 * @param isValidate
	 * @return Descrição do código informado.
	 */
	public NString getMotCancelamentoGuia(NNumber cdMotCancelamentoGuia, boolean isValidate) {
		String sql = " SELECT DS_MOT_CANCELAMENTO_GUIA " + " FROM DBAPS.MOT_CANCELAMENTO_GUIA " + " WHERE CD_MOT_CANCELAMENTO_GUIA = :PCD_MOT_CANCELAMENTO_GUIA ";
		DataCursor cCursor = new DataCursor(sql);
		try {
			cCursor.addParameter("PCD_MOT_CANCELAMENTO_GUIA", cdMotCancelamentoGuia);
			cCursor.open();

			if (cCursor.found()) {
				ResultSet rs = cCursor.fetchInto();
				return rs.getStr("DS_MOT_CANCELAMENTO_GUIA");
			}
		} finally {
			cCursor.close();
		}
		return NString.getNull();
	}

	/**
	 * ATUALIZA O CAMPO DT_IMPRESSAO_GUIA
	 * 
	 * @param nrGuia
	 */
	public void setDtGuiaImpressa(NNumber nrGuia) {
		if (getGuiaElement().getDtImpressaoGuia().isNull()) {
			getGuiaElement().setDtImpressaoGuia(DbManager.getDBDateTime());
			//MULTI-IDIOMA: MSG_0044 - EMITIDA
			getGuiaElement().setDspDsImpressaoGuia(NString.toStr(ResourceManager.getString("guia.msg0044")));
			TaskServices.commitTask();
		}
	}

	/**
	 * Usado ao negar um item da guia.
	 * 
	 * @param pCdItGuia Código da itGuia
	 * @param pCdMotivoPtu Código do de/para do motivo de glosa.
	 */
	public void insertItGuiaMensagemEspecifica(NNumber nrGuia, NNumber pCdItGuia, NNumber pCdMotivoPtu,NString snTodosOsProcedimentos) {
		String sqlCommand = "";
		
		if (snTodosOsProcedimentos.equals("N")) {
			sqlCommand = "INSERT INTO DBAPS.ITGUIA_MENSAGEM_ESPECIFICA(CD_ITGUIA, CD_ITGUIA_MENSAGEM_ESPECIFICA, CD_PTU_MENSAGEM_ESPECIFICA) VALUES (:PCD_ITGUIA, DBAPS.SEQ_ITGUIA_MENSAGEM_ESPECIFICA.NEXTVAL, :PCD_PTU_MENSAGEM_ESPECIFICA)";			
		}else if(snTodosOsProcedimentos.equals("S")){
			sqlCommand = " INSERT INTO DBAPS.ITGUIA_MENSAGEM_ESPECIFICA                                 " +
					"   (CD_ITGUIA,                                                                     " +
					"    CD_PTU_MENSAGEM_ESPECIFICA,                                                    " +
					"    CD_PTU_MENSAGEM_ESPECIFICA)                                                    " +
					"   SELECT ITG.CD_ITGUIA,                                                           " +
					"          DBAPS.SEQ_ITGUIA_MENSAGEM_ESPECIFICA.NEXTVAL,                            " +
					"          :PCD_PTU_MENSAGEM_ESPECIFICA                                             " +
					"     FROM DBAPS.ITGUIA ITG                                                         " +
					"    WHERE ITG.NR_GUIA = :PNR_GUIA                                                  " +
					"      AND NOT EXISTS (SELECT 1                                                     " +
					"             FROM DBAPS.ITGUIA_MENSAGEM_ESPECIFICA IME2                            " +
					"            WHERE IME2.CD_ITGUIA = ITG.CD_ITGUIA                                   " +
					"              AND IME2.CD_PTU_MENSAGEM_ESPECIFICA = :PCD_PTU_MENSAGEM_ESPECIFICA)  " ;
		}
		
		DataCommand command = new DataCommand(sqlCommand);
		if (snTodosOsProcedimentos.equals("N")) {
			command.addParameter("PCD_ITGUIA", pCdItGuia);			
		}else if(snTodosOsProcedimentos.equals("S")){
			command.addParameter("PNR_GUIA", pCdItGuia);
		}
		command.addParameter("PCD_PTU_MENSAGEM_ESPECIFICA", pCdMotivoPtu);
		command.execute();
	}

	/**
	 * Por conta do bloco da guia está bloqueiado não e possivel alterar o valor do campo e para evitar dados alterados por outro usuário e realizado um update informando o valor passado.
	 * @param nrGuia
	 * @param dtAltaInternacao
	 */
	public void setDtAltaInternacao(NNumber nrGuia, NDate dtAltaInternacao){
		if (getGuiaElement().getDtAltaInternacao().isNull() && !dtAltaInternacao.isNull()) {
			getGuiaElement().setDtAltaInternacao(dtAltaInternacao);
		}
	}
	
	public void setDtExecucaoInternacao(NNumber nrGuia, NDate dtExecucaoInternacao, NString snOperadoraUnimed){
		if (!dtExecucaoInternacao.isNull() && snOperadoraUnimed.equals("N")) {
			if (isGuiaExistente(nrGuia) && !getGuiaElement().getDtExecucaoInternacao().isNull() &&
					isDtExecucaoInternacaoAlterada(nrGuia, dtExecucaoInternacao)) {
				NNumber cdAutorizador = null;
				ResultSet rs = GuiaServices.getAutorizadorLogado();
				if(rs != null){
					cdAutorizador = rs.getNumber("CD_AUTORIZADOR");
				}
				insertLog(nrGuia, NString.toStr("ALTERACAO DA DATA DE EXECUCAO DE INTERNACAO"), cdAutorizador, NString.getNull(), NString.toStr(getGuiaElement().getDtExecucaoInternacao()), NString.toStr(dtExecucaoInternacao));
			}
			getGuiaElement().setDtExecucaoInternacao(dtExecucaoInternacao);
		}
	}
	
	public NNumber fncAnalisarGuia(NNumber pnrGuia,NNumber psqGuiaProrrogacao,NString psnProrrogacao) {
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("DBAPS.FNC_ANALISAR_GUIA", DbManager.getDataBaseFactory());
		cmd.addReturnParameter(NNumber.class);
		cmd.addParameter("@PNR_GUIA", pnrGuia);
		cmd.addParameter("@PSQ_GUIA_PRORROGACAO", psqGuiaProrrogacao);
		cmd.addParameter("@PSN_PRORROGACAO", psnProrrogacao);
		cmd.execute();
		return cmd.getReturnValue(NNumber.class);
	}
	
	public void configuracoesUruguai(NString tpPais){
		
		ItemServices.setItemEnabled("GUIA.BTN_AGENDA", tpPais.equals("URU"));
		ItemServices.setItemVisible("GUIA.BTN_AGENDA", tpPais.equals("URU"));
		
		ItemServices.setItemEnabled("GUIA.BTN_HOME_CARE", tpPais.equals("URU"));
		ItemServices.setItemVisible("GUIA.BTN_HOME_CARE", tpPais.equals("URU"));
		
		ItemServices.setItemEnabled("GUIA.BTN_ATENDIMENTO_URGENCIA", tpPais.equals("URU"));
		ItemServices.setItemVisible("GUIA.BTN_ATENDIMENTO_URGENCIA", tpPais.equals("URU"));
		ViewServices.setTabPageVisible("PAGE_TAXAS", tpPais.equals("URU"));
		
	}
	
	/**
	 * Validações para os Oculos
	 * @param itguiaOculosAdapter
	 */
	public void chkItGuiaOculos(ItguiaOculosAdapter itguiaOculosAdapter) {
		if (getGuiaElement().getDspTpGuia().equals("B")) {/* Reembolso */
			if(	itguiaOculosAdapter.getTpLongeEsfericoDireito().isNull() 
					&& itguiaOculosAdapter.getTpLongeEsfericoEsquerdo().isNull() 
					&& itguiaOculosAdapter.getTpLongeCilindroDireito().isNull() 
					&& itguiaOculosAdapter.getTpLongeCilindroEsquerdo().isNull() 
					&& itguiaOculosAdapter.getTpPertoEsfericoDireito().isNull()
					&& itguiaOculosAdapter.getTpPertoEsfericoEsquerdo().isNull()
					&& itguiaOculosAdapter.getTpPertoCilindroDireito().isNull()
					&& itguiaOculosAdapter.getTpPertoCilindroEsquerdo().isNull()){
					getTask().getMv2000().msgAlert("Valor do [ " +ResourceManager.getString("guia.itguiaOculos.tpLongeEsfericoDireito.label")+ " ] inválido.", "W", NBool.True);
				}
			
			/** Longe **/
			/* Esférico */
			if (!itguiaOculosAdapter.getTpLongeEsfericoDireito().isNull() && itguiaOculosAdapter.getVlLongeEsfericoDireito().isNull()) {
				ItemServices.goItem("ITGUIA_OCULOS.VL_LONGE_ESFERICO_DIREITO");
				//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ResourceManager.getString("guia.itguiaOculos.tpLongeEsfericoDireito.label")), "W", NBool.True);
			} else if(itguiaOculosAdapter.getTpLongeEsfericoDireito().isNull()) {
				itguiaOculosAdapter.setVlLongeEsfericoDireito(NNumber.getNull());
			}
			
			if (!itguiaOculosAdapter.getTpLongeEsfericoEsquerdo().isNull() && itguiaOculosAdapter.getVlLongeEsfericoEsquerdo().isNull()) {
				ItemServices.goItem("ITGUIA_OCULOS.VL_LONGE_ESFERICO_ESQUERDO");
				//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ResourceManager.getString("guia.itguiaOculos.tpLongeEsfericoEsquerdo.label")), "W", NBool.True);
			} else if(itguiaOculosAdapter.getTpLongeEsfericoEsquerdo().isNull()) {
				itguiaOculosAdapter.setVlLongeEsfericoEsquerdo(NNumber.getNull());
			}

			/* Cilindro */
			if (!itguiaOculosAdapter.getTpLongeCilindroDireito().isNull() && itguiaOculosAdapter.getVlLongeCilindroDireito().isNull()) {
				ItemServices.goItem("ITGUIA_OCULOS.VL_LONGE_CILINDRO_DIREITO");
				//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("ITGUIA_OCULOS.TP_LONGE_CILINDRO_DIREITO")), "W", NBool.True);
			} else if(itguiaOculosAdapter.getTpLongeCilindroDireito().isNull()) {
				itguiaOculosAdapter.setVlLongeCilindroDireito(NNumber.getNull());
			}
			
			if (!itguiaOculosAdapter.getTpLongeCilindroEsquerdo().isNull() && itguiaOculosAdapter.getVlLongeCilindroEsquerdo().isNull()) {
				ItemServices.goItem("ITGUIA_OCULOS.VL_LONGE_CILINDRO_ESQUERDO");
				//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("ITGUIA_OCULOS.TP_LONGE_CILINDRO_ESQUERDO")), "W", NBool.True);
			} else if(itguiaOculosAdapter.getTpLongeCilindroEsquerdo().isNull()) {
				itguiaOculosAdapter.setVlLongeCilindroEsquerdo(NNumber.getNull());
			}
			
			/** Perto **/
			/* Esférico */
			if (!itguiaOculosAdapter.getTpPertoEsfericoDireito().isNull() && itguiaOculosAdapter.getVlPertoEsfericoDireito().isNull()) {
				ItemServices.goItem("ITGUIA_OCULOS.VL_PERTO_ESFERICO_DIREITO");
				//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("ITGUIA_OCULOS.TP_PERTO_ESFERICO_DIREITO")), "W", NBool.True);
			} else if(itguiaOculosAdapter.getTpPertoEsfericoDireito().isNull()) {
				itguiaOculosAdapter.setVlPertoEsfericoDireito(NNumber.getNull());
			}
			
			if (!itguiaOculosAdapter.getTpPertoEsfericoEsquerdo().isNull() && itguiaOculosAdapter.getVlPertoEsfericoEsquerdo().isNull()) {
				ItemServices.goItem("ITGUIA_OCULOS.VL_PERTO_ESFERICO_ESQUERDO");
				//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("ITGUIA_OCULOS.TP_PERTO_ESFERICO_ESQUERDO")), "W", NBool.True);
			} else if(itguiaOculosAdapter.getTpPertoEsfericoEsquerdo().isNull()) {
				itguiaOculosAdapter.setVlPertoEsfericoEsquerdo(NNumber.getNull());
			}

			/* Cilindro */
			if (!itguiaOculosAdapter.getTpPertoCilindroDireito().isNull() && itguiaOculosAdapter.getVlPertoCilindroDireito().isNull()) {
				ItemServices.goItem("ITGUIA_OCULOS.VL_PERTO_CILINDRO_DIREITO");
				//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("ITGUIA_OCULOS.TP_PERTO_CILINDRO_DIREITO")), "W", NBool.True);
			} else if(itguiaOculosAdapter.getTpPertoCilindroDireito().isNull()) {
				itguiaOculosAdapter.setVlPertoCilindroDireito(NNumber.getNull());
			}
			
			if (!itguiaOculosAdapter.getTpPertoCilindroEsquerdo().isNull() && itguiaOculosAdapter.getVlPertoCilindroEsquerdo().isNull()) {
				ItemServices.goItem("ITGUIA_OCULOS.VL_PERTO_CILINDRO_ESQUERDO");
				//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("ITGUIA_OCULOS.TP_PERTO_CILINDRO_ESQUERDO")), "W", NBool.True);
			} else if(itguiaOculosAdapter.getTpPertoCilindroEsquerdo().isNull()) {
				itguiaOculosAdapter.setVlPertoCilindroEsquerdo(NNumber.getNull());
			}
		}
	}
	
	public void insertOcorrenciaOdontologia() {
		String sqlDeletaDuplicado = " DELETE FROM DBAPS.GUIA_OCORRENCIA           " +
				"       WHERE NR_GUIA = :PNR_GUIA                                 " +
				"         AND CD_CLASSIFICACAO_OCOR_GUIA IN                       " +
				"             ( SELECT CD_CLASSIFICACAO_OCOR_GUIA                 " +
				"                 FROM DBAPS.CLASSIFICACAO_OCORRENCIA_GUIA        " +
				"                WHERE TP_CLASS_OCORRENCIA_GUIA = 'W'             " +
				"                  AND CD_USUARIO_PERITO IS NOT NULL              " +
				"             )                                                   " +
				"        AND CD_CLASSIFICACAO_OCOR_GUIA NOT IN (NVL(:PCD_PERICIA_INI,0), NVL(:PCD_PERICIA_FIM,0)) ";

		DataCommand command = new DataCommand(sqlDeletaDuplicado);
		command.addParameter("PNR_GUIA", getGuiaElement().getNrGuia());
		command.addParameter("PCD_PERICIA_INI", getGuiaElement().getCdOcorrenciaPericiaInicial());
		command.addParameter("PCD_PERICIA_FIM", getGuiaElement().getCdOcorrenciaPericiaFinal());
		command.execute();
				
		if (!getGuiaElement().getCdOcorrenciaPericiaInicial().isNull() && !getGuiaElement().getNrGuia().isNull() && getGuiaElement().getDspTpGuia().equals("D")) {

			StringBuilder sb = new StringBuilder();
			String whereClause = sb.append("NR_GUIA = ") .append(getGuiaElement().getNrGuia().toString()).append(" AND CD_CLASSIFICACAO_OCOR_GUIA IN  ( NVL(").append(getGuiaElement().getCdOcorrenciaPericiaInicial()).append(",0) , NVL(").append(getGuiaElement().getCdOcorrenciaPericiaFinal()).append(",0 ) ) ").toString();

			if (!Services.exist("GUIA_OCORRENCIA", whereClause, false)) {
				String sqlCommand = " INSERT INTO DBAPS.GUIA_OCORRENCIA (             " 
								  + "   			CD_GUIA_OCORRENCIA,               " 
								  + "   			CD_USUARIO,                       " 
								  + "   			CD_CLASSIFICACAO_OCOR_GUIA,       " 
								  + "   			DS_OBSERVACAO,                    " 
								  + "   			DT_INCLUSAO,                      " 
								  + "   			NR_GUIA                           " 
								  + "   ) VALUES (                                    " 
								  + "   			DBAPS.SEQ_GUIA_OCORRENCIA.NEXTVAL," 
								  + "   			USER,                             " 
								  + "   			:PCD_CLASSIFICACAO_OCOR_GUIA,     " 
								  + "   			:PDS_OBSERVACAO,                  " 
								  + "   			SYSDATE,                          " 
								  + "   			:PNR_GUIA )                       ";
				
				command = null;
				command = new DataCommand(sqlCommand);
				command.addParameter("PNR_GUIA", getGuiaElement().getNrGuia());
				command.addParameter("PCD_CLASSIFICACAO_OCOR_GUIA", getGuiaElement().getCdOcorrenciaPericiaInicial());
				command.addParameter("PDS_OBSERVACAO", getGuiaElement().getDsOcorrenciaPericiaInicial());
				command.execute();
			}
		}
	}
	
	public void chkChavesConfiguracaoGlobal(){
		if(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("ATEND_GUIA_OBG_LOCAL").equals("S")){
			//MULTI-IDIOMA: MSG_0087 - [ATEND_GUIA_OBG_LOCAL] Campo %s obrigatório.
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0087",ItemServices.getItemLabel("GUIA.CD_PRESTADOR_ENDERECO")), "W", NBool.True);
		}
	}
	
	public void updateItGuiaNegativa(NNumber nrGuia, NString tpNegativa){
		if (!nrGuia.isNull() && !tpNegativa.isNull()) {
			String sqlCommand = "";
			DataCommand command = null;
			if (tpNegativa.equals("C")) {
				sqlCommand = "UPDATE DBAPS.ITGUIA SET TP_STATUS = :PTP_STATUS , QT_SOLICITADO = 0 WHERE NR_GUIA = :PNR_GUIA ";
				command = new DataCommand(sqlCommand);
				command.addParameter("PTP_STATUS","5");
			}else{
				sqlCommand = "UPDATE DBAPS.ITGUIA SET TP_STATUS = :PTP_STATUS WHERE NR_GUIA = :PNR_GUIA ";
				command = new DataCommand(sqlCommand);
				command.addParameter("PTP_STATUS","3");
			}
			command.addParameter("PNR_GUIA", nrGuia);
			command.execute();
		}		
	}
	
	public void chkObrigatoriosOdontologia(GuiaAdapter guiaElement){
		if (guiaElement.getDspTpGuia().equals("D")) {
			if (guiaElement.getCdTipoAtendimentoOdonto().isNull()) {
				//MULTI-IDIOMA: MSG_0089 - Valor do %s obrigatório.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0089", ItemServices.getItemLabel("GUIA.CD_TIPO_ATENDIMENTO_ODONTO")), "W", NBool.True);
			}
			
			if (guiaElement.getCdTipoFaturamentoOdonto().isNull()) {
				//MULTI-IDIOMA: MSG_0089 - Valor do %s obrigatório.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0089", ItemServices.getItemLabel("GUIA.CD_TIPO_FATURAMENTO_ODONTO")), "W", NBool.True);
			}
		}
	}
	
	
	public ResultSet getCdPaciente(NNumber cdMatricula){
		String sql = "  SELECT U.CD_PACIENTE,PL.CD_PLANO_MV2000, C.CD_CONVENIO " + 
				"    FROM  DBAPS.USUARIO U                                " +
				"        , DBAMV.PACIENTE P                               " +
				"        , DBAMV.CARTEIRA C                               " +
				"        , DBAPS.PLANO PL                                 " +
				"  WHERE P.CD_PACIENTE  = U.CD_PACIENTE                   " +
				"    AND C.CD_PACIENTE  = P.CD_PACIENTE                   " +
				"    AND U.CD_PLANO     = PL.CD_PLANO                     " +
				"    AND U.CD_MATRICULA = :PCD_MATRICULA                  ";
				  
		DataCursor cCursor = new DataCursor(sql);
		
		try {
			cCursor.addParameter("PCD_MATRICULA", cdMatricula );
			cCursor.open(); 
				if(cCursor.found()){
					return cCursor.fetchInto();
				}
			return null;
		}finally {
			cCursor.close();
		}
	}
	
	/**
	 * 
	 * @param nrGuia
	 * @return
	 */
	public DataCursor getItemAgendamento(NNumber nrGuia){
		String sql = " SELECT IA.CD_ITEM_AGENDAMENTO                " +
				"      , IT.CD_PROCEDIMENTO                         " +
				"      , COUNT(IA.CD_PRO_FAT) QTD_ITENS_ENCONTRADOS " + 
				"   FROM DBAMV.ITEM_AGENDAMENTO IA                  " +
				"      , DBAPS.ITGUIA IT                            " +
				"  WHERE IA.CD_PRO_FAT(+) = IT.CD_PROCEDIMENTO      " +
				"    AND IT.NR_GUIA = :PNR_GUIA                     " +
				"  GROUP BY IA.CD_ITEM_AGENDAMENTO                  " +
				"         , IT.CD_PROCEDIMENTO                      " ;
		
		DataCursor cCursor = new DataCursor(sql);
		cCursor.addParameter("PNR_GUIA", nrGuia );
		cCursor.open(); 

		if(cCursor.found()){
			return cCursor;
		}
		return null;
	}
	
	public static ResultSet getAutorizadorLogado(){
		String sql = "SELECT AUTORIZADOR.CD_AUTORIZADOR, AUTORIZADOR.NM_AUTORIZADOR FROM DBAPS.AUTORIZADOR , DBAPS.ME_AUTORIZADOR WHERE AUTORIZADOR.CD_USUARIO = USER AND AUTORIZADOR.CD_AUTORIZADOR = ME_AUTORIZADOR.CD_AUTORIZADOR AND ROWNUM = 1 AND ME_AUTORIZADOR.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA";
		DataCursor cCursor = new DataCursor(sql);
		try {
			cCursor.open(); 
			if(cCursor.found()){
				return cCursor.fetchInto();	
			}
			return null;
		}finally {
			cCursor.close();
		}
	}
	
	/**
	 * Recebe a matricula e verifica a data de desligamento do beneficiário.
	 * @param cdMatricula
	 * @return data de desligamento
	 */
	public NDate fncDadosDesligamento(NNumber cdMatricula){
		Ref<NDate> dtDesligamento = new Ref<NDate>(NDate.getNull());
		Ref<NDate> dtReativacao = new Ref<NDate>(NDate.getNull());
		
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("DBAPS.FNC_DADOS_DESLIGAMENTO", DbManager.getDataBaseFactory());
		cmd.addReturnParameter(NNumber.class);
		cmd.addParameter("@pcd_matricula",cdMatricula);
		cmd.addParameter("@pdt_referencia",DbManager.getDBDateTime());
		cmd.addParameter("@pdt_desligamento",dtDesligamento,true);
		cmd.addParameter("@pdt_reativacao",dtReativacao,true);
		cmd.execute();
		
		dtDesligamento.val = ((NDate)cmd.getParameterValue("@pdt_desligamento", NDate.class));
		dtReativacao.val = ((NDate)cmd.getParameterValue("@pdt_reativacao", NDate.class));
		if(dtReativacao.val.isNull()){
			return dtDesligamento.val;
		}
		return  NDate.getNull();
	}

	/**
	 * if (!nrGuia.isNull()) {<br />
	 *		BlockServices.setBlockWhereClause("GUIA", "NR_GUIA = ".concat(nrGuia.toString())); <br />
	 *		BlockServices.getBlockController("GUIA").getInteractionRulesStrategy().executeQuery(); <br />
	 *		BlockServices.setBlockWhereClause("GUIA", "");<br />
	 *	}
	 *
	 * @author anderson.santos
	 * @param nrGuia
	 */
	public void recarregarTela(NNumber nrGuia) {
		if (!nrGuia.isNull()) {
			BlockServices.setBlockWhereClause("GUIA", "NR_GUIA = ".concat(nrGuia.toString()));
			BlockServices.getBlockController("GUIA").getInteractionRulesStrategy().executeQuery();
			BlockServices.setBlockWhereClause("GUIA", "");
		}
	}
	
	public ResultSet getInfoProcedimento(NString cdProcedimento){
		String sqlCProc = " SELECT GP.TP_GRU_PRO,                                                                                                                                                                               " +
				"        P.NR_ANVISA,                                                                                                                                                                                 " +
				"        P.CD_MATERIAL_FABRICANTE,                                                                                                                                                                    " +
				"        P.NR_AUTORIZACAO_FUNCIONAMENTO,                                                                                                                                                              " +
				"        P.TP_NATUREZA,                                                                                                                                                                               " +
				"        P.SN_PROCED_UNIVERSAL,                                                                                                                                                                       " +
				"        DECODE(P.TP_TABELA, NULL, Decode(RU.DT_VIGENCIA, NULL, Decode(GP.TP_GRU_PRO, 'SP', 0, 'SD', 0, 'TE', 0, 'SH', 1, 'DI', 1, 'TX', 1, 'MT', 2, 'OP', 2, 'MD', 3, 0), 0), P.TP_TABELA) TP_TABELA " +
				"   FROM DBAPS.PROCEDIMENTO       P,                                                                                                                                                                  " +
				"        DBAPS.GRUPO_PROCEDIMENTO GP,                                                                                                                                                                 " +
				"        DBAPS.ROL_UNIMED         RU                                                                                                                                                                  " +
				"  WHERE P.CD_GRUPO_PROCEDIMENTO = GP.CD_GRUPO_PROCEDIMENTO(+)                                                                                                                                        " +
				"    AND P.CD_PROCEDIMENTO = RU.CD_PROCEDIMENTO(+)                                                                                                                                                    " +
				"    AND P.CD_PROCEDIMENTO =  :PCD_PROCEDIMENTO                                                                                                                                                       " ;
		
		DataCursor dcProc = new DataCursor(sqlCProc);
		dcProc.addParameter("PCD_PROCEDIMENTO",cdProcedimento);
		dcProc.open();
		return dcProc.fetchInto();
	}
	
	/**
	 * 	Método responsável por exibir os campos de intercambio e local referente ao beneficiário sendo atendido.
	 * 
	 *  //Intercambio/Avulsa
	 *	GUIA.CD_BENEFICIARIO_TRANSITO
	 *	GUIA.NR_CARTEIRA_BENEFICIARIO
	 *	GUIA.BTN_LEITOR_MAGNETO_AVULSO
	 *	GUIA.DS_DESTINO_CORTESIA
	 *	//Local
	 *	GUIA.CD_MATRICULA
	 *	GUIA.CD_MAT_ALTERNATIVA
	 *	GUIA.BTN_CD_MATRICULA
	 *	GUIA.BTN_LEITOR_MAGNETO
	 *	GUIA.DSP_NM_SEGURADO
	 *
	 * @param snEmissaoAvulsa
	 * @param guiaElement
	 */
	public static void chkCamposBeneficiario(String snEmissaoAvulsa,GuiaAdapter guiaElement){
		//Intercambio/Avulsa
		ItemServices.setItemVisible("GUIA.CD_BENEFICIARIO_TRANSITO", snEmissaoAvulsa.equals("S") || !guiaElement.getDsDestinoCortesia().isNull());
		ItemServices.setItemVisible("GUIA.NR_CARTEIRA_BENEFICIARIO", snEmissaoAvulsa.equals("S") || !guiaElement.getDsDestinoCortesia().isNull());
		ItemServices.setItemVisible("GUIA.BTN_LEITOR_MAGNETO_AVULSO", snEmissaoAvulsa.equals("S") || !guiaElement.getDsDestinoCortesia().isNull());
		ItemServices.setItemVisible("GUIA.DS_DESTINO_CORTESIA", snEmissaoAvulsa.equals("S") || !guiaElement.getDsDestinoCortesia().isNull());
		//Local
		ItemServices.setItemVisible("GUIA.CD_MATRICULA", snEmissaoAvulsa.equals("N") && guiaElement.getDsDestinoCortesia().isNull());
		ItemServices.setItemVisible("GUIA.CD_MAT_ALTERNATIVA", snEmissaoAvulsa.equals("N") && guiaElement.getDsDestinoCortesia().isNull());
		ItemServices.setItemVisible("GUIA.BTN_CD_MATRICULA", snEmissaoAvulsa.equals("N") && guiaElement.getDsDestinoCortesia().isNull());
		ItemServices.setItemVisible("GUIA.BTN_LEITOR_MAGNETO", snEmissaoAvulsa.equals("N") && guiaElement.getDsDestinoCortesia().isNull());
		ItemServices.setItemVisible("GUIA.DSP_NM_SEGURADO", snEmissaoAvulsa.equals("N") && guiaElement.getDsDestinoCortesia().isNull());
	}
	
	/**
	 * Exibe as colunas : ITGUIA.VL_PROCEDIMENTO, ITGUIA.DSP_VL_TOTAL_PROCEDIMENTO, CG$CTRL.DSP_VL_TOTAL_PROCEDIMENTO caso a configuração na tabela DBAMV.MULTI_EMPRESAS_MV_SAUDE.SN_EXIBE_VALOR_PROCED for igual a "S"
	 * @param snExibeValorProced
	 */
	public void exibeValorProced(String snExibeValorProced) {
		ItemServices.setItemVisible("ITGUIA.VL_PROCEDIMENTO", snExibeValorProced.equals("S"));
		ItemServices.setItemVisible("ITGUIA.DSP_VL_TOTAL_PROCEDIMENTO", snExibeValorProced.equals("S"));
		ItemServices.setItemVisible("CG$CTRL.DSP_VL_TOTAL_PROCEDIMENTO", snExibeValorProced.equals("S"));
	}
	
	public void isReciprocidade(String isReciprocidade){
		ItemServices.setItemVisible("GUIA.NR_AUTORIZACAO_RECIPROCIDADE", isReciprocidade.equals("S"));
	}
	
	public void exibirCamposOperadoraUnimed(String snOperadoraUnimed,String snEmissaoAvulsa){
		ItemServices.setItemVisible("GUIA.CD_UNIMED_ORIGEM", snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.DSP_DS_UNIMED_ORIGEM", snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.CD_UNIMED_EXECUTORA", snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.DSP_DS_UNIMED_EXECUTORA", snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.CD_UNIMED_SOLICITANTE", snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.DSP_DS_UNIMED_SOLICITANTE", snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.TP_REDE_MIN", snOperadoraUnimed.equals("S"));

		ItemServices.setItemVisible("GUIA.CD_VERSAO_PTU", snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.BTN_PTU_RESPOSTA_AUDITORIA", snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.CD_REDE_REFERENCIADA", snOperadoraUnimed.equals("S"));
		
		ItemServices.setItemVisible("ITGUIA.TP_INDICADOR_ANEXO", snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("ITGUIA.SN_PACOTE_PTU", snOperadoraUnimed.equals("S"));
		
		ItemServices.setItemVisible("GUIA.CD_UNI_SOLICIT_EVENTUAL", snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.CD_PREST_SOLICIT_EVENTUAL", snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.CD_UNI_EXEC_EVENTUAL", snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.CD_PREST_EXEC_EVENTUAL", snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.NM_PREST_EXEC_EVENTUAL", snOperadoraUnimed.equals("S"));
		
		ItemServices.setItemVisible("GUIA.CD_PTU_MENS_ORDEM_SERVICO_ORI",snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.CD_PTU_MENS_ORDEM_SERVICO_DES",snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.CD_PTU_MENSAGEM_ORIGEM",snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.CD_PTU_MENSAGEM_DESTINO",snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.CD_PTU_MENSAGEM_DECURSO_PRAZO",snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.SN_ORDEM_SERVICO",snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.BTN_SOLIC_ORDEM_SERVICO",snOperadoraUnimed.equals("S"));
		ItemServices.setItemVisible("GUIA.BTN_PTU_AUTORIZACAO_ORDEM_SERVICO",snOperadoraUnimed.equals("S"));
		
		/*Botões do intercambio*/
		ItemServices.setItemVisible("GUIA.BTN_PTU_PEDIDO_AUTORIZACAO",(snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S")) || (snOperadoraUnimed.equals("S") && !getGuiaElement().getDsDestinoCortesia().isNull()) );
		ItemServices.setItemVisible("GUIA.BTN_PTU_PEDIDO_COMPLEMENTO_AUTORIZACAO",(snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S")) || (snOperadoraUnimed.equals("S") && !getGuiaElement().getDsDestinoCortesia().isNull()) );
		ItemServices.setItemVisible("GUIA.BTN_PTU_INSISTENCIA",(snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S")) || (snOperadoraUnimed.equals("S") && !getGuiaElement().getDsDestinoCortesia().isNull()) );
		ItemServices.setItemVisible("GUIA.BTN_PTU_STATUS",(snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S")) || (snOperadoraUnimed.equals("S") && !getGuiaElement().getDsDestinoCortesia().isNull()) );
		ItemServices.setItemVisible("GUIA.BTN_PTU_DECURSO_PRAZO",(snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S")) || (snOperadoraUnimed.equals("S") && !getGuiaElement().getDsDestinoCortesia().isNull()) );
		ItemServices.setItemVisible("GUIA.BTN_COMUNIC_INTERNA_ALTA_BENEF",(snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S")) || (snOperadoraUnimed.equals("S") && !getGuiaElement().getDsDestinoCortesia().isNull()) );
		
		ViewServicesExtensions.setVisualAttribute("PAGE_OBSERVACOES_camposAuditoriaIntercambio", "Visible", snOperadoraUnimed.equals("S"));
		ViewServicesExtensions.setVisualAttribute("PAGE_LOG_abaLogGridlogTransacaoPtuOnline", "Visible", snOperadoraUnimed.equals("S"));
		
		//Botão Chat Unimed Brasil
		ItemServices.setItemVisible("GUIA.BTN_CHAT_UNIMED_BRASIL", (("S").equals(snOperadoraUnimed)));
	}
	
	/**
	 * @author anderson.santos
	 * @since 09/01/2019
	 * 
	 * Oculta as abas da tela de acordo com o tipo de atendimento informado. <br />
	 * [C] CONSULTA <br />
	 * [S] SP/SADT <br />
	 * [I] SOLICITACAO DE INTERNACAO <br />
	 * [H] HONORARIO INDIVIDUAL <br />
	 * [D] ODONTOLOGICO <br />
	 * [R] RADIOTERAPIA <br />
	 * [Q] QUIMIOTERAPIA <br />
	 * [O] OPME <br />
	 * [E] SP/SADT EXECUCAO <br />
	 * [L] SP/SADT SOLICITACAO <br />
	 * [N] SAUDE OCUPACIONAL <br />
	 * [B] REEMBOLSO <br />
	 * [P] PRORROGACAO DE INTERNACAO <br />
	 * @param tpGuia
	 */
	public void exibirAbas(String tpGuia) {
		if (tpGuia == null) {
			tpGuia = "C";
		}
		if (tpGuia != null && !tpGuia.isEmpty()) {

			ViewServices.setTabPageVisible("PAGE_CHAT", !tpGuia.equals("B"));
			ViewServices.setTabPageVisible("PAGE_DIAGNOSTICO", !tpGuia.equals("B"));
			ViewServices.setTabPageVisible("PAGE_REEMBOLSO", tpGuia.equals("B"));
			ViewServices.setTabPageVisible("PAGE_ODONTOLOGIA", tpGuia.equals("D"));
			
			ViewServices.setTabPageVisible("PAGE_SOLICITACAO", Lib.in(tpGuia, "O","Q","R").toBoolean());
			if (tpGuia.equals("O")) {
				ViewServices.setTabPageLabel("PAGE_SOLICITACAO", "OPME");//O	
			}else if(tpGuia.equals("Q")){
				ViewServices.setTabPageLabel("PAGE_SOLICITACAO", "Quimioterapia");//Q	
			}else if(tpGuia.equals("R")){
				ViewServices.setTabPageLabel("PAGE_SOLICITACAO", "Radioterapia");//R
			}else{
				ViewServices.setTabPageLabel("PAGE_SOLICITACAO", "Solicitações");
			}
		}
	}
	
	/**
	 * Método responsável por exibir os campos de odontologia.
	 * @author anderson.santos
	 * @since 16/01/2019
	 * @param tpGuia
	 * @param guiaElement
	 */
	public void exibirCamposBotoesOdontologia(String tpGuia,GuiaAdapter guiaElement){
		if (tpGuia != null && !tpGuia.isEmpty()) {
			ItemServices.setItemVisible("GUIA.DT_TERMINO_TRATAMENTO", tpGuia.equals("D"));
			ItemServices.setItemVisible("ITGUIA.CD_REGIAO_DENTE", tpGuia.equals("D") || tpGuia.equals("B"));
			ItemServices.setItemVisible("ITGUIA.CD_FACES_DENTES_ODONTO", tpGuia.equals("D") || tpGuia.equals("B"));
			ItemServices.setItemVisible("ITGUIA.DT_REALIZACAO", tpGuia.equals("D"));
			ItemServices.setItemVisible("ITGUIA.DS_REGIAO_DENTE", tpGuia.equals("D") || tpGuia.equals("B"));
			ItemServices.setItemVisible("ITGUIA.DS_FACES_DENTES_ODONTO",tpGuia.equals("D"));
			ItemServices.setItemVisible("ITGUIA.BTN_PERICIA_ODONTO", tpGuia.equals("D"));
		}
	}
	
	public void exibirCamposConsulta(String tpGuia, GuiaAdapter guiaElement){
	}
	
	/**
	 * Método responsável por exibir os campos que Quimio Radio  tem em comum 
	 * @param tpGuia
	 * @param guiaElement
	 */
	public void exibirCamposSpSadt(String tpGuia, GuiaAdapter guiaElement){
	}
	
	public void exibirCamposConsultaSpSadt(String tpGuia, GuiaAdapter guiaElement){
		ItemServices.setItemVisible("GUIA.CD_TIPO_CONSULTA", Lib.in(tpGuia,"C","S"));
	}
	
	/**
	 * Método responsável por exibir os campos que Quimio Radio  tem em comum 
	 * @param tpGuia
	 * @param guiaElement
	 */
	public void exibirCamposInternacao(String tpGuia, GuiaAdapter guiaElement){
	}
	
	/**
	 * Método responsável por exbibir os campos de guias de Opme
	 * @author anderson.santos
	 * @since 07/02/2019
	 * @param tpGuia
	 * @param guiaElement
	 */
	public void exibirCamposOpme(String tpGuia, GuiaAdapter guiaElement){
		ItemServices.setItemVisible("GUIA.DS_JUSTIFICATIVA_TECNICA", tpGuia.equals("O"));
		ItemServices.setItemVisible("GUIA.DS_ESPECIFICACAO_MATERIAL", tpGuia.equals("O"));
		
		ItemServices.setItemVisible("ITGUIA.VL_SOLICITADO", tpGuia.equals("O"));
		ItemServices.setItemVisible("ITGUIA.SN_PRESTADOR_EXECUTOR_OPME", tpGuia.equals("O"));
		ItemServices.setItemVisible("ITGUIA.NR_ORDEM_PREFERENCIA", tpGuia.equals("O"));
		ItemServices.setItemVisible("ITGUIA.NR_ANVISA", tpGuia.equals("O"));
		ItemServices.setItemVisible("ITGUIA.CD_MATERIAL_FABRICANTE", tpGuia.equals("O"));
		ItemServices.setItemVisible("ITGUIA.NR_AUTORIZACAO_FUNCIONAMENTO", tpGuia.equals("O"));
		ItemServices.setItemVisible("ITGUIA.VL_UNITARIO_AUTORIZADO", tpGuia.equals("O"));
	}

	/**
	 * Método responsável por exbibir os campos de guias de Quimio
	 * @author anderson.santos
	 * @since 07/02/2019
	 * @param tpGuia
	 * @param guiaElement
	 */
	public void exibirCamposQuimio(String tpGuia, GuiaAdapter guiaElement){
		ItemServices.setItemVisible("GUIA.NR_PESO_BENEFICIARIO", tpGuia.equals("Q"));
		ItemServices.setItemVisible("GUIA.NR_ALTURA_BENEFICIARIO", tpGuia.equals("Q"));
		ItemServices.setItemVisible("GUIA.NR_SUPERFICIE_CORPORAL", tpGuia.equals("Q"));
		ItemServices.setItemVisible("GUIA.NR_CICLO_PREVISTO", tpGuia.equals("Q"));
		ItemServices.setItemVisible("GUIA.QTD_DIAS_CICLO", tpGuia.equals("Q"));
		ItemServices.setItemVisible("GUIA.NR_CICLO_ATUAL", tpGuia.equals("Q"));
		ItemServices.setItemVisible("GUIA.NR_INTERVALO_CICLO", tpGuia.equals("Q"));
		ItemServices.setItemVisible("GUIA.CD_QUIMIOTERAPIA",tpGuia.equals("Q"));
		ItemServices.setItemVisible("GUIA.DSP_QUIMIOTERAPIA",tpGuia.equals("Q"));
		ItemServices.setItemVisible("GUIA.CD_CLASSIFICACAO_METASTASE", Lib.in(tpGuia,"Q"));
		ItemServices.setItemVisible("GUIA.DSP_DS_CLASSIFICACAO_METASTASE", Lib.in(tpGuia,"Q"));
		ItemServices.setItemVisible("GUIA.CD_CLASSIFICACAO_NODULO", Lib.in(tpGuia,"Q"));
		ItemServices.setItemVisible("GUIA.DSP_DS_CLASSIFICACAO_NODULO", Lib.in(tpGuia,"Q"));
		ItemServices.setItemVisible("GUIA.CD_CLASSIFICACAO_TUMOR", Lib.in(tpGuia,"Q"));
		ItemServices.setItemVisible("GUIA.DSP_DS_CLASSIFICACAO_TUMOR", Lib.in(tpGuia,"Q"));
		ItemServices.setItemVisible("GUIA.DS_PLANO_TERAPEUTICO",tpGuia.equals("Q"));
		
		ItemServices.setItemVisible("ITGUIA.CD_VIA_ADMINISTRACAO", Lib.in(tpGuia,"Q"));
	}
	
	/**
	 * Método responsável por exbibir os campos de guias de Radio
	 * @author anderson.santos
	 * @since 07/02/2019
	 * @param tpGuia
	 * @param guiaElement
	 */
	public void exibirCamposRadio(String tpGuia, GuiaAdapter guiaElement){
		ItemServices.setItemVisible("GUIA.DS_QUIMIOTERAPIA", Lib.in(tpGuia,"R"));
		ItemServices.setItemVisible("GUIA.CD_DIAGNOSTICO_IMAGEM", Lib.in(tpGuia,"R"));
		ItemServices.setItemVisible("GUIA.DS_DIAGNOSTICO_IMAGEM", Lib.in(tpGuia,"R"));
		ItemServices.setItemVisible("GUIA.NR_CAMPOS_IRRADIACAO", Lib.in(tpGuia,"R"));
		ItemServices.setItemVisible("GUIA.NR_DOSE_RADIOTERAPICO_DIA", Lib.in(tpGuia,"R"));
		ItemServices.setItemVisible("GUIA.NR_DOSE_RADIOTERAPICO_TOTAL", Lib.in(tpGuia,"R"));
		ItemServices.setItemVisible("GUIA.DT_INICIO_ADMINISTRACAO", Lib.in(tpGuia,"R"));
		ItemServices.setItemVisible("GUIA.NR_TRATAMENTO_DIA", Lib.in(tpGuia,"R"));
	}
	
	public void exibirCamposOpmeRadioQuimio(String tpGuia, GuiaAdapter guiaElement){
		ItemServices.setItemVisible("ITGUIA.CD_MATERIAL_FABRICANTE", Lib.in(tpGuia,"R","Q","O"));
	}
	
	public void exibirCamposOpmeRadioQuimioInternacaoSpSadt(String tpGuia, GuiaAdapter guiaElement){
		ItemServices.setItemVisible("GUIA.TP_CARATER_SOLIC_INTER", Lib.in(tpGuia,"R","Q","O","I","S"));
	}
	
	public void exibirCamposOpmeRadioQuimioInternacao(String tpGuia, GuiaAdapter guiaElement){
		ItemServices.setItemVisible("GUIA.NR_TELEFONE_PROFISSIONAL", Lib.in(tpGuia,"R","Q","O","I"));
		ItemServices.setItemVisible("GUIA.DS_EMAIL_PROFISSIONAL", Lib.in(tpGuia,"R","Q","O","I"));

		ItemServices.setItemVisible("GUIA.DT_SUGERIDA_INTERNACAO", Lib.in(tpGuia,"R","Q","O","I"));
		ItemServices.setItemVisible("GUIA.SN_PREVISAO_USO_OPME", Lib.in(tpGuia,"R","Q","O","I"));
		ItemServices.setItemVisible("GUIA.SN_PREVISAO_USO_QUIMIO", Lib.in(tpGuia,"R","Q","O","I"));
		
		ItemServices.setItemVisible("GUIA.CD_CID2", Lib.in(tpGuia,"R","Q","O","I"));
		ItemServices.setItemVisible("GUIA.CD_CID3", Lib.in(tpGuia,"R","Q","O","I"));
		ItemServices.setItemVisible("GUIA.CD_CID4", Lib.in(tpGuia,"R","Q","O","I"));

		ItemServices.setItemVisible("GUIA.CD_REGIME_INTERNACAO", Lib.in(tpGuia,"R","Q","O","I"));

		ItemServices.setItemVisible("GUIA.TP_CARATER_SOLIC_INTER", Lib.in(tpGuia,"R","Q","O","I"));
		ItemServices.setItemVisible("GUIA.TP_INTERNACAO", Lib.in(tpGuia,"R","Q","O","I"));
	}
	
	public void exibirCamposRadioQuimio(String tpGuia, GuiaAdapter guiaElement){
		ItemServices.setItemVisible("GUIA.DS_DIAGNOSTICO_CITO_HISTO", Lib.in(tpGuia,"R","Q"));
		ItemServices.setItemVisible("GUIA.DS_INFORMACOES_RELEVANTES", Lib.in(tpGuia,"R","Q"));

		ItemServices.setItemVisible("GUIA.DS_CIRURGIA", Lib.in(tpGuia,"R","Q"));
		ItemServices.setItemVisible("GUIA.DT_REALIZACAO", Lib.in(tpGuia,"R","Q"));
		ItemServices.setItemVisible("GUIA.DT_APLICACAO", Lib.in(tpGuia,"R","Q"));
		
		ItemServices.setItemVisible("GUIA.DSP_CD_ECOG", Lib.in(tpGuia,"R","Q"));
		ItemServices.setItemVisible("GUIA.DS_ECOG", Lib.in(tpGuia,"R","Q"));
		
		ItemServices.setItemVisible("GUIA.CD_FINALIDADE", Lib.in(tpGuia,"R","Q"));
		ItemServices.setItemVisible("GUIA.DS_FINALIDADE", Lib.in(tpGuia,"R","Q"));

		ItemServices.setItemVisible("GUIA.CD_ESTADIAMENTO", Lib.in(tpGuia,"R","Q"));
		ItemServices.setItemVisible("GUIA.DS_ESTADIAMENTO", Lib.in(tpGuia,"R","Q"));
		
		ItemServices.setItemVisible("GUIA.DT_DIAGNOSTICO", Lib.in(tpGuia,"R","Q"));
	}
	
	/**
	 * Método responsável por exibir os campos de reembolso.
	 * @author anderson.santos
	 * @since 16/01/2019
	 * @param tpGuia
	 * @param guiaElement
	 */
	public void exibirCamposReembolso(String tpGuia, GuiaAdapter guiaElement) {
		if (tpGuia != null && !tpGuia.isEmpty()) {
			ItemServices.setItemVisible("ITGUIA.VL_COBRADO", tpGuia.equals("B"));
			ItemServices.setItemVisible("ITGUIA.BTN_INFO_OCULOS", tpGuia.equals("B"));
			ItemServices.setItemEnabled("GUIA.BTN_GERAR_REEMBOLSO", tpGuia.equals("B"));
			ItemServices.setItemEnabled("GUIA.CD_PRESTADOR_EXTERNO", tpGuia.equals("B"));
		}
	}
	
	public ResultSet getMultiEmpresasMvSaude(){
		String sql ="" 
				+" SELECT PDS.SN_VALIDA_CADASTRO,                                         "
				+"        PDS.SN_DTGUIA_FUTURA,                                           "
				+"        M.SN_EXIBE_VALOR_PROCED,                                        "
				+"        NVL(M.NR_DIAS_VENCIMENTO_DA_GUIA,0) NR_DIAS_VENCIMENTO_DA_GUIA, "
				+"        M.TP_DATA_VENCIMENTO_GUIA,		                              "
				+"        M.SN_ALERTA_AUTOMATICO,                                         "
				+"        M.SN_OPERADORA_UNIMED,                                          "
				+"        M.SN_RECIPROCIDADE,                                             "
				+"        M.DS_SERVIDOR_EMAIL,                                            "
				+"        M.SN_OBRIGAR_CID,                                               "
				+"        M.SN_LIBERA_GUIA_SEM_PAGAMENTO,                                 "
				+"		  M.SN_GUIA_AUTORIZA_AUTOMATICO,							      "
				+"        M.CD_UNIMED,                                                    "
				+"        PDS.SN_OBRIGA_CPF_TITULAR,                                      "
				+"        PDS.SN_OBRIGA_CPF_DEP,                                          "
				+"        PDS.SN_OBRIGA_END_RESIDENCIAL,                                  "
				+"        NVL(M.SN_OPERADORA_UNIMED, 'N') SN_OPERADORA_UNIMED,            "
				+"		  M.DS_SERVIDOR_EMAIL,										      "
				+"        M.TP_PAIS,												      "
				+"        M.SN_ENVIO_AUTO_SMS_LIBERA_GUIA                                 "
				+"   FROM DBAPS.PLANO_DE_SAUDE PDS, DBAMV.MULTI_EMPRESAS_MV_SAUDE M       "
				+"  WHERE ID = 1                                                          "
				+"    AND M.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA                ";
		DataCursor cCursor = new DataCursor(sql);

		try {
			cCursor.open();
			if (cCursor.found()) {
				return cCursor.fetchInto();
			}

		} finally {
			cCursor.close();
		}
		return null;
	}
	
	/**
	 * PLANO-6083
	 */
	public void negarTodosOsProcedimentoDaGuia(GuiaAdapter guiaElement,ItguiaAdapter itguiaElement){
		String sql = " UPDATE DBAPS.ITGUIA          " +
				"    SET CD_USUARIO_NEGACAO = USER  " +
				"      , DT_NEGACAO = SYSDATE       " +
				"      , TP_STATUS = 3              " +
				"      , QT_SOLICITADO = 0          " +
				"      , VL_PROCEDIMENTO = 0		" +
				"      , CD_MOTIVO = :PCD_MOTIVO    " +
				"  WHERE NR_GUIA = :PNR_GUIA		" ;
		
		DataCommand cmd = new DataCommand(sql);
		cmd.addParameter("PNR_GUIA", guiaElement.getNrGuia());
		cmd.addParameter("PCD_MOTIVO", itguiaElement.getCdMotivo());
		cmd.execute();
	}
	
	/**
	 * Quando o tipo do atendimento tiss for igual a 04 - Consulta, o campo Tipo de Consulta é obrigatório
	 * @param guiaElement
	 */
	public void isTipoConsultaObrigatorio(GuiaAdapter guiaElement){
		if (guiaElement.getCdTipoAtendimentoTiss().equals("4") && guiaElement.getCdTipoConsulta().isNull() && guiaElement.getDspTpGuia().equals("S") && !getGuiaElement().getTpFluxoPtuWs().equals("SERVER")) {
			ItemServices.goItem("GUIA.CD_TIPO_CONSULTA");
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0100"), "W", NBool.True);
		}
	}
	
	public NString fncTabelaTuss(NString cdProcedimento){
		NString retorno = NString.getNull();
		if (!cdProcedimento.isNull()) {
			IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("DBAPS.FNC_TABELA_TUSS", DbManager.getDataBaseFactory());
			cmd.addReturnParameter(NString.class);
			cmd.addParameter("@pcd_procedimento",cdProcedimento);			
			cmd.execute();
			retorno = cmd.getReturnValue(NString.class);		
		}
		return retorno;
	}
	
	public void isBeneficiarioDesligado(){
		NDate ddtDesligamento = getTask().getMPkgMvsUsuario().getMPkgMvsUsuario().fRetornaDtDesligamento(getGuiaElement().getCdMatricula());
		if (!ddtDesligamento.isNull()) {
			if (!(getTask().getMv2000().msgAlertSn(Types.toStr("O usuário está desligado desde ").append(toChar(ddtDesligamento, "dd/mm/yyyy")).append(".").append(chr(10)).append("Deseja continuar?"), Types.toStr("W"), Types.toStr("Sim/Não"))).toBoolean()) {
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Operação inválida!")
						.append(Lib.chr(10))
						.append("Motivo..: Usuário não está ativo.")
						.append(Lib.chr(10))
						.append("Ação....: Informe um usuário ativo.").toString(),
						"W", /*W = Atenção, I = Informação, E = Erro */
						NBool.True /*bloquear/travar?*/);
			}
		}
	}
	
	public void chkDsDiagnostico(GuiaAdapter guiaElement){
		if (guiaElement.getDsDiagnostico().isNull() && (guiaElement.getDspTpGuia().equals("I") || guiaElement.getDspTpGuia().equals("P")) && !guiaElement.getTpOrigem().equals("PTU")) {
			ItemServices.goItem("GUIA.DS_DIAGNOSTICO");
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0101"), "W", NBool.True);
		}
	}
	
	public void chkIndicadorAcidente(GuiaAdapter guiaElement){
		if (isOperadoraRegidaANS() && (guiaElement.getCdIndicadorAcidente().isNull() && Lib.in(guiaElement.getDspTpGuia(),"S","I","C").toBoolean() && !guiaElement.getTpOrigem().equals("PTU"))) {
			ItemServices.goItem("GUIA.CD_INDICADOR_ACIDENTE");
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0102"), "W", NBool.True);
		}
	}
	
	public void chkItGuiaTaxas(GuiaAdapter guiaElement){
		if(!guiaElement.getNrGuia().isNull() && Services.exist("ITGUIA_TAXA, DBAPS.ITGUIA", "ITGUIA.CD_ITGUIA = ITGUIA_TAXA.CD_ITGUIA AND ITGUIA.NR_GUIA = ".concat(guiaElement.getNrGuia().toString()), false)){
			TaskServices.executeQuery("ITGUIA_TAXA");
		}
	}
	
	private boolean validarAlterarValorProcedimento(NNumber tpTabela, NString pCdProcedimento,
			NString cdGrupoProcedimento, NString snProcedUniversal) {
		boolean retorno = false;

		if (snProcedUniversal.equals("S") || getItguiaElement().getSnPacotePtu().equals("S")
				|| getGuiaElement().getDspTpGuia().equals("O") || liberarAlterarValorProcedimentoRolUnimed(tpTabela)) {
			retorno = true;
		} else {
			if (snAlteraValorCalculadoGrupoProcedimento(cdGrupoProcedimento).equals("S")
					|| snAlteraValorCalculadoGrupoProcedimentoExc(cdGrupoProcedimento, snProcedUniversal,
							pCdProcedimento).equals("S")) {
				retorno = true;
			}
		}
		return retorno;
	}
	
	private NString snAlteraValorCalculadoGrupoProcedimento(NString cdGrupoProcedimento) {
		return Services.getDescricao("SN_ALTERA_VALOR_CALCULADO", "GRUPO_PROCEDIMENTO",
				"CD_GRUPO_PROCEDIMENTO = " + cdGrupoProcedimento, false);
	}
	
	private NString snAlteraValorCalculadoGrupoProcedimentoExc(NString cdGrupoProcedimento, NString snProcedUniversal,
			NString pCdProcedimento) {
		return Services.getDescricao("SN_ALTERA_VALOR_CALCULADO", "GRUPO_PROCED_PERM_ALTR_VL_EXC",
				"CD_GRUPO_PROCEDIMENTO = " + cdGrupoProcedimento + " AND CD_PROCEDIMENTO = '" + pCdProcedimento + "'",
				false);
	}
	
	private boolean liberarAlterarValorProcedimentoRolUnimed(NNumber tpTabela) {
		return (getItguiaElement().getVlProcedimento().isNull() || getItguiaElement().getVlProcedimento().equals(0))
				&& Services.getSnOperadoraUnimed().equals("S") && isPtu();
	}
	
	private boolean isPtu(){
		return !Services.getCdUnimedOrigem().equals(getGuiaElement().getCdUnimedOrigem());
	}
	
	/**
	 * Busca as guias filhas que não foram autorizadas nem negadas.
	 * @param nrGuiaPrincipal Número da guia que está sendo tratada
	 * @return guias
	 */
	public NString existeGuiasFilhasEmAnalise(NNumber nrGuiaPrincipal, NString validation){
		String sql = " SELECT G.NR_GUIA, G.NR_TRANSACAO, TA.DS_TIPO_ATENDIMENTO FROM DBAPS.GUIA G, DBAPS.TIPO_ATENDIMENTO TA WHERE G.NR_GUIA_TEM = :PNR_GUIA AND G.CD_TIPO_ATENDIMENTO = TA.CD_TIPO_ATENDIMENTO";
		
		if (validation.equals("S")) {
			sql += " AND G.SN_VALIDA_REST_CARENCIA = 'N' AND G.CD_MOT_CANCELAMENTO_GUIA IS NULL ";
		}
		DataCursor cCursor = new DataCursor(sql);
		String retorno = "";
		
		try {
			cCursor.addParameter("PNR_GUIA", nrGuiaPrincipal);
			cCursor.open();
			
			if (cCursor.found()) {
				retorno = ResourceManager.getString("guia.msg0104");
				ResultSet rs = cCursor.fetchInto();
				while (rs != null && rs.hasData()) {
					retorno += ResourceManager.getString("guia.msg0105", rs.getString("NR_GUIA"),rs.getString("NR_TRANSACAO"),rs.getString("DS_TIPO_ATENDIMENTO"), fncStatusGuia(rs.getNumber("NR_GUIA")));
					rs = cCursor.fetchInto();
				}
			}

		} finally {
			cCursor.close();
		}
		return NString.toStr(retorno);
	}
	/**
	 * Verifica se existem guias pais negadas
	 * @param nrGuiaPrincipal
	 * @param validation
	 * @return
	 */
	public NString existeGuiasPaisNegadas(NNumber nrGuiaPrincipal, NString validation){
		String sql = " SELECT G.NR_GUIA, G.NR_TRANSACAO, TA.DS_TIPO_ATENDIMENTO FROM DBAPS.GUIA G, DBAPS.TIPO_ATENDIMENTO TA WHERE G.NR_GUIA = :PNR_GUIA AND G.CD_TIPO_ATENDIMENTO = TA.CD_TIPO_ATENDIMENTO";
		
		if (validation.equals("S")) {
			sql += " AND G.SN_VALIDA_REST_CARENCIA = 'N' AND G.CD_MOT_CANCELAMENTO_GUIA IS NOT NULL ";
		}
		DataCursor cCursor = new DataCursor(sql);
		String retorno = "";
		
		try {
			cCursor.addParameter("PNR_GUIA", nrGuiaPrincipal);
			cCursor.open();
			
			if (cCursor.found()) {
				retorno = ResourceManager.getString("guia.msg0104");
				ResultSet rs = cCursor.fetchInto();
				while (rs != null && rs.hasData()) {
					retorno += ResourceManager.getString("guia.msg0105", rs.getString("NR_GUIA"),rs.getString("NR_TRANSACAO"),rs.getString("DS_TIPO_ATENDIMENTO"), fncStatusGuia(rs.getNumber("NR_GUIA")));
					rs = cCursor.fetchInto();
				}
			}
		} finally {
			cCursor.close();
		}
		return NString.toStr(retorno);
	}
	
	/**
	 * No processamento de cancelamento/negativa de guias filhas só é iniciado quando são encontrado as guias.
	 * @param nrGuiaPrincipal 
	 */
	public void negarOuCancelaGuiasFilhas(NNumber nrGuiaPrincipal) {
		if (!existeGuiasFilhasEmAnalise(nrGuiaPrincipal,NString.toStr("N")).isEmpty()) {
			NBool confirmarExecucao = getTask().getMv2000().msgAlertSn(NString.toStr(ResourceManager.getString("guia.msg0106")), NString.toStr("W"), NString.toStr("Sim/Não"));

			if (confirmarExecucao.toBoolean()) {
				this.fncNegarCancelarGuia(getFormModel().getCgCtrl().getCdAutorizadorOpe(), nrGuiaPrincipal, getFormModel().getCgCtrl().getCdMotCancelamento(),getFormModel().getCgCtrl().getDspDsMotCancelamento(), NString.toStr("S"));
			}else if(!confirmarExecucao.toBoolean()){
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0108"), "W", NBool.True);
			}
		}else{
			this.fncNegarCancelarGuia(getFormModel().getCgCtrl().getCdAutorizadorOpe(), nrGuiaPrincipal, getFormModel().getCgCtrl().getCdMotCancelamento(),getFormModel().getCgCtrl().getDspDsMotCancelamento());
		}

	}
	
	/**
	 * Função responsável por cancelar e negar a guia e seus procedimentos
	 * @param pCdAutorizador Código do autorizador que está fazendo o Cancelamento/Negativa
	 * @param pNrGuiaPrincipal Número da guia principal que será negada
	 * @param pCdMotivoCancelamento Código do motivo que será utilizado para Cancelar/Negar a guia
	 * @return 0 Se não encontrou guias | 1 Se encontrou guias 
	 */
	public NNumber fncNegarCancelarGuia(NNumber pCdAutorizador,NNumber pNrGuiaPrincipal,NNumber pCdMotivoCancelamento,NString pDsMotivoCancelamento){
		return this.fncNegarCancelarGuia(pCdAutorizador, pNrGuiaPrincipal, pCdMotivoCancelamento,pDsMotivoCancelamento, NString.toStr("N"));
	}
	 
	/**
	 * Função responsável por cancelar e negar a guia e seus procedimentos
	 * @param pCdAutorizador Código do autorizador que está fazendo o Cancelamento/Negativa
	 * @param pNrGuiaPrincipal Número da guia principal que será negada
	 * @param pCdMotivoCancelamento Código do motivo que será utilizado para Cancelar/Negar a guia
	 * @param pSnNegarCancelarGuiaFilha Indica se será aplicado para as guias filhas/associadas a guia principal se existir
	 * @return 0 Se não encontrou guias | 1 Se encontrou guias 
	 */
	public NNumber fncNegarCancelarGuia(NNumber pCdAutorizador,NNumber pNrGuiaPrincipal,NNumber pCdMotivoCancelamento,NString pDsMotivoCancelamento,NString pSnNegarCancelarGuiaFilha){
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("DBAPS.FNC_NEGAR_CANCELAR_GUIA", DbManager.getDataBaseFactory());

		cmd.addReturnParameter(NNumber.class);
		cmd.addParameter("@P_CD_AUTORIZADOR", pCdAutorizador);
		cmd.addParameter("@P_NR_GUIA_PRINCIPAL", pNrGuiaPrincipal);
		cmd.addParameter("@P_CD_MOTIVO_CANCELAMENTO", pCdMotivoCancelamento);
		cmd.addParameter("@P_DS_MOTIVO_CANCELAMENTO", pDsMotivoCancelamento);
		cmd.addParameter("@P_SN_NEGAR_CANCELAR_GUIA_FILHA", pSnNegarCancelarGuiaFilha);		
		cmd.execute();
		return cmd.getReturnValue(NNumber.class);
	}
	
	/**
	 * Método responsável por exibir os campos da tela de GUIA conforme o Tipo
	 * de Atendimento. OBS: Não alterar a ordem com que é chamado os métodos
	 * exibirCampos, pois irá gerar impacto na exibição dos campos e abas.
	 */
	public void exibirAbasCampos(GuiaAdapter guiaElement, String snOperadoraUnimed, String snEmissaoAvulsa){
		//Abas
		this.getTask().getServices().exibirAbas(guiaElement.getDspTpGuia().toString());
		
		//Campos
		this.getTask().getServices().exibirCamposOperadoraUnimed(snOperadoraUnimed.toString(), snEmissaoAvulsa.toString());
		this.getTask().getServices().exibirCamposConsulta(guiaElement.getDspTpGuia().toString(),guiaElement);
		this.getTask().getServices().exibirCamposSpSadt(guiaElement.getDspTpGuia().toString(),guiaElement);
		this.getTask().getServices().exibirCamposConsultaSpSadt(guiaElement.getDspTpGuia().toString(),guiaElement);
		this.getTask().getServices().exibirCamposInternacao(guiaElement.getDspTpGuia().toString(),guiaElement);
		this.getTask().getServices().exibirCamposOpme(guiaElement.getDspTpGuia().toString(),guiaElement);
		this.getTask().getServices().exibirCamposQuimio(guiaElement.getDspTpGuia().toString(),guiaElement);
		this.getTask().getServices().exibirCamposRadio(guiaElement.getDspTpGuia().toString(),guiaElement);
		this.getTask().getServices().exibirCamposRadioQuimio(guiaElement.getDspTpGuia().toString(),guiaElement);
		this.getTask().getServices().exibirCamposOpmeRadioQuimio(guiaElement.getDspTpGuia().toString(),guiaElement);
		this.getTask().getServices().exibirCamposOpmeRadioQuimioInternacao(guiaElement.getDspTpGuia().toString(),guiaElement);
		this.getTask().getServices().exibirCamposOpmeRadioQuimioInternacaoSpSadt(guiaElement.getDspTpGuia().toString(),guiaElement);
		this.getTask().getServices().exibirCamposReembolso(guiaElement.getDspTpGuia().toString(),guiaElement);
		
		//Botoes
		this.getTask().getServices().exibirCamposBotoesOdontologia(guiaElement.getDspTpGuia().toString(),guiaElement);
	}
	
	private NString obterValorChaveEmiteGuiaRetroPrest() {
		return Services.getDescricao("VALOR", "MVS_CONFIGURACAO",
				"CHAVE = 'ATEND_GUIA_EMISSAO_RETRO_PREST' AND CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA", false);
	}
	
	public boolean isOperadoraRegidaANS() {
		boolean retorno = false;
		StringBuilder sqlConsulta = new StringBuilder();
		sqlConsulta.append("SELECT SN_REGIDO_ANS FROM DBAMV.MULTI_EMPRESAS_MV_SAUDE ");
		sqlConsulta.append("WHERE CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA ");

		DataCursor cursor = new DataCursor(sqlConsulta.toString());

		try {
			cursor.open();
			if (cursor.found()) {
				ResultSet rs = cursor.fetchInto();
				if ((NString.toStr("S")).equals(rs.getStr("SN_REGIDO_ANS"))) {
					retorno = true;
				}
			}

		} catch (Exception e) {
			logger.error(new LogTraceEvent(this, new LogTraceMessage("msgErro"), e, LEVEL.ERROR));
		} finally {
			cursor.close();
		}

		return retorno;
	}
	
	public void removerPiscaAlerta(){
		ItemServices.setItemStyleClass("GUIA.BTN_ALERTA", "");
	}
	
	public void getDescricaoPrestadorExecutante(GuiaAdapter guiaElement) {
 		StringBuilder sqlConsulta = new StringBuilder();
 		sqlConsulta.append("SELECT TP_PRESTADOR, CD_PRESTADOR_SOLICITANTE, DSP_NM_SOLICITANTE, ATEND_PROFSOLIC_LISTATODOS, ");
 		sqlConsulta.append("NR_CPF_CGC, NR_FONE FROM (SELECT P.TP_PRESTADOR TP_PRESTADOR, P.CD_PRESTADOR CD_PRESTADOR_SOLICITANTE, ");
 		sqlConsulta.append("P.NM_PRESTADOR DSP_NM_SOLICITANTE, P.NR_CPF_CGC, 'N' ATEND_PROFSOLIC_LISTATODOS, SUBSTR(P.NR_FONE, 0, 20) NR_FONE ");
 		sqlConsulta.append("FROM DBAPS.PRESTADOR P, DBAPS.PRESTADOR_ASSOCIADO PA, DBAPS.MVS_CONFIGURACAO MC ");
 		sqlConsulta.append("WHERE P.CD_PRESTADOR = PA.CD_PRESTADOR AND P.SN_EXECUTOR = 'S' ");
 		sqlConsulta.append("AND PA.CD_PRESTADOR_ASSOCIADO = :P_CD_PRESTADOR  AND P.CD_PRESTADOR = :GUIA_CD_PRESTADOR ");
 		sqlConsulta.append("AND P.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA AND P.TP_PRESTADOR = 'F' ");
 		sqlConsulta.append("AND P.CD_MULTI_EMPRESA = MC.CD_MULTI_EMPRESA AND MC.CHAVE = 'ATEND_PROFSOLIC_LISTATODOS' ");
 		sqlConsulta.append("AND MC.VALOR = 'N' ");
 		sqlConsulta.append("UNION ");
 		sqlConsulta.append("SELECT P.TP_PRESTADOR TP_PRESTADOR, P.CD_PRESTADOR CD_PRESTADOR_SOLICITANTE, ");
 		sqlConsulta.append("P.NM_PRESTADOR DSP_NM_SOLICITANTE, P.NR_CPF_CGC, 'N' ATEND_PROFSOLIC_LISTATODOS, ");
 		sqlConsulta.append("SUBSTR(P.NR_FONE, 0, 20) NR_FONE ");
 		sqlConsulta.append("FROM DBAPS.PRESTADOR P, DBAPS.MVS_CONFIGURACAO MC ");
 		sqlConsulta.append("WHERE P.CD_PRESTADOR = :GUIA_CD_PRESTADOR AND P.CD_PRESTADOR = :P_CD_PRESTADOR ");
 		sqlConsulta.append("AND P.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA AND P.TP_PRESTADOR = 'F' ");
 		sqlConsulta.append("AND P.CD_MULTI_EMPRESA = MC.CD_MULTI_EMPRESA AND MC.CHAVE = 'ATEND_PROFSOLIC_LISTATODOS' AND MC.VALOR = 'N' ");
 		sqlConsulta.append("UNION ALL ");
 		sqlConsulta.append("SELECT P.TP_PRESTADOR TP_PRESTADOR, P.CD_PRESTADOR CD_PRESTADOR_SOLICITANTE, ");
 		sqlConsulta.append("P.NM_PRESTADOR DSP_NM_SOLICITANTE, P.NR_CPF_CGC, 'S' ATEND_PROFSOLIC_LISTATODOS, SUBSTR(P.NR_FONE, 0, 20) NR_FONE ");
 		sqlConsulta.append("FROM DBAPS.PRESTADOR P, DBAPS.MVS_CONFIGURACAO MC ");
 		sqlConsulta.append("WHERE P.CD_PRESTADOR = :GUIA_CD_PRESTADOR ");
 		sqlConsulta.append("AND P.TP_SITUACAO = 'A' ");
 		sqlConsulta.append("AND P.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA AND P.CD_MULTI_EMPRESA = MC.CD_MULTI_EMPRESA ");
 		sqlConsulta.append("AND MC.CHAVE = 'ATEND_PROFSOLIC_LISTATODOS' AND P.TP_PRESTADOR = 'F' AND MC.VALOR = 'S') ");

		DataCursor cursor = new DataCursor(sqlConsulta.toString());
		
		cursor.addParameter("GUIA_CD_PRESTADOR", guiaElement.getCdPrestadorExecutorPf());
		cursor.addParameter("P_CD_PRESTADOR", guiaElement.getCdPrestador());

		try {
			cursor.open();

			if (cursor.found()) {

				ResultSet rCursor = cursor.fetchInto();

				if (!rCursor.getStr("TP_PRESTADOR").equals("F")) {
					getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0129"), "E", NBool.True);
				}
				
				guiaElement.setNmPrestadorExecutorPf(rCursor.getStr("DSP_NM_SOLICITANTE"));
			} else {
				if (!guiaElement.getCdPrestador().isNull()) {
					getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0130"), "E", NBool.True);
				} else {
					getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0131"), "E", NBool.True);
				}
			}
		} finally {
			cursor.close();
		}
	}
	
	public void limparEspecialidadeExecutante(GuiaAdapter guiaElement) {
		guiaElement.setCdEspecialidadeExecutante(NNumber.getNull());
		guiaElement.setDspDsEspecialidadeExecutante(NString.getNull());
	}
	
	public void configurarEspecialidadeExecutante(GuiaAdapter guiaElement) {
		if (!guiaElement.getCdPrestador().isNull()) {

			ItemServices.setItemEnabled("GUIA.CD_ESPECIALIDADE_EXECUTANTE", true);
			ItemServices.setItemNavigable("GUIA.CD_ESPECIALIDADE_EXECUTANTE", true);
			ItemServices.setItemInsertAllowed("GUIA.CD_ESPECIALIDADE_EXECUTANTE", true);
			ItemServices.setItemUpdateAllowed("GUIA.CD_ESPECIALIDADE_EXECUTANTE", true);
			
			StringBuilder sqlConsulta = new StringBuilder();
			sqlConsulta.append("SELECT CD_ESPECIALIDADE ");
			sqlConsulta.append("FROM dbaps.ESPECIALIDADE_PRESTADOR ESP_PRE ");
			sqlConsulta.append("WHERE CD_PRESTADOR =  NVL(:P_CD_PRESTADOR_EXECUTANTE, :P_CD_PRESTADOR) ");
			sqlConsulta.append("AND EXISTS (SELECT 1 FROM DBAPS.PRESTADOR WHERE CD_PRESTADOR = ESP_PRE.CD_PRESTADOR ");
			sqlConsulta.append("AND CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA) ");


			DataCursor dataCursor = new DataCursor(sqlConsulta.toString());
			dataCursor.addParameter("P_CD_PRESTADOR_EXECUTANTE", guiaElement.getCdPrestadorSolicitado());
			dataCursor.addParameter("P_CD_PRESTADOR", guiaElement.getCdPrestador());
			try {
				dataCursor.open();
				ResultSet resultado = dataCursor.fetchInto();
				int count = dataCursor.getRowCount();
				if (resultado != null) {
					if (count == 1) {
						ItemServices.setItemEnabled("GUIA.CD_ESPECIALIDADE_EXECUTANTE", true);
						ItemServices.setItemNavigable("GUIA.CD_ESPECIALIDADE_EXECUTANTE", true);
						ItemServices.setItemInsertAllowed("GUIA.CD_ESPECIALIDADE_EXECUTANTE", true);
						ItemServices.setItemUpdateAllowed("GUIA.CD_ESPECIALIDADE_EXECUTANTE", true);
					}
				}
			} finally {
				dataCursor.close();
			}
		}
	}
	
	public void configurarConselhoExecutante(GuiaAdapter guiaElement){
		if(!guiaElement.getCdPrestadorExecutorPf().isNull()){
			StringBuilder sqlCursor = new StringBuilder();
			sqlCursor.append("SELECT CP.CD_TISS, CP.DS_SIGLA, ");
			sqlCursor.append("P.UF_CONSELHO, P.DS_COD_CONSELHO, CF.NM_UF ");
			sqlCursor.append("FROM DBAPS.PRESTADOR P, DBAPS.CONSELHO_PROFISSIONAL CP, DBAPS.CEP_UF CF ");
			sqlCursor.append("WHERE P.CD_CONSELHO_PROFISSIONAL = CP.CD_CONSELHO_PROFISSIONAL ");
			sqlCursor.append("AND P.UF_CONSELHO = CF.CD_UF ");
			sqlCursor.append("AND  P.cd_prestador = NVL(:P_CD_PRESTADOR_EXECUTANTE, :P_CD_PRESTADOR) ");

			DataCursor dataCursor = new DataCursor(sqlCursor.toString());

			dataCursor.addParameter("P_CD_PRESTADOR_EXECUTANTE", guiaElement.getCdPrestadorExecutorPf());
			dataCursor.addParameter("P_CD_PRESTADOR", guiaElement.getCdPrestador());

			try {
				dataCursor.open();
				ResultSet dataCursorResults = dataCursor.fetchInto();
				if (dataCursorResults != null) {
					guiaElement.setCdTissConselhoProfiExecPf(dataCursorResults.getStr("CD_TISS"));
					guiaElement.setDspDsTissConselhoProfiExecPf(dataCursorResults.getStr("DS_SIGLA"));
					guiaElement.setNrRegConselhoProfiExec(dataCursorResults.getStr("DS_COD_CONSELHO"));
					guiaElement.setUfConselhoProfissionalExec(dataCursorResults.getStr("UF_CONSELHO"));
					guiaElement.setDspDsUfConselhoProfissionalExec(dataCursorResults.getStr("NM_UF"));
				}

			} finally {
				dataCursor.close();
			}
		} 

	}
	
	private boolean isGuiaExistente(NNumber nrGuia){
		return Services.exist("GUIA", "NR_GUIA = " + nrGuia, false);
	}
	
	private boolean isDtExecucaoInternacaoAlterada(NNumber nrGuia, NDate dtExecucaoInternacao){
		return !(dtExecucaoInternacaoAnterior(nrGuia)).equals(dtExecucaoInternacao);
	}
	
	private NDate dtExecucaoInternacaoAnterior(NNumber nrGuia) {
		NDate retorno = NDate.getNull();

		StringBuilder sqlConsulta = new StringBuilder();
		sqlConsulta.append("SELECT To_Char(DT_EXECUCAO_INTERNACAO, 'DD/MM/YYYY') DT_EXECUCAO_INTERNACAO ");
		sqlConsulta.append("FROM DBAPS.GUIA ");
		sqlConsulta.append("WHERE NR_GUIA = :P_NR_GUIA ");

		DataCursor cursor = new DataCursor(sqlConsulta.toString());
		try {
			cursor.addParameter("P_NR_GUIA", nrGuia);
			cursor.open();

			if (cursor.found()) {
				ResultSet rs = cursor.fetchInto();
				retorno = rs.getDate("DT_EXECUCAO_INTERNACAO");
			}
		} catch (Exception ex) {
			logger.error(new LogTraceEvent(this, new LogTraceMessage("msgErro"), ex, LEVEL.ERROR));
		} finally {
			cursor.close();
		}

		return retorno;
	}
	
	/**
	 * Método para exibir a aba de rateio da fachesf
	 */
	public void exibirGridRateioFachest(){
		boolean isExibir = Lib.isNull(Services.getDescricao("VALOR", "MVS_CONFIGURACAO", "CHAVE = 'CONFIG_OPERADORA_RATEIO' AND CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA", false),"N").equals("S");
		
		ViewServicesExtensions.setVisualAttribute("PAGE_PROCEDIMENTOS_grdCopartRateioFachesf", "Visible", isExibir);
		ViewServicesExtensions.setVisualAttribute("PAGE_PROCEDIMENTOS_grdGlosasDefault", "Visible", !isExibir);
	}
	
	public boolean isGuiaAutorizada(GuiaAdapter guiaElement){
		return (NString.toStr("S")).equals(getGuiaElement().getSnValidaRestCarencia());
	}
	
}
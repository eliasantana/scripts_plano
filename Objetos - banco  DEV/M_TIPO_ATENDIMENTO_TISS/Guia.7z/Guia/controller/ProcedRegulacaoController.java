package br.com.mv.soul.mvsaude.forms.Guia.controller;

import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class ProcedRegulacaoController extends DefaultBlockController {

	public ProcedRegulacaoController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}

	@AfterQuery
    public void proced_regulacao_AfterQuery(RowAdapterEvent rowAdapterEvent) {
		this.getTask().getServices().setDspDsProcedTipoRegulacao();
    }

	@ActionTrigger(item = "BTN_VOLTAR", action = "btn_voltar_click")
    public void btn_voltar_click() {
		
		ItemServices.goItem("ITGUIA.CD_PROCEDIMENTO");

    }
}

package br.com.mv.soul.mvsaude.forms.Guia.controller;

import static morphis.foundations.core.appsupportlib.Globals.getGlobal;
import static morphis.foundations.core.appsupportlib.Lib.chr;
import static morphis.foundations.core.appsupportlib.Lib.isNull;
import static morphis.foundations.core.appsupportlib.Lib.toChar;
import static morphis.foundations.core.appsupportlib.Lib.trunc;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.getBlockCurrentRecord;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.setBlockWhereClause;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.goItem;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemEnabled;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemInsertAllowed;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemIsValid;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemNavigable;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemRequired;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemUpdateAllowed;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemValue;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.addParameter;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.callTask;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.commitTask;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.createParameterList;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.deleteParameter;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.executeAction;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.executeQuery;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.getParameterList;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.goBlock;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.hideView;
import static morphis.foundations.core.types.Types.toBool;
import static morphis.foundations.core.types.Types.toDate;
import static morphis.foundations.core.types.Types.toNumber;
import static morphis.foundations.core.types.Types.toStr;
import static morphis.foundations.core.util.globals.Globals.setGlobal;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.EventObject;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import br.com.mv.soul.common.dbservices.PkgMv2000;
import br.com.mv.soul.common.dbservices.StoredProcedures;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.common.libs.DbUtils.DataList;
import br.com.mv.soul.common.localization.ResourceManager;
import br.com.mv.soul.flavor.runtime.action.ViewTrigger;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.EnviarEmailAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.FiltroPrestExterno;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaProrrogacaoAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaAuditoriaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.MensContratoAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.PrestExternoAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.services.GuiaServices;
import br.com.mv.soul.mvsaude.forms.Guia.services.PkgMvsGuia;
import br.com.mv.soul.mvsaude.libs.Services;
import br.com.mv.soul.mvsaude.libs.Alerta.Alerta;
import br.com.mv.soul.mvsaude.libs.Configuracao.Configuracao;
import br.com.mv.soul.mvsaude.libs.WebService.SingleSignOnUnimed;
import br.com.mv.soul.mvsaude.libs.WebService.WebService;
import br.com.mv.soul.mvsaude.libs.WebService.unimed.sso.AutenticaUsuarioSSORequest;
import br.com.mv.soul.mvsaude.libs.WebService.unimed.sso.AutorizaAcessoAplicacaoResponse;
import br.com.mv.soul.mvsaude.libs.WebService.unimed.sso.CtAplicacao;
import br.com.mv.soul.mvsaude.libs.WebService.unimed.sso.CtAutorizacaoAplicacao;
import br.com.mv.soul.mvsaude.libs.WebService.unimed.sso.CtUsuarioUnimed;
import morphis.foundations.core.appdatalayer.data.DataCommand;
import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.DataLayerException;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.data.IDataCommand;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appdatalayer.data.TableRow;
import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.AfterRowInsert;
import morphis.foundations.core.appdatalayer.events.AfterRowUpdate;
import morphis.foundations.core.appdatalayer.events.BeforeQuery;
import morphis.foundations.core.appdatalayer.events.BeforeRowDelete;
import morphis.foundations.core.appdatalayer.events.BeforeRowInsert;
import morphis.foundations.core.appdatalayer.events.BeforeRowUpdate;
import morphis.foundations.core.appdatalayer.events.QueryComplete;
import morphis.foundations.core.appdatalayer.events.QueryEvent;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.MessageServices;
import morphis.foundations.core.appsupportlib.runtime.Task;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.ViewServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.appsupportlib.runtime.events.RecordCreated;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.types.Types;
import morphis.foundations.core.util.Ref;
import morphis.foundations.core.util.logging.ILogger;
import morphis.foundations.core.util.logging.LogTraceEvent;
import morphis.foundations.core.util.logging.LogTraceEvent.LEVEL;
import morphis.foundations.core.util.logging.LogTraceMessage;
import morphis.foundations.core.util.logging.LoggerFactory;

public class GuiaController extends DefaultBlockController {
	
	private static final String CHAT_INTERCAMBIO = "Chat Intercambio"; 
	protected static ILogger logger = LoggerFactory.getInstance(GuiaController.class);

	NString backup = NString.getEmpty();

	public GuiaController(IFormController parentController, String name) {

		super(parentController, name);
	}
  
	public FiltroPrestExterno  getFiltroPrestExternoElement() {
		return (FiltroPrestExterno) this.getFormModel().getFiltroPrestExterno().getItems();
	}
	
	
	
	@Override
	public GuiaTask getTask() {

		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {

		return this.getTask().getModel();
	}

	public EnviarEmailAdapter getEnviarEmailElement() {

		return (EnviarEmailAdapter) this.getFormModel().getEnviarEmail().getRowAdapter(true);
	}
	
	
	
	public ItguiaAuditoriaAdapter getItguiaAuditoriaElement(){
		return (ItguiaAuditoriaAdapter) this.getFormModel().getItguiaAuditoria().getRowAdapter(true);
	}
	
	public GuiaProrrogacaoAdapter getGuiaProrrogacaoElement(){
		return (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
	}

	/**
	 * Método padrão de reuso do adapter
	 * 
	 * @author Diego.Nobre
	 * @since 23/04/2013
	 * @return GuiaAdapter
	 */
	public GuiaAdapter getGuiaElement() {
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}
	
	public ItguiaAdapter getItguiaElement(){
		return (ItguiaAdapter) this.getFormModel().getItguia().getRowAdapter(true);
	}

	@AfterQuery
	public void guia_AfterQuery(RowAdapterEvent args) {

		GuiaAdapter guiaElement = (GuiaAdapter) args.getRow();
		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
		
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		
		if (guiaElement != null && !guiaElement.getNrGuia().isNull()) {//Habilitar o botao de upload anexo apenas se houver guia salva.
			ItemServices.setItemEnabled("GUIA_ANEXO.BTN_UPLOAD_ANEXO", true);
		} else {
			ItemServices.setItemEnabled("GUIA_ANEXO.BTN_UPLOAD_ANEXO", false);
		}
		
		this.getTask().getServices().prcGrupoFranquia(guiaElement, toBool(NBool.False), toStr("A"));

		guiaElement.setNmPrestadorExecutorPf(Services.getDescricao("NM_PRESTADOR", "PRESTADOR", "CD_MULTI_EMPRESA = PKG_MV2000.LE_EMPRESA AND CD_PRESTADOR = " + guiaElement.getCdPrestadorExecutorPf(), false));
        
		guiaElement.setDspCdPrestadorExecutorPfInterno(Services.getDescricao("CD_INTERNO", "PRESTADOR", "CD_MULTI_EMPRESA = PKG_MV2000.LE_EMPRESA AND CD_PRESTADOR = " + guiaElement.getCdPrestadorExecutorPf(), false));

		guiaElement.setDspDsAtiMed(Services.getDescricao("DS_ATI_MED", "ATI_MED", "CD_ATI_MED = " + guiaElement.getCdAtiMed(), false));

		guiaElement.setDspNmExecutor(Services.getDescricao("NM_PRESTADOR", "PRESTADOR", "CD_MULTI_EMPRESA = PKG_MV2000.LE_EMPRESA AND CD_PRESTADOR = " + guiaElement.getCdPrestadorExecutor(), false));
		guiaElement.setDspCdPrestadorExecutorInterno(Services.getDescricao("CD_INTERNO", "PRESTADOR", "CD_MULTI_EMPRESA = PKG_MV2000.LE_EMPRESA AND CD_PRESTADOR = " + guiaElement.getCdPrestadorExecutor(), false));

		guiaElement.setDspDsCid(getTask().getMPkgMvsCid().getMPkgMvsCid().fRetornaDescricao(guiaElement.getCdCid(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.False), toBool(NBool.False)));

		guiaElement.setDspDsProcedimentoPrincipal(getTask().getMPkgMvsContasMedicas().getMPkgMvsContasMedicas().fProcPrincipal(guiaElement.getCdProcedimentoPrincipal(), guiaElement.getCdTipoAtendimento(), toBool(NBool.False)));

		getTask().getServices().getLovDsEspecialidade(guiaElement, "A");

		this.getTask().getServices().prcUsuario(guiaElement, toBool(NBool.False));

		guiaElement.setDspDsPlano(getTask().getMPkgMvsPlano().getMPkgMvsPlano().fRetornaDescricao(guiaElement.getCdPlano(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.False), toBool(NBool.False)));

		this.getTask().getServices().prcAutorizador(guiaElement, toBool(NBool.False));

		this.getTask().getServices().prcTipoAtendimento(toBool(NBool.False));

		if (guiaElement.getDspSnTpInternacao().equals("S")) {
			this.getTask().getServices().prcTipAcomodacao(toStr("N"), NBool.False);
			ItemServices.setItemEnabled("GUIA.BTN_PRORROGACAO", true);
		} else {
			ItemServices.setItemEnabled("GUIA.BTN_PRORROGACAO", false);
		}

		this.getTask().getServices().prcPrestador(guiaElement, toBool(NBool.False));

		guiaElement.setDspDsMotCancelamentoGuia(getTask().getMPkgMvsMotCancelaGuia().getMPkgMvsMotCancelaGuia().fRetornaDescricao(guiaElement.getCdMotCancelamentoGuia(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.False), toBool(NBool.False)));


		guiaElement.setDspEspecialidadeSolicitante(getTask().getMPkgMvsPrestador().getMPkgMvsPrestador().fVerificaEspPrestador(isNull(guiaElement.getCdPrestadorSolicitante(), guiaElement.getCdPrestador()), guiaElement.getCdEspecialidadeSolicitante(), toBool(NBool.False)));

		guiaElement.setNmPrestadorSolicitado(getTask().getMPkgMvsPrestador().getMPkgMvsPrestador().fRetornaDescricao(guiaElement.getCdPrestadorSolicitado(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.False), toBool(NBool.False)));
        guiaElement.setNmPrestadorExecutorPf(Services.getDescricao("NM_PRESTADOR_EXECUTOR_PF", "GUIA", "NR_GUIA = " + getGuiaElement().getNrGuia(), false));
		guiaElement.setDspCdPrestadorInterno(Services.getDescricao("CD_INTERNO", "PRESTADOR", "CD_MULTI_EMPRESA = PKG_MV2000.LE_EMPRESA AND CD_PRESTADOR = " + guiaElement.getCdPrestador(), false));
		
		this.getTask().getServices().prcCheckGuiaAltera();

		guiaElement.setDspDsCortesia(getTask().getMPkgMvsCortesia().getMPkgMvsCortesia().fRetornaDescricao(guiaElement.getCdCortesia(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.False), toBool(NBool.False)));

		guiaElement.setDspDsPlanoCortesia(getTask().getMPkgMvsPlano().getMPkgMvsPlano().fRetornaDescricao(guiaElement.getCdPlanoPgtoCortesia(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.False), toBool(NBool.False)));

		if (!guiaElement.getDsDestinoCortesia().isNull()) {
			guiaElement.setDspNmSegurado(guiaElement.getDsDestinoCortesia());			
		}
		
		cdMatriculaResponsavel_validate(false);
		this.getTask().getServices().getMotivoAutorizacao(false);
		cdEmpresaResponsavel_validate();

		/*
		 * Cleber Kellmane - Devido a incompatibilidade da versão 16 do
		 * framework publicada em 12/09/2012, foi necessário criar um campo
		 * virtual para que possamos não exibir o numero da guia quando a mesma
		 * não estiver autorizada. Desta forma tivemos que chamar o metodo
		 * abaixo:
		 */
		this.getTask().getServices().prcHabilitaBotoes(guiaProrrogacaoElement, guiaElement, toStr("N"));

		/*
		 * Preenche e-mail do prestador para enviar a guia e só habilita botão
		 * de enviar se a guia estiver autorizada
		 * 
		 * @author diego.nobre
		 * 
		 * @since 05/12/2012
		 */
		EnviarEmailAdapter enviarEmail = (EnviarEmailAdapter) getFormModel().getEnviarEmail().getRowAdapter(true);
		getTask().getServices().setDspEmailPrestador(guiaElement, enviarEmail);
//
		// Verifica se deve habilitar botão de enviar e-mail;
		getTask().getServices().verificaBotaoEmailGuia();
		getTask().getServices().verificaBotaoSms();
		
		getTask().getServices().verificaDsCancelamentoGuia();
		
		/**
		 * Desabilitada o botão de remover anexo se a guia estiver autorizada
		 * @author rosemere.mota
		 * @since 28/08/2014
		 */
		getTask().getServices().verificaBotaoExcluirAnexo();

		/**
		 * Se a guia for de odontologia, buscar pelo código tiss dos campos de atendimento e faturamento
		 * @since 14/10/2013
		 */
		if (guiaElement.getDspTpGuia().equals("D")) {
			cd_tipo_atendimento_odonto_validation();
			cd_tipo_faturamento_odonto_validation();
			cd_ocorrencia_pericia_inicial_validation();
			cd_ocorrencia_pericia_final_validation();
			sn_pericia_inicial_change();
			sn_pericia_final_change();
		}

		guiaElement.setDsEstadiamento(this.getTask().getServices().getDescricaoEstadiamento(guiaElement.getCdEstadiamento(), false));
		guiaElement.setDspQuimioterapia(this.getTask().getServices().getDescricaoQuimioterapia(guiaElement.getCdQuimioterapia(), false));
		guiaElement.setDsFinalidade(this.getTask().getServices().getDescricaoFinalidade(guiaElement.getCdFinalidade(), false));
		guiaElement.setDspCdEcog(NString.toStr(obterEcogSalva(guiaElement.getCdEcog())));
		guiaElement.setDsEcog(this.getTask().getServices().getDescricaoEcog(guiaElement.getDspCdEcog(), false));
		guiaElement.setDsDiagnosticoImagem(this.getTask().getServices().getDescricaoDiagnostico(guiaElement.getCdDiagnosticoImagem(), true));
		camposSolicitacoes(guiaElement.getDspTpGuia());

		/**
		 * Exibir a descrição do tp_origem
		 * @since 11/03/2015
		 */
		if (guiaElement != null) {
			if (guiaElement.getTpOrigem().equals("MVS")) {
				guiaElement.setDspTpOrigem(toStr("Soul"));
			} else if (guiaElement.getTpOrigem().equals("INT")) {
				guiaElement.setDspTpOrigem(toStr("Internet"));
			} else if (guiaElement.getTpOrigem().equals("AV")) {
				guiaElement.setDspTpOrigem(toStr("Avulsa/Intercâmbio"));
			} else if (guiaElement.getTpOrigem().equals("MC")) {
				guiaElement.setDspTpOrigem(toStr("Mens Contrato"));
			} else if (guiaElement.getTpOrigem().equals("WS")) {
				guiaElement.setDspTpOrigem(toStr("WebService"));
			} else if (guiaElement.getTpOrigem().equals("PTU")) {
				guiaElement.setDspTpOrigem(toStr("PTU"));
			} else {
				guiaElement.setDspTpOrigem(toStr("Outro"));
			}
			
			if (!guiaElement.getDtImpressaoGuia().isNull()) {
				//MULTI-IDIOMA: MSG_0044 - EMITIDA
				guiaElement.setDspDsImpressaoGuia(NString.toStr(ResourceManager.getString("guia.msg0044")));
			}
			
			if(Services.exist("GUIA", "NR_GUIA_TEM = ".concat(guiaElement.getNrGuia().toString()), false)){
				//MULTI-IDIOMA: MSG_0076 - SIM
				guiaElement.setDspDsGuiaTem(NString.toStr(ResourceManager.getString("guia.msg0076")));
			}else{
				//MULTI-IDIOMA: MSG_0077 - NÃO
				guiaElement.setDspDsGuiaTem(NString.toStr(ResourceManager.getString("guia.msg0077")));
			}
			
		}
		
		
		if(snOperadoraUnimed.equals("S")){
			cd_unimed_executora_validation();
			cd_unimed_origem_validation();
			cd_unimed_solicitante_validation();
			if(guiaElement.getTpFluxoPtuWs().equals("CLIENT") && !guiaElement.getCdPtuMensagemDestino().isNull()) {
				BlockServices.setBlockUpdateAllowed("GUIA", false);
			}
		}
		
		if (!guiaElement.getCdEspecialidadeSolicitante().isNull()) {
			getTask().getServices().getDsEspecialidade(guiaElement.getCdEspecialidadeSolicitante());
		}

		this.getTask().getServices().exibeAlerta(false);
		
		getGuiaElement().setDspTpSituacaoAtual(this.getTask().getServices().fncStatusGuia(getGuiaElement().getNrGuia()));
		
		if (this.getTask().getServices().existeMensagensNaoLidas(getGuiaElement().getNrGuia(), Lib.isNull(getGuiaElement().getCdPrestadorExecutor(), getGuiaElement().getCdPrestador()))) {
			//MULTI-IDIOMA: MSG_0024 - Existem mensagens não lidas, para visualizar acesse a Aba \"Chat\".
			String msg = ResourceManager.getString("guia.msg0024");
			getTask().getMv2000().msgAlert(msg, "I", NBool.False);
			BlockServices.getBlockController("CHAT_MENSAGEM").getInteractionRulesStrategy().executeQuery();
		}
		
		if(!getGuiaElement().getNrGuia().isNull()){
			this.getFormModel().getCgCtrl().setDspDtAltaInternacao(getGuiaElement().getDtAltaInternacao());
			this.getFormModel().getCgCtrl().setDspDtExecucaoInternacao(getGuiaElement().getDtExecucaoInternacao());
			
			if(!getGuiaElement().getCdPtuMensagemOrigem().isNull()){
				if(getGuiaElement().getTpFluxoPtuWs().equals("CLIENT")){
					BlockServices.setWhereClauseParameter("LOG_TRANSACAO_PTU_ONLINE", "PNR_TRANSACAO_PRESTADORA", getGuiaElement().getCdPtuMensagemOrigem());
				}else{
					BlockServices.setWhereClauseParameter("LOG_TRANSACAO_PTU_ONLINE", "PNR_TRANSACAO_PRESTADORA", getGuiaElement().getCdPtuMensagemDestino());	
				}
				BlockServices.getBlockController("LOG_TRANSACAO_PTU_ONLINE").getInteractionRulesStrategy().executeQuery();
			}
			
		}
		cd_prestador_externo_validation();
		cd_programa_atendimento_validation();
		this.getTask().getServices().desabilitarBotaoGuiaNegativa(getGuiaElement());
		
		cd_classificacao_nodulo_validation();
		cd_classificacao_tumor_validation();
		cd_classificacao_metastase_validation();
		cd_tiss_conselho_prof_sol_ValidationTrigger();
		uf_conselho_prof_solc_ValidationTrigger();
		cd_tiss_conselho_profi_exec_pf_ValidationTrigger();
		uf_conselho_profissional_exec_ValidationTrigger();
		cd_especialidade_executante_ValidationTrigger();
	}

	@BeforeRowDelete
	public void guia_BeforeRowDelete(RowAdapterEvent args) {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		if (guiaElement != null && !guiaElement.getNrGuia().isNull()) {//Habilitar o botao de upload anexo apenas se houver guia salva.
			ItemServices.setItemEnabled("GUIA_ANEXO.BTN_UPLOAD_ANEXO", true);
		} else {
			ItemServices.setItemEnabled("GUIA_ANEXO.BTN_UPLOAD_ANEXO", false);
		}
		PkgMvsGuia.pBPdGuia(guiaElement);
	}

	@BeforeRowInsert
	public void guia_BeforeRowInsert(RowAdapterEvent args) {

		GuiaAdapter guiaElement = (GuiaAdapter)args.getRow();
		ItguiaAdapter itguiaElement = (ItguiaAdapter) this.getFormModel().getItguia().getRowAdapter(true);
		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
		
		NString snEmissaoAvulsa = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N"); // Emissão Avulsa
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");

		guiaElement.setCdUsuarioEmissao(TaskServices.getUser());

		if (snOperadoraUnimed.equals("S")) {
			
			if (getGuiaElement().getCdTipoAtendimentoTiss().isNull() 
					&& getGuiaElement().getDspTpGuia().equals("S") && !getGuiaElement().getTpFluxoPtuWs().equals("SERVER") ) {
				
				//MULTI-IDIOMA: MSG_0027 - Informe o Tipo de Atendimento na aba 'Dados Complementares' .
				ItemServices.goItem("GUIA.CD_TIPO_ATENDIMENTO_TISS");
				String msg = ResourceManager.getString("guia.msg0027_1");
				getTask().getMv2000().msgAlert(msg, "W", NBool.True);
			}
			
		}else if(getGuiaElement().getCdTipoAtendimentoTiss().isNull() && getGuiaElement().getDspTpGuia().equals("S") && snOperadoraUnimed.equals("N")){
				//MULTI-IDIOMA: MSG_0027 - Informe o Tipo de Atendimento na aba 'Dados Complementares' .
				ItemServices.goItem("GUIA.CD_TIPO_ATENDIMENTO_TISS");
				String msg = ResourceManager.getString("guia.msg0027_1");
				getTask().getMv2000().msgAlert(msg, "W", NBool.True);
		}
				
		if(guiaElement.getDspSnPrestador().equals("S") && ( !getGuiaElement().getTpFluxoPtuWs().equals("SERVER") && !getGuiaElement().getTpOrigem().equals("PTU") ) ){
			
			if(guiaElement.getCdPrestador().isNull() && guiaElement.getNmPrestador().isNull()){
				ItemServices.goItem("GUIA.CD_PRESTADOR");
				//MULTI-IDIOMA: MSG_0061 - Não é permitido salvar guia sem Contratado Solicitante
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0061"), "W", NBool.True);
				
			}
		}
		
		if (guiaElement.getDspTpGuia().equals("C") && !getGuiaElement().getTpOrigem().equals("PTU")) { // Consulta
			if (guiaElement.getCdEspecialidade().isNull()) {
				ItemServices.goItem("GUIA.CD_ESPECIALIDADE");
				
				//MULTI-IDIOMA: MSG_0029 - Não é permitido salvar guia de consulta sem Especialidade.
				String msg = ResourceManager.getString("guia.msg0029");
				getTask().getMv2000().msgAlert(msg.toString(), "W", NBool.True);
			}
		}
		
		if (snEmissaoAvulsa.equals("N") && guiaElement.getCdMatricula().isNull()) {
			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Operação inválida!")
					.append(Lib.chr(10))
					.append("Motivo..: Beneficiário não foi informado.").toString(),
					"W", /*W = Atenção, I = Informação, E = Erro */
					NBool.True /*bloquear/travar?*/);
		}
		
		if (guiaElement != null && !guiaElement.getNrGuia().isNull()) {//Habilitar o botao de upload anexo apenas se houver guia salva.
			ItemServices.setItemEnabled("GUIA_ANEXO.BTN_UPLOAD_ANEXO", true);
		} else {
			ItemServices.setItemEnabled("GUIA_ANEXO.BTN_UPLOAD_ANEXO", false);
		}
		
		if (guiaElement.getDspTpGuia().equals("S") || guiaElement.getDspTpGuia().equals("I")) {// - SP/SADT - INTERNAÇÃO
			if(guiaElement.getTpCaraterSolicInter().isNull()){
				ItemServices.goItem("GUIA.TP_CARATER_SOLIC_INTER");
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0116"), "W", NBool.True);
			}
		}

		// Alteração a pedido de Dellanio.
		NString snExigeGuiaInternacaoHonor = Configuracao.fncMvsRetornaValorConfig(toStr("SN_EXIGE_GUIA_INTERNACAO_HONOR"));
		if (!guiaElement.getDspTpGuia().isNull()) {
			if (guiaElement.getDspTpGuia().equals("H") && Lib.isNull(snExigeGuiaInternacaoHonor, 'N').equals("S") && !guiaElement.getDspTpGuiaTem().equals("I")) {
				getTask().getMv2000().msgAlert(toStr("Erro: Guia de Honorário deve estar vinculada à uma guia de solicitação de internação."), toStr("E"), toBool(NBool.True));
			}
		}

		String sqlcseqguia = "SELECT DBAPS.SEQ_GUIA.NEXTVAL FROM SYS.DUAL ";
		DataCursor cseqguia = new DataCursor(sqlcseqguia);
		NString csnobrigaobs = NString.getNull();
		NNumber nnrregistroatual = NNumber.getNull();
		Ref<DataList> vlstParamret = new Ref<DataList>(new DataList());

		if (guiaElement != null && !guiaElement.getDsDestinoCortesia().isNull() && guiaElement.getNmMatriculaResponsavel().isNull() && guiaElement.getDspNmSegurado().isNull()) {
			guiaElement.setDspNmSegurado(guiaElement.getDsDestinoCortesia());
		}

		try {

			nnrregistroatual = toNumber(getBlockCurrentRecord("ITGUIA"));

			if (Lib.isNull(nnrregistroatual, 0).lesserOrEquals(1) && itguiaElement.getCdProcedimento().isNull() && !getGuiaElement().getDspTpGuia().equals("R")) {	
				getTask().getMv2000().msgAlert("Não Foram Cadastrados Procedimentos para essa Guia!", "W", NBool.True);
			}
			csnobrigaobs = toStr("");

			if (!guiaElement.getCdTipoAtendimento().isNull()) {
				getTask().getMPkgMvsTipoAtendimento().getMPkgMvsTipoAtendimento().pRetornaDados(guiaElement.getCdTipoAtendimento(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.False), toBool(NBool.False), vlstParamret);
				csnobrigaobs = vlstParamret.val.getStr("SN_OBRIGA_OBS", NBool.False);
			}

			if (isNull(csnobrigaobs, "N").notEquals("N") && guiaElement.getDsObservacao().isNull()) {
				setItemEnabled("Guia.Ds_Observacao", true);
				setItemRequired("Guia.Ds_Observacao", true);
				getTask().getMv2000().msgAlert(toStr("Erro: A observação é obrigatória para esse tipo de Guia!"), toStr("W"), toBool(NBool.True));
			} else {
				setItemRequired("Guia.Ds_Observacao", false);
				setItemIsValid("Guia.Ds_Observacao", true);
			}

			if (guiaElement.getNrGuia().isNull()) {

				cseqguia.open();

				ResultSet cseqguiaResults = cseqguia.fetchInto();

				if (cseqguiaResults != null) {
					guiaElement.setNrGuia(cseqguiaResults.getNumber(0));
				}

				cseqguia.close();

				guiaElement.setNrGuia(toNumber(toStr(guiaElement.getNrGuia()).append("9")));

				// Atribuir guia pai a guia atual
				// Só deve vincular às guias de SP/SADT, Honoráriom Radio, Quimio e OPME
				if (guiaElement.getNrGuiaTem().isNull() && Lib.in(guiaElement.getDspTpGuia(), "I", "S", "H", "R", "Q", "O").toBoolean()) {

					String csqlguiapai = "SELECT G.NR_GUIA, G.DT_PREV_EXECUCAO, G.NR_DIAS_AUTORIZACAO " + 
							" FROM DBAPS.GUIA G, DBAPS.TIPO_ATENDIMENTO TA " + 
							" WHERE G.CD_MATRICULA = :GUIA_CD_MATRICULA " + 
							" AND G.NR_GUIA !=  :GUIA_NR_GUIA " + 
							" AND G.CD_TIPO_ATENDIMENTO = TA.CD_TIPO_ATENDIMENTO " + 
							" AND TA.SN_TP_INTERNACAO = 'S' " + 
							" AND G.SN_VALIDA_REST_CARENCIA = 'S' " + 
							" ORDER BY G.NR_GUIA DESC ";

					DataCursor cguiapai = new DataCursor(csqlguiapai);

					cguiapai.addParameter("GUIA_CD_MATRICULA", guiaElement.getCdMatricula());
					cguiapai.addParameter("GUIA_NR_GUIA", guiaElement.getNrGuia());

					cguiapai.open();

					NNumber nNrGuia;
					NDate dDtPrevExecucao;
					NNumber nNrDiasAutorizacao;

					while (true) {

						ResultSet cguiapaiResults = cguiapai.fetchInto();

						if (cguiapaiResults != null) {

							nNrGuia = cguiapaiResults.getNumber("NR_GUIA");
							dDtPrevExecucao = cguiapaiResults.getDate("DT_PREV_EXECUCAO");
							nNrDiasAutorizacao = cguiapaiResults.getNumber("NR_DIAS_AUTORIZACAO");

							String csqldiaspro = " SELECT NVL( SUM(NR_DIAS_PRORROGADOS) , 0 ) DIAS_PROR" + 
									" FROM DBAPS.GUIA_PRORROGACAO " + 
									" WHERE GUIA_PRORROGACAO.NR_GUIA = :GUIA_SQL_NR_GUIA " + 
									" AND CD_MOT_CANCELAMENTO_GUIA IS NULL";
							DataCursor cdiaspro = new DataCursor(csqldiaspro);

							cdiaspro.addParameter("GUIA_SQL_NR_GUIA", nNrGuia);

							cdiaspro.open();

							ResultSet cdiasproResults = cdiaspro.fetchInto();

							NNumber nTotDiasAutorizados;
							NDate dDtFinal;
							NNumber nDiasProrrogados;

							if (cdiasproResults != null && cdiasproResults.getNumber("DIAS_PROR").greater(0)) {
								nDiasProrrogados = cdiasproResults.getNumber("DIAS_PROR");
								nTotDiasAutorizados = nNrDiasAutorizacao.add(nDiasProrrogados);
								dDtFinal = dDtPrevExecucao.add(nTotDiasAutorizados);
							} else {
								nTotDiasAutorizados = nNrDiasAutorizacao;
								dDtFinal = dDtPrevExecucao.add(nTotDiasAutorizados);
							}

							/**
							 * Busca uma guia de internação já autorizada para o beneficiário no período de emissao desta nova guia
							 * e oferece ao usuário uma vinculação
							 */
							if ((trunc(guiaElement.getDtPrevExecucao()).greater(trunc(dDtPrevExecucao)) || trunc(guiaElement.getDtPrevExecucao()).equals(trunc(dDtPrevExecucao))) && trunc(guiaElement.getDtPrevExecucao()).lesser(trunc(dDtFinal)) || trunc(guiaElement.getDtPrevExecucao()).equals(trunc(dDtFinal))) {
								if (!((getTask().getMv2000().msgAlertSn(toStr("Existe uma guia de solicitação de internação autorizada neste período - " + nNrGuia + ". Deseja vincular esta guia à ela?"), toStr("I"), toStr("Sim/Não")))).toBoolean()) {
									break;
								}
								guiaElement.setNrGuiaTem(nNrGuia);
								break;
							}

						} else {
							break;
						}

					}

					cguiapai.close();

				}

				if (!this.getFormModel().getParam("NR_GUIA", NNumber.class).isNull()) {
					this.getFormModel().setParam("NR_GUIA", toNumber(guiaElement.getNrGuia()));
					setBlockWhereClause("GUIA", toStr("GUIA.NR_GUIA = ").append(this.getFormModel().getParam("NR_GUIA", NNumber.class)));
				}

				this.getTask().getServices().prcHabilitaBotoes(guiaProrrogacaoElement, guiaElement, toStr("N"));
			}

			guiaElement.setCdIdUsuario(toNumber(this.getFormModel().getParam("CD_USUARIO_ID", NString.class)));
			guiaElement.setCdMultiEmpresa(PkgMv2000.leEmpresa());
			guiaElement.setDtRegistroLocado(DbManager.getDBDateTime());

			guiaElement.setCdVersaoTiss(Configuracao.fncMvsRetornaValorConfig(toStr("VERSAO_TISS")));
			
			if(snOperadoraUnimed.equals("S")){
				if (guiaElement.getCdUnimedExecutora().isNull()) {
					if(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("CD_UNIMED") != null ){
						guiaElement.setCdUnimedExecutora(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("CD_UNIMED"));
						cd_unimed_executora_validation();
					}
				}
				
				if(guiaElement.getCdUnimedSolicitante().isNull()){
					if(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("CD_UNIMED") != null ){
						guiaElement.setCdUnimedSolicitante(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("CD_UNIMED"));
						cd_unimed_solicitante_validation();
					}
				}
				guiaElement.setCdVersaoPtu(Services.getDescricao("VALOR", "MVS_CONFIGURACAO", "CHAVE = 'VERSAO_PTU_ONLINE' AND CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA", false));
			}

		} finally {
			cseqguia.close();
		}

		if( !getGuiaElement().getTpOrigem().equals("PTU") ){
			this.getTask().getServices().verificaObrigatoriedadePrestadorExecutante();
		}
		
		NString nrProtocoloAns = this.getTask().getServices().fncProtocoloAns(Lib.isNull(Configuracao.fncMvsRetornaValorConfig(NString.toStr("ATEND_PROTANS_MOTIVO_PADRAO")), "9001").toString(),guiaElement.getNrGuia(),guiaElement.getCdMatricula());
		
		guiaElement.setNrProtocolo(nrProtocoloAns);
		
		if (getGuiaElement().getNrTransacao().isNull()) {
			NNumber seqNrGuiaTransacao = StoredProcedures.fncMvRetornaValorSequence(NString.toStr("SEQ_NR_GUIA_TRANSACAO"),NString.toStr("DBAPS"));
			NString nrTransacao = Lib.lpad(seqNrGuiaTransacao, 9,"0");
			NString dsPeridoEmissao = Lib.toChar(DbManager.getDBDate(), "YYMM");
			getGuiaElement().setNrTransacao(dsPeridoEmissao.append(nrTransacao));
		}
		
		this.getTask().getServices().setDtAltaInternacao(guiaElement.getNrGuia(), this.getFormModel().getCgCtrl().getDspDtAltaInternacao());
		
		cd_programa_atendimento_validation();
		this.getTask().getServices().chkObrigatoriosOdontologia(guiaElement);
		this.getTask().getServices().insertOcorrenciaOdontologia();
		if (guiaElement.getCdPrestadorEndereco().isNull()) {
			this.getTask().getServices().chkChavesConfiguracaoGlobal();
		}
		
		this.getTask().getServices().isTipoConsultaObrigatorio(guiaElement);
		this.getTask().getServices().chkDsDiagnostico(guiaElement);
		this.getTask().getServices().chkIndicadorAcidente(guiaElement);
		validarCamposObrigatoriosProfissionalExecutante();
		validarCamposObrigatoriosAbaDadosComplementares();
		this.getTask().getServices().prestadorExecutor(guiaElement);
	}

	@ViewTrigger(context={"CANVAS_PRORROGACAO", "CG$PAGE_1", "PAGE_CORTESIA", "PAGE_DADOS", "PAGE_DIAGNOSTICO", "PAGE_OBSERVACOES"})
	@ActionTrigger(action = "guia_recordChange", function=KeyFunction.RECORD_CHANGE)
	public void guia_recordChange() {
		
		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
		
		NString snOperadoraUnimed = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		NString snEmissaoAvulsa = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
				
		
		if (getGuiaElement() != null && !getGuiaElement().equals(null)) {
			this.getTask().getServices().configurarCampo("GUIA.TP_CARATER_SOLIC_INTER", true);
			
			if (getGuiaElement().getDspSnTpInternacao().equals("S") || (snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S") && Lib.in(getGuiaElement().getDspTpGuia().toString(), "O","Q","R").toBoolean() ) ) {
				setItemEnabled("GUIA.TP_INTERNACAO", true);
				setItemNavigable("GUIA.TP_INTERNACAO", true);
				setItemInsertAllowed("GUIA.TP_INTERNACAO", true);
				setItemEnabled("GUIA.NR_DIAS_SOLICITACAO", true);
				setItemNavigable("GUIA.NR_DIAS_SOLICITACAO", true);
				setItemInsertAllowed("GUIA.NR_DIAS_SOLICITACAO", true);
				setItemUpdateAllowed("GUIA.NR_DIAS_SOLICITACAO", true);
				setItemEnabled("GUIA.CD_PRESTADOR_SOLICITADO", true);
				setItemNavigable("GUIA.CD_PRESTADOR_SOLICITADO", true);
				setItemInsertAllowed("GUIA.CD_PRESTADOR_SOLICITADO", true);
				setItemUpdateAllowed("GUIA.CD_PRESTADOR_SOLICITADO", true);
				
				setItemEnabled("GUIA.CD_TIP_ACOMODACAO", true);
				setItemRequired("GUIA.CD_TIP_ACOMODACAO", true);
				setItemNavigable("GUIA.CD_TIP_ACOMODACAO", true);
				setItemInsertAllowed("GUIA.CD_TIP_ACOMODACAO", true);
				
				if (this.getFormModel().getParam("PERMITE_ALT", NString.class).equals("S")) {
					this.getTask().getServices().configurarCampo("GUIA.TP_CARATER_SOLIC_INTER", true);
					setItemUpdateAllowed("GUIA.CD_TIP_ACOMODACAO", true);
				}
				
			} else {
				if (getGuiaElement().getDspTpGuia().equals("C")) {
					this.getTask().getServices().configurarCampo("GUIA.TP_CARATER_SOLIC_INTER", false);
					setItemEnabled("GUIA.CD_PRESTADOR_SOLICITADO", false);
				}

				setItemEnabled("GUIA.TP_INTERNACAO", false);
				this.getTask().getServices().configurarCampo("GUIA.CD_TIP_ACOMODACAO", true);
				
				if (getGuiaElement().getDspTpGuia().equals("R")) {
					setItemEnabled("GUIA.NR_DIAS_SOLICITACAO", true);
					setItemRequired("GUIA.NR_DIAS_SOLICITACAO", true);
				} else {
					setItemEnabled("GUIA.NR_DIAS_SOLICITACAO", false);
					setItemRequired("GUIA.NR_DIAS_SOLICITACAO", false);
					setItemIsValid("GUIA.NR_DIAS_SOLICITACAO", true);
				}
				
				if (snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S") && Lib.in(getGuiaElement().getDspTpGuia().toString(), "O","Q","R").toBoolean() ) {
					this.getTask().getServices().configurarCampo("GUIA.TP_INTERNACAO", true);
					this.getTask().getServices().configurarCampo("GUIA.CD_TIP_ACOMODACAO", true);
				}
			}
			if (getGuiaElement().getDspSnPrestador().equals("S")) {
				setItemNavigable("GUIA.CD_PRESTADOR", true);
				setItemInsertAllowed("GUIA.CD_PRESTADOR", true);
				setItemEnabled("GUIA.CD_PRESTADOR_SOLICITANTE", true);
				setItemNavigable("GUIA.CD_PRESTADOR_SOLICITANTE", true);
				setItemInsertAllowed("GUIA.CD_PRESTADOR_SOLICITANTE", true);
				setItemEnabled("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);
				
				if (this.getFormModel().getParam("PERMITE_ALT", NString.class).equals("S")) {
					setItemUpdateAllowed("GUIA.CD_PRESTADOR_SOLICITANTE", true);
					setItemUpdateAllowed("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);
					setItemUpdateAllowed("GUIA.CD_PRESTADOR", true);
				}
				
			} else {
				setItemIsValid("GUIA.CD_PRESTADOR", true);
				setItemEnabled("GUIA.CD_PRESTADOR2", false);
				setItemRequired("GUIA.CD_PRESTADOR_SOLICITANTE", false);
				setItemIsValid("GUIA.CD_PRESTADOR_SOLICITANTE", true);
				setItemEnabled("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);
			}
			
			if (getGuiaElement().getDspSnDsSenhaAutorizacao().equals("S")) {
				setItemEnabled("GUIA.DS_SENHA_AUTORIZADOR", true);
				setItemNavigable("GUIA.DS_SENHA_AUTORIZADOR", true);
				setItemInsertAllowed("GUIA.DS_SENHA_AUTORIZADOR", true);
				setItemUpdateAllowed("GUIA.DS_SENHA_AUTORIZADOR", true);
				setItemRequired("GUIA.DS_SENHA_AUTORIZADOR", true);
			} else {
				setItemEnabled("GUIA.DS_SENHA_AUTORIZADOR", false);
				setItemRequired("GUIA.DS_SENHA_AUTORIZADOR", false);
				setItemIsValid("GUIA.DS_SENHA_AUTORIZADOR", true);
			}
			
			if (getGuiaElement().getDspSnNrDiasAutorizacao().equals("S")) {
				setItemRequired("GUIA.NR_DIAS_AUTORIZACAO", true);
			} else {
				setItemRequired("GUIA.NR_DIAS_AUTORIZACAO", false);
				setItemIsValid("GUIA.NR_DIAS_AUTORIZACAO", true);
			}

			this.getTask().getServices().prcHabilitaBotoes(guiaProrrogacaoElement, getGuiaElement(), toStr("N"));

			if (!getGuiaElement().getNrGuia().isNull()) {
				getGuiaElement().setDspTotDiasProrrogados(getTask().getMPkgMvsContasMedicas().getMPkgMvsContasMedicas().fNrDiasProrrogados(toNumber(getGuiaElement().getNrGuia())));
				getGuiaElement().setDspTotDiasAutorizados(isNull(getGuiaElement().getNrDiasAutorizacao(), 0).add(isNull(getGuiaElement().getDspTotDiasProrrogados(), 0))); // pda
				// 404139
			}
			
			this.getTask().getServices().setaEspecialidadeSolicitante(getGuiaElement());
			
			if (isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N").equals("S")) {
				setItemEnabled("GUIA.BTN_CD_MATRICULA", false);
				setItemEnabled("GUIA.BTN_LEITOR_MAGNETO", false);
				setItemRequired("GUIA.CD_MATRICULA", false);
				setItemIsValid("GUIA.CD_MATRICULA", true);
				setItemEnabled("GUIA.BTN_CD_MATRICULA", false);
				setItemEnabled("GUIA.CD_GRUPO_FRANQUIA", false);
				setItemEnabled("GUIA.BTN_CD_GRUPO_FRANQUIA", false);
				setItemEnabled("GUIA.SN_AVISTA", false);
				setItemRequired("GUIA.SN_AVISTA", false);
				setItemIsValid("GUIA.SN_AVISTA", true);
			}
		}

		sn_ordem_servico_change();
		this.getTask().getServices().verificarConRec();
		
		ItemServices.setItemEnabled("GUIA.CD_PRESTADOR_EXECUTOR", !getGuiaElement().getDspTpGuia().equals("L"));
		
		ItemServices.setItemDisplayAsPassword("GUIA.NR_GUIA", getGuiaElement().getSnValidaRestCarencia().equals("N"));
		this.getTask().getServices().exibirAbasCampos(getGuiaElement(), snOperadoraUnimed.toString(), snEmissaoAvulsa.toString());
		GuiaServices.chkCamposBeneficiario(snEmissaoAvulsa.toString(),getGuiaElement());
		this.getTask().getServices().desabilitarBotaoGuiaNegativa(getGuiaElement());
	}

	@BeforeQuery
	public void guia_BeforeQuery(QueryEvent args) {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (guiaElement != null && !guiaElement.getNrGuia().isNull()) {//Habilitar o botao de upload anexo apenas se houver guia salva.
			ItemServices.setItemEnabled("GUIA_ANEXO.BTN_UPLOAD_ANEXO", true);
		} else {
			ItemServices.setItemEnabled("GUIA_ANEXO.BTN_UPLOAD_ANEXO", false);
		}

		if (!getGlobal("NR_GUIA").isNull()) {
			//args.getCriteria().add("NR_GUIA", toNumber(getGlobal("NR_GUIA")));
			setGlobal("NR_GUIA", toNumber(null));
		}

		//verifica se o autorizador do usuário logado tem permissão de ver guia de terceiros
		NString sn_restringe_guia_terceiro = Services.getDescricao("SN_RESTRINGE_GUIA_TERCEIRO", "AUTORIZADOR, DBAPS.ME_AUTORIZADOR", "ME_AUTORIZADOR.CD_AUTORIZADOR = AUTORIZADOR.CD_AUTORIZADOR AND ME_AUTORIZADOR.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA AND AUTORIZADOR.CD_USUARIO = '"+TaskServices.getUser()+"'", false);
		if(!sn_restringe_guia_terceiro.isNull() && sn_restringe_guia_terceiro.equals("S")){

			NString defaultWhere = BlockServices.getBlockWhereClause("GUIA");

			//verifica se o defaultWhere está vazio
			if(defaultWhere.isNull()){

				BlockServices.setBlockWhereClause("GUIA", " (CD_USUARIO_EMISSAO = '"+TaskServices.getUser()+"' OR CD_USUARIO_EMISSAO IS NULL) ");

			}else{

				//verifica se a cláusula já está no defaultWhere
				if(!defaultWhere.contains("CD_USUARIO_EMISSAO")){
					BlockServices.setBlockWhereClause("GUIA", defaultWhere.append(" AND (CD_USUARIO_EMISSAO = '"+TaskServices.getUser()+"' OR CD_USUARIO_EMISSAO IS NULL) "));
				}

			}
		}else{
			NString defaultWhere = BlockServices.getBlockWhereClause("GUIA");
			if(defaultWhere.isNull()){
				BlockServices.setBlockWhereClause("GUIA", " CD_MULTI_EMPRESA = '"+PkgMv2000.leEmpresa()+"'");
			}else{
				if (!defaultWhere.contains("CD_MULTI_EMPRESA")) {
					BlockServices.setBlockWhereClause("GUIA", defaultWhere.append(" AND CD_MULTI_EMPRESA = '"+PkgMv2000.leEmpresa()+"'"));	
				}

			}
		}
	}

	@SuppressWarnings({ "unused"})
	@ValidationTrigger(item = "CD_MATRICULA")
	public void cdMatricula_validate() {
		ItemServices.setItemIsValid("GUIA.CD_MAT_ALTERNATIVA", true);

		NString vmae = NString.getNull();
		NString vendereco = NString.getNull();
		NString vbairro = NString.getNull();
		NString vcidade = NString.getNull();
		NNumber ncep = NNumber.getNull();
		NString vuf = NString.getNull();
		NNumber ncpf = NNumber.getNull();
		NString vtp_usuario = NString.getNull();
		NNumber vidade = NNumber.getNull();
		NString verro = NString.getNull();
		NString validarCpf = toStr("N");
		NDate ddtDesligamento = NDate.getNull();
		Ref<DataList> vlstParamret = new Ref<DataList>(new DataList());
		
		if (!getGuiaElement().getCdMatricula().isNull()) {
			this.getTask().getServices().prcUsuario(getGuiaElement(), toBool(NBool.True));
			
			if (getGuiaElement().getDspSnAtivo().equals("N")) {
				ddtDesligamento = getTask().getMPkgMvsUsuario().getMPkgMvsUsuario().fRetornaDtDesligamento(getGuiaElement().getCdMatricula());
				if (!ddtDesligamento.isNull()) {
					if (!(getTask().getMv2000().msgAlertSn(Types.toStr("O usuário está desligado desde ").append(toChar(ddtDesligamento, "dd/mm/yyyy")).append(".").append(chr(10)).append("Deseja continuar?"), Types.toStr("W"), Types.toStr("Sim/Não"))).toBoolean()) {
						getTask().getMv2000().msgAlert(NString.toStr("")
								.append("Operação inválida!")
								.append(Lib.chr(10))
								.append("Motivo..: Usuário não está ativo.")
								.append(Lib.chr(10))
								.append("Ação....: Informe um usuário ativo.").toString(),
								"W", /*W = Atenção, I = Informação, E = Erro */
								NBool.True /*bloquear/travar?*/);
					}
				}
			}
			
			if (this.getFormModel().getParam("SN_VALIDA_CADASTRO", NString.class).equals("S")) {
				String sql = " Select nm_mae" 
						   + ",ds_endereco " 
						   + ",ds_bairro " 
						   + ",nm_cidade " 
						   + ",nr_cep " 
						   + ",nm_uf " 
						   + ",nr_cpf " 
						   + ",tp_usuario " 
						   + ",Trunc(Trunc(SYSDATE - dt_nascimento)/365.25) idade " 
						   + " From dbaps.usuario " 
						   + " Where cd_matricula = :CD_MATRICULA " 
						   + " And cd_multi_empresa = DBAMV.PKG_MV2000.LE_EMPRESA ";

				DataCursor cCursor = new DataCursor(sql);
				cCursor.addParameter("CD_MATRICULA", getGuiaElement().getCdMatricula());
				cCursor.open();
				ResultSet rCursor = cCursor.fetchInto();
				if (rCursor != null) {
					vmae = rCursor.getStr(0);
					vendereco = rCursor.getStr(1);
					vbairro = rCursor.getStr(2);
					vcidade = rCursor.getStr(3);
					ncep = rCursor.getNumber(4);
					vuf = rCursor.getStr(5);
					ncpf = rCursor.getNumber(6);
					vtp_usuario = rCursor.getStr(7);
					vidade = rCursor.getNumber("idade");
				}
				if (vmae.isNull()) {
					verro = verro.append(" NOME DA MÃE, ");
				}
				if (this.getFormModel().getParam("SN_OBRIGA_END_RESIDENCIAL", NString.class).equals("S")) {
					if (vendereco.isNull()) {
						verro = verro.append("ENDERECO, ");
					}
					if (vbairro.isNull()) {
						verro = verro.append("BAIRRO, ");
					}
					if (vcidade.isNull()) {
						verro = verro.append("CIDADE, ");
					}
					if (ncep.isNull()) {
						verro = verro.append("CEP, ");
					}
					if (vuf.isNull()) {
						verro = verro.append("UF, ");
					}
				}
				
				if (this.getFormModel().getParam("SN_OBRIGA_CPF_TITULAR", NString.class).equals("S") && vtp_usuario.equals("T")) {
					validarCpf = toStr("S");
				}
				
				if (this.getFormModel().getParam("SN_OBRIGA_CPF_DEP", NString.class).equals("S") && vtp_usuario.equals("D")) {
					/*
					 * Verifica se a idade do dependente é maior do que 18
					 * para justificar obrigatoriedade do CPF
					 * 
					 * @author diego.nobre
					 * 
					 * @since 09/05/2012
					 */
					if (vidade.greater(17)) {
						validarCpf = toStr("S");
					} else {
						validarCpf = toStr("N");
					}
				}
				
				NString result = Services.getDescricao("SN_CPF_MENOR18", "DBAMV", "MULTI_EMPRESAS_MV_SAUDE", "CD_MULTI_EMPRESA = PKG_MV2000.LE_EMPRESA", false);
				
				if (result.equals("S") && ncpf.isNull()) {
					
					getTask().getMv2000().msgAlert(NString.toStr("")
							.append("Operação inválida!")
							.append(Lib.chr(10))
							.append(ResourceManager.getString("guia.msg0120")).toString(),
							"W", /*W = Atenção, I = Informação, E = Erro */
							NBool.True /*bloquear/travar?*/);
				} 		
			}			
		}

		this.getTask().getServices().exibeAlerta(true);

	}

	@ActionTrigger(action = "cdMatricula_listValues", item = "CD_MATRICULA", function = KeyFunction.LIST_VALUES)
	public void cdMatricula_listValues() {

		callTask("C_CONSULTA_USU", TaskServices.HIDE, TaskServices.NO_REPLACE, TaskServices.NO_QUERY_ONLY);
		if (!toNumber(getGlobal("CD_USUARIO")).isNull()) {
			getGuiaElement().setCdMatricula(toNumber(getGlobal("CD_USUARIO")));
			getGuiaElement().setDspNmSegurado(getGlobal("NM_USUARIO"));	
		}
		goItem(toStr("guia.cd_matricula"));
	}

	@ActionTrigger(action = "btnCdMatricula_click", item = "BTN_CD_MATRICULA")
	public void btnCdMatricula_click() {

		getTask().getMv2000().chamaForm(toStr("..\\mvsaude\\c_consulta_usu"));
		if (!toNumber(getGlobal("CD_USUARIO")).isNull()) {
			getGuiaElement().setCdMatricula(toNumber(getGlobal("CD_USUARIO")));
			getGuiaElement().setDspNmSegurado(getGlobal("NM_USUARIO"));	
			cdMatricula_validate();
		}
		goItem(toStr("guia.cd_matricula"));
	}

	@ValidationTrigger(item = "NR_GUIA_EXTERNA")
	public void nrGuiaExterna_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		String sqlcguia = "SELECT NR_GUIA " 
						+ " FROM DBAPS.GUIA " 
						+ " WHERE NR_GUIA_EXTERNA = :GUIA_NR_GUIA_EXTERNA " 
						+ " AND NR_GUIA <> NVL(:GUIA_NR_GUIA, - 1) " 
						+ " AND CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA ";
		DataCursor cguia = new DataCursor(sqlcguia);
		NString cnrguias = NString.getNull();
		cnrguias = toStr(null);
		// Setting query parameters
		cguia.addParameter("GUIA_NR_GUIA_EXTERNA", guiaElement.getNrGuiaExterna());
		cguia.addParameter("GUIA_NR_GUIA", guiaElement.getNrGuia());
		try {
			cguia.open();
			while (true) {
				TableRow rguia = cguia.fetchRow();
				if (cguia.notFound())
					break;
				if (cnrguias.isNull()) {
					cnrguias = toChar(rguia.getStr("NR_GUIA"));
				} else {
					cnrguias = toStr(", ").append(toChar(rguia.getStr("NR_GUIA")));
				}
			}
		} finally {
			cguia.close();
		}
		if (!cnrguias.isNull()) {
			
			//MULTI-IDIOMA: MSG_0059 - A(s) autorização(ões): %s está(ão) associada(s) a esta guia externa. Deseja continuar?
			String message = ResourceManager.getString("guia.msg0059",cnrguias);
			//MULTI-IDIOMA: MSG_0057 - Sim/Não
			String simNao = ResourceManager.getString("guia.msg0057");
			
			if (!(getTask().getMv2000().msgAlertSn(message, toStr("I"), toStr(simNao))).toBoolean()) {
				throw new ApplicationException();
			}
		}
	}

	@ValidationTrigger(item = "NR_GUIA_TEM")
	public void nrGuiaTem_validate() {
		
		NString snOperadoraUnimed = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		NString snEmissaoAvulsa = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");

		if (!getGuiaElement().getNrGuiaTem().isNull()) {
			StringBuilder sqlConsulta = new StringBuilder();
			sqlConsulta.append("	SELECT GUIA.CD_MOT_CANCELAMENTO 									");
			sqlConsulta.append("	     , GUIA.SN_VALIDA_REST_CARENCIA 								");
			sqlConsulta.append("	     , GUIA.DT_EMISSAO 												");
			sqlConsulta.append("	     , TA.TP_GUIA TP_GUIA_TEM 										");
			sqlConsulta.append("	     , GUIA.CD_MATRICULA 											");
			sqlConsulta.append("	     , GUIA.NR_CARTEIRA_BENEFICIARIO 								");
			sqlConsulta.append("	     , GUIA.CD_PRESTADOR 											");
			sqlConsulta.append("	     , GUIA.NM_PRESTADOR 											");
			sqlConsulta.append("	     , GUIA.CD_PRESTADOR_EXECUTOR 									");
			sqlConsulta.append("        , TAT.CD_TISS CD_TIPO_ATENDIMENTO_TISS 							");
			sqlConsulta.append("	     , MEMS.SN_REGIDO_ANS 											");
			sqlConsulta.append("	  FROM DBAPS.GUIA 													");
			sqlConsulta.append("	     , DBAPS.TIPO_ATENDIMENTO TA 									");
			sqlConsulta.append("	     , DBAPS.TIPO_ATENDIMENTO_TISS TAT 								");
			sqlConsulta.append("	     , DBAMV.MULTI_EMPRESAS_MV_SAUDE MEMS 							");
			sqlConsulta.append("	 WHERE GUIA.NR_GUIA_TEM IS NULL 									");
			sqlConsulta.append("	   AND GUIA.CD_TIPO_ATENDIMENTO_TISS = TAT.CD_TIPO_ATENDIMENTO(+) 	");
			sqlConsulta.append("	   AND GUIA.CD_MULTI_EMPRESA = MEMS.CD_MULTI_EMPRESA 				");
			sqlConsulta.append("	   AND GUIA.SN_VALIDA_REST_CARENCIA = 'S'                           ");
			
			if( !getGuiaElement().getCdMatricula().isNull() ||  !getGuiaElement().getNrCarteiraBeneficiario().isNull()){
				sqlConsulta.append(!getGuiaElement().getCdMatricula().isNull() ?  " AND GUIA.CD_MATRICULA = :PCD_MATRICULA " : " AND GUIA.NR_CARTEIRA_BENEFICIARIO = :PCD_MATRICULA ");
			}
			
			if(isGuiaProrrogacaoInternacao()){
				sqlConsulta.append(" AND TA.TP_GUIA = 'I' ");
			}
			
			sqlConsulta.append(" AND GUIA.NR_GUIA <> NVL(:PNR_GUIA,0)  					");
			sqlConsulta.append(" AND GUIA.NR_GUIA = NVL(:PNR_GUIA_TEM,0) 				");
			sqlConsulta.append(" AND GUIA.CD_TIPO_ATENDIMENTO = TA.CD_TIPO_ATENDIMENTO 	");
			sqlConsulta.append(" AND GUIA.CD_MULTI_EMPRESA = :PMULTIEMPRESA				");

			DataCursor cGuiaSolicitao = new DataCursor(sqlConsulta.toString());
			try {

				if (getGuiaElement().getNrGuia().equals(getGuiaElement().getNrGuiaTem())) {
					throw new ApplicationException("Guia de solicitação não pode ser igual a autorizada.");
				}

				cGuiaSolicitao.addParameter("PMULTIEMPRESA", toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)));
	
				if( !getGuiaElement().getCdMatricula().isNull() ||  !getGuiaElement().getNrCarteiraBeneficiario().isNull()){
					cGuiaSolicitao.addParameter("PCD_MATRICULA", Lib.isNull(getGuiaElement().getCdMatricula(), getGuiaElement().getNrCarteiraBeneficiario()));
				}
				
				cGuiaSolicitao.addParameter("PNR_GUIA", getGuiaElement().getNrGuia());
				cGuiaSolicitao.addParameter("PNR_GUIA_TEM", getGuiaElement().getNrGuiaTem());
				cGuiaSolicitao.open();
				
				if (cGuiaSolicitao.hasData()) {
					ResultSet rGuiaSolicitao = cGuiaSolicitao.fetchInto();

					
					if (!rGuiaSolicitao.getNumber("CD_MOT_CANCELAMENTO").isNull()) {
						throw new ApplicationException("Guia de solicitação cancelada!");
					}
					
					if("N".equals(snOperadoraUnimed.toString()) && "N".equals(snEmissaoAvulsa.toString())){
						
						if (!Lib.in(rGuiaSolicitao.getStr("TP_GUIA_TEM"), "S", "I").toBoolean()) {
							//MULTI-IDIOMA: MSG_0063 - A Guia informada não é uma Solicitação de internação ou SP\\SADT! 
							getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0063"), "E", NBool.True);
						}

					}
					
					if (rGuiaSolicitao.getStr("TP_GUIA_TEM").equals("S") && rGuiaSolicitao.getStr("CD_TIPO_ATENDIMENTO_TISS").equals("11")) {
						getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0139"), "W", NBool.True);
					}
					
					getGuiaElement().setDtEmissaoGuiaSolicitacao(rGuiaSolicitao.getDate("DT_EMISSAO"));
					
					if(!rGuiaSolicitao.getNumber("cd_matricula").isNull()){
						getGuiaElement().setCdMatricula(rGuiaSolicitao.getNumber("CD_MATRICULA"));
						cdMatricula_validate();
					}
					if(!rGuiaSolicitao.getNumber("nr_carteira_beneficiario").isNull()){
						getGuiaElement().setNrCarteiraBeneficiario(rGuiaSolicitao.getStr("NR_CARTEIRA_BENEFICIARIO"));
						nr_carteira_beneficiario_validation();
					}
					
					if(!rGuiaSolicitao.getNumber("CD_PRESTADOR").isNull()){
						getGuiaElement().setCdPrestador(rGuiaSolicitao.getNumber("CD_PRESTADOR"));
						getGuiaElement().setNmPrestador(rGuiaSolicitao.getStr("NM_PRESTADOR"));
					}else if(!rGuiaSolicitao.getStr("NM_PRESTADOR").isNull()){
						getGuiaElement().setNmPrestador(rGuiaSolicitao.getStr("NM_PRESTADOR"));
					}
					
					if(!rGuiaSolicitao.getNumber("CD_PRESTADOR_EXECUTOR").isNull()){
						getGuiaElement().setCdPrestadorExecutor(rGuiaSolicitao.getNumber("CD_PRESTADOR_EXECUTOR"));
						cdPrestadorExecutor_validate();
					}
					
					
					getGuiaElement().setDspTpGuiaTem(rGuiaSolicitao.getStr("TP_GUIA_TEM"));
					if (Lib.trunc(rGuiaSolicitao.getDate("DT_EMISSAO")).greater(Lib.trunc(getGuiaElement().getDtEmissao())) && !getGuiaElement().getDtEmissao().isNull()) {
						//MULTI-IDIOMA: MSG_0064 - Data de emissão da guia de solicitação maior que a da guia a ser autorizada!
						getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0064"), "E", NBool.True);
					}

				} else {
					//MULTI-IDIOMA: MSG_0065 - Guia informada não existe ou não é uma guia de solicitação válida para este usuário!
					getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0065"), "E", NBool.True);
				}
			} catch (Exception e) {
				getGuiaElement().setDtEmissaoGuiaSolicitacao(NDate.getNull());
				getGuiaElement().setDtVencimento(NDate.getNull());
				getGuiaElement().setDspTpGuiaTem(NString.getNull());
				if (e.getMessage() != null) {
					getTask().getMv2000().msgAlert("Erro: " + e.getMessage(), "E", NBool.True);					
				}
			} finally {
				cGuiaSolicitao.close();
			}

			if (!getGuiaElement().getCdTipoAtendimento().isNull()) {
				this.getTask().getServices().verificarGuiaHonorarioIndividual(getGuiaElement());
			} else {

				setItemEnabled("GUIA.CD_ESPECIALIDADE", true);
				setItemEnabled("GUIA.CD_PRESTADOR_EXECUTOR", true);
				setItemEnabled("GUIA.CD_PRESTADOR_ENDERECO", true);
			}
		} else {

			setItemEnabled("GUIA.CD_ESPECIALIDADE", true);
			setItemEnabled("GUIA.CD_PRESTADOR_EXECUTOR", true);
			setItemEnabled("GUIA.CD_PRESTADOR_ENDERECO", true);
		}

	}

	@ValidationTrigger(item = "CD_GRUPO_FRANQUIA")
	public void cdGrupoFranquia_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		this.getTask().getServices().prcGrupoFranquia(guiaElement, toBool(NBool.True), toStr("V"));
	}

	/*
		- HABILITAR ATENDIMENTO A RN (QUANDO FOR SADT, INTERNACAO, CONSULTA, HONORARIO). Solicitação de Dellanio.
		- DATA SUGERIDA INTERNACAO, PREVISAO DE USO DE OPME  E PREVISAO DE USO QUIMIOTERAPICO só devem estar habilitados para guia do tipo INTERNACAO
		- CAMPO MOTIVO DE ENCERRAMENTO DO ATENDIMENTO não foi encontrado na tela para a guia de SPSADT
	 */
	private void setEnableFields1(GuiaAdapter guia) {
		
		NString snOperadoraUnimed = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		NString snEmissaoAvulsa = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
		this.getTask().getServices().configurarCampo("ITGUIA.QT_TOTAL_DOSAGEM_CICLO", false,false,false);
		this.getTask().getServices().configurarCampo("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", false,false,false);
		if (!guia.getCdTipoAtendimento().isNull()) {

			if (!guia.getCdTipoAtendimento().isNull() && !guia.getCdTipoAtendimentoTiss().isNull()) {
				if (Lib.in(getGuiaElement().getDspTpGuia().toString(), "I","S").toBoolean() || (snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S") && Lib.in(getGuiaElement().getDspTpGuia().toString(), "O","Q","R").toBoolean() )) {
					ItemServices.setItemEnabled("GUIA.SN_AVISTA", BlockServices.getCurrentRecord("GUIA").toInt32(), true);
					ItemServices.setItemEnabled("GUIA.CD_TIPO_CONSULTA", BlockServices.getCurrentRecord("GUIA").toInt32(), true);
				}
			}

			
		}

	}

	@ValidationTrigger(item = "CD_TIPO_ATENDIMENTO")
	public void cdTipoAtendimento_validate() {
		
		NString snOperadoraUnimed = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		NString snEmissaoAvulsa = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
		
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		PkgMvsGuia.pIWviGCdTpAtendimento();

		if(guiaElement.getDspSnDsSenhaAutorizacao().equals("N")){
			ItemServices.setItemRequired("GUIA.DS_SENHA_AUTORIZADOR", false);
		}else{
			ItemServices.setItemRequired("GUIA.DS_SENHA_AUTORIZADOR", true);
		}

		setEnableFields1(guiaElement);

		if (!guiaElement.getNrGuiaTem().isNull()) {
			if (guiaElement.getDspTpGuia().equals("C")) {
				getTask().getMv2000().msgAlert(toStr("Erro: Guia de consulta não pode se vincular à outras guias."), toStr("W"), toBool(NBool.False));
				guiaElement.setNrGuiaTem(NNumber.getNull());
			}

			if (guiaElement.getDspTpGuia().equals("I") && (snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("N"))) {
				getTask().getMv2000().msgAlert(toStr("Erro: Guia de Solicitação de internação não pode se vincular à outras guias."), toStr("E"), toBool(NBool.False));
				guiaElement.setNrGuiaTem(NNumber.getNull());
			}

			if (guiaElement.getDspTpGuia().equals("H") && !guiaElement.getDspTpGuiaTem().equals("I")) {
				getTask().getMv2000().msgAlert(toStr("Erro: Guia de Honorário deve estar vinculada à uma guia de solicitação de internação. Verifique o tipo da guia número: " + guiaElement.getNrGuiaTem()), toStr("E"), toBool(NBool.False));
				guiaElement.setNrGuiaTem(NNumber.getNull());
			}
		}

		if (guiaElement.getDspTpGuia().equals(toStr("I")) || guiaElement.getDspTpGuia().equals(toStr("H"))) {
			guiaElement.setNrDiasSolicitacao(toNumber(1));
			guiaElement.setNrDiasAutorizacao(toNumber(1));
			setItemValue("GUIA.CD_REGIME_INTERNACAO", NNumber.toNumber(1));

		} else {

			guiaElement.setNrDiasSolicitacao(toNumber(0));
			guiaElement.setNrDiasAutorizacao(toNumber(0));
		}
		if (guiaElement.getDspTpGuia().equals(toStr("S"))) { // - SP/SADT			
			this.getTask().getServices().configurarCampo("GUIA.CD_TIP_ACOMODACAO", true);
			setItemRequired("GUIA.CD_TIP_ACOMODACAO", false);
			setItemIsValid("GUIA.CD_TIP_ACOMODACAO", true);

			setItemEnabled("GUIA.CD_PRESTADOR_SOLICITANTE", true);
			
			if (snOperadoraUnimed.equals("S")) {
				NNumber cdTipoAtendimentoTiss = NNumber.toNumber(Services.getDescricao("CD_TIPO_ATENDIMENTO", "TIPO_ATENDIMENTO_TISS", "CD_TISS = '05'", false));
				if (guiaElement.getCdTipoAtendimentoTiss().isNull()) {
					guiaElement.setCdTipoAtendimentoTiss(cdTipoAtendimentoTiss);
				}
			}
		}

		if (guiaElement.getDspTpGuia().equals(toStr("C"))) {// - CONSULTA
			
			this.getTask().getServices().configurarCampo("GUIA.TP_CARATER_SOLIC_INTER", false);
			setItemValue("GUIA.TP_CARATER_SOLIC_INTER", NString.getNull());

			
		} else if (guiaElement.getDspTpGuia().equals("S") || guiaElement.getDspTpGuia().equals("I")) {// - SP/SADT - INTERNAÇÃO
			
			this.getTask().getServices().configurarCampo("GUIA.TP_CARATER_SOLIC_INTER", true);
			setItemValue("GUIA.TP_CARATER_SOLIC_INTER", "E");
			if (Services.getDescricao("VALOR", "MVS_CONFIGURACAO", "CHAVE = 'ATEND_CARAT_ATEND_PADRAO_ELET' AND CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA", false).equals("N")) {
				setItemValue("GUIA.TP_CARATER_SOLIC_INTER", NString.getNull());
			}
			
		} else {
			this.getTask().getServices().configurarCampo("GUIA.TP_CARATER_SOLIC_INTER", true);
			setItemValue("GUIA.TP_CARATER_SOLIC_INTER", NString.getNull());
		}

		/**
		 * Se o Tipo de Guia não exigir PS (Prestador/Contratado Solicitante)
		 * não desabilitar a Lov Contratado Solicitante; Levantamento feito no
		 * treinamento com Andresson Mota (Recife, 30/01 a 03/02/12)
		 * 
		 * @author diego.nobre
		 * @since 2012-02-14
		 */

		// verifica se o tipo de guia exige PS
		if (guiaElement.getDspSnPrestador().equals("S")) {
			//ItemServices.setItemRequired("GUIA.CD_PRESTADOR", true);
			ItemServices.setItemEnabled("GUIA.CD_PRESTADOR", true);
			ItemServices.setItemNavigable("GUIA.CD_PRESTADOR", true);
			ItemServices.setItemEnabled("GUIA.NM_PRESTADOR", true);
			ItemServices.setItemNavigable("GUIA.NM_PRESTADOR", true);
		} else {
			ItemServices.setItemEnabled("GUIA.NM_PRESTADOR", false);
			ItemServices.setItemNavigable("GUIA.NM_PRESTADOR", false);
			ItemServices.setItemRequired("GUIA.CD_PRESTADOR", false);
			ItemServices.setItemEnabled("GUIA.CD_PRESTADOR", false);
			ItemServices.setItemNavigable("GUIA.CD_PRESTADOR", false);
		}

		/**
		 * Solicitação do cliente São Bernardo. Se o Tipo de Atendimento for
		 * "Internação" o campo CID é obrigatório
		 * 
		 * @author diego.nobre
		 * @since 2012-03-06
		 */
		if (guiaElement.getDspTpGuia().equals("I") && toStr(this.getFormModel().getParam("P_SN_OBRIGAR_CID", NString.class)).equals("S")) {
			setItemRequired("GUIA.CD_CID", true);
		} else {
			setItemRequired("GUIA.CD_CID", false);
		}
		if (guiaElement.getDspSnTpInternacao().equals("S") || (snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S") && Lib.in(getGuiaElement().getDspTpGuia().toString(), "O","Q","R").toBoolean() ) ) {
			setItemRequired("GUIA.CD_TIP_ACOMODACAO", true);
		} else {
			setItemRequired("GUIA.CD_TIP_ACOMODACAO", false);
		}

		setItemIsValid("ITGUIA.CD_PROCEDIMENTO", false);

		camposSolicitacoes(guiaElement.getDspTpGuia());
		camposSolicitacaoInternacao(guiaElement.getDspTpGuia());

		if (!guiaElement.getNrGuiaTem().isNull()) {
			this.getTask().getServices().verificarGuiaHonorarioIndividual(guiaElement);
		} else {
			setItemEnabled("GUIA.CD_ESPECIALIDADE", true);
			setItemEnabled("GUIA.CD_PRESTADOR_EXECUTOR", true);
			setItemEnabled("GUIA.CD_PRESTADOR_ENDERECO", true);
		}

		/*
		 * Se a guia for de consulta, os campos Contratado Solicitante e Profissional Solicitante 
		 * não pode ser obrigatórios
		 */
		if (guiaElement.getDspTpGuia().equals("C")) {

			setItemRequired("GUIA.CD_PRESTADOR_SOLICITANTE", false);
			setItemRequired("GUIA.NM_PROFISSIONAL_SOLICITANTE", false);
			setItemEnabled("GUIA.TP_CARATER_SOLIC_INTER", false);

		} else if (guiaElement.getDspTpGuia().equals("I") || (snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S") && Lib.in(getGuiaElement().getDspTpGuia().toString(), "O","Q","R").toBoolean() )) { // - Internação
			

			setItemEnabled("GUIA.CD_PRESTADOR", true);
			setItemEnabled("GUIA.CD_PRESTADOR_SOLICITANTE", true);
			setItemEnabled("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);
			setItemEnabled("GUIA.TP_CARATER_SOLIC_INTER", true);
			setItemUpdateAllowed("GUIA.TP_CARATER_SOLIC_INTER", true);

			this.getTask().getServices().configurarCampo("GUIA.CD_PRESTADOR_SOLICITADO",true);
			this.getTask().getServices().configurarCampo("GUIA.CD_TIP_ACOMODACAO",true);
			setItemRequired("GUIA.CD_TIP_ACOMODACAO",true);
			
			if (snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S")) {
				setItemRequired("GUIA.CD_TIP_ACOMODACAO",false);	
			}
			
		} else if (guiaElement.getDspTpGuia().equals("S")) { // - SP/SADT
			setItemEnabled("GUIA.CD_PRESTADOR", true);
			setItemEnabled("GUIA.CD_PRESTADOR_SOLICITANTE", true);
			setItemEnabled("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);
			setItemEnabled("GUIA.TP_CARATER_SOLIC_INTER", true);
			setItemUpdateAllowed("GUIA.TP_CARATER_SOLIC_INTER", true);
			
		} else {
			setItemEnabled("GUIA.CD_PRESTADOR", true);
			setItemEnabled("GUIA.CD_PRESTADOR_SOLICITANTE", true);
		}
		
		if(guiaElement.getDspTpGuia().equals("B")){//Reembolso;
			
			
			ItemServices.setItemEnabled("ITGUIA.BTN_INFO_OCULOS", true);
			ItemServices.setItemEnabled("GUIA.BTN_GERAR_REEMBOLSO", true);
			ItemServices.setItemEnabled("GUIA.CD_PRESTADOR_EXTERNO", true);
			this.getTask().getServices().configurarCampo("ITGUIA.VL_COBRADO", true, false, true);
		}else{
			this.getTask().getServices().configurarCampo("ITGUIA.VL_COBRADO", false, false, false);
			ItemServices.setItemEnabled("ITGUIA.BTN_INFO_OCULOS", false);
			ItemServices.setItemEnabled("GUIA.BTN_GERAR_REEMBOLSO", false);
			ItemServices.setItemEnabled("GUIA.CD_PRESTADOR_EXTERNO", false);
		}
		
		// SP/SADT - SOLICITAÇÃO
		if(NString.toStr("L").equals(guiaElement.getDspTpGuia())){ 
			ItemServices.setItemEnabled("GUIA.CD_PRESTADOR_EXECUTOR", false);
		} else {
			ItemServices.setItemEnabled("GUIA.CD_PRESTADOR_EXECUTOR", true);
		}
		
		this.getTask().getServices().exibirAbasCampos(getGuiaElement(), snOperadoraUnimed.toString(), snEmissaoAvulsa.toString());
		
		getGuiaElement().setCdProgramaAtendimento(NNumber.getNull());
		cd_programa_atendimento_validation();
		
	}

	/**
	 * 
	 * @author raphael.chaves
	 * @param tpGuia
	 */
	public void camposSolicitacoes(NString tpGuia) {
		
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"), "N");
		NString snCortesia = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
		
		this.getTask().getServices().configurarCampo("ITGUIA.QT_FRANQUIA", false,false,false);
		this.getTask().getServices().configurarCampo("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", false,false,false);
		this.getTask().getServices().configurarCampo("ITGUIA.QT_TOTAL_DOSAGEM_CICLO", false,false,false);
		this.getTask().getServices().configurarCampo("GUIA.CD_CID", true,false,true);
		//Se a guia for de Quimioterapia
		if (tpGuia.equals(toStr("Q"))) {
			
			this.getTask().getServices().configurarCampo("GUIA.NR_PESO_BENEFICIARIO", true,false,true);
			this.getTask().getServices().configurarCampo("GUIA.NR_ALTURA_BENEFICIARIO", true,false,true);
			this.getTask().getServices().configurarCampo("GUIA.NR_SUPERFICIE_CORPORAL", true,false,true);
			this.getTask().getServices().configurarCampo("GUIA.NR_CICLO_PREVISTO", true,false,true);
			this.getTask().getServices().configurarCampo("GUIA.QTD_DIAS_CICLO", true,false,true);
			this.getTask().getServices().configurarCampo("GUIA.NR_CICLO_ATUAL", true,false,true);
			this.getTask().getServices().configurarCampo("GUIA.NR_INTERVALO_CICLO", true,false,true);

			ItemServices.setItemEnabled("GUIA.DT_INICIO_ADMICAO", false);

			ItemServices.setItemEnabled("GUIA.DS_JUSTIFICATIVA_TECNICA", false);
			ItemServices.setItemEnabled("GUIA.DS_ESPECIFICACAO_MATERIAL", false);

			this.getTask().getServices().configurarCampo("GUIA.NR_TEMPO_DOENCA", false);

			ItemServices.setItemVisible("GUIA.DS_AREA_IRRADIADA", true);
			ItemServices.setItemNavigable("GUIA.DS_AREA_IRRADIADA", true);

			ItemServices.setItemVisible("ITGUIA.DT_PROVAVEL", true);
			
			ItemServices.setItemVisible("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", true);
			ItemServices.setItemVisible("ITGUIA.DSP_DS_UNIDADE_MEDIDA", true);
			this.getTask().getServices().configurarCampo("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", true,false,true);
			
			this.getTask().getServices().configurarCampo("ITGUIA.DT_PROVAVEL", true, true,true);

			ItemServices.setItemVisible("ITGUIA.QT_SOLICITADO_DIA", true);
			ItemServices.setItemEnabled("ITGUIA.QT_SOLICITADO_DIA", true);
			ItemServices.setItemNavigable("ITGUIA.QT_SOLICITADO_DIA", true);

			setItemRequired("GUIA.CD_PRESTADOR", false);
			this.getTask().getServices().configurarCampo("GUIA.TP_CARATER_SOLIC_INTER", false,false,false);
			ItemServices.setItemLabel("GUIA.NR_GUIA_TEM", "Guia Referenciada");
			ItemServices.setItemEnabled("GUIA.NR_DIAS_SOLICITACAO", false);

			// ABA PROCEDIMENTOS
			if (!snOperadoraUnimed.equals("S")) {
				ItemServices.setItemFormatMask("ITGUIA.QT_SOLIC_PREST", "MVMask419");
				ItemServices.setItemFormatMask("ITGUIA.QT_SOLICITADO", "MVMask419");
			}

			// DSP_NM_PROFISSIONAL_SOLICITANTE
			setItemEnabled("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);
			setItemNavigable("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);
			setItemInsertAllowed("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);
			setItemUpdateAllowed("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);

			// CD_PRESTADOR_SOLICITANTE
			setItemEnabled("GUIA.CD_PRESTADOR_SOLICITANTE", true);
			setItemNavigable("GUIA.CD_PRESTADOR_SOLICITANTE", true);
			setItemInsertAllowed("GUIA.CD_PRESTADOR_SOLICITANTE", true);
			setItemUpdateAllowed("GUIA.CD_PRESTADOR_SOLICITANTE", true);
			
			this.getTask().getServices().configurarCampo("ITGUIA.QT_TOTAL_DOSAGEM_CICLO", true,false,true);
			
			this.getTask().getServices().configurarCampo("ITGUIA.QT_TOTAL_DOSAGEM_CICLO", true,false,true);
			this.getTask().getServices().configurarCampo("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", true,false,true);
			

			//Se a guia for de Radioterapia
		} else if (tpGuia.equals(toStr("R"))) {
			this.getTask().getServices().configurarCampo("GUIA.NR_DOSE_RADIOTERAPICO_TOTAL", true);
			ItemServices.setItemEnabled("GUIA.CD_DIAGNOSTICO_IMAGEM", true);

			ItemServices.setItemEnabled("GUIA.NR_PESO_BENEFICIARIO", false);
			ItemServices.setItemEnabled("GUIA.NR_ALTURA_BENEFICIARIO", false);
			ItemServices.setItemEnabled("GUIA.NR_SUPERFICIE_CORPORAL", false);
			ItemServices.setItemEnabled("GUIA.NR_CICLO_PREVISTO", false);
			ItemServices.setItemEnabled("GUIA.QTD_DIAS_CICLO", false);
			ItemServices.setItemEnabled("GUIA.NR_CICLO_ATUAL", false);
			ItemServices.setItemEnabled("GUIA.NR_INTERVALO_CICLO", false);

			ItemServices.setItemEnabled("GUIA.DS_JUSTIFICATIVA_TECNICA", false);
			ItemServices.setItemEnabled("GUIA.DS_ESPECIFICACAO_MATERIAL", false);

			this.getTask().getServices().configurarCampo("GUIA.NR_TEMPO_DOENCA", false);

			ItemServices.setItemVisible("GUIA.DS_AREA_IRRADIADA", false);
			ItemServices.setItemNavigable("GUIA.DS_AREA_IRRADIADA", false);

			ItemServices.setItemVisible("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", true);
			ItemServices.setItemVisible("ITGUIA.DSP_DS_UNIDADE_MEDIDA", true);
			this.getTask().getServices().configurarCampo("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", true,false,true);
			
			ItemServices.setItemVisible("ITGUIA.DT_PROVAVEL", true);
			ItemServices.setItemEnabled("ITGUIA.DT_PROVAVEL", true);
			ItemServices.setItemVisible("ITGUIA.QT_SOLICITADO_DIA", false);
			ItemServices.setItemEnabled("ITGUIA.QT_SOLICITADO_DIA", false);
			ItemServices.setItemNavigable("ITGUIA.QT_SOLICITADO_DIA", false);

			setItemRequired("GUIA.CD_PRESTADOR", false);
			this.getTask().getServices().configurarCampo("GUIA.TP_CARATER_SOLIC_INTER", false);
			ItemServices.setItemLabel("GUIA.NR_GUIA_TEM", "Guia Referenciada");
			ItemServices.setItemEnabled("GUIA.NR_DIAS_SOLICITACAO", true);

			// ABA PROCEDIMENTOS
			ItemServices.setItemFormatMask("ITGUIA.QT_SOLIC_PREST", "MVMask419");
			ItemServices.setItemFormatMask("ITGUIA.QT_SOLICITADO", "MVMask419");

			// DSP_NM_PROFISSIONAL_SOLICITANTE
			setItemEnabled("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);
			setItemNavigable("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);
			setItemInsertAllowed("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);
			setItemUpdateAllowed("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);

			// CD_PRESTADOR_SOLICITANTE
			setItemEnabled("GUIA.CD_PRESTADOR_SOLICITANTE", true);
			setItemNavigable("GUIA.CD_PRESTADOR_SOLICITANTE", true);
			setItemInsertAllowed("GUIA.CD_PRESTADOR_SOLICITANTE", true);
			setItemUpdateAllowed("GUIA.CD_PRESTADOR_SOLICITANTE", true);
			
			ItemServices.setItemRequired("IGTUIA.CD_PROCEDIMENTO", false);

			//Se a guia for de OPME
		} else if (tpGuia.equals(toStr("O"))) {
			ItemServices.setItemEnabled("GUIA.CD_DIAGNOSTICO_IMAGEM", false);
			ItemServices.setItemEnabled("GUIA.NR_DOSE_RADIOTERAPICO_TOTAL", false);
			ItemServices.setItemEnabled("GUIA.DT_INICIO_ADMICAO", false);

			ItemServices.setItemEnabled("GUIA.NR_PESO_BENEFICIARIO", false);
			ItemServices.setItemEnabled("GUIA.NR_ALTURA_BENEFICIARIO", false);
			ItemServices.setItemEnabled("GUIA.NR_SUPERFICIE_CORPORAL", false);
			ItemServices.setItemEnabled("GUIA.NR_CICLO_PREVISTO", false);
			ItemServices.setItemEnabled("GUIA.QTD_DIAS_CICLO", false);
			ItemServices.setItemEnabled("GUIA.NR_CICLO_ATUAL", false);
			ItemServices.setItemEnabled("GUIA.NR_INTERVALO_CICLO", false);

			ItemServices.setItemEnabled("GUIA.DS_JUSTIFICATIVA_TECNICA", true);
			ItemServices.setItemEnabled("GUIA.DS_ESPECIFICACAO_MATERIAL", true);

			ItemServices.setItemVisible("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", true);
			ItemServices.setItemVisible("ITGUIA.DSP_DS_UNIDADE_MEDIDA", true);
			this.getTask().getServices().configurarCampo("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", true);
			
			ItemServices.setItemVisible("GUIA.DS_AREA_IRRADIADA", false);
			ItemServices.setItemNavigable("GUIA.DS_AREA_IRRADIADA", false);
			
			ItemServices.setItemVisible("ITGUIA.DT_PROVAVEL", false);
			ItemServices.setItemEnabled("ITGUIA.DT_PROVAVEL", false);
			ItemServices.setItemVisible("ITGUIA.QT_SOLICITADO_DIA", false);
			ItemServices.setItemEnabled("ITGUIA.QT_SOLICITADO_DIA", false);
			ItemServices.setItemNavigable("ITGUIA.QT_SOLICITADO_DIA", false);

			this.getTask().getServices().configurarCampo("GUIA.NR_TEMPO_DOENCA", false);

			setItemRequired("GUIA.CD_PRESTADOR", false);
			this.getTask().getServices().configurarCampo("GUIA.TP_CARATER_SOLIC_INTER", false);
			ItemServices.setItemLabel("GUIA.NR_GUIA_TEM", "Guia Referenciada");
			ItemServices.setItemEnabled("GUIA.NR_DIAS_SOLICITACAO", false);
			
			// ABA PROCEDIMENTOS
			if (!snOperadoraUnimed.equals("S")) {
				ItemServices.setItemFormatMask("ITGUIA.QT_SOLIC_PREST", "MVMask421");
				ItemServices.setItemFormatMask("ITGUIA.QT_SOLICITADO", "MVMask421");
			}

			//Se guia for de SPSADT 
		} else if (tpGuia.equals(toStr("S"))) {
			
			ItemServices.setItemLabel("GUIA.NR_GUIA_TEM", "Guia Principal");
			
			ItemServices.setItemVisible("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", false);
			ItemServices.setItemVisible("ITGUIA.DSP_DS_UNIDADE_MEDIDA", false);
			this.getTask().getServices().configurarCampo("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", false);
			// ABA PROCEDIMENTOS
			if (!snOperadoraUnimed.equals("S")) {
				ItemServices.setItemFormatMask("ITGUIA.QT_SOLIC_PREST", "MVMask421");
				ItemServices.setItemFormatMask("ITGUIA.QT_SOLICITADO", "MVMask421");				
			}

			ItemServices.setItemVisible("ITGUIA.DT_PROVAVEL", false);
			ItemServices.setItemEnabled("ITGUIA.DT_PROVAVEL", false);
			ItemServices.setItemVisible("ITGUIA.QT_SOLICITADO_DIA", false);
			ItemServices.setItemEnabled("ITGUIA.QT_SOLICITADO_DIA", false);
			ItemServices.setItemNavigable("ITGUIA.QT_SOLICITADO_DIA", false);

		}else if(tpGuia.equals("C")){
			this.getTask().getServices().configurarCampo("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", false);
			this.getTask().getServices().configurarCampo("ITGUIA.DSP_DS_UNIDADE_MEDIDA", false);
			this.getTask().getServices().configurarCampo("ITGUIA.QT_FRANQUIA", false);
			this.getTask().getServices().configurarCampo("ITGUIA.QT_TOTAL_DOSAGEM_CICLO", false);
			this.getTask().getServices().configurarCampo("GUIA.NR_TEMPO_DOENCA", false);
		} 
		
		if(tpGuia.equals(toStr("I")) || ( snOperadoraUnimed.equals("S") && snCortesia.equals("S") && Lib.in(tpGuia.toString(), "O","Q","R").toBoolean() ) ){ //guia de internacao
			this.getTask().getServices().configurarCampo("GUIA.NR_TEMPO_DOENCA",true,false,true);
			this.getTask().getServices().configurarCampo("GUIA.NR_DIAS_SOLICITACAO",true,false,true);
			this.getTask().getServices().configurarCampo("CG$CTRL.DSP_DT_ALTA_INTERNACAO",true,false,true);
			
			this.getTask().getServices().configurarCampo("ITGUIA.QT_TOTAL_DOSAGEM_CICLO", true,false,true);
			this.getTask().getServices().configurarCampo("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", true,false,true);
			
			//Se for unimed utilizar os campos da internação junto com os anexos
			if( !snOperadoraUnimed.equals("S") && !snCortesia.equals("S") && !Lib.in(tpGuia.toString(), "O","Q","R").toBoolean() ){
				//Na internação o campo CID principal deve ser habilitado
				ItemServices.setItemEnabled("GUIA.NR_PESO_BENEFICIARIO", false);
				ItemServices.setItemEnabled("GUIA.NR_ALTURA_BENEFICIARIO", false);
				ItemServices.setItemEnabled("GUIA.NR_SUPERFICIE_CORPORAL", false);
				ItemServices.setItemEnabled("GUIA.NR_CICLO_PREVISTO", false);
				ItemServices.setItemEnabled("GUIA.QTD_DIAS_CICLO", false);
				ItemServices.setItemEnabled("GUIA.NR_CICLO_ATUAL", false);
				ItemServices.setItemEnabled("GUIA.NR_INTERVALO_CICLO", false);
	
				ItemServices.setItemVisible("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", false);
				ItemServices.setItemVisible("ITGUIA.DSP_DS_UNIDADE_MEDIDA", false);
				this.getTask().getServices().configurarCampo("ITGUIA.DS_TERMO_UNIDADE_MEDIDA", false);
				
				ItemServices.setItemVisible("GUIA.DS_AREA_IRRADIADA", false);
				ItemServices.setItemNavigable("GUIA.DS_AREA_IRRADIADA", false);
	
				ItemServices.setItemVisible("ITGUIA.DT_PROVAVEL", false);
				ItemServices.setItemEnabled("ITGUIA.DT_PROVAVEL", false);
				ItemServices.setItemVisible("ITGUIA.QT_SOLICITADO_DIA", false);
				ItemServices.setItemEnabled("ITGUIA.QT_SOLICITADO_DIA", false);
				ItemServices.setItemNavigable("ITGUIA.QT_SOLICITADO_DIA", false);
			}
			//Alterei aqui teste.
			//setItemRequired("GUIA.CD_PRESTADOR", true);
			ItemServices.setItemEnabled("GUIA.TP_INTERNACAO", true);
			this.getTask().getServices().configurarCampo("GUIA.TP_CARATER_SOLIC_INTER",true,false,true);
			ItemServices.setItemLabel("GUIA.NR_GUIA_TEM", "Guia de Solicitação");

			// ABA PROCEDIMENTOS
			ItemServices.setItemFormatMask("ITGUIA.QT_SOLIC_PREST", "MVMask421");
			ItemServices.setItemFormatMask("ITGUIA.QT_SOLICITADO", "MVMask421");

		}

		if (tpGuia.equals(toStr("H"))) {
			this.getTask().getServices().configurarCampo("GUIA.NR_TEMPO_DOENCA", false);
		}
		
	}

	@ValidationTrigger(item = "CD_TIP_ACOMODACAO")
	public void cdTipAcomodacao_validate() {
		NString snEmissaoAvulsa = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
		if(snEmissaoAvulsa.equals("N")) {
			this.getTask().getServices().prcTipAcomodacao(toStr("N"), NBool.True);			
		}else if(snEmissaoAvulsa.equals("S")){
			if (!getGuiaElement().getCdTipAcomodacao().isNull()) {
				ResultSet resultSet = this.getTask().getServices().cdTipoAcomodocacao_validate(getGuiaElement().getCdTipAcomodacao(), getGuiaElement().getDspCdPlano());
				try{
					if(resultSet != null && resultSet.hasData()){
						getGuiaElement().setDspDsTipAcomodacao(resultSet.getStr("DS_TIP_ACOMODACAO"));
					}else{
						getGuiaElement().setCdTipAcomodacao(NNumber.getNull());
						getGuiaElement().setDspDsTipAcomodacao(NString.getNull());
					}
				}catch(Exception ex){
					ex.printStackTrace();
				}finally{
					if(resultSet != null){resultSet.close();}
				}
			}	
		}
	}

	@ValidationTrigger(item = "CD_TIPO_CONSULTA")
	public void cdTipoConsulta_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		if (guiaElement.getDspTpGuia().equals("C") && guiaElement.getCdTipoConsulta().isNull()) {
			getTask().getMv2000().msgAlert(toStr("Erro: Tipo de consulta deve ser preenchido."), toStr("E"), toBool(NBool.True));
		}
	}

	@ValidationTrigger(item = "CD_PRESTADOR")
	public void cdPrestador_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		

		this.getTask().getServices().prcPrestador(guiaElement, toBool(NBool.True));
		
		if (!guiaElement.getCdPrestador().isNull()){
			validaTpSituacao(guiaElement.getCdPrestador());
		}   
		this.getTask().getServices().limpaEspecialidadeSolicitant(guiaElement);
		this.getTask().getServices().setaEspecialidadeSolicitante(guiaElement);

		if(Services.getDescricao("TP_PRESTADOR", "PRESTADOR", "CD_PRESTADOR = " +guiaElement.getCdPrestador() , true).equals("F")){
			guiaElement.setCdPrestadorSolicitante(guiaElement.getCdPrestador());
			guiaElement.setNmProfissionalSolicitante(getTask().getMPkgMvsPrestador().getMPkgMvsPrestador().fRetornaDescricao(guiaElement.getCdPrestador(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.True), toBool(NBool.True)));
			guiaElement.setNrTelefoneProfissional(Services.getDescricao("SUBSTR(NR_FONE,0,20) NR_FONE", "PRESTADOR", "CD_PRESTADOR = " +guiaElement.getCdPrestador() , true));
			guiaElement.setDspCdPrestadorInterno(Services.getDescricao("CD_INTERNO", "PRESTADOR", "CD_PRESTADOR = " +guiaElement.getCdPrestador() , true));
			this.getTask().getServices().setaConselho(guiaElement);
		}else{
			guiaElement.setCdPrestadorSolicitante(NNumber.getNull());
			guiaElement.setNmProfissionalSolicitante(NString.getNull());
			guiaElement.setNrTelefoneProfissional(NString.getNull());
			guiaElement.setDspCdPrestadorInterno(NString.getNull());
			guiaElement.setCdTissConselhoProfSol(NString.getNull());
			guiaElement.setDspDsSiglaConselhoProfissionalTiss(NString.getNull());
			guiaElement.setNrRegConselhoProfSolic(NString.getNull());
			guiaElement.setUfConselhoProfSolc(NString.getNull());
			guiaElement.setDspNmUf(NString.getNull());
			this.getTask().getServices().limpaEspecialidadeSolicitant(guiaElement);
		}
	  
	}	
	
	/*
	 * 
	 * Valida se o Prestador inativo ou suspenso pode ser informado como Contratado Solicitante  
	 */
	
	public void validaTpSituacao(NNumber CdPrestador) {
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true); 
		
		NString TpSituacao = Services.getDescricao("TP_SITUACAO", "DBAPS", "prestador", "cd_prestador ="  + CdPrestador , false);
				
			
			if (TpSituacao.equals("I")){
				 NString descricao = Services.getDescricao("SN_GUIA_CONT_SOLIC_PREST_INAT", "DBAMV", "multi_empresas_mv_saude", "cd_multi_empresa = dbamv.pkg_mv2000.Le_Empresa", false);	
				 //diferente de SIM
				 if (!descricao.equals("S")) {
							guiaElement.setNmPrestador(NString.getNull());
							getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg1005"), "W",NBool.True);
						}
				
			 }	
		         		
			 if (TpSituacao.equals("S")){
				 NString descricao = Services.getDescricao("SN_GUIA_CONT_SOLIC_PREST_SUSP", "DBAMV", "multi_empresas_mv_saude", "cd_multi_empresa = dbamv.pkg_mv2000.Le_Empresa", false);	
				 //diferente de Sim
				 if (!descricao.equals("S")) {
						guiaElement.setNmPrestador(NString.getNull());
						getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg1006"), "W",NBool.True);
					}
				 }		
	}

	@ValidationTrigger(item = "CD_PRESTADOR_SOLICITANTE")
	public void cdPrestadorSolicitante_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (!guiaElement.getCdPrestadorSolicitante().isNull()) {

			this.getTask().getServices().getDescricaoPrestadorSolicitante(guiaElement);

			this.getTask().getServices().limpaEspecialidadeSolicitant(guiaElement);

			this.getTask().getServices().setaEspecialidadeSolicitante(guiaElement);
			
			this.getTask().getServices().setaConselho(guiaElement);

			if (!guiaElement.getDspTpGuia().equals("S") && !guiaElement.getDspTpGuia().equals("I") && !guiaElement.getDspTpGuia().equals("C")) {
				setItemEnabled("CD_ESPECIALIDADE_SOLICITANTE", true);
			}
			setItemEnabled("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);
		} else {
			guiaElement.setCdTissConselhoProfSol(NString.getNull());
			guiaElement.setDspDsSiglaConselhoProfissionalTiss(NString.getNull());
			guiaElement.setNrRegConselhoProfSolic(NString.getNull());
			guiaElement.setUfConselhoProfSolc(NString.getNull());
			guiaElement.setDspNmUf(NString.getNull());
			guiaElement.setNmProfissionalSolicitante(NString.getNull());
			guiaElement.setNrTelefoneProfissional(NString.getNull());
			if (!guiaElement.getDspTpGuia().equals("S") && !guiaElement.getDspTpGuia().equals("I") && !guiaElement.getDspTpGuia().equals("C")) {
				setItemEnabled("GUIA.NM_PROFISSIONAL_SOLICITANTE", true);
			}
			setItemEnabled("GUIA.CD_ESPECIALIDADE_SOLICITANTE", true);
		}
	}


	@ValidationTrigger(item = "CD_PRESTADOR_SOLICITADO")
	public void cdPrestadorSolicitado_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (!guiaElement.getCdPrestadorSolicitado().isNull()) {

			guiaElement.setNmPrestadorSolicitado(getTask().getMPkgMvsPrestador().getMPkgMvsPrestador().fRetornaDescricao(guiaElement.getCdPrestadorSolicitado(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.True), toBool(NBool.True)));
		} else {
			guiaElement.setNmPrestadorSolicitado(NString.getNull());
		}
	}

	@ValidationTrigger(item = "TP_INTERNACAO")
	public void tpInternacao_validate() {
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		if (guiaElement.getDspSnTpInternacao().equals("S") && guiaElement.getTpInternacao().isNull()) {
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0141"), toStr("E"), toBool(NBool.True));
		}
	}

	@ValidationTrigger(item = "CD_REGIME_INTERNACAO")
	public void cdRegimeInternacao_validate() {
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (!isGuiaProrrogacaoInternacao() && guiaElement.getDspSnTpInternacao().equals("S")
				&& guiaElement.getCdRegimeInternacao().isNull()) {
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0134"), toStr("W"), toBool(NBool.True));
		}
	}

	@ViewTrigger
	@ActionTrigger(action = "dtEmissao_itemIn", item = "DT_EMISSAO", function=KeyFunction.ITEM_IN)
	public void dtEmissao_itemIn() {
		//ADICIONADO VARIAVEL NO MODEL
	}

	@ValidationTrigger(item = "DT_EMISSAO")
	public void dtEmissao_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		boolean isMensagemInativo = ItemServices.getItemIsValid("GUIA.CD_MATRICULA").toBoolean(); // utilizado para verificar se a mensagem de dada de inativação já foi exibida
		/**
		 * Concatenar a data de emissao da guia com hora atual para verificar corretamente situação do beneficiario
		 * infelizmente nosso sistema hoje sempre considera a hora emissao de guia como sendo 00:00:00
		 * isso estava prejudicando a fn_situacao_usuario em casos de reativacao do beneficiario no mesmo dia de emissao da guia
		 * 
		 *  By Dellanio em 13/08/2014
		 */
		Calendar cal = Calendar.getInstance();
		if (!guiaElement.getDtEmissao().isNull()) {

			try {
				Calendar horaAtual = Calendar.getInstance();

				cal.setTime(guiaElement.getDtEmissao().getValue());
				cal.set(Calendar.HOUR, horaAtual.get(Calendar.HOUR_OF_DAY));
				cal.set(Calendar.MINUTE, horaAtual.get(Calendar.MINUTE));
				cal.set(Calendar.SECOND, horaAtual.get(Calendar.SECOND));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (!guiaElement.getCdMatricula().isNull() && StoredProcedures.fnSituacaoUsuario(guiaElement.getCdMatricula(), new NDate(cal.getTime()), toStr("S")).equals("N")) {

			String sql = " select u.dt_cadastro, d.dt_desligamento " 
					+ " from dbaps.usuario u, dbaps.DESLIGAMENTO d " 
					+ " where u.cd_matricula = d.cd_matricula(+) " 
					+ "and u.cd_matricula = :P_CD_MATRICULA";
			DataCursor dc = new DataCursor(sql);

			dc.addParameter("P_CD_MATRICULA", guiaElement.getCdMatricula());
			dc.open();

			ResultSet rs = dc.fetchInto();

			if (rs != null) {

				if (rs.getDate("dt_cadastro").greater(guiaElement.getDtEmissao())) {

					getTask().getMv2000().msgAlert(toStr("Guia não poderá ser gerada: O beneficiário estará ativo apartir do dia " + rs.getDate("dt_cadastro") + "!"), toStr("E"), toBool(NBool.True));

				} else {
					if(!isMensagemInativo){			
						if (!(getTask().getMv2000().msgAlertSn(Types.toStr("O usuário está desligado desde ").append(toChar(rs.getDate("dt_desligamento"), "dd/mm/yyyy")).append(".").append(chr(10)).append("Deseja continuar?"), Types.toStr("W"), Types.toStr("Sim/Não"))).toBoolean()) {
							getTask().getMv2000().msgAlert(NString.toStr("")
									.append("Operação inválida!")
									.append(Lib.chr(10))
									.append("Motivo..: Usuário não está ativo.")
									.append(Lib.chr(10))
									.append("Ação....: Informe um usuário ativo.").toString(),
									"W", /*W = Atenção, I = Informação, E = Erro */
									NBool.True /*bloquear/travar?*/);
						}
					}
				}
			}

			dc.close();
		}

		if (trunc(guiaElement.getDtEmissao().clearTime()).greater(trunc(DbManager.getDBDate()))) {

			if (isNull(this.getFormModel().getParam("SN_DTGUIA_FUTURA", NString.class), "N").equals("S")) {

				if (getTask().getMv2000().msgAlertSn(toStr("A Data de Emissão é Maior que a Data Atual. Confirma o Lançamento ?"), toStr("I"), toStr("Não/Sim")).equals(NBool.True)) {

					throw new ApplicationException();
				}

			} else {
				getTask().getMv2000().msgAlert(toStr("Data de Emissão Não Pode ser Maior que Data Atual."), toStr("E"), toBool(NBool.True));
			}
		}

		if (guiaElement.getDtEmissaoGuiaSolicitacao().greater(guiaElement.getDtEmissao()) && !guiaElement.getDtEmissao().isNull() && !guiaElement.getDtEmissaoGuiaSolicitacao().isNull()) {

			//MULTI-IDIOMA: MSG_0064 - Data de emissão da guia de solicitação maior que a da guia a ser autorizada!
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0064"), "E", NBool.True);
		}

		if (guiaElement.getDtVencimento().isNull() && !guiaElement.getDtEmissao().isNull()) {

			guiaElement.setDtVencimento(toDate(((guiaElement.getDtEmissao().add(toNumber(isNull(this.getFormModel().getParam("NR_DIAS_VENCIMENTO_DA_GUIA", NString.class), 0)))))));
		}
	}

	@ValidationTrigger(item = "DT_VENCIMENTO")
	public void dtVencimento_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (guiaElement.getDtVencimento().clearTime().lesser(guiaElement.getDtEmissao().clearTime())) {

			if (!((getTask().getMv2000().msgAlertSn(toStr("Data do Vencimento da Guia não pode ser anterior a Data da Emissão. Deseja continuar?"), toStr("I"), toStr("Sim/Não")))).toBoolean()) {
				throw new ApplicationException();
			}

		}

		if (guiaElement.getDtPrevExecucao().clearTime().greater(guiaElement.getDtVencimento().clearTime())) {

			if (!((getTask().getMv2000().msgAlertSn(toStr("Data da Previsão da Execução da Guia Não pode ser Maior que a Data de Vencimento. Deseja continuar?"), toStr("I"), toStr("SIm/Não")))).toBoolean()) {
				throw new ApplicationException();
			}
		}

	}

	@ValidationTrigger(item = "DT_PREV_EXECUCAO")
	public void dtPrevExecucao_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		
		if(snOperadoraUnimed.equals("N") && !guiaElement.getDtEmissao().isNull()){
			if (guiaElement.getDtPrevExecucao().clearTime().lesser(guiaElement.getDtEmissao().clearTime()) ) {

				getTask().getMv2000().msgAlert(toStr("Erro: Data da Previsão da Execução da Guia Não pode ser anterior a Data da Emissão"), toStr("E"), toBool(NBool.True));

			} else if (guiaElement.getDtPrevExecucao().clearTime().greater(guiaElement.getDtVencimento().clearTime())) {

				getTask().getMv2000().msgAlert(toStr("Erro: Data da Previsão da Execução da Guia Não pode ser Maior que a Data de Vencimento"), toStr("E"), toBool(NBool.True));

			} else if (guiaElement.getDtPrevExecucao().isNull()) {

				getTask().getMv2000().chamaMensagem(toStr("Atenção"), toStr("Erro...: Operação inválida!").append(chr(10)).append("Motivo: Data de Previsão não informada.").append(chr(10)).append("Ação...: Informe a Data de Previsão."), toBool(NBool.True));
			}
		}
	}

	@ViewTrigger
	@ActionTrigger(action = "dtPrevExecucao_itemIn", item = "DT_PREV_EXECUCAO", function=KeyFunction.ITEM_IN)
	public void dtPrevExecucao_itemIn() {

		if (getGuiaElement().getDtPrevExecucao().isNull() && !getGuiaElement().getDtEmissao().isNull()) {
			getGuiaElement().setDtPrevExecucao(getGuiaElement().getDtEmissao());
		}

	}

	@ValidationTrigger(item = "CD_ESPECIALIDADE")
	public void cdEspecialidade_validate() {

		if (!this.getGuiaElement().getCdEspecialidade().isNull()){

			this.getGuiaElement().setDspDsEspecialidade(getTask().getServices().getDescricaoEspecialidade(this.getGuiaElement().getCdEspecialidade()));		

			if (this.getGuiaElement().getDspDsEspecialidade().isNull()){
				getTask().getMv2000().msgAlert(toStr("O código da especialidade [ " + this.getGuiaElement().getCdEspecialidade() + " ] não existe ou está inativo"), toStr("E"), toBool(NBool.True));	
			}else{
				cdEspecialidadeValidatelimpa(this.getGuiaElement());
			}
		}else{

			this.getGuiaElement().setDspDsEspecialidade(NString.getNull());
			this.getGuiaElement().setCdEspecialidade(NNumber.getNull());
		}

	}

	@ValidationTrigger(item = "CD_PRESTADOR_EXECUTOR")
	public void cdPrestadorExecutor_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		this.getTask().getServices().prestadorExecutor(guiaElement);
		cdPrestadorEnderecoValidatelimpa(guiaElement);

		this.getTask().getServices().exibeAlerta(true);

	}

	@ValidationTrigger(item = "CD_PRESTADOR_EXECUTOR_PF")
	public void cdPrestadorExecutorPf_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		String sql1 = "SELECT * FROM (                    " 
		+ "	SELECT distinct(P.CD_PRESTADOR), P.NM_PRESTADOR, p.nr_cpf_cgc, PA.DT_INICIO DT_INICIO, PA.DT_TERMINO DT_TERMINO, P.TP_PRESTADOR TP_PRESTADOR,P.CD_INTERNO " 
		+ "	FROM DBAPS.PRESTADOR P, DBAPS.PRESTADOR_ASSOCIADO PA, dbaps.especialidade_prestador esp_pre, DBAPS.PRESTADOR_ASSOCIADO_ESPL PA_ESPEL " 
		+ "	WHERE esp_pre.cd_prestador = P.cd_prestador " 
		+ "	and P.CD_PRESTADOR = PA.CD_PRESTADOR_ASSOCIADO " 
		+ "	AND P.CD_PRESTADOR = PA.CD_PRESTADOR_ASSOCIADO " 
		+ "	AND P.SN_EXECUTOR = 'S' AND P.TP_PRESTADOR = 'F' " 
		+ "	AND PA.CD_PRESTADOR = :CD_PRESTADOR_EXECUTOR AND esp_pre.cd_especialidade = :CD_ESPECIALIDADE " 
		+ "	AND PA_ESPEL.CD_PRESTADOR = :CD_PRESTADOR_EXECUTOR " 
		+ "	AND PA_ESPEL.CD_PRESTADOR_ASSOCIADO = P.CD_PRESTADOR " 
		+ "	AND (PA_ESPEL.CD_ESPECIALIDADE = :CD_ESPECIALIDADE  OR :CD_ESPECIALIDADE IS NULL) " 
		+ "	AND P.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA " 
		+ "	ORDER BY NM_PRESTADOR " 
		+ "	) WHERE cd_prestador = :CD_PRESTADOR_EXECUTOR_PF";

		DataCursor c2 = new DataCursor(sql1);

		@SuppressWarnings("unused")
		NDate dtInicio = NDate.getNull();
		@SuppressWarnings("unused")
		NDate dtTermino = NDate.getNull();
		NString tpPrestador = NString.getNull();

		if (!guiaElement.getCdPrestadorExecutorPf().isNull()) {
			this.getTask().getServices().getDescricaoPrestadorExecutante(guiaElement);
			this.getTask().getServices().limparEspecialidadeExecutante(guiaElement);
			this.getTask().getServices().configurarEspecialidadeExecutante(guiaElement);
			this.getTask().getServices().configurarConselhoExecutante(guiaElement);
			
			if(!("C").equals(guiaElement.getDspTpGuia())){
				setItemEnabled("GUIA.CD_ESPECIALIDADE_EXECUTANTE", true);
			}
				setItemEnabled("GUIA.NM_PRESTADOR_EXECUTOR_PF", true);
				
			try {
				c2.addParameter("CD_PRESTADOR_EXECUTOR_PF", guiaElement.getCdPrestadorExecutorPf());
				c2.addParameter("CD_PRESTADOR_EXECUTOR", guiaElement.getCdPrestadorExecutor());
				c2.addParameter("CD_ESPECIALIDADE", guiaElement.getCdEspecialidade());
				c2.open();
				ResultSet cResults = c2.fetchInto();
				if (cResults != null) {
					dtInicio = cResults.getDate(3);
					dtTermino = cResults.getDate(4);
					tpPrestador = cResults.getStr(5);
					guiaElement.setNmPrestadorExecutorPf(cResults.getStr(1));
					guiaElement.setDspCdPrestadorExecutorPfInterno(cResults.getStr(6));
				} else {
					getTask().getMv2000().msgAlert(toStr("Atenção! O prestador executante não está associado ao contratado " + "executante ou não possui vinculo com a especialidade informada."), toStr("E"), toBool(NBool.True));
				}

				if (tpPrestador.equals("J")) {
					getTask().getMv2000().msgAlert(toStr(" Erro:   Profissional Executante inválido! ").append("\n Motivo: Profissional Executante selecionado é uma pessoa jurídica!").append("\n Ação:   Selecione um profissional cadastrado como pessoa física "), toStr("E"), toBool(NBool.True));
				}

			} catch (DataLayerException e) {
				getTask().getMv2000().msgAlert(toStr("Erro ao tentar executar a query do validade cd_prestador_executante. " + "Por favor, contactar o suporte\nErro: " + e), toStr("E"), toBool(NBool.True));
			} finally {
				c2.close();
			}
		} else {
			if (ItemServices.getItemRequired("GUIA.CD_PRESTADOR_EXECUTOR_PF").getValue()) {
				getTask().getMv2000().msgAlert(toStr("Atenção! O prestador executante é obrigatório para contratado executante cadastrado como pessoa jurídica!"), toStr("E"), toBool(NBool.True));
			}
			guiaElement.setNmPrestadorExecutorPf(NString.getNull());
			guiaElement.setCdTissConselhoProfiExecPf(NString.getNull());
			guiaElement.setNrRegConselhoProfiExec(NString.getNull());
			guiaElement.setUfConselhoProfissionalExec(NString.getNull());
			guiaElement.setCdEspecialidadeExecutante(NNumber.getNull());
			
			if(!("C").equals(guiaElement.getDspTpGuia())){
				setItemEnabled("GUIA.NM_PRESTADOR_EXECUTOR_PF", true);
			}
			setItemEnabled("GUIA.CD_ESPECIALIDADE_EXECUTANTE", true);
		}

		this.getTask().getServices().exibeAlerta(true);
	}

	@ValidationTrigger(item = "CD_PROCEDIMENTO_PRINCIPAL")
	public void cdProcedimentoPrincipal_WhenValidateItem() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		guiaElement.setDspDsProcedimentoPrincipal(getTask().getMPkgMvsContasMedicas().getMPkgMvsContasMedicas().fProcPrincipal(guiaElement.getCdProcedimentoPrincipal(), guiaElement.getCdTipoAtendimento(), toBool(NBool.True)));
	}

	@ValidationTrigger(item = "CD_CID")
	public void cdCid_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		guiaElement.setDspDsCid(getTask().getMPkgMvsCid().getMPkgMvsCid().fRetornaDescricao(guiaElement.getCdCid(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.True), toBool(NBool.True)));

		/**
		 * Solicitação do cliente São Bernardo. Se o Tipo de Atendimento for
		 * "Internação" o campo CID é obrigatório
		 * 
		 * @author diego.nobre
		 * @since 2012-03-06
		 */
		// if (guiaElement.getDspSnTpInternacao().equals("S")) {
		// setItemRequired("GUIA.CD_CID", true);
		// } else {
		// setItemRequired("GUIA.CD_CID", false);
		// }
	}

	@ValidationTrigger(item = "CD_CID2")
	public void cdCid2_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		if (!guiaElement.getCdCid2().isNull()) {
			if ((guiaElement.getCdCid2().equals(isNull(guiaElement.getCdCid(), " "))) || (guiaElement.getCdCid2().equals(isNull(guiaElement.getCdCid3(), " "))) || (guiaElement.getCdCid2().equals(isNull(guiaElement.getCdCid4(), " ")))) {
				//MULTI-IDIOMA: MSG_0053 - CID já informado.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0053"), "W", NBool.True);
			}
			guiaElement.setDspDsCid2(getTask().getMPkgMvsCid().getMPkgMvsCid().fRetornaDescricao(guiaElement.getCdCid2(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.True), toBool(NBool.True)));
		} else {
			guiaElement.setDspDsCid2(toStr(null));
		}
	}

	@ValidationTrigger(item = "CD_CID3")
	public void cdCid3_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		if (!guiaElement.getCdCid3().isNull()) {
			if ((guiaElement.getCdCid3().equals(isNull(guiaElement.getCdCid(), " "))) || (guiaElement.getCdCid3().equals(isNull(guiaElement.getCdCid2(), " "))) || (guiaElement.getCdCid3().equals(isNull(guiaElement.getCdCid4(), " ")))) {
				//MULTI-IDIOMA: MSG_0053 - CID já informado.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0053"), "W", NBool.True);
			}
			guiaElement.setDspDsCid3(getTask().getMPkgMvsCid().getMPkgMvsCid().fRetornaDescricao(guiaElement.getCdCid3(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.True), toBool(NBool.True)));
		} else {
			guiaElement.setDspDsCid3(toStr(null));
		}
	}

	@ValidationTrigger(item = "CD_CID4")
	public void cdCid4_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		if (!guiaElement.getCdCid4().isNull()) {
			if ((guiaElement.getCdCid4().equals(isNull(guiaElement.getCdCid(), " "))) || (guiaElement.getCdCid4().equals(isNull(guiaElement.getCdCid2(), " "))) || (guiaElement.getCdCid4().equals(isNull(guiaElement.getCdCid3(), " ")))) {
				//MULTI-IDIOMA: MSG_0053 - CID já informado.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0053"), "W", NBool.True);
			}
			guiaElement.setDspDsCid4(getTask().getMPkgMvsCid().getMPkgMvsCid().fRetornaDescricao(guiaElement.getCdCid4(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.True), toBool(NBool.True)));
		} else {
			guiaElement.setDspDsCid4(toStr(null));
		}
	}

	@ValidationTrigger(item = "NR_DIAS_SOLICITACAO")
	public void nrDiasSolicitacao_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		if (isNull(guiaElement.getNrDiasAutorizacao(), 0).equals(0)) {
			guiaElement.setNrDiasAutorizacao(guiaElement.getNrDiasSolicitacao());
		}
	}

	@ViewTrigger
	@ActionTrigger(action = "nrDiasAutorizacao_replicar", item = "NR_DIAS_AUTORIZACAO", function=KeyFunction.ITEM_OUT)
	public void nrDiasAutorizacao_replicar() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		guiaElement.setDspTotDiasAutorizados(isNull(guiaElement.getNrDiasAutorizacao(), 0).add(isNull(guiaElement.getDspTotDiasProrrogados(), 0)));

		/**
		 * Quando informar Dias Autorizados atualizar Dias Solicitados com mesmo
		 * valor (a quantidade de dias solicitados é geralmente maior do que a
		 * de dias autorizados – nunca é menor); Levantamento feito no
		 * treinamento com Andresson Mota (Recife, 30/01 a 03/02/12)
		 * 
		 * @author diego.nobre
		 * @since 2012-02-15
		 */
		if (guiaElement.getNrDiasSolicitacao().lesser(guiaElement.getNrDiasAutorizacao())) {
			guiaElement.setNrDiasSolicitacao(guiaElement.getNrDiasAutorizacao());
		}
		
		getGuiaElement().setDtPrevisaoAlta(getGuiaElement().getDtSugeridaInternacao().add(getGuiaElement().getNrDiasAutorizacao()));
	}

	@ValidationTrigger(item = "SN_VALIDA_REST_CARENCIA")
	public void snValidaRestCarencia_validate() {


		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		this.getTask().getServices().prcHabilitaBotoes(guiaProrrogacaoElement, guiaElement, toStr("N"));
	}

	@ValidationTrigger(item = "CD_AUTORIZADOR")
	public void cdAutorizador_validate() {
		this.getTask().getServices().prcAutorizador(getGuiaElement(), toBool(NBool.True));
	}

	@ValidationTrigger(item = "DS_SENHA_AUTORIZADOR")
	public void dsSenhaAutorizador_validate() {

		PkgMvsGuia.pIWviGDsSenhaAutor();

	}


	@ValidationTrigger(item = "CD_ID_USUARIO")
	public void cdIdUsuario_WhenValidateItem() {

		this.getTask().getServices().prcAutorizador(this.getGuiaElement(), toBool(NBool.True));
	}

	@ActionTrigger(action = "btnEmissaoDaGuia_click", item = "BTN_EMISSAO_DA_GUIA")
	public void btnEmissaoDaGuia_click(){

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (guiaElement.getNrGuia().isNull()) {
			executeAction("SAVE");
		}

		//tipo consulta
		NString tpGuia = this.getTask().getServices().getTpGuia(guiaElement);
		if(tpGuia !=null && tpGuia.equals("C")){
			this.getTask().getServices().validaGuiaConsulta();
		}

		this.getTask().getServices().prcEmiteGuia(guiaElement);

		ItemServices.goItem("GUIA.CD_MATRICULA");
	}

	/**
	 * Botão LIBERAR da tela
	 */
	@ActionTrigger(action = "btnSenha_click", item = "BTN_SENHA")
	public void btnSenha_click() {
		TaskServices.commitTask(true);
		
		validarBeneficiarioAtivo();
		
		NNumber ncont = NNumber.getNull();
		NNumber qtdProc = NNumber.getNull();
		NNumber nnrregistroatual = NNumber.getNull();

		String sqlcitguiaerros = "SELECT count(1) FROM DBAPS.ITGUIA_ERROS IE, DBAPS.ITGUIA IT WHERE IE.cd_itguia = IT.cd_itguia AND IT.TP_STATUS <> 3 AND IE.NR_GUIA = :GUIA_NR_GUIA ";

		String sqlExisteItem = "SELECT COUNT(1) QTD_PROC" +
				"                 FROM DBAPS.ITGUIA " +
				"         	     WHERE TP_STATUS <> 3 " +
				"        	       AND NR_GUIA = :P_NR_GUIA";
		DataCursor cCursor = new DataCursor(sqlExisteItem);

		try {

			cCursor.addParameter("P_NR_GUIA", getGuiaElement().getNrGuia());
			cCursor.open(); 

			if(cCursor.found()){

				ResultSet rs = cCursor.fetchInto();

				qtdProc = rs.getNumber("QTD_PROC");

			}

		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			cCursor.close();
		}

		DataCursor citguiaerros = new DataCursor(sqlcitguiaerros);
		citguiaerros.addParameter("GUIA_NR_GUIA", getGuiaElement().getNrGuia());

		citguiaerros.open();

		ResultSet citguiaerrosResults = citguiaerros.fetchInto();

		if (citguiaerrosResults != null) {
			ncont = citguiaerrosResults.getNumber(0);
		}

		citguiaerros.close();

		if(qtdProc.equals(0) && !Lib.in(getGuiaElement().getDspTpGuia(), "R","P").toBoolean()){
			getTask().getMv2000().msgAlert("Guia não possui itens ou todos os itens estão negados!", "W", NBool.True);
		}
		
		if (Services.exist("ITGUIA", "QT_SOLICITADO = 0 AND TP_STATUS = 4 AND NR_GUIA = " + getGuiaElement().getNrGuia(), false)) {
			
			getTask().getMv2000().msgAlert("Guia possui itens que estão autorizados com a quantidade 0!", "W", NBool.True);
		}

		if (getGuiaElement().getDtUltimaAnalise().isNull()) {
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0099"), "W", NBool.True);
		}
		
		if (isNull(ncont, 0).equals(0) && getGuiaElement().getDtUltimaAnalise().isNull()) {
			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Operação inválida!")
					.append(Lib.chr(10))
					.append("Motivo..: Não existem restrições a serem liberadas.")
					.append(Lib.chr(10))
					.append("Ação....: Clique em Analisar.").toString(),
					"W", /*W = Atenção, I = Informação, E = Erro */
					NBool.True /*bloquear/travar?*/);
		}

		if (!getGuiaElement().getCdMensContrato().isNull()) {
			
			if((getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_LIBERA_GUIA_SEM_PAGAMENTO") != null && 
				 getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_LIBERA_GUIA_SEM_PAGAMENTO").equals("N"))) {
				getTask().getMv2000().msgAlert(toStr("Guia possui receita associada e deve ser recebida no caixa para autorização."), toStr("E"), toBool(NBool.True));
			} else {
				getTask().getMv2000().msgAlert(toStr("Lembrete: A Guia possui uma receita de código ["+getGuiaElement().getCdMensContrato()+"] associada. Favor lembrar de pagar no caixa."), toStr("W"), toBool(NBool.False));
			}
			
		}

		if (trunc(getGuiaElement().getDtVencimento()).lesser(trunc(DbManager.getDBDate()))) {
			getTask().getMv2000().msgAlert(toStr("Guia vencida não pode ser liberada."), toStr("E"), toBool(NBool.True));
		}

		nnrregistroatual = toNumber(getBlockCurrentRecord("ITGUIA"));

		if (!getItguiaElement().getCdProcedimento().isNull() || nnrregistroatual.greater(1) || (qtdProc.equals(0) && Lib.in(getGuiaElement().getDspTpGuia(), "R","P").toBoolean())) {

			getFormModel().getCgCtrl().setDspDsLiberacao(toStr("Digite a Senha de Liberacao da Guia"));
			getFormModel().getCgCtrl().setDsSenhaAutorizacaoSemBase(toStr(null));
			
			getFormModel().getCgCtrl().setCdAutorizadorOpe(getGuiaElement().getCdAutorizador());
			getFormModel().getCgCtrl().setDspNmAutorizadorOpe(getGuiaElement().getDspNmAutorizador());
			
			ResultSet rs = GuiaServices.getAutorizadorLogado();
			
			if(rs != null){
				getFormModel().getCgCtrl().setCdAutorizadorOpe(rs.getNumber("CD_AUTORIZADOR"));
				getFormModel().getCgCtrl().setDspNmAutorizadorOpe(rs.getStr("NM_AUTORIZADOR"));	
			}
			
			getFormModel().getCgCtrl().setSnCancelaAutorizacao(toStr("N"));
			getFormModel().getCgCtrl().setCdMotCancelamento(toNumber(null));
			getFormModel().getCgCtrl().setDspDsMotCancelamento(toStr(null));
			getFormModel().getCgCtrl().setTpStatus(getGuiaElement().getTpStatus());
			getFormModel().getCgCtrl().setCdMotivoAutorizacao(getGuiaElement().getCdMotivoAutorizacao());
			getFormModel().getCgCtrl().setDspDsMotivoAutorizacao(getGuiaElement().getDspDsMotivoAutorizacao());

			this.getFormModel().setParam("CHAMA_AUTORIZ", toStr("L"));

			this.getTask().getServices().configuraSolicitacaoSenha(NString.toStr("L"));
		}
	}

	@ActionTrigger(action = "btnProrrogacao_click", item = "BTN_PRORROGACAO")
	public void btnProrrogacao_click() {

//CARE-VALIDATION: HideView without Go 
		

		// pda 404139 - início
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		//
		
		this.getTask().getServices().isBeneficiarioDesligado();
		
		guiaElement.setProrrDspNrGuia(guiaElement.getNrGuia());
		guiaElement.setProrrDspCdMatricula(guiaElement.getCdMatricula());
		guiaElement.setProrrDspNmAssociado(guiaElement.getDspNmSegurado());
		guiaElement.setProrrDspNmPlano(guiaElement.getDspDsPlano());
		guiaElement.setProrrDspDsTipoAcomodacao(guiaElement.getDspDsTipAcomodacao());
		guiaElement.setProrrDspNmPrestador(guiaElement.getDspNmExecutor());
		guiaElement.setProrrDspTipoGuia(guiaElement.getDspDsTipoAtendimento());
		// pda 404139 - fim
		hideView("CNV_TAB_GUIA");
		ViewServices.hideView("CG$PAGE_1");
		ViewServices.showView("CANVAS_PRORROGACAO");
		goItem(toStr("GUIA_PRORROGACAO.NR_DIAS_PRORROGADOS"));
		TaskServices.executeQuery("GUIA_PRORROGACAO");
		//
	}

	@SuppressWarnings("rawtypes")
	@ActionTrigger(action = "btnFinanceiro_click", item = "BTN_FINANCEIRO")
	public void btnFinanceiro_click() {

		GuiaAdapter guiaElement = this.getGuiaElement();
		MensContratoAdapter mensContratoElement = (MensContratoAdapter) this.getFormModel().getMensContrato().getRowAdapter(true);
		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);

		if (!guiaElement.getCdMensContrato().isNull()) {
			String sqlcmc = "SELECT CD_CON_REC FROM DBAPS.MENS_CONTRATO MC WHERE MC.CD_MENS_CONTRATO = :GUIA_CD_MENS_CONTRATO ";
			DataCursor cmc = new DataCursor(sqlcmc);
			Hashtable plId = null;
			NNumber ncdconrec = NNumber.getNull();
			try {
				ncdconrec = toNumber(null);
				// Setting query parameters
				cmc.addParameter("GUIA_CD_MENS_CONTRATO", guiaElement.getCdMensContrato());
				// F2N_WARNING : Make sure that the method "Close" is being
				// called over the variable cmc.
				cmc.open();
				ResultSet cmcResults = cmc.fetchInto();
				if (cmcResults != null) {
					ncdconrec = cmcResults.getNumber(0);
				}
				cmc.close();
				if (!ncdconrec.isNull()) {
					plId = getParameterList("P_CD_CON_REC");
					if ((plId == null)) {
						plId = createParameterList("P_CD_CON_REC");
					} else {
						deleteParameter("P_CD_CON_REC", "P_CD_CON_REC");
					}
					addParameter(plId, "P_CD_CON_REC", ncdconrec);

					/*
					 * se a tela versão SOUL não existir chama a tela do Oracle Forms
					 * @author diego.nobre
					 * @since 23/07/2013
					 */
					Boolean telaSoul = false;
					try {
						callTask("M_CON_REC", TaskServices.HIDE, TaskServices.NO_REPLACE, TaskServices.NO_QUERY_ONLY, plId);
						telaSoul = true;
					} catch (Exception e) {
						telaSoul = false;
					}

					if (telaSoul) {
						setGlobal("NR_GUIA", guiaElement.getNrGuia());
						goBlock(toStr("GUIA"));
						BlockServices.setBlockWhereClause("GUIA", "NR_GUIA = " + toNumber(getGlobal("NR_GUIA")));
						executeQuery();
						/**
						 * PDA 521677
						 */
						if (mensContratoElement.getTpQuitacao().equals("Q")) {
							/**
							 * Ao retornar do FNFI se a mensalidade for quitada
							 * deve ser desabilitado o botao de analisar e
							 * habilitar o de emissao e retirar a mascara
							 * ******** do NR_GUIA.
							 */
							this.getTask().getServices().prcHabilitaBotoes(guiaProrrogacaoElement, guiaElement, toStr("N"));
						}
					} else {
						if (Lib.in(toStr(DbManager.getUser()), toStr("DBAPS"), toStr("DBAMV"), toStr("USERMV")).toBoolean()) {
							getTask().getMv2000().msgAlert("Integração automática não pode ser realizada utilizando usuários administrativos como DBAPS ou DBAMV.", "W", NBool.True);
						}

						if (this.getFormModel().getParam("P_DS_SERVIDOR_EMAIL", NString.class).isNull()) {
							getTask().getMv2000().msgAlert("Não existe configuração para o servidor do autorizador web. Por favor verifique configurações do servidor em: Configurações > Configurações (aba Dados da Operadora).", "W", NBool.True);
						}

						ViewServices.showView("CNV_M_CON_REC_FORMS");
						ItemServices.goItem("M_CON_REC_FORMS.BTN_M_CON_REC_FORMS");

						String urlAutorizador = this.getFormModel().getParam("P_DS_SERVIDOR_EMAIL", NString.class).toString();
						urlAutorizador = urlAutorizador.replace("ServletEmailGuia", "app/soulforms/openForm");

						NString urlTelaForms = toStr(urlAutorizador).append("?u=").append(toStr(DbManager.getUser())).append("&s=").append(toStr(DbManager.getPassword())).append("&b=").append(toStr(DbManager.getDatabase())).append("&e=").append(toStr(PkgMv2000.leEmpresa())).append("&sis=FNCP").append("&m=M_CON_REC").append("&p=P_CD_CON_REC=").append(toStr(ncdconrec));

						getFormModel().getMConRecForms().setDsUrlTelaForms(urlTelaForms);
					}

				} else {
					getTask().getMv2000().msgAlert(toStr("A receita está sem conta a receber associada. Para criá-la localize a mensalidade ").append(toChar(guiaElement.getCdMensContrato())).append(" no menu Faturamento, opção Composição."), toStr("E"), toBool(NBool.True));
				}
			} finally {
				cmc.close();
			}
		} else {
			this.getTask().getMv2000().msgAlert(toStr("Essa guia não tem receita associada."), toStr("E"), toBool(NBool.True));
		}
	}

	@ValidationTrigger(item = "CD_MOT_CANCELAMENTO_GUIA")
	public void cdMotCancelamentoGuia_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		guiaElement.setDspDsMotCancelamentoGuia(getTask().getMPkgMvsMotCancelaGuia().getMPkgMvsMotCancelaGuia().fRetornaDescricao(guiaElement.getCdMotCancelamentoGuia(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.True), toBool(NBool.True)));
	}

	@SuppressWarnings("unused")
	@ActionTrigger(action = "btnAnalisar_click", item = "BTN_ANALISAR")
	public void btnAnalisar_click() {

		NString snGuiaAutorizaAutomatico = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_GUIA_AUTORIZA_AUTOMATICO"),"N");
		NString snEnvioAutoSmsLiberaGuia = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_ENVIO_AUTO_SMS_LIBERA_GUIA"), "N");
		NNumber nretorno = NNumber.getNull();
		//MULTI-IDIOMA: MSG_0008 - Guia Autorizada.
		String msgGuiaAutorizada = ResourceManager.getString("guia.msg0008");
		

		ResultSet cmcResults = null;
		dtPrevExecucao_validate();

		if (isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N").equals("S")) {

			if (getGuiaElement() != null && getGuiaElement().getCdMatriculaResponsavel().isNull() && getGuiaElement().getCdPlanoPgtoCortesia().isNull() && getGuiaElement().getDsDestinoCortesia().isNull()) {
				getTask().getMv2000().msgAlert(toStr("Para emitir guia avulsa é necessário informar o nome do Beneficiário Intercâmbio/Eventual/Favorecido!"), toStr("W"), toBool(NBool.True));
			}
		}
		
			if (!getGuiaElement().getCdMensContrato().isNull() && getGuiaElement().getCdMensContrato() != null) {
				String sqlcmc = "SELECT CD_MENS_CONTRATO " + 
						" FROM DBAPS.MENS_CONTRATO MC " + 
						" WHERE MC.CD_MENS_CONTRATO = :GUIA_CD_MENS_CONTRATO " + 
						" AND MC.TP_QUITACAO = 'Q'";

				DataCursor cmc = new DataCursor(sqlcmc);
				cmc.addParameter("GUIA_CD_MENS_CONTRATO", getGuiaElement().getCdMensContrato());
				cmc.open();
				cmcResults = cmc.fetchInto();
				cmc.close();
			}

			if (getGuiaElement().getSnAvista().equals("S") && 
					!getGuiaElement().getCdMensContrato().isNull() && 
					getGuiaElement().getSnValidaRestCarencia().equals("N")) {

				if((getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_LIBERA_GUIA_SEM_PAGAMENTO") != null &&
						getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_LIBERA_GUIA_SEM_PAGAMENTO").equals("N"))) {
					getTask().getMv2000().msgAlert(toStr("É necessário pagar essa guia para que ela seja liberada! Código da Receita: "+getGuiaElement().getCdMensContrato()), toStr("W"), toBool(NBool.False));
				} else {
					getTask().getMv2000().msgAlert(toStr("Lembrete: A Guia já possui uma receita de código ["+getGuiaElement().getCdMensContrato()+"] associada. Favor lembrar de pagar no caixa."), toStr("W"), toBool(NBool.False));
				}


			} else {

				int rowCount = 0;

				NNumber ncont = NNumber.getNull();
				String sqlcitguiaerros = "SELECT count(1) " + 
						" FROM DBAPS.ITGUIA_ERROS IE " + 
						" WHERE IE.NR_GUIA = :GUIA_NR_GUIA ";
				DataCursor citguiaerros = new DataCursor(sqlcitguiaerros);
				try {

					TaskServices.commitTask(true);

					nretorno = this.getTask().getServices().fncAnalisarGuia(toNumber(getGuiaElement().getNrGuia()), toNumber(null), toStr("N"));

					ncont = toNumber(null);
					String sql1 = "DELETE FROM DBAPS.ITGUIA_ERROS " 
							+" WHERE  EXISTS(SELECT 1 " 
							+" FROM DBAPS.MOTIVO_GLOSA " 
							+" WHERE CD_MOTIVO = ITGUIA_ERROS.CD_MOTIVO AND SN_GLOSAR = 'N' ) AND NR_GUIA = :GUIA_NR_GUIA";
					DataCommand command1 = new DataCommand(sql1);

					command1.addParameter("GUIA_NR_GUIA", getGuiaElement().getNrGuia());
					rowCount = command1.execute();

					if (!toNumber(rowCount).equals(0)) {
						commitTask();
					}

					citguiaerros.addParameter("GUIA_NR_GUIA", getGuiaElement().getNrGuia());

					citguiaerros.open();
					ResultSet citguiaerrosResults = citguiaerros.fetchInto();
					if (citguiaerrosResults != null) {
						ncont = citguiaerrosResults.getNumber(0);
					}
					citguiaerros.close();
					//Correção: Raphael Baden - Migracao - SCS
					if (ncont.equals(new NNumber(0))) {
						if (nretorno.equals(-1)) {
							nretorno = new NNumber(0);
						}
					}
					//Correção: Raphael Baden - Migracao - SCS               
					if (isNull(ncont, 0).notEquals(0) && !nretorno.equals(1)) {
						nretorno = toNumber(-(1));
					} else if (isNull(ncont, 0).equals(0) && !getGuiaElement().getSnAvista().equals("S") && nretorno.equals(0)) {

						/**
						 * Verifica se a configuração para liberar automaticamente não está ativa.
						 */
						if(!"S".equals(snGuiaAutorizaAutomatico.toString())){

							if(getTask().getMv2000().msgAlertSn(NString.toStr("Análise Concluída. Não foram encontrado erros! Deseja autorizar esta guia?"), NString.toStr("W"), NString.toStr("Sim/Não")).toBoolean()){
								rowCount = this.getTask().getServices().autorizaGuia(getGuiaElement());
								nretorno = toNumber(0);
								if (!toNumber(rowCount).equals(0)) {
									TaskServices.commitTask(true);
									getTask().getMv2000().msgAlert(msgGuiaAutorizada, toStr("I"), toBool(NBool.False));
								}

							}

						} else {

							rowCount = this.getTask().getServices().autorizaGuia(getGuiaElement());

							nretorno = toNumber(0);

							if (!toNumber(rowCount).equals(0)) {
								TaskServices.commitTask(true);
							}
						}

					}
					setGlobal("NR_GUIA", getGuiaElement().getNrGuia());
					goBlock(toStr("GUIA"));
					BlockServices.setBlockWhereClause("GUIA", "NR_GUIA = " + toNumber(getGlobal("NR_GUIA")));
					executeQuery("GUIA");

					MessageServices.clearMessage();
					this.getTask().getServices().prcHabilitaBotoes(null, getGuiaElement());
					if (nretorno.equals(-(1))) {
						getTask().getMv2000().msgAlert(toStr("Análise da solicitação concluída com restrições!"), toStr("W"), toBool(NBool.False));
					} else if (nretorno.equals(0)) {
						if("S".equals(snGuiaAutorizaAutomatico.toString())){
							//MULTI-IDIOMA: MSG_0008 - Guia Autorizada.
							getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0008"), toStr("I"), toBool(NBool.False));
						}

					} else {

						if(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_LIBERA_GUIA_SEM_PAGAMENTO") != null
								&& getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_LIBERA_GUIA_SEM_PAGAMENTO").equals("S")) {
							this.getTask().getMv2000().msgAlert(toStr("Análise concluída/Guia Autorizada. Favor comparecer ao caixa para pagamento."), toStr("I"), toBool(NBool.False));
						} else {
							getTask().getMv2000().msgAlert(toStr("Análise concluída. A guia será autorizada automaticamente após pagamento no caixa."), toStr("I"), toBool(NBool.False));
						}					

					}
					
					//PLANO-6182
					if(snEnvioAutoSmsLiberaGuia.equals("S") && nretorno.equals(0) && getGuiaElement().getSnValidaRestCarencia().equals("S")) {
						try{
							((CgCtrlController)this.getTask().getFormController().getBlockController("CG$CTRL")).btn_envio_sms_click();
						}catch(Exception e){
							e.printStackTrace();
						}
					}
					//#PLANO-6182
					
					TaskServices.commitTask(false);
					setGlobal("NR_GUIA", getGuiaElement().getNrGuia());
					if (Services.exist("ITGUIA", "NR_GUIA = ".concat(toNumber(getGlobal("NR_GUIA")).toString()), false)) {
						BlockServices.setBlockWhereClause("ITGUIA", "NR_GUIA = " + toNumber(getGlobal("NR_GUIA")));
						goBlock(toStr("ITGUIA"));
						executeQuery();
						BlockServices.setBlockWhereClause("ITGUIA","");
					}
					goBlock(toStr("GUIA"));
					guia_recordChange();
				} finally {
					citguiaerros.close();
				}
				
				NString dsErro = Services.getDescricao("DS_ERRO", "GUIA", "CD_MOTIVO IN (9622) AND NR_GUIA = " + getGuiaElement().getNrGuia(), false);
				if (!dsErro.isNull()) {
					getTask().getMv2000().msgAlert(NString.toStr("")
							.append("Atenção!")
							.append(Lib.chr(10))
							.append("Motivo..: ").append(dsErro).toString(),
							"W", /*W = Atenção, I = Informação, E = Erro */
							NBool.False/*bloquear/travar?*/);
				}
			}
	}

	@SuppressWarnings("rawtypes")
	@ActionTrigger(action = "btnBeneficiarios_click", item = "BTN_BENEFICIARIOS")
	public void btnBeneficiarios_click() {

		GuiaAdapter guiaElement = this.getGuiaElement();

		if (!guiaElement.getCdMatricula().isNull()) {
			
			NString tpBeneficiario = this.getTask().getServices().fncRetornaTipoBeneficiario( guiaElement.getCdMatricula(), guiaElement.getCdMatAlternativa()); 

			if(tpBeneficiario.equals("EV") || tpBeneficiario.equals("ID") || tpBeneficiario.equals("RC")){
				getTask().getMv2000().msgAlert(toStr("O número da matrícula deve ser informado."), toStr("E"), toBool(NBool.True));
			}
			
			Hashtable plId = null;
			plId = getParameterList("matricula");
			if ((plId == null)) {
				plId = createParameterList("matricula");
			} else {
				deleteParameter("matricula", "cd_matricula");
				deleteParameter("matricula", "cd_unimed_executora");
			}
			
			addParameter(plId, "cd_matricula", guiaElement.getCdMatricula());
			
			if(!guiaElement.getCdUnimedExecutora().isNull()){
				addParameter(plId, "cd_unimed_executora", guiaElement.getCdUnimedExecutora());
			}
			callTask("C_DADOS_COMPL_BENEF", TaskServices.NO_HIDE, TaskServices.NO_REPLACE, TaskServices.NO_QUERY_ONLY, plId);
		} else {
			getTask().getMv2000().msgAlert(toStr("O número da matrícula deve ser informado."), toStr("E"), toBool(NBool.True));
		}
	}

	@SuppressWarnings("unused")
	@ActionTrigger(action = "btnCancelar_click", item = "BTN_CANCELAR")
	public void btnCancelar_click() {

		// F2N_WARNING : Caution, the variable may be null.
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		// Validar caso, a guia possuir contas médicas associadas. Não permitir o seu cancelamento. PDA 689823.
		String sqlCancelamentoGuia = "SELECT 1 FROM DBAPS.V_CTAS_MEDICAS WHERE NR_GUIA = :P_NR_GUIA_2";
		DataCursor cCancelamentoGuia = new DataCursor(sqlCancelamentoGuia);
		cCancelamentoGuia.addParameter("P_NR_GUIA_2", guiaElement.getNrGuia());
		ResultSet cCancelamentoGuiaResults = cCancelamentoGuia.fetchInto();
		try {
			cCancelamentoGuia.open();
			if (cCancelamentoGuia.found()) {
				//MULTI-IDIOMA: MSG_0039 - Esta guia possui contas médicas associadas e não é permitido seu cancelamento. 
				String msg = ResourceManager.getString("guia.msg0039");
				this.getTask().getMv2000().msgAlert(msg, "E", NBool.True);
			}
		} catch (DataLayerException e) {
			this.getTask().getMv2000().msgAlert("Atenção! Não foi possível validar o cancelamento da guia, por favor, contactar o suporte. Erro: " + e, "E", NBool.True);
		} finally {
			cCancelamentoGuia.close();
			sqlCancelamentoGuia = null;
			cCancelamentoGuia = null;
			cCancelamentoGuiaResults = null;
		}
 

		String sqlCancelamento = "SELECT To_Char(mens_contrato.dt_emissao,'MM') " + "FROM DBAPS.GUIA, dbaps.mens_contrato " + "WHERE guia.cd_mens_contrato = mens_contrato.cd_mens_contrato " + "AND NR_GUIA = :P_NR_GUIA ";

		DataCursor cCancelamento = new DataCursor(sqlCancelamento);
		cCancelamento.addParameter("P_NR_GUIA", guiaElement.getNrGuia());

		cCancelamento.open();
		ResultSet cCancelamentoResults = cCancelamento.fetchInto();
		String tpCancelamento = "";
		if (cCancelamentoResults != null && cCancelamentoResults.getNumber(0).isNotNull()) {
			Date data = new Date();
			SimpleDateFormat formatador = new SimpleDateFormat("MM");

			BigDecimal mesAtual = new BigDecimal(formatador.format(data).toString());

			if (mesAtual.equals(cCancelamentoResults.getNumber(0))) {
				tpCancelamento = "%";
			} else {
				tpCancelamento = "C";
			}
		}


		setGlobal("TP_CANCELAMENTO", tpCancelamento);

		getFormModel().getCgCtrl().setDspDsLiberacao(toStr("Negativa/Cancelamento da Guia"));
		getFormModel().getCgCtrl().setDsSenhaAutorizacaoSemBase(toStr(null));
		getFormModel().getCgCtrl().setCdAutorizadorOpe(guiaElement.getCdAutorizador());
		getFormModel().getCgCtrl().setDspNmAutorizadorOpe(guiaElement.getDspNmAutorizador());
		
		ResultSet rs = GuiaServices.getAutorizadorLogado();
		
		if(rs != null){
			getFormModel().getCgCtrl().setCdAutorizadorOpe(rs.getNumber("CD_AUTORIZADOR"));
			getFormModel().getCgCtrl().setDspNmAutorizadorOpe(rs.getStr("NM_AUTORIZADOR"));	
		}
		
		getFormModel().getCgCtrl().setSnCancelaAutorizacao(toStr("N"));
		getFormModel().getCgCtrl().setCdMotCancelamento(toNumber(null));
		getFormModel().getCgCtrl().setDspDsMotCancelamento(toStr(null));
		getFormModel().getCgCtrl().setTpStatus(guiaElement.getTpStatus());
		getFormModel().getCgCtrl().setCdMotivoAutorizacao(getGuiaElement().getCdMotivoAutorizacao());
		getFormModel().getCgCtrl().setDspDsMotivoAutorizacao(getGuiaElement().getDspDsMotivoAutorizacao());
		getFormModel().getCgCtrl().setCdMotivoAutorizacao(guiaElement.getCdMotivoAutorizacao());
		getFormModel().getCgCtrl().setDspDsMotivoAutorizacao(guiaElement.getDspDsMotivoAutorizacao());

		this.getFormModel().setParam("CHAMA_AUTORIZ", toStr("C"));		
		this.getTask().getServices().configuraSolicitacaoSenha(NString.toStr("C"));
	}

	@ActionTrigger(action = "tpStatus_PostChange", item = "TP_STATUS")
	public void tpStatus_PostChange() {

		// F2N_WARNING : Caution, the variable may be null.
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		if (guiaElement.getTpStatus().equals(0)) {
			guiaElement.setDspTpStatus(toStr("Nenhum"));
		} else if (guiaElement.getTpStatus().equals(1)) {
			guiaElement.setDspTpStatus(toStr("Em Análise"));
		} else {
			guiaElement.setDspTpStatus(toStr("Analisado"));
		}
	}

	@ActionTrigger(action = "btnTpStatus_click", item = "BTN_TP_STATUS")
	public void btnTpStatus_click() {

		// F2N_WARNING : Caution, the variable may be null.
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		getFormModel().getCgCtrl().setDspDsLiberacao(NString.toStr(ResourceManager.getString("guia.msg0142")));
		getFormModel().getCgCtrl().setDsSenhaAutorizacaoSemBase(toStr(null));
		getFormModel().getCgCtrl().setCdAutorizadorOpe(guiaElement.getCdAutorizador());
		getFormModel().getCgCtrl().setDspNmAutorizadorOpe(guiaElement.getDspNmAutorizador());
		
		ResultSet rs = GuiaServices.getAutorizadorLogado();
		
		if(rs != null){
			getFormModel().getCgCtrl().setCdAutorizadorOpe(rs.getNumber("CD_AUTORIZADOR"));
			getFormModel().getCgCtrl().setDspNmAutorizadorOpe(rs.getStr("NM_AUTORIZADOR"));	
		}
		
		getFormModel().getCgCtrl().setSnCancelaAutorizacao(toStr("N"));
		getFormModel().getCgCtrl().setCdMotCancelamento(toNumber(null));
		getFormModel().getCgCtrl().setDspDsMotCancelamento(toStr(null));
		getFormModel().getCgCtrl().setTpStatus(guiaElement.getTpStatus());
		this.getFormModel().setParam("CHAMA_AUTORIZ", toStr("S"));
		this.getTask().getServices().configuraSolicitacaoSenha(NString.toStr("S"));
		goItem(toStr("CG$CTRL.TP_STATUS"));
	}

	@ValidationTrigger(item = "TP_SEXO")
	public void tpSexo_validate() {
		if (this.getFormModel().getParam("PSN_CORTESIA", NString.class).equals("S") && getGuiaElement().getTpSexo().isNull()) {
			getTask().getMv2000().msgAlert(toStr("O sexo do usuário deve ser preenchido"), toStr("E"), toBool(NBool.True));
		}
	}

	@ValidationTrigger(item = "CD_CORTESIA")
	public void cdCortesia_validate() {

		// F2N_WARNING : Caution, the variable may be null.
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		guiaElement.setDspDsCortesia(getTask().getMPkgMvsCortesia().getMPkgMvsCortesia().fRetornaDescricao(guiaElement.getCdCortesia(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.True), toBool(NBool.True)));
	}

	@ValidationTrigger(item = "CD_MATRICULA_RESPONSAVEL")
	public void cdMatriculaResponsavel_validate() {

		cdMatriculaResponsavel_validate(true);
	}

	public void cdMatriculaResponsavel_validate(boolean validate) {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		Ref<NString> ptp_grupo_franquia_ref = new Ref<NString>(NString.getNull());
		
		if (guiaElement != null && !guiaElement.getCdMatriculaResponsavel().isNull()) {
			String sqlcUsuario = "select usu.nm_segurado, usu.cd_plano, usu.cd_empresa, " + "p.ds_plano, emp.ds_empresa, p.cd_tip_acomodacao " + "from dbaps.usuario usu, dbaps.plano p, dbaps.empresa emp " + "where cd_matricula = :P_CD_MATRICULA " + "AND usu.cd_plano = p.cd_plano(+) " + "AND usu.cd_empresa = emp.cd_empresa(+) " + "AND usu.sn_ativo = 'S'";

			DataCursor cUsuario = new DataCursor(sqlcUsuario);
			cUsuario.addParameter("P_CD_MATRICULA", guiaElement.getCdMatriculaResponsavel());
			cUsuario.open();
			ResultSet cUsuarioResults = cUsuario.fetchInto();
			if (cUsuarioResults != null) {
				guiaElement.setNmMatriculaResponsavel(cUsuarioResults.getStr(0));
				if (validate) {
					guiaElement.setCdMatricula(guiaElement.getCdMatriculaResponsavel());
					if (!cUsuarioResults.getNumber(1).isNull()) {
						guiaElement.setCdPlanoPgtoCortesia(cUsuarioResults.getNumber(1));
					} else {
						guiaElement.setCdPlanoPgtoCortesia(NNumber.getNull());
					}

					if (!cUsuarioResults.getNumber(2).isNull()) {
						guiaElement.setCdEmpresaResponsavel(cUsuarioResults.getNumber(2));
					} else {
						guiaElement.setCdEmpresaResponsavel(NNumber.getNull());
					}

					if (!cUsuarioResults.getNumber("cd_plano").isNull()) {
						guiaElement.setDspCdPlano(cUsuarioResults.getNumber("cd_plano"));
					} else {
						guiaElement.setDspCdPlano(NNumber.getNull());
					}
					
					guiaElement.setCdGrupoFranquia(StoredProcedures.fncRetornaGrupoFranquia(guiaElement.getCdMatricula(), ptp_grupo_franquia_ref));
					this.getTask().getServices().prcGrupoFranquia(guiaElement, toBool(NBool.False), toStr("V"));
				}
				guiaElement.setDspNmSegurado(cUsuarioResults.getStr(0));
				if (!cUsuarioResults.getStr(3).isNull()) {
					guiaElement.setDspDsPlanoCortesia(cUsuarioResults.getStr(3));
				} else {
					guiaElement.setDspDsPlanoCortesia(NString.getNull());
				}

				if (!cUsuarioResults.getStr(4).isNull()) {
					guiaElement.setNmEmpresaResponsavel(cUsuarioResults.getStr(4));
				} else {
					guiaElement.setNmEmpresaResponsavel(NString.getNull());
				}

				if (isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N").equals("S") && guiaElement.getCdTipoAtendimento().isNull()) {
					goItem("GUIA.CD_TIPO_ATENDIMENTO");
				}
			} else {
				guiaElement.setNmMatriculaResponsavel(NString.getNull());
				if (validate) {
					guiaElement.setCdMatricula(NNumber.getNull());
					getTask().getMv2000().msgAlert(toStr("Matricula do responsável não cadastrada ou estar inativo no sistema!"), toStr("E"), toBool(NBool.True));
				}
				guiaElement.setDspNmSegurado(NString.getNull());

			}
			cUsuario.close();
			setItemEnabled("GUIA.CD_PLANO_PGTO_CORTESIA", false);
			setItemEnabled("GUIA.CD_EMPRESA_RESPONSAVEL", false);
		} else {
			setItemEnabled("GUIA.CD_PLANO_PGTO_CORTESIA", true);
			guiaElement.setNmMatriculaResponsavel(NString.getNull());
			setItemEnabled("GUIA.CD_EMPRESA_RESPONSAVEL", true);
			if (validate) {
				guiaElement.setCdPlanoPgtoCortesia(NNumber.getNull());
				guiaElement.setDspDsPlanoCortesia(NString.getNull());
				guiaElement.setCdEmpresaResponsavel(NNumber.getNull());
				guiaElement.setNmEmpresaResponsavel(NString.getNull());
			}

			if (validate && isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N").equals("S")) {
				guiaElement.setCdMatricula(NNumber.getNull());
				guiaElement.setDspNmSegurado(NString.getNull());
			}
		}
	}

	@ValidationTrigger(item = "CD_EMPRESA_RESPONSAVEL")
	public void cdEmpresaResponsavel_validate() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (guiaElement != null && guiaElement.getCdEmpresaResponsavel().isNotNull()) {
			String sqlcEmpresa = "select ds_empresa " + "from dbaps.empresa " + "where sn_ativo = 'S' " + " and cd_empresa = :P_CD_EMPRESA ";

			DataCursor cEmpresa = new DataCursor(sqlcEmpresa);
			// Setting query parameters
			cEmpresa.addParameter("P_CD_EMPRESA", guiaElement.getCdEmpresaResponsavel());
			// F2N_WARNING : Make sure that the method "Close" is being called
			// over the variable citguiaerros.
			cEmpresa.open();
			ResultSet cEmpresaResults = cEmpresa.fetchInto();
			if (cEmpresaResults != null) {
				guiaElement.setNmEmpresaResponsavel(cEmpresaResults.getStr(0));
			} else {
				getTask().getMv2000().msgAlert(toStr("Empresa inválida"), toStr("E"), toBool(NBool.True));
			}
			cEmpresa.close();
			setItemEnabled("GUIA.CD_MATRICULA_RESPONSAVEL", false);
		} else {
			guiaElement.setNmEmpresaResponsavel(new NString(""));
			setItemEnabled("GUIA.CD_MATRICULA_RESPONSAVEL", true);
		}

		if (isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N").equals("S") && guiaElement.getCdTipoAtendimento().isNull()) {
			goItem("GUIA.CD_TIPO_ATENDIMENTO");
		}
	}

	@ValidationTrigger(item = "CD_PLANO_PGTO_CORTESIA")
	public void cdPlanoPgtoCortesia_validate() {

		// F2N_WARNING : Caution, the variable may be null.
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (guiaElement != null && !guiaElement.getCdPlanoPgtoCortesia().isNull() && !guiaElement.getCdMatriculaResponsavel().isNull()) {
			String sqlcPlano = "SELECT cd_matricula FROM dbaps.usuario " + "WHERE cd_plano = :P_CD_PLANO " + "AND cd_matricula = :P_CD_MATRICULA";
			DataCursor dcPlano = new DataCursor(sqlcPlano);
			dcPlano.addParameter("P_CD_PLANO", guiaElement.getCdPlanoPgtoCortesia());
			dcPlano.addParameter("P_CD_MATRICULA", guiaElement.getCdMatriculaResponsavel());

			try {
				dcPlano.open();
				if (!dcPlano.found()) {
					getTask().getMv2000().chamaMensagem(toStr("Atenção"), toStr("Erro...: Beneficiário ou Plano inválido.").append(chr(10)).append("Motivo: O beneficiário não possui a esse plano ou esse não é um plano válido.").append(chr(10)).append("Ação...: Verifique o plano informado."), toBool(NBool.True));
				}
			} finally {
				dcPlano.close();
			}
		}
		if (guiaElement.getDspDsPlanoCortesia().isNull()) {
			guiaElement.setDspDsPlanoCortesia(getTask().getMPkgMvsPlano().getMPkgMvsPlano().fRetornaDescricao(guiaElement.getCdPlanoPgtoCortesia(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.True), toBool(NBool.True)));
		}
	}

	@ActionTrigger(item = "BTN_ENVIAR_GUIA_EMAIL", action = "btn_enviar_guia_email_click")
	public void btn_enviar_guia_email_click() {

		ViewServices.showView("CNV_EMAIL");
		ItemServices.goItem("ENVIAR_EMAIL.DSP_EMAIL_PRESTADOR");

		//seta os emails dos checkboxes
		this.getTask().getServices().setEmails();

		GuiaAdapter guiaElement = (GuiaAdapter) getFormModel().getGuia().getRowAdapter(true);
		guiaElement.setDsUrlEmailGuia(
				// toStr("http://simulacao.mv.proasa.org.br/mvautorizadorguias/ServletEmailGuia")
				toStr(this.getFormModel().getParam("P_DS_SERVIDOR_EMAIL", NString.class)).append("?nrGuia=").append(guiaElement.getNrGuia()).append("&tpAtendimento=").append(guiaElement.getCdTipoAtendimento()).append("&empresa=").append(PkgMv2000.leEmpresa()));

	}

	@SuppressWarnings("rawtypes")
	@ActionTrigger(item = "BTN_NEGATIVA_GUIA", action = "btn_negativa_guia_click")
	public void btn_negativa_guia_click() {

		GuiaAdapter guiaElement = (GuiaAdapter) getFormModel().getGuia().getRowAdapter(true);

		if (!guiaElement.getNrGuia().isNull()) {
			Hashtable plId = createParameterList("PL_GUIA_NEGATIVA");
			addParameter(plId, "P_NR_GUIA", toChar(guiaElement.getNrGuia()));
			callTask("M_GUIA_NEGATIVA", TaskServices.HIDE, TaskServices.NO_REPLACE, TaskServices.NO_QUERY_ONLY, plId);
		} else {
			getTask().getMv2000().msgAlert("Informe uma guia! ", "E", NBool.True);
		}
	}

	/**
	 * Evento RecrodCreated adicionado para atualizar botões ao clicar em
	 * adicionar nova guia
	 * 
	 * @author Dellanio Alencar <francisco.alencar@mv.com.br>
	 * @since 19/04/2013
	 * @param eventObject
	 * @return void
	 */
	@RecordCreated
	public void guia_RecordCreated(EventObject eventObject) {
		NString snCortesia = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
		NString snOperadoraUnimed = Services.getSnOperadoraUnimed();
		GuiaAdapter guiaElement = (GuiaAdapter) getFormModel().getGuia().getRowAdapter(true);

		if (guiaElement != null && !guiaElement.getNrGuia().isNull()) {//Habilitar o botao de upload anexo apenas se houver guia salva.
			ItemServices.setItemEnabled("GUIA_ANEXO.BTN_UPLOAD_ANEXO", true);
		} else {
			ItemServices.setItemEnabled("GUIA_ANEXO.BTN_UPLOAD_ANEXO", false);
		}

		// desabilita botão de enviar guia por email
		ItemServices.setItemEnabled("GUIA.BTN_ENVIAR_GUIA_EMAIL", false);
		
		ItemServices.setItemEnabled("CG$CTRL.BTN_ENVIO_SMS", false);

		
		if (guiaElement != null && guiaElement.getCdAutorizador().isNull()) {
			this.getTask().getServices().prcGetAutorizador(guiaElement);
		}
		
		if (snCortesia.equals("S")) {
			guiaElement.setTpOrigem(NString.toStr("AV"));
			guiaElement.setDspTpOrigem(toStr("Avulsa/Intercâmbio"));
			if(snOperadoraUnimed.equals("S")){
				guiaElement.setTpOrigem(NString.toStr("PTU"));
				guiaElement.setDspTpOrigem(toStr("PTU"));

				if (guiaElement.getCdCortesia().isNull()) {				
					guiaElement.setCdCortesia(NNumber.toNumber(9000));
				}
				cdCortesia_validate();	
			}
		}
		if(snOperadoraUnimed.equals("S")){
			NNumber cdIndicadorAcidente = NNumber.toNumber(Services.getDescricao("CD_INDICADOR_ACIDENTE", "INDICADOR_ACIDENTE", "CD_PTU = 9", false));
			if (guiaElement.getCdIndicadorAcidente().isNull()) {
				guiaElement.setCdIndicadorAcidente(cdIndicadorAcidente);
			}
			
		}
		
		dtEmissao_validate();
		dtVencimento_validate();
		dtPrevExecucao_itemIn();
		dtPrevExecucao_validate();
		dt_prev_execucao_itemOut();
		
	}

	@ValidationTrigger(item = "CD_PRESTADOR_ENDERECO")
	public void cd_prestador_endereco_validation() {

		GuiaAdapter guiaElement = this.getGuiaElement();

		this.getTask().getServices().prestadorEndereco(guiaElement);
		cdPrestadorEnderecoValidatelimpa(guiaElement);
	}

	/**
	 * Limpa os dados influenciados pelo campo CD_ESPECIALIDADE
	 * 
	 * @OP 5857
	 * @author Diego Nobre
	 * @since 23/04/2013
	 * @param guiaElement
	 */
	public void cdEspecialidadeValidatelimpa(GuiaAdapter guiaElement) {

		if (!(!guiaElement.getNrGuiaTem().isNull() && !guiaElement.getCdTipoAtendimento().isNull() && guiaElement.getDspTpGuia().equals("H"))) {
			guiaElement.setCdPrestadorExecutor(NNumber.getNull());
			guiaElement.setDspNmExecutor(NString.getNull());
			guiaElement.setDspCdPrestadorExecutorInterno(NString.getNull());

			guiaElement.setCdPrestadorEndereco(NNumber.getNull());
			guiaElement.setDsEndereco(NString.getNull());

			guiaElement.setCdPrestadorExecutorPf(NNumber.getNull());
			guiaElement.setNmPrestadorExecutorPf(NString.getNull());
			guiaElement.setDspCdPrestadorExecutorPfInterno(NString.getNull());
		}
	}

	/**
	 * Limpa os dados influenciados pelo campo CD_PRESTADOR_EXECUTOR
	 * 
	 * @OP 5857
	 * @author Diego Nobre
	 * @since 23/04/2013
	 * @param guiaElement
	 */
	public void cdPrestadorExecutorValidatelimpa(GuiaAdapter guiaElement) {

		if (!(!guiaElement.getNrGuiaTem().isNull() && !guiaElement.getCdTipoAtendimento().isNull() && guiaElement.getDspTpGuia().equals("H"))) {
			guiaElement.setCdPrestadorEndereco(NNumber.getNull());
			guiaElement.setDsEndereco(NString.getNull());

			guiaElement.setCdPrestadorExecutorPf(NNumber.getNull());
			guiaElement.setNmPrestadorExecutorPf(NString.getNull());
			guiaElement.setDspCdPrestadorExecutorPfInterno(NString.getNull());
		}
	}

	/**
	 * Limpa os dados influenciados pelo campo CD_PRESTADOR_ENDERECO
	 * 
	 * @OP 5857
	 * @author Diego Nobre
	 * @since 23/04/2013
	 * @param guiaElement
	 */
	public void cdPrestadorEnderecoValidatelimpa(GuiaAdapter guiaElement) {

		guiaElement.setCdPrestadorExecutorPf(NNumber.getNull());
		guiaElement.setNmPrestadorExecutorPf(NString.getNull());
		guiaElement.setDspCdPrestadorExecutorPfInterno(NString.getNull());
		
	}

	@AfterRowInsert
	public void guia_AfterRowInsert(RowAdapterEvent rowAdapterEvent) {

		GuiaAdapter guiaElement = (GuiaAdapter) rowAdapterEvent.getRow();

		if (guiaElement != null && !guiaElement.getNrGuia().isNull()) {//Habilitar o botao de upload anexo apenas se houver guia salva.
			ItemServices.setItemEnabled("GUIA_ANEXO.BTN_UPLOAD_ANEXO", true);
		} else {
			ItemServices.setItemEnabled("GUIA_ANEXO.BTN_UPLOAD_ANEXO", false);
		}

		if (this.getFormModel().getParam("SN_FORMA_PGTO_ORIGINAL") != null && !toStr(this.getFormModel().getParam("SN_FORMA_PGTO_ORIGINAL")).equals(guiaElement.getSnAvista())) {

			String sql1 = "INSERT INTO DBAPS.LOG_AUTORIZA " + 
					"(NR_GUIA, DS_FUNCIONALIDADE, NM_USUARIO_ORACLE, DT_ACAO, CD_AUTORIZADOR, CD_LOG_AUTORIZA)" + 
					"VALUES (:GUIA_NR_GUIA, :P_CMSG, USER, SYSDATE, :CD_AUTORIZADOR_OPE, SEQ_LOG_AUTORIZA.NEXTVAL)";

			DataCommand command1 = new DataCommand(sql1);

			command1.addParameter("GUIA_NR_GUIA", guiaElement.getNrGuia());
			command1.addParameter("P_CMSG", "ALTERAÇÃO DO MODO DE PAGAMENTO - À VISTA (S/N)");
			command1.addParameter("CD_AUTORIZADOR_OPE", guiaElement.getCdAutorizador());
			command1.execute();

			TaskServices.executeQuery("LOG_AUTORIZA");

		}
	}

	@QueryComplete
	public void guia_QueryComplete(EventObject eventObject) {
		 
	}

	@ValidationTrigger(item = "CD_ESTADIAMENTO")
	public void cd_estadiamento_validation() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (guiaElement != null && !guiaElement.getCdEstadiamento().isNull()) {
			guiaElement.setDsEstadiamento(this.getTask().getServices().getDescricaoEstadiamento(guiaElement.getCdEstadiamento(), true));
		}
	}

	@ValidationTrigger(item = "CD_QUIMIOTERAPIA")
	public void cd_quimioterapia_validation() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (guiaElement != null && !guiaElement.getCdQuimioterapia().isNull()) {
			guiaElement.setDspQuimioterapia(this.getTask().getServices().getDescricaoQuimioterapia(guiaElement.getCdQuimioterapia(), true));
		}
	}

	@ValidationTrigger(item = "CD_FINALIDADE")
	public void cd_finalidade_validation() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (guiaElement != null && !guiaElement.getCdFinalidade().isNull()) {
			guiaElement.setDsFinalidade(this.getTask().getServices().getDescricaoFinalidade(guiaElement.getCdFinalidade(), true));
		}
	}

	@ValidationTrigger(item = "CD_DIAGNOSTICO_IMAGEM")
	public void cd_diagnostico_imagem_validation() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (guiaElement != null && !guiaElement.getCdDiagnosticoImagem().isNull()) {
			guiaElement.setDsDiagnosticoImagem(this.getTask().getServices().getDescricaoDiagnostico(guiaElement.getCdDiagnosticoImagem(), true));
		}
	}

	@ViewTrigger
	@ActionTrigger(item = "CD_PRESTADOR", action = "cd_prestador_itemOut", function=KeyFunction.ITEM_OUT)
	public void cd_prestador_itemOut() {

		setItemEnabled("GUIA.CD_ESPECIALIDADE_SOLICITANTE", true);
	}

	@ValidationTrigger(item = "CD_TIPO_ATENDIMENTO_TISS")
	public void cd_tipo_atendimento_tiss_validation() {

		GuiaAdapter guia = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (!guia.getCdTipoAtendimento().isNull() && !guia.getCdTipoAtendimentoTiss().isNull()) {
			if (guia.getCdTipoAtendimento().equals(toNumber(2)) && guia.getCdTipoAtendimentoTiss().equals(toNumber(3))) {
				ItemServices.setItemEnabled("GUIA.SN_AVISTA", BlockServices.getCurrentRecord("GUIA").toInt32(), true);
				ItemServices.setItemEnabled("GUIA.CD_TIPO_CONSULTA", BlockServices.getCurrentRecord("GUIA").toInt32(), true);
			}
		}
	}

	@BeforeRowUpdate
	public void guia_BeforeRowUpdate(RowAdapterEvent rowAdapterEvent) {
		
		GuiaAdapter guiaElement = (GuiaAdapter)rowAdapterEvent.getRow();
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		
		if (guiaElement.getDspTpGuia().equals("S") || guiaElement.getDspTpGuia().equals("I")) {// - SP/SADT || Internação
			if(guiaElement.getTpCaraterSolicInter().isNull()){
				ItemServices.goItem("GUIA.TP_CARATER_SOLIC_INTER");
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0116"), "W", NBool.True);
			}
		}
		
		if (guiaElement.getDspTpGuia().equals("C") && !getGuiaElement().getTpOrigem().equals("PTU")) { // Consulta
			if (guiaElement.getCdEspecialidade().isNull()) {
				ItemServices.goItem("GUIA.CD_ESPECIALIDADE");
				//MULTI-IDIOMA: MSG_0029 - Não é permitido salvar guia de consulta sem Especialidade.
				String msg = ResourceManager.getString("guia.msg0029");
				getTask().getMv2000().msgAlert(msg.toString(), "W", NBool.True);
			}
		}
				
		if (snOperadoraUnimed.equals("S")) {
			
			if (getGuiaElement().getCdTipoAtendimentoTiss().isNull() && getGuiaElement().getDspTpGuia().equals("S") && !Lib.isNull(this.getFormModel().getParam("CHAMA_AUTORIZ"), "X").equals("C") && getGuiaElement().getTpFluxoPtuWs().equals("CLIENT")   ) {
				
				//MULTI-IDIOMA: MSG_0027 - Informe o Tipo de Atendimento na aba 'Dados Complementares'.
				ItemServices.goItem("GUIA.CD_TIPO_ATENDIMENTO_TISS");
				String msg = ResourceManager.getString("guia.msg0027_2");
				getTask().getMv2000().msgAlert(msg, "W", NBool.True);
			}
			
		}
		
		if(guiaElement.getDspSnPrestador().equals("S") && ( !getGuiaElement().getTpFluxoPtuWs().equals("SERVER") && !getGuiaElement().getTpOrigem().equals("PTU") ) ){
			
			if(guiaElement.getCdPrestador().isNull() && guiaElement.getNmPrestador().isNull()){
				ItemServices.goItem("GUIA.CD_PRESTADOR");
				//MULTI-IDIOMA: MSG_0061 - Não é permitido salvar guia sem Contratado Solicitante
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0061"), "W", NBool.True);
			}
		}
		
		if ((guiaElement.getCdAutorizador().equals(0) || guiaElement.getCdAutorizador().isNull()) && guiaElement.getSnValidaRestCarencia().equals("N")) {
			NString cdAutorizador = Services.getDescricao("A.CD_AUTORIZADOR", "AUTORIZADOR A, DBAPS.ME_AUTORIZADOR MA ", "A.CD_AUTORIZADOR = MA.CD_AUTORIZADOR AND MA.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA  AND A.CD_USUARIO = '"+TaskServices.getUser()+"'", false);
			if (!cdAutorizador.isNull()) {
				guiaElement.setCdAutorizador(NNumber.toNumber(cdAutorizador));
			}
		}
		if( !getGuiaElement().getTpOrigem().equals("PTU") ){
			this.getTask().getServices().verificaObrigatoriedadePrestadorExecutante();
		}
		
		this.getTask().getServices().setDtAltaInternacao(guiaElement.getNrGuia(), this.getFormModel().getCgCtrl().getDspDtAltaInternacao());
		
		cd_programa_atendimento_validation();
		this.getTask().getServices().chkObrigatoriosOdontologia(guiaElement);
		this.getTask().getServices().insertOcorrenciaOdontologia();
		if (guiaElement.getCdPrestadorEndereco().isNull()) {			
			this.getTask().getServices().chkChavesConfiguracaoGlobal();
		}
		this.getTask().getServices().isTipoConsultaObrigatorio(guiaElement);
		this.getTask().getServices().chkDsDiagnostico(guiaElement);
		this.getTask().getServices().chkIndicadorAcidente(guiaElement);
		validarCamposObrigatoriosProfissionalExecutante();
		validarCamposObrigatoriosAbaDadosComplementares();
		this.getTask().getServices().prestadorExecutor(guiaElement);
	}

	@ActionTrigger(item = "BTN_ALERTA", action = "btn_alerta_click")
	public void btn_alerta_click() {

		HashMap<String, String> param = new HashMap<String, String>();

		String prestadores = "";
		String matriculas = "";
		String carteiras = "";

		if(!getGuiaElement().getCdMatricula().isNull()){
			matriculas = getGuiaElement().getCdMatricula().toString();
		}

		if(!getGuiaElement().getCdPrestadorExecutor().isNull()){
			prestadores = prestadores + getGuiaElement().getCdPrestadorExecutor() + ",";
		}

		if(!getGuiaElement().getCdPrestadorExecutorPf().isNull()){
			prestadores = prestadores + getGuiaElement().getCdPrestadorExecutorPf() + ",";
		}
		 
		if (!getGuiaElement().getCdMatAlternativa().isNull()) {
			carteiras = getGuiaElement().getCdMatAlternativa().toString();
		}

		param.put("PRESTADORES", prestadores);
		param.put("MATRICULAS", matriculas);
		param.put("CARTEIRA", carteiras);

		Alerta.exibeAlerta(param);

	}

	@ValidationTrigger(item = "CD_ATI_MED")
	public void cd_ati_med_validation() {

		if(!getGuiaElement().getCdAtiMed().isNull()){

			NString dsAtiMed = Services.getDescricao("DS_ATI_MED", "ATI_MED", "CD_ATI_MED = " + getGuiaElement().getCdAtiMed(), false);

			if(!dsAtiMed.isNull()){
				getGuiaElement().setDspDsAtiMed(dsAtiMed);
			}else{
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Operação inválida!")
						.append(Lib.chr(10))
						.append("Motivo..: Esta atividade médica não existe.")
						.append(Lib.chr(10))
						.append("Ação....: Informe outra atividade médica.").toString(),
						"W", /*W = Atenção, I = Informação, E = Erro */
						NBool.True /*bloquear/travar?*/);
			}

		}else{
			getGuiaElement().setDspDsAtiMed(NString.getNull());
		}

	}

	@ActionTrigger(item = "BTN_LEITOR_MAGNETO", action = "btn_leitor_magneto_click")
	public void btn_leitor_magneto_click() {
		this.getTask().getServices().leitorMagnetico();
	}

	@ValidationTrigger(item = "CD_ESPECIALIDADE_SOLICITANTE")
	public void cd_especialidade_solicitante_validation() {
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (!guiaElement.getCdEspecialidadeSolicitante().isNull()){
			guiaElement.setDspEspecialidadeSolicitante(getTask().getServices().getDescricaoEspecialidadePrestador(guiaElement.getCdEspecialidadeSolicitante(), isNull(guiaElement.getCdPrestadorSolicitante(), guiaElement.getCdPrestador())));		
			
			if (guiaElement.getDspEspecialidadeSolicitante().isNull()){
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0103", this.getGuiaElement().getCdEspecialidadeSolicitante()), "E", NBool.True);
			}
		}else{
			guiaElement.setDspEspecialidadeSolicitante(NString.getNull());
		}
	}

	@ValidationTrigger(item = "CD_MOTIVO_AUTORIZACAO")
	public void cd_motivo_autorizacao_validation() {
		this.getTask().getServices().getMotivoAutorizacao(true);
	}

	@ValidationTrigger(item = "CD_MAT_ALTERNATIVA")
	public void cd_mat_alternativa_validation() {
		ItemServices.setItemIsValid("GUIA.CD_MATRICULA", true);
		if (!getGuiaElement().getCdMatAlternativa().isNull()) {
			NString cdMatricula = Services.getDescricao("CD_MATRICULA", "USUARIO", "CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA AND CD_MAT_ALTERNATIVA = '" + getGuiaElement().getCdMatAlternativa()+"'", true);
			if (cdMatricula.isNull()) {
					getTask().getMv2000().msgAlert(NString.toStr("")
							.append("Operação inválida!")
							.append(Lib.chr(10))
							.append("Motivo..: Usuário não encontrato.")
							.append(Lib.chr(10))
							.append("Ação....: Verifique se a Carteira/Mat.Alternativa está preenchido corretamente.").toString(),
							"W", /*W = Atenção, I = Informação, E = Erro */
							NBool.True /*bloquear/travar?*/);
			}else{
				getGuiaElement().setCdMatricula(NNumber.toNumber(cdMatricula));
				cdMatricula_validate();
			}
		}else{
			getGuiaElement().setCdMatricula(NNumber.getNull());
			getGuiaElement().setDspNmSegurado(NString.getNull());
		}
	}

	@ValidationTrigger(item = "CD_BENEFICIARIO_TRANSITO")
	public void cd_beneficiario_transito_validation() {
		
		ItemServices.setItemIsValid("GUIA.NR_CARTEIRA_BENEFICIARIO", true);
		if (!getGuiaElement().getCdBeneficiarioTransito().isNull()) {
			ResultSet resultSet = null;
			DataCursor dataCursor = null;

			try{
				String sql = ""+
						" SELECT CD_BENEFICIARIO_TRANSITO 																  "+
						" , BT.CD_MATRICULA CD_MATRICULA						          "+
						" , BT.NM_SEGURADO,TP_SEXO  																	  "+
						" , U.CD_UNIMED CD_UNIMED  																	  "+
						" , BT.NR_VIA_CARTAO  																	          "+
						"   FROM DBAPS.BENEFICIARIO_TRANSITO BT,                                                          "+
						"		  DBAPS.UNIMED U 																		  "+
						"   WHERE BT.CD_UNIMED = U.CD_UNIMED                                                          	  "+
						"     AND BT.CD_BENEFICIARIO_TRANSITO = :P_CD_BENEFICIARIO_TRANSITO                               ";
				dataCursor = new DataCursor(sql);
				dataCursor.addParameter("P_CD_BENEFICIARIO_TRANSITO",getGuiaElement().getCdBeneficiarioTransito());
				dataCursor.open();
				
				setDadosBeneficiarioTransito(dataCursor);
			}finally{
				if(resultSet != null){
					resultSet.close();
				}
				if (dataCursor != null) {
					dataCursor.close();
				}
			}
		}else{
			getGuiaElement().setNrCarteiraBeneficiario(NString.getNull());
		}
	}

	@ValidationTrigger(item = "NR_CARTEIRA_BENEFICIARIO")
	public void nr_carteira_beneficiario_validation() {
		ItemServices.setItemIsValid("GUIA.CD_BENEFICIARIO_TRANSITO", true);
		
		if(!getGuiaElement().getNrCarteiraBeneficiario().isNull() && !Services.isDigit(getGuiaElement().getNrCarteiraBeneficiario().toString())){
			getGuiaElement().setNrCarteiraBeneficiario(NString.getNull());
			//MULTI-IDIOMA: MSG_1001 - Código inválido
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg1001"), "W", NBool.False);
		}else{
			if (!getGuiaElement().getNrCarteiraBeneficiario().isNull()) {
				DataCursor dataCursor = null;
	
				try{
					String sql = ""+
							" SELECT CD_BENEFICIARIO_TRANSITO                         "
							+ "      , BT.NM_SEGURADO,TP_SEXO                         "
							+ "		 , BT.CD_MATRICULA CD_MATRICULA					  "
							+"       , U.CD_UNIMED                                    "
							+"       , BT.NR_VIA_CARTAO                               "
							+"    FROM DBAPS.BENEFICIARIO_TRANSITO BT,                "                                           
							+"          DBAPS.UNIMED U                                "                                     
							+"    WHERE BT.CD_UNIMED = U.CD_UNIMED(+)                 "                                        
							+"      AND BT.CD_MATRICULA = :P_CD_MATRICULA             ";                                           
					dataCursor = new DataCursor(sql);
					dataCursor.addParameter("P_CD_MATRICULA",getGuiaElement().getNrCarteiraBeneficiario());
					dataCursor.open();
					setDadosBeneficiarioTransito(dataCursor);
					
				}finally{
		
					if (dataCursor != null) {
						dataCursor.close();
					}
				}
			}else{
				getGuiaElement().setCdBeneficiarioTransito(NNumber.getNull());
			}
		}
	}
	
	/**
	 * Esse método só deve ser utizilado no validade do CD_BENEFICIARIO_TRANSITO e do NR_CARTEIRA_BENEFICIARIO
	 * @param dataCursor
	 */
	public void setDadosBeneficiarioTransito(DataCursor dataCursor){
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"), "N");
		ResultSet resultSet = null;
		if (dataCursor.found()) {
			resultSet = dataCursor.fetchInto();
			
			getGuiaElement().setCdBeneficiarioTransito(resultSet.getNumber("CD_BENEFICIARIO_TRANSITO"));
			getGuiaElement().setNrCarteiraBeneficiario(resultSet.getStr("CD_MATRICULA"));
			getGuiaElement().setDsDestinoCortesia(resultSet.getStr("NM_SEGURADO"));
			getGuiaElement().setNrViaCartao(resultSet.getNumber("NR_VIA_CARTAO"));
			
			if (!resultSet.getStr("CD_UNIMED").isNull() && snOperadoraUnimed.equals("S")) {
				if (!getGuiaElement().getCdUnimedOrigem().equals(resultSet.getStr("CD_UNIMED"))) {							
					getGuiaElement().setCdUnimedOrigem(resultSet.getStr("CD_UNIMED"));
					cd_unimed_origem_validation();
				}
				getGuiaElement().setTpSexo(resultSet.getStr("TP_SEXO"));
			}
		}else{
			if (snOperadoraUnimed.equals("S")) {
				if(getGuiaElement().getNrCarteiraBeneficiario() != null && getGuiaElement().getNrCarteiraBeneficiario().getLength() == 20){
					NString nrCarteiraBeneficiario = NString.toStr(getGuiaElement().getNrCarteiraBeneficiario().substring(0, 3));							
					if (!getGuiaElement().getCdUnimedOrigem().equals(nrCarteiraBeneficiario)) {							
						getGuiaElement().setCdUnimedOrigem(nrCarteiraBeneficiario);
						cd_unimed_origem_validation();
					}
				}else if(getGuiaElement().getNrCarteiraBeneficiario().getLength() <= 15){
					getTask().getMv2000().msgAlert(NString.toStr("")
							.append("Operação inválida!")
							.append(Lib.chr(10))
							.append("Motivo..: O código informado da carteira não tem o tamanho correto de 16 dígitos ou não foi encontrado.").toString(),
							"W", /*W = Atenção, I = Informação, E = Erro */
							NBool.False /*bloquear/travar?*/);
				}
			}
		}
		
		if(resultSet != null){
			resultSet.close();
		}
	}

	@ValidationTrigger(item = "CD_REDE_REFERENCIADA")
	public void cd_rede_referenciada_validation() {
		if(!getGuiaElement().getCdRedeReferenciada().isNull()){
			this.getTask().getServices().getRedeReferenciadaPrestador(getGuiaElement().getCdPrestadorEndereco(),getGuiaElement().getCdRedeReferenciada(), true);
		}
	}

	@ValidationTrigger(item = "CD_TIPO_INTERNACAO")
	public void cd_tipo_internacao_validation() {
		if (!getGuiaElement().getCdTipoInternacao().isNull()) {
			String whereClause = " CD_TIPO_INTERNACAO = " + getGuiaElement().getCdTipoInternacao();
			NString retorno = Services.getDescricao("DS_TIPO_INTERNACAO", "TIPO_INTERNACAO", whereClause, false);
			if (retorno.isNull()) {
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Operação inválida!")
						.append(Lib.chr(10))
						.append("Motivo..: O código do tipo de internação informado não foi encontrado.")
						.append(Lib.chr(10))
						.append("Ação....: Verifique o código informado.").toString(),
						"W", /*W = Atenção, I = Informação, E = Erro */
						NBool.True /*bloquear/travar?*/);
			}else{
				getGuiaElement().setDspDsTipoInternacao(retorno);
			}
		}else{
			getGuiaElement().setDspDsTipoInternacao(NString.getNull());
		}
		
	}

	@ValidationTrigger(item = "CD_UNIMED_EXECUTORA")
	public void cd_unimed_executora_validation() {
		NString snOperadoraUnimed = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		if (!getGuiaElement().getCdUnimedExecutora().isNull() && snOperadoraUnimed.equals("S")) {
			String whereClause = " CD_UNIMED = " + getGuiaElement().getCdUnimedExecutora();
			NString retorno = Services.getDescricao("DS_UNIMED", "UNIMED", whereClause, false);
			if (retorno.isNull()) {
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Operação inválida!")
						.append(Lib.chr(10))
						.append("Motivo..: O código da UNIMED informado não foi encontrado.")
						.append(Lib.chr(10))
						.append("Ação....: Verifique o código informado.").toString(),
						"W", /*W = Atenção, I = Informação, E = Erro */
						NBool.True /*bloquear/travar?*/);
			}else{
				getGuiaElement().setDspDsUnimedExecutora(retorno);
			}
		}else{
			getGuiaElement().setDspDsUnimedExecutora(NString.getNull());
		}
	}

	@ValidationTrigger(item = "CD_CLASSIFICACAO_METASTASE")
	public void cd_classificacao_metastase_validation() {
		if (!getGuiaElement().getCdClassificacaoMetastase().isNull()) {
			String whereClause = " CD_CLASSIFICACAO_METASTASE = " + getGuiaElement().getCdClassificacaoMetastase();
			NString retorno = Services.getDescricao("DS_CLASSIFICACAO_METASTASE", "CLASSIFICACAO_METASTASE", whereClause, false);
			if (retorno.isNull()) {
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Operação inválida!")
						.append(Lib.chr(10))
						.append("Motivo..: O código da classificação informado não foi encontrado.")
						.append(Lib.chr(10))
						.append("Ação....: Verifique o código informado.").toString(),
						"W", /*W = Atenção, I = Informação, E = Erro */
						NBool.True /*bloquear/travar?*/);
			}else{
				getGuiaElement().setDspDsClassificacaoMetastase(retorno);
			}
		}else{
			getGuiaElement().setDspDsClassificacaoMetastase(NString.getNull());
		}
	}

	@ValidationTrigger(item = "CD_CLASSIFICACAO_NODULO")
	public void cd_classificacao_nodulo_validation() {
		if (!getGuiaElement().getCdClassificacaoNodulo().isNull()) {
			String whereClause = " CD_CLASSIFICACAO_NODULO = " + getGuiaElement().getCdClassificacaoNodulo();
			NString retorno = Services.getDescricao("DS_CLASSIFICACAO_NODULO", "CLASSIFICACAO_NODULO", whereClause, false);
			if (retorno.isNull()) {
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Operação inválida!")
						.append(Lib.chr(10))
						.append("Motivo..: O código da classificação informado não foi encontrado.")
						.append(Lib.chr(10))
						.append("Ação....: Verifique o código informado.").toString(),
						"W", /*W = Atenção, I = Informação, E = Erro */
						NBool.True /*bloquear/travar?*/);
			}else{
				getGuiaElement().setDspDsClassificacaoNodulo(retorno);
			}
		}else{
			getGuiaElement().setDspDsClassificacaoNodulo(NString.getNull());
		}
	}

	@ValidationTrigger(item = "CD_CLASSIFICACAO_TUMOR")
	public void cd_classificacao_tumor_validation() {
		if (!getGuiaElement().getCdClassificacaoTumor().isNull()) {
			String whereClause = " CD_CLASSIFICACAO_TUMOR = " + getGuiaElement().getCdClassificacaoTumor();
			NString retorno = Services.getDescricao("DS_CLASSIFICACAO_TUMOR", "CLASSIFICACAO_TUMOR", whereClause, false);
			if (retorno.isNull()) {
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Operação inválida!")
					.append(Lib.chr(10))
						.append("Motivo..: O código da classificação informado não foi encontrado.")
						.append(Lib.chr(10))
						.append("Ação....: Verifique o código informado.").toString(),
						"W", /*W = Atenção, I = Informação, E = Erro */
						NBool.True /*bloquear/travar?*/);
			}else{
				getGuiaElement().setDspDsClassificacaoTumor(retorno);
			}
		}else{
			getGuiaElement().setDspDsClassificacaoTumor(NString.getNull());
		}
	}

	@ValidationTrigger(item = "CD_UNIMED_ORIGEM")
	public void cd_unimed_origem_validation() {
		NString snOperadoraUnimed = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		if (!getGuiaElement().getCdUnimedOrigem().isNull() && snOperadoraUnimed.equals("S")) {
			String whereClause = " CD_UNIMED = " + getGuiaElement().getCdUnimedOrigem();
			NString retorno = Services.getDescricao("DS_UNIMED", "UNIMED", whereClause, false);
			if (retorno.isNull()) {
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Operação inválida!")
						.append(Lib.chr(10))
						.append("Motivo..: O código da UNIMED informado não foi encontrado.")
						.append(Lib.chr(10))
						.append("Ação....: Verifique o código informado.").toString(),
						"W", /*W = Atenção, I = Informação, E = Erro */
						NBool.True /*bloquear/travar?*/);
			}else{
				getGuiaElement().setDspDsUnimedOrigem(retorno);
			}
		}else{
			getGuiaElement().setDspDsUnimedOrigem(NString.getNull());
		}
	}

	@ValidationTrigger(item = "CD_UNIMED_SOLICITANTE")
	public void cd_unimed_solicitante_validation() {
		NString snOperadoraUnimed = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		if (!getGuiaElement().getCdUnimedSolicitante().isNull() && snOperadoraUnimed.equals("S")) {
			String whereClause = " CD_UNIMED = " + getGuiaElement().getCdUnimedSolicitante();
			NString retorno = Services.getDescricao("DS_UNIMED", "UNIMED", whereClause, false);
			if (retorno.isNull()) {
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Operação inválida!")
						.append(Lib.chr(10))
						.append("Motivo..: O código da UNIMED informado não foi encontrado.")
						.append(Lib.chr(10))
						.append("Ação....: Verifique o código informado.").toString(),
						"W", /*W = Atenção, I = Informação, E = Erro */
						NBool.True /*bloquear/travar?*/);
			}else{
				getGuiaElement().setDspDsUnimedSolicitante(retorno);
			}
		}else{
			getGuiaElement().setDspDsUnimedSolicitante(NString.getNull());
		}
	}

	@ActionTrigger(item = "BTN_PTU_RESPOSTA_AUDITORIA", action = "btn_ptu_resposta_auditoria_click")
	public void btn_ptu_resposta_auditoria_click(){

		String errorMessage = null;
		String resposta = null;
		
		if(getGuiaElement().getNrGuia().isNull()){
			getTask().getMv2000().msgAlert("Não foi possivel identificar o número da guia.", "W", NBool.True);		
		}
		
		if (getGuiaElement().getTpFluxoPtuWs().equals("CLIENT") && !getGuiaElement().getTpFluxoPtuWs().isNull()) {
			getTask().getMv2000().msgAlert("Guia não necessita de uma resposta de auditoria.", "W", NBool.True);
		}
				
		if (getGuiaElement().getCdUnimedOrigem().equals(getGuiaElement().getCdUnimedExecutora())) { 
			   getTask().getMv2000().msgAlert("Não é possível executar uma consulta para Unimed Origem igual a Unimed Executora.", "W", NBool.True);
		}
		
		if (getGuiaElement().getCdPtuMensagemOrigem().isNull()) {
			getTask().getMv2000().msgAlert("Não foi realizado um Pedido de Autorização para a guia selecionada.", "W", NBool.True);
		}
		
		if (getGuiaElement().getDsAuditoria().isNull()) {
			getTask().getMv2000().msgAlert("A observação da auditoria deve ser preenchido.", "W", NBool.True);
		}
		
		if (Services.exist("ITGUIA", "QT_SOLICITADO = 0 AND TP_STATUS = 4 AND NR_GUIA = " + getGuiaElement().getNrGuia(), false)) {
			getTask().getMv2000().msgAlert("Guia possui itens que estão autorizados com a quantidade 0!", "W", NBool.True);
		}

		NString procedimentos = NString.getNull();
		
		NNumber reg = BlockServices.getCurrentRecord("ITGUIA_AUDITORIA");
		BlockServices.firstRecord();
		while (true) {
			if(!Lib.in(getItguiaAuditoriaElement().getTpStatus(),"3","4").getValue()){
				procedimentos = procedimentos.append(getItguiaAuditoriaElement().getCdProcedimento()).append(",");
			}
			
			if ( BlockServices.isInLastRecord() ) break;
			BlockServices.nextRecord(); 
		} 
		BlockServices.setCurrentRecord(reg);
			    
		if (!procedimentos.isNull()) {
			getTask().getMv2000().msgAlert("Os procedimentos ["+procedimentos.substring(0, procedimentos.getLength()-1)+"] precisam ser auditados.", "W", NBool.True);
		}
		
		try{
			TaskServices.commitTask(true);
			
			resposta = WebService.executaRespotaAuditoria(getGuiaElement().getNrGuia()).toString();
		}catch(Exception ex){
			errorMessage = ex.getMessage();
		}finally{
			if(errorMessage == null){
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Resposta Unimed!")
						.append(Lib.chr(10))
						.append(resposta).toString(),
						"I",
						NBool.False);
			}else{
				getTask().getMv2000().msgAlert(errorMessage, "E", NBool.False);
			}

			this.getTask().getServices().recarregarTela(getGuiaElement().getNrGuia());
		}
	}

	@ViewTrigger
	@ActionTrigger(item = "DT_PREV_EXECUCAO", action = "dt_prev_execucao_itemOut", function=KeyFunction.ITEM_OUT)
	public void dt_prev_execucao_itemOut() {
		
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		NString snEmissaoAvulsa = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
		
		if (getGuiaElement().getDtSugeridaInternacao().isNull() && (getGuiaElement().getDspTpGuia().equals("I") || (snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S") && Lib.in(getGuiaElement().getDspTpGuia().toString(), "O","Q","R").toBoolean() ) ) ) {
			getGuiaElement().setDtSugeridaInternacao(getGuiaElement().getDtPrevExecucao());
		}
	}

	@ViewTrigger
	@ActionTrigger(item = "DT_SUGERIDA_INTERNACAO", action = "dt_sugerida_internacao_itemOut", function=KeyFunction.ITEM_OUT)
	public void dt_sugerida_internacao_itemOut() {
		if (getGuiaElement().getDtPrevisaoAlta().isNull()) {
			getGuiaElement().setDtPrevisaoAlta(getGuiaElement().getDtSugeridaInternacao().add(getGuiaElement().getNrDiasAutorizacao()));
		}
	}

	@ViewTrigger
	@ActionTrigger(item = "NR_GUIA_PRESTADOR", action = "nr_guia_prestador_itemOut", function=KeyFunction.ITEM_OUT)
	public void nr_guia_prestador_itemOut() {}

	@ViewTrigger
	@ActionTrigger(item = "NR_GUIA_TEM", action = "nr_guia_tem_itemOut", function=KeyFunction.ITEM_OUT)
	public void nr_guia_tem_itemOut() {
		NString snCortesia = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
		if (snCortesia.equals("S")) {
			ItemServices.setItemPreviousItem("GUIA.NR_GUIA_TEM", "GUIA.DS_DESTINO_CORTESIA");
		}else{
			ItemServices.setItemPreviousItem("GUIA.NR_GUIA_TEM", "GUIA.CD_MAT_ALTERNATIVA");
		}
	}

	@ActionTrigger(item = "BTN_LEITOR_MAGNETO_AVULSO", action = "btn_leitor_magneto_avulso_click")
	public void btn_leitor_magneto_avulso_click() {
		this.getTask().getServices().leitorMagnetico();
	}

	@ActionTrigger(item = "BTN_SOLIC_ORDEM_SERVICO", action = "btn_solic_ordem_servico_click")
	public void btn_solic_ordem_servico_click(){
		NString resposta = NString.getNull();
		String errorMessage = null;

		if(getGuiaElement().getNrGuia().isNull()){
			getTask().getMv2000().msgAlert("Não foi possivel identificar o número da guia.", "W", NBool.True);
		}
		if (getGuiaElement().getSnOrdemServico().equals("N")) {
			getTask().getMv2000().msgAlert("Essa guia não é uma ordem de serviço.", "W", NBool.True);
		}

		if (!getGuiaElement().getCdPtuMensOrdemServicoDes().isNull()) {
			getTask().getMv2000().msgAlert("Essa guia já tem uma solicitação de ordem de serviço.", "W", NBool.True);
		}

		try{
			TaskServices.commitTask();
			resposta = WebService.executaOrdemServico(getGuiaElement().getNrGuia());
		} catch (Exception e) {
			e.printStackTrace();
			errorMessage = e.getMessage().toString();
		}finally{
			if(errorMessage == null){
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Resposta Unimed!")
						.append(Lib.chr(10))
						.append(resposta).toString(),
						"I",
						NBool.False);
			}else{
				getTask().getMv2000().msgAlert(errorMessage, "E", NBool.False);
			}

			this.getTask().getServices().recarregarTela(getGuiaElement().getNrGuia());
		}

	}

	@ActionTrigger(item = "SN_ORDEM_SERVICO", action = "sn_ordem_servico_change")
	public void sn_ordem_servico_change() {
		
		ItemServices.setItemEnabled("ITGUIA.TP_STATUS_PTU_OS", getGuiaElement().getSnOrdemServico().equals("N"));
		ItemServices.setItemInsertAllowed("ITGUIA.TP_STATUS_PTU_OS", getGuiaElement().getSnOrdemServico().equals("N"));
		ItemServices.setItemUpdateAllowed("ITGUIA.TP_STATUS_PTU_OS", getGuiaElement().getSnOrdemServico().equals("N"));
		ItemServices.setItemVisible("ITGUIA.TP_STATUS_PTU_OS", getGuiaElement().getSnOrdemServico().equals("S"));
	}

	@ActionTrigger(item = "BTN_PTU_STATUS", action = "btn_ptu_status_click")
	public void btn_ptu_status_click() throws Exception  {
		if(getGuiaElement() == null) {
			getTask().getMv2000().msgAlert("Selecione uma guia.", "W", NBool.True);
		}
		if (getGuiaElement().getNrGuia().isNull()) {
			getTask().getMv2000().msgAlert("Informe o número da guia.", "W", NBool.True);
		}
		if (getGuiaElement().getCdUnimedOrigem().equals(getGuiaElement().getCdUnimedExecutora())) { 
			getTask().getMv2000().msgAlert("Não é possível executar uma consulta para Unimed Origem igual a Unimed Executora.", "W", NBool.True);
		}
		if (getGuiaElement().getCdPtuMensagemOrigem().isNull()) { 
			getTask().getMv2000().msgAlert("Não foi realizado um Pedido de Autorização para a guia selecionada.", "W", NBool.True);			
		}
		if (getGuiaElement().getSnOrdemServico().equals("S")) {
			getTask().getMv2000().msgAlert("Essa guia é uma Ordem de Serviço.", "W", NBool.True);
		}
		NString resposta = WebService.executaStatusTransacao(getGuiaElement().getCdPtuMensagemOrigem(), getGuiaElement().getNrGuia());
		
		this.getTask().getServices().recarregarTela(getGuiaElement().getNrGuia());
		
		getTask().getMv2000().msgAlert(NString.toStr("")
				.append("Resposta Unimed!")
				.append(Lib.chr(10))
				.append(resposta).toString(),
				"I",
				NBool.False);
	}

	@ActionTrigger(item = "BTN_PTU_DECURSO_PRAZO", action = "btn_ptu_decurso_prazo_click")
	public void btn_ptu_decurso_prazo_click(){
		
		if(getGuiaElement() == null) {
			getTask().getMv2000().msgAlert("Selecione uma guia.", "W", NBool.True);
		}
		if (getGuiaElement().getNrGuia().isNull()) {
			getTask().getMv2000().msgAlert("Informe o número da guia.", "W", NBool.True);
		}
		if (!getGuiaElement().getCdMotCancelamentoGuia().isNull()) {
			getTask().getMv2000().msgAlert("Não é possível realizar o processo selecionado para uma guia cancelada.", "W", NBool.True);
		}
		if (getGuiaElement().getCdUnimedOrigem().equals(getGuiaElement().getCdUnimedExecutora())) { 
			getTask().getMv2000().msgAlert("Não é possível executar uma consulta para Unimed Origem igual a Unimed Executora.", "W", NBool.True);
		}
		if (getGuiaElement().getCdPtuMensagemOrigem().isNull()) { 
			getTask().getMv2000().msgAlert("Não foi realizado um Pedido de Autorização para a guia selecionada.", "W", NBool.True);			
		}
		
		if (getGuiaElement().getSnOrdemServico().equals("S")) {
			getTask().getMv2000().msgAlert("Essa guia é uma Ordem de Serviço.", "W", NBool.True);
		}
		String resposta = null;
		try{
			resposta = WebService.executaDecursoDePrazo(getGuiaElement().getNrGuia()).toString();
		}catch(Exception ex){
			ex.printStackTrace();
			resposta = ex.getMessage();
		}finally{
			
			this.getTask().getServices().recarregarTela(getGuiaElement().getNrGuia());

			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Resposta Unimed!")
					.append(Lib.chr(10))
					.append(resposta).toString(),
					"I",
					NBool.False);
		}
		
	}

	@ActionTrigger(item = "BTN_PTU_INSISTENCIA", action = "btn_ptu_insistencia_click")
	public void btn_ptu_insistencia_click() {

		NString cdUnimed = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("CD_UNIMED"),"");
		if(getGuiaElement() == null) {
			getTask().getMv2000().msgAlert("Selecione uma guia.", "W", NBool.True);
		}
		if (getGuiaElement().getNrGuia().isNull()) {
			getTask().getMv2000().msgAlert("Informe o número da guia.", "W", NBool.True);
		}
		if (getGuiaElement().getCdUnimedOrigem().equals(getGuiaElement().getCdUnimedExecutora())) { 
			getTask().getMv2000().msgAlert("Não é possível executar uma consulta para Unimed Origem igual a Unimed Executora.", "W", NBool.True);
		}
		
		if (getGuiaElement().getCdPtuMensagemOrigem().isNull()) { 
			getTask().getMv2000().msgAlert("Não foi realizado um Pedido de Autorização para a guia selecionada.", "W", NBool.True);			
		}
		
		if (!getGuiaElement().getCdUnimedExecutora().equals(cdUnimed)) { 
			getTask().getMv2000().msgAlert("Não é possivel realizar pedido de insistência.", "W", NBool.True);			
		}
		
		if (getGuiaElement().getSnOrdemServico().equals("S")) {
			getTask().getMv2000().msgAlert("Essa guia é uma Ordem de Serviço.", "W", NBool.True);
		}
		getFormModel().getCgCtrl().setDspDsLiberacao(toStr("Pedido de Insistência"));
		getFormModel().getCgCtrl().setDspDsMensagemLivre(NString.getNull());
		this.getTask().getServices().configuraSolicitacaoSenha(NString.toStr("PTU-I"));
	}

	@ActionTrigger(item = "BTN_PTU_PEDIDO_AUTORIZACAO", action = "btn_ptu_pedido_autorizacao_click")
	public void btn_ptu_pedido_autorizacao_click(){
		
		NNumber retorno = NNumber.getNull();
		String errorMessage = null;

		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");

		if(getGuiaElement() == null) {
			getTask().getMv2000().msgAlert("Selecione uma guia.", "W", NBool.True);
		}
		
		if (!getGuiaElement().getNrGuiaTem().isNull()) {
			getTask().getMv2000().msgAlert("Realize um Pedido de Complementação de Autorização.", "W", NBool.True);
		}
		
		if (getGuiaElement().getNrGuia().isNull()) {
			getTask().getMv2000().msgAlert("Informe o número da guia.", "W", NBool.True);
		}
		if (!getGuiaElement().getCdMotCancelamentoGuia().isNull()) {
			getTask().getMv2000().msgAlert("Não é possível realizar o processo selecionado para uma guia cancelada.", "W", NBool.True);
		}
		
		if (!getGuiaElement().getCdPtuMensagemDestino().isNull()) { 
			getTask().getMv2000().msgAlert("Já foi realizado um Pedido de Autorização para a guia selecionada.", "W", NBool.True);			
		}
		
		if (!getGuiaElement().getCdPtuMensagemDestino().isNull()) {
			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Operação inválida!")
					.append(Lib.chr(10))
					.append("Motivo..: Essa guia já possui um Pedido de Autorização para a guia selecionada.")
					.append(Lib.chr(10))
					.append("Ação....: Solicite pedido de \"Insistência\" ou um \"Status Transação\".").toString(),
					"W", /*W = Atenção, I = Informação, E = Erro */
					NBool.True /*bloquear/travar?*/);
			getTask().getMv2000().msgAlert("Essa guia já possui um Pedido de Autorização para a guia selecionada.", "W", NBool.True);			
		}
		
		try{
			TaskServices.commitTask(true);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		if ("I".equals(getGuiaElement().getDspTpGuia().toString())) { // Internação
			
			if (getGuiaElement().getDtSugeridaInternacao().isNull()) {
				getTask().getMv2000().msgAlert("Informe a data sugerida pelo profissional solicitante para o início da internação do paciente.", "W", NBool.True);
			}
			
			if (getGuiaElement().getDsDiagnostico().isNull()) {
				getTask().getMv2000().msgAlert("Para transações de internação, é obrigátorío informar a indicação clínica na aba \"Indicação Clínica\".", "W", NBool.True);
			}
		}
		
		NString tipoBeneficiario = NString.getNull();
		NString whereClause = NString.getNull();
		
		
		if(snOperadoraUnimed.equals("S")){
			
			whereClause = whereClause.append(" CD_MATRICULA = '"+getGuiaElement().getNrCarteiraBeneficiario()+"' ");
			whereClause = whereClause.append(" AND CD_UNIMED = '"+getGuiaElement().getCdUnimedOrigem()+"' ");
			
			if (getGuiaElement().getTpSexo().equals("I")) {
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Operação inválida!")
						.append(Lib.chr(10))
						.append("Motivo..: O tipo do sexo não pode ser \"Indefinido\".")
						.append(Lib.chr(10))
						.append("Ação....: Modifique o sexo na aba \" Avulsa/Intercâmbio \".").toString(),
						"W", /*W = Atenção, I = Informação, E = Erro */
						NBool.True /*bloquear/travar?*/);
			}
			
			if(!Services.exist("BENEFICIARIO_TRANSITO", whereClause.toString(), false)){
				String sql = "	INSERT INTO DBAPS.BENEFICIARIO_TRANSITO (CD_BENEFICIARIO_TRANSITO, CD_MATRICULA, NM_SEGURADO, DT_ATENDIMENTO , CD_USUARIO_INCLUSAO, NR_VIA_CARTAO ,TP_SEXO ,CD_UNIMED) "
						   + "	VALUES (DBAPS.SEQ_BENEFICIARIO_TRANSITO.NEXTVAL, :PCD_MATRICULA , :PNM_SEGURADO, SYSDATE, USER, :PNR_VIA_CARTAO , :PTP_SEXO, :PCD_UNIMED)";
				DataCommand dataCommand = new DataCommand(sql);
				dataCommand.addParameter("PCD_MATRICULA", getGuiaElement().getNrCarteiraBeneficiario());
				dataCommand.addParameter("PNM_SEGURADO", getGuiaElement().getDsDestinoCortesia());
				dataCommand.addParameter("PNR_VIA_CARTAO", getGuiaElement().getNrViaCartao());
				dataCommand.addParameter("PTP_SEXO", getGuiaElement().getTpSexo());
				dataCommand.addParameter("PCD_UNIMED", getGuiaElement().getCdUnimedOrigem());
				dataCommand.execute();
			}
			
			tipoBeneficiario = this.getTask().getServices().fncRetornaTipoBeneficiario(getGuiaElement().getCdMatricula(),getGuiaElement().getNrCarteiraBeneficiario());
			
		}
		
		if (snOperadoraUnimed.equals("S") && ( tipoBeneficiario.equals("EV") || tipoBeneficiario.equals("ID") || tipoBeneficiario.equals("RC") ) ) {
			
			try {
				retorno = WebService.executaPedidoAutorizacao(getGuiaElement().getNrGuia());
				
			} catch (Exception e) {
				e.printStackTrace();
				errorMessage = e.getMessage().toString();
			}finally{

				if(errorMessage == null){
					if ("0".equals(retorno.toString())) {
						getTask().getMv2000().msgAlert("PTU Online - Guia Autorizada", "I", NBool.False);
					} else if ("-1".equals(retorno.toString())) {
						getTask().getMv2000().msgAlert("PTU Online - Guia com ocorrências/estudo.", "W", NBool.False);
					} else {
						getTask().getMv2000().msgAlert("PTU Online - Processo concluído.", "I", NBool.False);
					}
				}else{
					getTask().getMv2000().msgAlert(errorMessage, "E", NBool.False);
				}
				
				this.getTask().getServices().recarregarTela(getGuiaElement().getNrGuia());
			}
		}else{
			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Operação inválida!")
					.append(Lib.chr(10))
					.append("Motivo..: Guia não necessita de um pedido de autorização.").toString(),
					"W", /*W = Atenção, I = Informação, E = Erro */
					NBool.True /*bloquear/travar?*/);
		}
	}

	@ActionTrigger(item = "BTN_PTU_PEDIDO_COMPLEMENTO_AUTORIZACAO", action = "btn_ptu_pedido_complemento_autorizacao_click")
	public void btn_ptu_pedido_complemento_autorizacao_click() throws Exception  {

		NNumber retorno = NNumber.getNull();
		NString tipoBeneficiario = NString.getNull();
		String errorMessage = null;

		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");

		if(getGuiaElement() == null) {
			getTask().getMv2000().msgAlert("Selecione uma guia.", "W", NBool.True);
		}
		if (getGuiaElement().getNrGuia().isNull()) {
			getTask().getMv2000().msgAlert("Informe o número da guia.", "W", NBool.True);
		}
		if (!getGuiaElement().getCdMotCancelamentoGuia().isNull()) {
			getTask().getMv2000().msgAlert("Não é possível realizar o processo selecionado para uma guia cancelada.", "W", NBool.True);
		}

		tipoBeneficiario = this.getTask().getServices().fncRetornaTipoBeneficiario(getGuiaElement().getCdMatricula(),getGuiaElement().getNrCarteiraBeneficiario());

		if (snOperadoraUnimed.equals("S") && (tipoBeneficiario.equals("EV") || tipoBeneficiario.equals("ID") || tipoBeneficiario.equals("RC")) ) {
			try{
				retorno = WebService.executaPedidoComplementoAutorizacao(getGuiaElement().getNrGuia());
			} catch (Exception e) {
				e.printStackTrace();
				errorMessage = e.getMessage().toString();
			}finally{

				if(errorMessage == null){
					if ("0".equals(retorno.toString())) {
						getTask().getMv2000().msgAlert("PTU Online - Guia Autorizada", "I", NBool.False);
					} else if ("-1".equals(retorno.toString())) {
						getTask().getMv2000().msgAlert("PTU Online - Guia com ocorrências/estudo.", "W", NBool.False);
					} else {
						getTask().getMv2000().msgAlert("PTU Online - Processo concluído.", "I", NBool.False);
					}
				}else{
					getTask().getMv2000().msgAlert(errorMessage, "E", NBool.False);
				}

				this.getTask().getServices().recarregarTela(getGuiaElement().getNrGuia());
			}
		}else{
			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Operação inválida!")
					.append(Lib.chr(10))
					.append("Motivo..: Guia não necessita de um pedido de autorização.").toString(),
					"W", /*W = Atenção, I = Informação, E = Erro */
					NBool.True /*bloquear/travar?*/);
		}

	}

	@ActionTrigger(item = "BTN_PTU_AUTORIZACAO_ORDEM_SERVICO", action = "btn_ptu_autorizacao_ordem_servico_click")
	public void btn_ptu_autorizacao_ordem_servico_click() throws Exception  {
		if(getGuiaElement() == null) {
			getTask().getMv2000().msgAlert("Selecione uma guia.", "W", NBool.True);
		}
		if (getGuiaElement().getNrGuia().isNull()) {
			getTask().getMv2000().msgAlert("Informe o número da guia.", "W", NBool.True);
		}
		if (!getGuiaElement().getCdMotCancelamentoGuia().isNull()) {
			getTask().getMv2000().msgAlert("Não é possível realizar o processo selecionado para uma guia cancelada.", "W", NBool.True);
		}
		if (getGuiaElement().getCdPtuMensagemDestino().isNull()) { 
			getTask().getMv2000().msgAlert("Não foi realizado um Pedido de Autorização para a guia selecionada.", "W", NBool.True);			
		}
		
		if (getGuiaElement().getCdPtuMensOrdemServicoDes().isNull()) {
			getTask().getMv2000().msgAlert("Não foi realizado um Pedido de Ordem de Serviço para a guia selecionada.", "W", NBool.True);
		}
		
		NString resposta = WebService.executaAutorizacaoOrdemServico(getGuiaElement().getNrGuia());
		
		this.getTask().getServices().recarregarTela(getGuiaElement().getNrGuia());
		
		getTask().getMv2000().msgAlert(NString.toStr("")
				.append("Resposta Unimed!")
				.append(Lib.chr(10))
				.append(resposta).toString(),
				"I",
				NBool.False);
	}

	@AfterRowUpdate
	public void guia_AfterRowUpdate(RowAdapterEvent rowAdapterEvent) {
		if (Services.exist("GUIA_HISTORICO_RESPONSAVEL", "NR_GUIA = " + getGuiaElement().getNrGuia() , false)) {
			BlockServices.getBlockController("GUIA_HISTORICO_RESPONSAVEL").getInteractionRulesStrategy().executeQuery();
		}
	}

	@ValidationTrigger(item = "DS_EMAIL_BENEFICIARIO")
	public void ds_email_beneficiario_validation() {

		if (!getGuiaElement().getDsEmailBeneficiario().isNull()) {
			Pattern pattern = Pattern.compile("^[\\w-]+(\\.[\\w-]+)*@([\\w-]+\\.)+[a-zA-Z]{2,7}$");   
			Matcher m = pattern.matcher(getGuiaElement().getDsEmailBeneficiario().toString());

			if (!m.find()){			
				getTask().getMv2000().msgAlert("Email inválido! \n Exemplo: email@email.com", "E", NBool.True);		
			}
		}
	}

	@ActionTrigger(item = "BTN_ALTERAR_OBSERVACAO", action = "btn_alterar_observacao_click")
	public void btn_alterar_observacao_click() {
		ItemServices.goItem("CG$CTRL.BTN_VOLT_ALTERACAO_OBSERVACAO");
		this.getFormModel().getCgCtrl().setDspDsObservacao(getGuiaElement().getDsObservacao());
	}
	
	@ActionTrigger(item = "BTN_ALTERAR_JUSTIFICATIVA_OPERADORA", action = "btn_alterar_justificativa_operadora_click")
	public void btn_alterar_justificativa_operadora_click() {
		ItemServices.goItem("CG$CTRL.BTN_VOLT_ALTER_JUSTIFI_OPERADORA");
		this.getFormModel().getCgCtrl().setDspDsJustificativaOperadora(getGuiaElement().getDsJustificativaOperadora());
	}

	@ActionTrigger(item = "CD_MOTIVO_AUTORIZACAO", action = "cd_motivo_autorizacao_doubleClick")
	public void cd_motivo_autorizacao_doubleClick() {
		if (getGuiaElement().getCdMotCancelamentoGuia().isNull() && getGuiaElement().getSnValidaRestCarencia().equals("S")) {
			TaskServices.showLov("LOV_MOTIVO_AUTORIZACAO_AUT");
		}
	}

	@ActionTrigger(item = "BTN_AGENDA", action = "btn_agenda_click")
	public void btn_agenda_click() {

		if(getGuiaElement().getSnValidaRestCarencia().equals("N")) {
			//MULTI-IDIOMA: MSG_0003 - Utilize esta opção quando a guia estiver autorizada.
			String msg = ResourceManager.getString("guia.msg0003");
			getTask().getMv2000().msgAlert(msg, toStr("E"), toBool(NBool.True));	
		}

		ResultSet rs = this.getTask().getServices().getCdPaciente(getGuiaElement().getCdMatricula());
		if(rs != null) {
			@SuppressWarnings("rawtypes")
			Hashtable plId = null;
			
			NString pCdItensMarcacao = NString.getNull();
			NString pCdServicos = NString.getNull();
			NString pTpConsulta = NString.getNull();
			
			plId = getParameterList("GUIA");

			if (plId == null){
				plId = createParameterList("GUIA");
			}else{
				plId.clear();
			}

			if (!rs.getStr("CD_PACIENTE").isNull()) {
				
				addParameter(plId, "P_CD_PACIENTE",rs.getNumber("CD_PACIENTE"));
				addParameter(plId, "P_CD_CONVENIO",rs.getNumber("CD_CONVENIO"));
				addParameter(plId, "P_CD_PLANO",rs.getNumber("CD_PLANO_MV2000"));
				addParameter(plId, "P_DT_AGENDA",getGuiaElement().getDtEmissao());
				
				DataCursor dataCursor = this.getTask().getServices().getItemAgendamento(getGuiaElement().getNrGuia());
								
				ResultSet resultSet = dataCursor.fetchInto(); 
				
				while(true){
					
					if (resultSet.getNumber("QTD_ITENS_ENCONTRADOS").equals(0)) {
						//MULTI-IDIOMA: MSG_0094 -  Não foi encontrado item de agendamento vinculado a esse procedimento. [%s]
						getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0094", resultSet.getStr("CD_PROCEDIMENTO")), "W", NBool.True);
					}
					
					if (resultSet.getNumber("QTD_ITENS_ENCONTRADOS").greater(1)) {
						//MULTI-IDIOMA: MSG_0095 - Foi encontrado mais de um item de agendamento vinculado a esse procedimento. [%s]
						getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0095", resultSet.getStr("CD_PROCEDIMENTO")), "W", NBool.True);
					}

					pCdItensMarcacao = pCdItensMarcacao.append(resultSet.getStr("CD_ITEM_AGENDAMENTO")).append(";");
					pCdServicos = pCdServicos.append("").append(";");
					pTpConsulta = pTpConsulta.append("").append(";");
					resultSet = dataCursor.fetchInto();
					
					if (resultSet == null) {
						break;
					}
				
				}
				
				addParameter(plId, "P_CD_ITENS_MARCACAO",pCdItensMarcacao);
				addParameter(plId, "P_CD_SERVICOS",pCdServicos);
				addParameter(plId, "P_TP_CONSULTA",pTpConsulta);
				
			}else {
				addParameter(plId, "P_CD_PACIENTE",NString.getNull());
				addParameter(plId, "P_CD_CONVENIO",NString.getNull());
				addParameter(plId, "P_CD_PLANO",NString.getNull());
				addParameter(plId, "P_DT_AGENDA",NString.getNull());
				addParameter(plId, "P_CD_ITENS_MARCACAO",NString.getNull());
				addParameter(plId, "P_CD_SERVICOS",NString.getNull());
				addParameter(plId, "P_TP_CONSULTA",NString.getNull());
			}

			TaskServices.callTask("SCMA/M_CENTRAL_MARCACOES", TaskServices.HIDE, TaskServices.NO_REPLACE, TaskServices.NO_QUERY_ONLY, plId);
		}else{
			//MULTI-IDIOMA: MSG_0092 - Não é possivel identificar o código do paciente. 
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0092"), "W", NBool.True);
		}
	}

	@ActionTrigger(item = "BTN_COMUNIC_INTERNA_ALTA_BENEF", action = "btn_comunic_interna_alta_benef_click")
	public void btn_comunic_interna_alta_benef_click() {
		getFormModel().getCgCtrl().setDspDsLiberacao(toStr("Comunicação de Internação ou Alta do Beneficiário"));
		if (!getGuiaElement().getCdPtuMensagemDestino().isNull() && getGuiaElement().getDspTpGuia().equals("I")) {
			this.getTask().getServices().configuraSolicitacaoSenha(NString.toStr("PTU-AI"));
		}else{
			getTask().getMv2000().msgAlert("Guia não é de Internação ou não possui código da transação Destino.", "W", NBool.True);
		}
		
	}

	@SuppressWarnings("rawtypes")
	@ActionTrigger(item = "BTN_CLONAR_GUIA", action = "btn_clonar_guia_click")
	public void btn_clonar_guia_click() {

		if (getGuiaElement().getCdTipoAtendimento().isNull()) {
			getTask().getMv2000().msgAlert("Informe o tipo de atendimento.", "E", NBool.True);
		}
		//MULTI-IDIOMA: MSG_0086 - Deseja copiar os procedimentos?
		String message = ResourceManager.getString("guia.msg0086");
		//MULTI-IDIOMA: MSG_0088 - Sim/Não/Cancelar
		String simNao = ResourceManager.getString("guia.msg0088");
		NBool retorno = getTask().getMv2000().msgAlertSn(message, NString.toStr("W"), simNao);
		String sqlCommand = "";
		DataCommand command = null;
		NNumber nrGuia = null;
		
		if(retorno == NBool.getNull()){
			return;
		}

		if(NBool.True.equals(retorno) || NBool.False.equals(retorno)){
			nrGuia = NNumber.toNumber( Services.getDescricao("DBAPS.SEQ_GUIA.NEXTVAL||'9'","SYS" ,"DUAL", "1 = 1", false) );
			sqlCommand = " INSERT INTO DBAPS.GUIA ( "
					+ "  NR_GUIA "
					+ " ,CD_BENEFICIARIO_TRANSITO "
					+ " ,CD_TIPO_ATENDIMENTO"
					+ " ,NR_CARTEIRA_BENEFICIARIO "
					+ " ,DS_DESTINO_CORTESIA "
					+ " ,CD_MATRICULA "
					+ " ,NR_GUIA_TEM  "
					+ " ,CD_PRESTADOR "
					+ " ,NM_PRESTADOR "
					+ " ,NR_GUIA_PRESTADOR  "
					+ " ,TP_CARATER_SOLIC_INTER "
					+ " ,TP_INTERNACAO "
					+ " ,SN_ATENDIMENTO_RECEM_NATO "
					+ " ,DT_EMISSAO "
					+ " ,DT_VENCIMENTO "
					+ " ,DT_PREV_EXECUCAO "
					+ " ,DT_SUGERIDA_INTERNACAO"
					+ " ,HR_PREVISAO "
					+ " ,CD_ESPECIALIDADE "
					+ " ,CD_PRESTADOR_EXECUTOR "
					+ " ,CD_PRESTADOR_ENDERECO "
					+ " ,DS_ENDERECO "
					+ " ,CD_PRESTADOR_EXECUTOR_PF "
					+ " ,CD_CID "
					+ " ,SN_VALIDA_REST_CARENCIA "
					+ " ,DT_AUTORIZACAO "
					+ " ,CD_UNIMED_ORIGEM "
					+ " ,CD_UNIMED_EXECUTORA "
					+ " ,CD_UNIMED_SOLICITANTE "
					+ " ,CD_AUTORIZADOR "
					+ " ,DS_SENHA_AUTORIZADOR "
					+ " ,NR_PROTOCOLO "
					+ " ,CD_ID_USUARIO "
					+ " ,TP_ORIGEM "
					+ " ,CD_MULTI_EMPRESA"
					+ " ,CD_CORTESIA"
					+ " ,TP_SEXO"
					+ " ,CD_PRESTADOR_SOLICITANTE "
					+ " ,NM_PROFISSIONAL_SOLICITANTE "
					+ " ,NR_TELEFONE_PROFISSIONAL "
					+ " ,DS_EMAIL_PROFISSIONAL "
					+ " ,CD_TIPO_ATENDIMENTO_TISS "
					+ " ) SELECT "
					+ "  :PNOVO_NR_GUIA "
					+ " ,CD_BENEFICIARIO_TRANSITO "
					+ " ,CD_TIPO_ATENDIMENTO "
					+ " ,NR_CARTEIRA_BENEFICIARIO "
					+ " ,DS_DESTINO_CORTESIA "
					+ " ,CD_MATRICULA "
					+ " ,:PNR_GUIA "
					+ " ,CD_PRESTADOR "
					+ " ,NM_PRESTADOR "
					+ " ,NR_GUIA_PRESTADOR "
					+ " ,TP_CARATER_SOLIC_INTER "
					+ " ,TP_INTERNACAO "
					+ " ,SN_ATENDIMENTO_RECEM_NATO  "
					+ " ,SYSDATE "
					+ " ,(SYSDATE + ( SELECT NVL(NR_DIAS_VENCIMENTO_DA_GUIA,0) NR_DIAS_VENCIMENTO_DA_GUIA FROM DBAMV.MULTI_EMPRESAS_MV_SAUDE WHERE CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA))"
					+ " ,SYSDATE "
					+ " ,SYSDATE "
					+ " ,HR_PREVISAO "
					+ " ,CD_ESPECIALIDADE "
					+ " ,CD_PRESTADOR_EXECUTOR "
					+ " ,CD_PRESTADOR_ENDERECO "
					+ " ,DS_ENDERECO "
					+ " ,CD_PRESTADOR_EXECUTOR_PF "
					+ " ,CD_CID "
					+ " ,'N' "
					+ " ,DT_AUTORIZACAO "
					+ " ,CD_UNIMED_ORIGEM "
					+ " ,CD_UNIMED_EXECUTORA "
					+ " ,CD_UNIMED_SOLICITANTE "
					+ " ,CD_AUTORIZADOR "
					+ " ,DS_SENHA_AUTORIZADOR "
					+ " ,DBAPS.FNC_PROTOCOLO_ANS(NVL(DBAPS.FNC_MVS_RETORNA_VALOR_CONFIG('ATEND_PROTANS_MOTIVO_PADRAO',DBAMV.PKG_MV2000.LE_EMPRESA),9001),:PNOVO_NR_GUIA,CD_MATRICULA) "
					+ " ,(SELECT USER_ID FROM USER_USERS) "
					+ " ,'MVS' "
					+ " ,NVL(CD_MULTI_EMPRESA,DBAMV.PKG_MV2000.LE_EMPRESA)"
					+ " ,CD_CORTESIA"
					+ " ,TP_SEXO"
					+ " ,CD_PRESTADOR_SOLICITANTE"
					+ " ,NM_PROFISSIONAL_SOLICITANTE "
					+ " ,NR_TELEFONE_PROFISSIONAL "
					+ " ,DS_EMAIL_PROFISSIONAL"
					+ ",CD_TIPO_ATENDIMENTO_TISS "
					+ "  FROM DBAPS.GUIA "
					+ "  WHERE NR_GUIA = :PNR_GUIA "; 

			command = new DataCommand(sqlCommand);
			command.addParameter("PNOVO_NR_GUIA", nrGuia);
			command.addParameter("PNR_GUIA", getGuiaElement().getNrGuia());
			command.execute();
		}

		if(NBool.True.equals(retorno)){
			sqlCommand = null;
			sqlCommand =  " INSERT INTO DBAPS.ITGUIA               "
					+ "   (CD_AUTORIZADOR,                     "
					+ "    CD_FACES_DENTES_ODONTO,             "
					+ "    CD_ITGUIA,                          "
					+ "    CD_MATERIAL_FABRICANTE,             "
					+ "    CD_MOTIVO,                          "
					+ "    CD_PORTE_ANESTESICO,                "
					+ "    CD_PORTE_MEDICO,                    "
					+ "    CD_PROCEDIMENTO,                    "
					+ "    CD_PROCEDIMENTO_AUTORIZADORWEB,     "
					+ "    CD_REGIAO_DENTE,                    "
					+ "    CD_UNIDADE_MEDIDA,                  "
					+ "    CD_USUARIO_ALTERACAO_FRANQUIA,      "
					+ "    CD_USUARIO_NEGACAO,                 "
					+ "    CD_VIA_ADMINISTRACAO,               "
					+ "    DS_ERRO,                            "
					+ "    DS_JUSTIFICATIVA_ALT_FRANQ,         "
					+ "    DS_MENSAGEM_ESPECIFICA,             "
					+ "    DS_PROCEDIMENTO,                    "
					+ "    DT_ALTERACAO_FRANQUIA,              "
					+ "    DT_BAIXADO,                         "
					+ "    DT_NEGACAO,                         "
					+ "    DT_PROVAVEL,                        "
					+ "    DT_REALIZACAO,                      "
					+ "    ID_TISSSOLGUIAINTOPMS,              "
					+ "    ID_TISSSOLGUIAINTPROC,              "
					+ "    ID_TISSSOLGUIASADTSPOPMS,           "
					+ "    ID_TISSSOLGUIASADTSPPROC,           "
					+ "    NR_ANVISA,                          "
					+ "    NR_AUTORIZACAO_FUNCIONAMENTO,       "
					+ "    NR_GUIA,                            "
					+ "    NR_ORDEM_PREFERENCIA,               "
					+ "    NR_SENHA,                           "
					+ "    NR_SQ_ITEM_PTU,                     "
					+ "    QT_FRANQUIA,                        "
					+ "    QT_SOLICITADO,                      "
					+ "    QT_SOLICITADO_DIA,                  "
					+ "    QT_SOLIC_PREST,                     "
					+ "    QT_TOTAL_DOSAGEM_CICLO,             "
					+ "    SN_BAIXO_RISCO,                     "
					+ "    SN_OPMS,                            "
					+ "    SN_PACOTE_PTU,                      "
					+ "    SN_PRESTADOR_EXECUTOR_OPME,         "
					+ "    SQ_GUIA_PRORROGACAO,                "
					+ "    TP_INDICADOR_ANEXO,                 "
					+ "    TP_STATUS,                          "
					+ "    TP_STATUS_PTU_OS,                   "
					+ "    VL_COBRADO,                         "
					+ "    VL_FILME,                           "
					+ "    VL_FRANQUIA,                        "
					+ "    VL_FRANQUIA_CALCULADO,              "
					+ "    VL_MEDIO_PROCEDIMENTO,              "
					+ "    VL_PROCEDIMENTO,                    "
					+ "    VL_SERVICO,                         "
					+ "    VL_SOLICITADO,                      "
					+ "    VL_TAXA,                            "
					+ "    VL_UCO,							   "
					+ "    NR_SQ_ITEM_TISS)                    "
					+ "   SELECT                               "
					+ "    CD_AUTORIZADOR,                     "
					+ "    CD_FACES_DENTES_ODONTO,             "
					+ "    DBAPS.SEQ_CD_ITGUIA.NEXTVAL,        "
					+ "    CD_MATERIAL_FABRICANTE,             "
					+ "    CD_MOTIVO,                          "
					+ "    CD_PORTE_ANESTESICO,                "
					+ "    CD_PORTE_MEDICO,                    "
					+ "    CD_PROCEDIMENTO,                    "
					+ "    CD_PROCEDIMENTO_AUTORIZADORWEB,     "
					+ "    CD_REGIAO_DENTE,                    "
					+ "    CD_UNIDADE_MEDIDA,                  "
					+ "    CD_USUARIO_ALTERACAO_FRANQUIA,      "
					+ "    CD_USUARIO_NEGACAO,                 "
					+ "    CD_VIA_ADMINISTRACAO,               "
					+ "    DS_ERRO,                            "
					+ "    DS_JUSTIFICATIVA_ALT_FRANQ,         "
					+ "    DS_MENSAGEM_ESPECIFICA,             "
					+ "    DS_PROCEDIMENTO,                    "
					+ "    DT_ALTERACAO_FRANQUIA,              "
					+ "    NULL,                         	   "
					+ "    NULL,                               "
					+ "    DT_PROVAVEL,                        "
					+ "    DT_REALIZACAO,                      "
					+ "    ID_TISSSOLGUIAINTOPMS,              "
					+ "    ID_TISSSOLGUIAINTPROC,              "
					+ "    ID_TISSSOLGUIASADTSPOPMS,           "
					+ "    ID_TISSSOLGUIASADTSPPROC,           "
					+ "    NR_ANVISA,                          "
					+ "    NR_AUTORIZACAO_FUNCIONAMENTO,       "
					+ "    :PNOVO_NR_GUIA,                     "
					+ "    NR_ORDEM_PREFERENCIA,               "
					+ "    NR_SENHA,                           "
					+ "    NR_SQ_ITEM_PTU,                     "
					+ "    QT_FRANQUIA,                        "
					+ "    QT_SOLICITADO,                      "
					+ "    QT_SOLICITADO_DIA,                  "
					+ "    QT_SOLIC_PREST,                     "
					+ "    QT_TOTAL_DOSAGEM_CICLO,             "
					+ "    SN_BAIXO_RISCO,                     "
					+ "    SN_OPMS,                            "
					+ "    SN_PACOTE_PTU,                      "
					+ "    SN_PRESTADOR_EXECUTOR_OPME,         "
					+ "    SQ_GUIA_PRORROGACAO,                "
					+ "    TP_INDICADOR_ANEXO,                 "
					+ "    0,                          		   "
					+ "    0,                   			   "
					+ "    VL_COBRADO,                         "
					+ "    VL_FILME,                           "
					+ "    VL_FRANQUIA,                        "
					+ "    VL_FRANQUIA_CALCULADO,              "
					+ "    VL_MEDIO_PROCEDIMENTO,              "
					+ "    VL_PROCEDIMENTO,                    "
					+ "    VL_SERVICO,                         "
					+ "    VL_SOLICITADO,                      "
					+ "    VL_TAXA,                            "
					+ "    VL_UCO,							   "
					+ "    NR_SQ_ITEM_TISS 					   "
					+ "    FROM DBAPS.ITGUIA 				   "
					+ "   WHERE NR_GUIA = :PNR_GUIA    		   "; 
			command = null;
			command = new DataCommand(sqlCommand);
			command.addParameter("PNOVO_NR_GUIA", nrGuia);
			command.addParameter("PNR_GUIA", getGuiaElement().getNrGuia());
			command.execute();

		}
		
		Hashtable plId = getParameterList("GUIA");
		plId = createParameterList("GUIA");
		addParameter(plId, "NR_GUIA", nrGuia);
		NString tipoBeneficiario = this.getTask().getServices().fncRetornaTipoBeneficiario(getGuiaElement().getCdMatricula(),Lib.lpad(getGuiaElement().getNrCarteiraBeneficiario(), 16,"0"));

		if (tipoBeneficiario.equals("EV") || tipoBeneficiario.equals("ID") || tipoBeneficiario.equals("RC")) {
			addParameter(plId, "PSN_CORTESIA", "S");
		} else {
			addParameter(plId, "PSN_CORTESIA", "N");
		}

		addParameter(plId, "P_EDITAR", "S");

		TaskServices.openTask("GUIA", TaskServices.ACTIVATE, TaskServices.SESSION, TaskServices.NO_SHARE_LIBRARY_DATA, plId);

	}

	@ActionTrigger(item = "BTN_GERAR_REEMBOLSO", action = "btn_gerar_reembolso_click")
	public void btn_gerar_reembolso_click() {
		
		if (!getGuiaElement().getDspTpGuia().equals("B")) {
			getTask().getMv2000().msgAlert("Tipo de guia não é de reembolso.", "W", NBool.True);
		}
		
		if (getGuiaElement().getSnValidaRestCarencia().equals("N")) {
			//MULTI-IDIOMA: MSG_0003 - Utilize esta opção quando a guia estiver autorizada.
			String msg = ResourceManager.getString("guia.msg0003");
			getTask().getMv2000().msgAlert(msg, toStr("E"), toBool(NBool.True));
		}
		
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("DBAPS.FNC_GERA_GUIA_REEMBOLSO", DbManager.getDataBaseFactory());
		cmd.addReturnParameter(NString.class);
		cmd.addParameter("@PNR_GUIA", getGuiaElement().getNrGuia());
		cmd.execute();
		
		@SuppressWarnings("rawtypes")
		Hashtable plId = getParameterList("GUIA");
		plId = createParameterList("GUIA");
		addParameter(plId, "CD_REEMBOLSO", cmd.getReturnValue(NString.class));
		
		TaskServices.openTask("M_REEMBOLSO", TaskServices.ACTIVATE, TaskServices.SESSION, TaskServices.NO_SHARE_LIBRARY_DATA, plId);
	}

	@ValidationTrigger(item = "CD_PRESTADOR_EXTERNO")
	public void cd_prestador_externo_validation() {
		NString dsPrestadorExterno = NString.getNull();
		if (!getGuiaElement().getCdPrestadorExterno().isNull()) {
			dsPrestadorExterno = Services.getDescricao("DS_NOME", "PRESTADOR_EVENTUAL", "CD_PRESTADOR_EVENTUAL = ".concat(getGuiaElement().getCdPrestadorExterno().toString()), false);
			if (dsPrestadorExterno.isNull()) {
				//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("GUIA.CD_PRESTADOR_EXTERNO")), "W", NBool.False);
				return;
			}
		}
		getGuiaElement().setDspDsPrestadorExterno(dsPrestadorExterno);
	}

	@ValidationTrigger(item = "CD_PROGRAMA_ATENDIMENTO")
	public void cd_programa_atendimento_validation() {
		NString dsProgramaAtendimento = NString.getNull();
		if (!getGuiaElement().getCdProgramaAtendimento().isNull()) {
			
			StringBuilder sqlConsulta = new StringBuilder();
			sqlConsulta.append(" SELECT DISTINCT *                                                              ");
			sqlConsulta.append("   FROM (SELECT CD_PROGRAMA_ATENDIMENTO,                                        ");
			sqlConsulta.append("                DS_PROGRAMA_ATENDIMENTO                                         ");
			sqlConsulta.append("           FROM DBAPS.PROGRAMA_ATENDIMENTO                                      ");
			sqlConsulta.append("          WHERE TP_PROGRAMA_ATENDIMENTO IN ('R', 'A')                           ");
			sqlConsulta.append("            AND 'B' IN (SELECT TP_GUIA                                          ");
			sqlConsulta.append("                          FROM DBAPS.TIPO_ATENDIMENTO                           ");
			sqlConsulta.append("                         WHERE CD_TIPO_ATENDIMENTO = :PCD_TIPO_ATENDIMENTO)     ");
			sqlConsulta.append("         UNION ALL                                                              ");
			sqlConsulta.append("         SELECT CD_PROGRAMA_ATENDIMENTO,                                        ");
			sqlConsulta.append("                DS_PROGRAMA_ATENDIMENTO                                         ");
			sqlConsulta.append("           FROM DBAPS.PROGRAMA_ATENDIMENTO                                      ");
			sqlConsulta.append("          WHERE TP_PROGRAMA_ATENDIMENTO IN ('C', 'A')                           ");
			sqlConsulta.append("            AND 'B' NOT IN (SELECT TP_GUIA                                      ");
			sqlConsulta.append("                              FROM DBAPS.TIPO_ATENDIMENTO                       ");
			sqlConsulta.append("                             WHERE CD_TIPO_ATENDIMENTO = :PCD_TIPO_ATENDIMENTO) ");
			sqlConsulta.append("         UNION ALL                                                              ");
			sqlConsulta.append("         SELECT CD_PROGRAMA_ATENDIMENTO,                                        ");
			sqlConsulta.append("                DS_PROGRAMA_ATENDIMENTO                                         ");
			sqlConsulta.append("           FROM DBAPS.PROGRAMA_ATENDIMENTO                                      ");
			sqlConsulta.append("          WHERE TP_PROGRAMA_ATENDIMENTO IN ('A')                                ");
			sqlConsulta.append("            AND :PCD_TIPO_ATENDIMENTO IS NULL)                                  ");
			sqlConsulta.append("   WHERE CD_PROGRAMA_ATENDIMENTO = :PCD_PROGRAMA_ATENDIMENTO                    ");
			
			DataCursor cCursor = new DataCursor(sqlConsulta.toString());

			try {

				cCursor.addParameter("PCD_TIPO_ATENDIMENTO", getGuiaElement().getCdTipoAtendimento());
				cCursor.addParameter("PCD_PROGRAMA_ATENDIMENTO", getGuiaElement().getCdProgramaAtendimento());
				cCursor.open();

				if (cCursor.found()) {
					ResultSet rs = cCursor.fetchInto();
					dsProgramaAtendimento = rs.getStr("DS_PROGRAMA_ATENDIMENTO");
					getGuiaElement().setDspDsProgramaAtendimento(rs.getStr("DS_PROGRAMA_ATENDIMENTO"));
				}

			} finally {
				cCursor.close();
			}
			
			if (dsProgramaAtendimento.isNull()) {
				//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("GUIA.CD_PROGRAMA_ATENDIMENTO")), "W", NBool.False);
				return;
			}
		}
		getGuiaElement().setDspDsProgramaAtendimento(dsProgramaAtendimento);
	}

	@ValidationTrigger(item = "CD_TIPO_ATENDIMENTO_ODONTO")
	public void cd_tipo_atendimento_odonto_validation() {
		NString dsDescricao = NString.getNull();
		if (!getGuiaElement().getCdTipoAtendimentoOdonto().isNull()) {
			dsDescricao = Services.getDescricao("ds_tipo_atendimento_odonto", "mvs_tipo_atendimento_odonto", "cd_tipo_atendimento_odonto = ".concat(getGuiaElement().getCdTipoAtendimentoOdonto().toString()), false);
			if (dsDescricao.isNull()) {
				getTask().getMv2000().msgAlert("O Código do tipo de atendimento odontológico informado não existe ou não esta vigente.", "W", NBool.True);
			}
		}
		getGuiaElement().setDspDsTipoAtendimentoOdonto(dsDescricao);
	}

	@ValidationTrigger(item = "CD_TIPO_FATURAMENTO_ODONTO")
	public void cd_tipo_faturamento_odonto_validation() {
		NString dsDescricao = NString.getNull();
		if (!getGuiaElement().getCdTipoFaturamentoOdonto().isNull()) {
			dsDescricao = Services.getDescricao("ds_tipo_faturamento_odonto", "mvs_tipo_faturamento_odonto", "cd_tipo_faturamento_odonto = ".concat(getGuiaElement().getCdTipoFaturamentoOdonto().toString()), false);
			if (dsDescricao.isNull()) {
				getTask().getMv2000().msgAlert("O Código do tipo de faturamento odontológico informado não existe ou não esta vigente.", "W", NBool.True);
			}
		}
		getGuiaElement().setDspDsTipoFaturamentoOdonto(dsDescricao);
	}

	@ValidationTrigger(item = "CD_OCORRENCIA_PERICIA_INICIAL")
	public void cd_ocorrencia_pericia_inicial_validation() {
		NString dsDescricao = NString.getNull();
		if (!getGuiaElement().getCdOcorrenciaPericiaInicial().isNull()) {
			dsDescricao = Services.getDescricao("DS_CLASSIFICACAO_OCOR_GUIA", "CLASSIFICACAO_OCORRENCIA_GUIA", "CD_CLASSIFICACAO_OCOR_GUIA < 8999 AND CD_CLASSIFICACAO_OCOR_GUIA = ".concat(getGuiaElement().getCdOcorrenciaPericiaInicial().toString()), false);
			if (dsDescricao.isNull()) {
				//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("GUIA.CD_OCORRENCIA_PERICIA_INICIAL")), "W", NBool.True);
			}
		}
		getGuiaElement().setDsOcorrenciaPericiaInicial(dsDescricao);
	}

	@ValidationTrigger(item = "CD_OCORRENCIA_PERICIA_FINAL")
	public void cd_ocorrencia_pericia_final_validation() {
		NString dsDescricao = NString.getNull();
		if (!getGuiaElement().getCdOcorrenciaPericiaFinal().isNull()) {
			dsDescricao = Services.getDescricao("DS_CLASSIFICACAO_OCOR_GUIA", "CLASSIFICACAO_OCORRENCIA_GUIA", "CD_CLASSIFICACAO_OCOR_GUIA < 8999 AND CD_CLASSIFICACAO_OCOR_GUIA = ".concat(getGuiaElement().getCdOcorrenciaPericiaFinal().toString()), false);
			if (dsDescricao.isNull()) {
				//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("GUIA.CD_OCORRENCIA_PERICIA_FINAL")), "W", NBool.True);
			}
		}
		getGuiaElement().setDsOcorrenciaPericiaFinal(dsDescricao);
	}

	@ActionTrigger(item = "SN_PERICIA_INICIAL", action = "sn_pericia_inicial_change")
	public void sn_pericia_inicial_change() {
		ItemServices.setItemEnabled("GUIA.CD_OCORRENCIA_PERICIA_INICIAL", getGuiaElement().getSnPericiaInicial().equals("S"));
		if(getGuiaElement().getSnPericiaInicial().equals("N")){
			getGuiaElement().setCdOcorrenciaPericiaInicial(NNumber.getNull());
		}
		cd_ocorrencia_pericia_inicial_validation();
	}

	@ActionTrigger(item = "SN_PERICIA_FINAL", action = "sn_pericia_final_change")
	public void sn_pericia_final_change() {
		ItemServices.setItemEnabled("GUIA.CD_OCORRENCIA_PERICIA_FINAL", getGuiaElement().getSnPericiaFinal().equals("S"));
		if(getGuiaElement().getSnPericiaFinal().equals("N")){
			getGuiaElement().setCdOcorrenciaPericiaFinal(NNumber.getNull());
		}else if(getGuiaElement().getSnPericiaFinal().equals("S")){
			if (getGuiaElement().getCdOcorrenciaPericiaFinal().isNull() && !getGuiaElement().getCdOcorrenciaPericiaInicial().isNull()) {
				getGuiaElement().setCdOcorrenciaPericiaFinal(getGuiaElement().getCdOcorrenciaPericiaInicial());
			}
		}
		cd_ocorrencia_pericia_final_validation();
	}

	@ActionTrigger(item = "BTN_LIBERACAO_GTO", action = "btn_liberacao_gto_click")
	public void btn_liberacao_gto_click() {
		if (getGuiaElement().getDtLiberacaoGto().isNull()) {
			getGuiaElement().setDtLiberacaoGto(DbManager.getDBDateTime());
		}
	}

	@ActionTrigger(item = "BTN_HOME_CARE", action = "btn_home_care_click")
	public void btn_home_care_click() {
		TaskServices.callTask("PAGU/M_CENTRAL_CHAMADO_DOMICILIAR", TaskServices.HIDE, TaskServices.NO_REPLACE, TaskServices.NO_QUERY_ONLY);
	}

	@ActionTrigger(item = "BTN_ATENDIMENTO_URGENCIA", action = "btn_atendimento_urgencia_click")
	public void btn_atendimento_urgencia_click() {
		ResultSet rs = this.getTask().getServices().getCdPaciente(getGuiaElement().getCdMatricula());
		
		if(getGuiaElement().getSnValidaRestCarencia().equals("N")) {
			//MULTI-IDIOMA: MSG_0003 - Utilize esta opção quando a guia estiver autorizada.
			String msg = ResourceManager.getString("guia.msg0003");
			getTask().getMv2000().msgAlert(msg, toStr("E"), toBool(NBool.True));	
		}
		
		if(rs != null) {
			@SuppressWarnings("rawtypes")
			Hashtable plId = null;

			plId = getParameterList("GUIA");

			if (plId == null){
				plId = createParameterList("GUIA");
			}else{
				plId.clear();
			}

			if (!rs.getStr("CD_PACIENTE").isNull()) {
				addParameter(plId, "P_CD_PACIENTE",rs.getNumber("CD_PACIENTE"));
				addParameter(plId, "P_CD_CONVENIO",rs.getNumber("CD_CONVENIO"));
				addParameter(plId, "P_CD_PLANO",rs.getNumber("CD_PLANO"));
				addParameter(plId, "P_CD_PROCEDIMENTO_PRINCIPAL",getItguiaElement().getCdProcedimento());
			}else{
				addParameter(plId, "P_CD_PACIENTE", NNumber.getNull());
				addParameter(plId, "P_CD_CONVENIO", NNumber.getNull());
				addParameter(plId, "P_CD_PLANO", NNumber.getNull());
				addParameter(plId, "P_CD_PROCEDIMENTO_PRINCIPAL", NString.getNull());
			}

			callTask("PAEU/ATEURG", TaskServices.HIDE, TaskServices.NO_REPLACE, TaskServices.NO_QUERY_ONLY, plId);
		}else{
			//MULTI-IDIOMA: MSG_0092 - Não é possivel identificar o código do paciente. 
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0092"), "W", NBool.True);
		}
		
	}

	@ActionTrigger(item = "CD_TIPO_ATENDIMENTO_TISS", action = "cd_tipo_atendimento_tiss_ActionTrigger")
	public void cd_tipo_atendimento_tiss_ActionTrigger() {		
	}

	@ValidationTrigger(item = "CD_TISS_CONSELHO_PROF_SOL")
	public void cd_tiss_conselho_prof_sol_ValidationTrigger() {
		if (!getGuiaElement().getCdTissConselhoProfSol().isNull()) {
			NString service = Services.getDescricao("DS_SIGLA", "CONSELHO_PROFISSIONAL_TISS","CD_TISS = '" + getGuiaElement().getCdTissConselhoProfSol()+"'", false);

			if (service.isNull()) {
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0112"), "W", NBool.True);
			} else {
				getGuiaElement().setDspDsSiglaConselhoProfissionalTiss(service);
			}
		} else {
			getGuiaElement().setDspDsSiglaConselhoProfissionalTiss(NString.getNull());
		}
	}

	@ValidationTrigger(item = "UF_CONSELHO_PROF_SOLC")
	public void uf_conselho_prof_solc_ValidationTrigger() {
		if (!getGuiaElement().getUfConselhoProfSolc().isNull()) {
			NString service = Services.getDescricao("NM_UF", "CEP_UF","CD_UF = '" + getGuiaElement().getUfConselhoProfSolc() + "'", false);

			if (service.isNull()) {
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0113"), "W", NBool.True);
			} else {
				getGuiaElement().setDspNmUf(service);
			}
		} else {
			getGuiaElement().setDspNmUf(NString.getNull());
		}
	}

	/**
	 * Método responsável por verificar a obrigatoriedade dos campos da aba de
	 * Dados Complementares
	 */
	private void validarCamposObrigatoriosAbaDadosComplementares() {
		if (("S").equals(getGuiaElement().getDspTpGuia().toString())
				|| ("I").equals(getGuiaElement().getDspTpGuia().toString())) {
			validarCampoConselhoSolicitanteObrigatorio();
			validarCampoNumeroConselhoSolicitanteObrigatorio();
			validarCampoUFSolicitanteObrigatorio();
		}
	}
	
	private void validarCampoConselhoSolicitanteObrigatorio() {
		if (getGuiaElement().getCdTissConselhoProfSol().isNull() && isProfissionalSolicitanteInformado()) {
			ItemServices.goItem("GUIA.CD_TISS_CONSELHO_PROF_SOL");
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0109"), "W", NBool.True);
		}
	}
	
	private void validarCampoNumeroConselhoSolicitanteObrigatorio() {
		if (getGuiaElement().getNrRegConselhoProfSolic().isNull() && isProfissionalSolicitanteInformado()) {
			ItemServices.goItem("GUIA.NR_REG_CONSELHO_PROF_SOLIC");
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0110"), "W", NBool.True);
		}
	}
	
	private void validarCampoUFSolicitanteObrigatorio() {
		if (getGuiaElement().getUfConselhoProfSolc().isNull() && isProfissionalSolicitanteInformado()) {
			ItemServices.goItem("GUIA.UF_CONSELHO_PROF_SOLC");
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0111"), "W", NBool.True);
		}
	}
	
	private boolean isProfissionalSolicitanteInformado() {
		return ( !getGuiaElement().getCdPrestadorSolicitante().isNull()
				|| !getGuiaElement().getNmProfissionalSolicitante().isNull() ) && getGuiaElement().getSnValidaRestCarencia().equals("N");
	}
	
	private boolean isProfissionalExecutanteInformado() {
		return ( !getGuiaElement().getCdPrestadorExecutorPf().isNull()
				|| !getGuiaElement().getNmPrestadorExecutorPf().isNull()) && getGuiaElement().getSnValidaRestCarencia().equals("N");
	}

	@ValidationTrigger(item = "CD_IDENTIFICACAO_BENEFICIARIO")
	public void cd_identificacao_beneficiario_ValidationTrigger() {
		NString descricao = NString.getNull();
		if (!getGuiaElement().getCdIdentificacaoBeneficiario().isNull()) {
			descricao = Services.getDescricao("DS_IDENTIFICACAO_BENEFICIARIO", "IDENTIFICACAO_BENEFICIARIO", " CD_IDENTIFICACAO_BENEFICIARIO = '"+getGuiaElement().getCdIdentificacaoBeneficiario()+"'", false);
			if (descricao.isNull()) {
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("GUIA.CD_IDENTIFICACAO_BENEFICIARIO")), "W", NBool.False);
			}
		}
		getGuiaElement().setDspDsIdentificacaoBeneficiario(descricao);
		
	}

	@ValidationTrigger(item = "CD_ETAPA_AUTORIZACAO")
	public void cd_etapa_autorizacao_ValidationTrigger() {
		NString descricao = NString.getNull();
		if (!getGuiaElement().getCdEtapaAutorizacao().isNull()) {
			descricao = Services.getDescricao("DS_ETAPA_AUTORIZACAO", "ETAPA_AUTORIZACAO", "CD_ETAPA_AUTORIZACAO = " + getGuiaElement().getCdEtapaAutorizacao() , false);
			if (descricao.isNull()) {
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("GUIA.CD_ETAPA_AUTORIZACAO")), "W", NBool.False);
			}
		}
		getGuiaElement().setDspDsEtapaAutorizacao(descricao);
	}

	@ValidationTrigger(item = "CD_MOT_AUSENCIA_COD_VALIDACAO")
	public void cd_mot_ausencia_cod_validacao_ValidationTrigger() {
		NString descricao = NString.getNull();
		if (!getGuiaElement().getCdMotAusenciaCodValidacao().isNull()) {
			descricao = Services.getDescricao("DS_MOT_AUSENCIA_COD_VALIDACAO", "MOT_AUSENCIA_COD_VALIDACAO", "CD_MOT_AUSENCIA_COD_VALIDACAO = " + getGuiaElement().getCdMotAusenciaCodValidacao(), false);
			if (descricao.isNull()) {
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("GUIA.CD_MOT_AUSENCIA_COD_VALIDACAO")), "W", NBool.False);
			}
		}
		getGuiaElement().setDspDsMotAusenciaCodValidacao(descricao);
	}
	
	private void validarBeneficiarioAtivo() {
		NDate dataDesligamento = NDate.getNull();
		dataDesligamento = getTask().getMPkgMvsUsuario().getMPkgMvsUsuario()
				.fRetornaDtDesligamento(getGuiaElement().getCdMatricula());
		if (!dataDesligamento.isNull() && !getTask().getMv2000()
				.msgAlertSn(ResourceManager.getString("guia.msg0121", toChar(dataDesligamento, "DD/MM/YYYY")),
						Types.toStr("W"), ResourceManager.getString("guia.msg0057"))
				.toBoolean()) {
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0122"), "E", NBool.True);
		}
	}

	@ActionTrigger(item = "BTN_CHAT_UNIMED_BRASIL", action = "btn_chat_unimed_click")
	public void btn_chat_unimed_brasil_click() throws Exception {
		if(isEndPointSSO()){
			AutenticaUsuarioSSORequest autenticaUsuarioSSORequest = popularRequestSSOChatUnimed();
			AutorizaAcessoAplicacaoResponse autorizaAcessoAplicacaoResponse = SingleSignOnUnimed
					.autenticaAutoriza(autenticaUsuarioSSORequest);

			if (autorizaAcessoAplicacaoResponse != null && autorizaAcessoAplicacaoResponse.getUrlAcesso() != null
					&& !autorizaAcessoAplicacaoResponse.getUrlAcesso().isEmpty()) {
				abrirNovaAbaChatUnimed(autorizaAcessoAplicacaoResponse.getUrlAcesso());
			}
		} else {
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0132"), "E", NBool.True);
		}
	}
	
	private AutenticaUsuarioSSORequest popularRequestSSOChatUnimed(){
		AutenticaUsuarioSSORequest autenticaUsuarioSSORequest = new AutenticaUsuarioSSORequest();
		CtUsuarioUnimed ctUsuarioUnimed = new CtUsuarioUnimed();
		consultarDadosAutorizadorUnimedBrasil(ctUsuarioUnimed);
		
		List<CtAutorizacaoAplicacao> autorizacoes = new ArrayList<CtAutorizacaoAplicacao>();
		
		List<String> acessos = new ArrayList<String>();
		consultarDadosAcessoUnimedBrasil(acessos);
		
		CtAplicacao aplicacao = new CtAplicacao();
		consultarDadosAplicacaoUnimedBrasil(aplicacao);
		
		CtAutorizacaoAplicacao autorizacao = new CtAutorizacaoAplicacao();
		autorizacao.setAcesso(acessos);
		autorizacao.setAplicacao(aplicacao);
		
		autorizacoes.add(autorizacao);
		
		autenticaUsuarioSSORequest.setUsuario(ctUsuarioUnimed);
		autenticaUsuarioSSORequest.setAutorizacoes(autorizacoes);
		
		return autenticaUsuarioSSORequest;
	}
	
	private CtUsuarioUnimed consultarDadosAutorizadorUnimedBrasil(CtUsuarioUnimed ctUsuarioUnimed){
		StringBuilder sqlConsulta = new StringBuilder();
		sqlConsulta.append("SELECT AUT.CD_AUTORIZADOR, AUT.CD_USUARIO, MEA.CD_MULTI_EMPRESA, DS_EMAIL, DS_LOGIN, NM_AUTORIZADOR, U.CD_UNIMED, U.DS_UNIMED ");
		sqlConsulta.append("FROM DBAPS.AUTORIZADOR AUT, ");
		sqlConsulta.append("DBAPS.ME_AUTORIZADOR MEA, ");
		sqlConsulta.append("DBAPS.UNIMED U, ");
		sqlConsulta.append("DBAMV.MULTI_EMPRESAS_MV_SAUDE MEMS ");
		sqlConsulta.append("WHERE AUT.CD_USUARIO = USER ");
		sqlConsulta.append("AND AUT.CD_AUTORIZADOR = MEA.CD_AUTORIZADOR ");
		sqlConsulta.append("AND MEA.CD_MULTI_EMPRESA = MEMS.CD_MULTI_EMPRESA ");
		sqlConsulta.append("AND U.CD_UNIMED = MEMS.CD_UNIMED ");
		sqlConsulta.append("AND ROWNUM = 1");

		DataCursor cCursor = new DataCursor(sqlConsulta.toString());
		
		try {
			cCursor.open();
			if(cCursor.found()){
				ResultSet rs = cCursor.fetchInto();
				ctUsuarioUnimed.setCodigoUnimed(Long.valueOf(rs.getStr("CD_UNIMED").toString()));
				ctUsuarioUnimed.setCodigoUsuario(Long.valueOf(rs.getStr("CD_AUTORIZADOR").toString()));
				ctUsuarioUnimed.setEmail(rs.getString("DS_EMAIL").toString());
				ctUsuarioUnimed.setLogin(rs.getString("DS_LOGIN").toString());
				ctUsuarioUnimed.setNomeUnimed(rs.getString("DS_UNIMED").toString());
				ctUsuarioUnimed.setNomeUsuario(rs.getString("NM_AUTORIZADOR").toString());
			}
		} catch(Exception ex){
			logger.error(new LogTraceEvent(this, new LogTraceMessage("msgErro"), ex, LEVEL.ERROR));
		} finally {
			cCursor.close();
		}
		
		return ctUsuarioUnimed;
	}
	
	private CtAplicacao consultarDadosAplicacaoUnimedBrasil(CtAplicacao aplicacao){
		StringBuilder sqlConsulta = new StringBuilder();
		sqlConsulta.append("SELECT VALOR ");
		sqlConsulta.append("FROM DBAPS.MVS_CONFIGURACAO ");
		sqlConsulta.append("WHERE CHAVE = 'TOKEN_APLICACAO_SSO_UNIMED' ");
		sqlConsulta.append("AND CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA ");
		
		DataCursor cCursor = new DataCursor(sqlConsulta.toString());
		 try{
			 cCursor.open();
			 if(cCursor.found()){
				ResultSet rs = cCursor.fetchInto();
				aplicacao.setToken(rs.getString("VALOR"));
				aplicacao.setNomeAplicacao(CHAT_INTERCAMBIO);
			 }
		 } catch (Exception ex){
			 logger.error(new LogTraceEvent(this, new LogTraceMessage("msgErro"), ex, LEVEL.ERROR)); 
		 } finally {
			 cCursor.close();
		 }
		 
		 return aplicacao;
	}
	
	private List<String> consultarDadosAcessoUnimedBrasil(List<String> acessos){
		StringBuilder sqlConsulta = new StringBuilder();
		sqlConsulta.append("SELECT DS_ACESSO_UNIMED_BRASIL ");
		sqlConsulta.append("FROM DBAPS.ACESSO_UNIMED_BRASIL AUB, ");
		sqlConsulta.append("DBAPS.AUTORIZADOR AUT ");
		sqlConsulta.append("WHERE AUT.CD_AUTORIZADOR = AUB.CD_AUTORIZADOR ");
		sqlConsulta.append("AND AUT.CD_USUARIO = USER ");
		
		DataCursor cCursor = new DataCursor(sqlConsulta.toString());
		
		try {
			cCursor.open();
			while(true){
				ResultSet rs = cCursor.fetchInto();
				
				if(rs != null){
					acessos.add(rs.getString("DS_ACESSO_UNIMED_BRASIL"));
				} else {
					break;
				}
			}
		} catch(Exception ex){
			logger.error(new LogTraceEvent(this, new LogTraceMessage("msgErro"), ex, LEVEL.ERROR));
		} finally {
			cCursor.close();
		}
		
		return acessos;
	}
	
	private void validarCamposObrigatoriosProfissionalExecutante() {
		if (("C").equals(getGuiaElement().getDspTpGuia().toString())) {
			validarCampoConselhoExecutantebrigatorio();
			validarCampoNumeroConselhoExecutanteObrigatorio();
			validarCampoUFExecutanteObrigatorio();
			validarCampoCodigoCBOExecutanteObrigatorio();
		}
	}

	private void validarCampoConselhoExecutantebrigatorio() {
		if (getGuiaElement().getCdTissConselhoProfiExecPf().isNull() && isProfissionalExecutanteInformado()) {
			ItemServices.goItem("GUIA.CD_TISS_CONSELHO_PROFI_EXEC_PF");
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0123"), "W", NBool.True);
		}
	}

	private void validarCampoNumeroConselhoExecutanteObrigatorio() {
		if (getGuiaElement().getNrRegConselhoProfiExec().isNull() && isProfissionalExecutanteInformado()) {
			ItemServices.goItem("GUIA.NR_REG_CONSELHO_PROFI_EXEC");
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0124"), "W", NBool.True);
		}
	}

	private void validarCampoUFExecutanteObrigatorio() {
		if (getGuiaElement().getUfConselhoProfissionalExec().isNull() && isProfissionalExecutanteInformado()) {
			ItemServices.goItem("GUIA.UF_CONSELHO_PROFISSIONAL_EXEC");
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0125"), "W", NBool.True);
		}
	}

	private void validarCampoCodigoCBOExecutanteObrigatorio() {
		if (getGuiaElement().getCdEspecialidadeExecutante().isNull() && isProfissionalExecutanteInformado()) {
			ItemServices.goItem("GUIA.CD_ESPECIALIDADE_EXECUTANTE");
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0126"), "W", NBool.True);
		}
	}

	@ValidationTrigger(item = "CD_TISS_CONSELHO_PROFI_EXEC_PF")
	public void cd_tiss_conselho_profi_exec_pf_ValidationTrigger() {
		if (!getGuiaElement().getCdTissConselhoProfiExecPf().isNull()) {
			NString service = Services.getDescricao("DS_SIGLA", "CONSELHO_PROFISSIONAL_TISS",
					"CD_TISS = '" + getGuiaElement().getCdTissConselhoProfiExecPf() + "'", false);

			if (service.isNull()) {
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0127"), "W", NBool.True);
			} else {
				getGuiaElement().setDspDsTissConselhoProfiExecPf(service);
			}
		} else {
			getGuiaElement().setDspDsTissConselhoProfiExecPf(NString.getNull());
		}
	}

	@ValidationTrigger(item = "UF_CONSELHO_PROFISSIONAL_EXEC")
	public void uf_conselho_profissional_exec_ValidationTrigger() {
		if (!getGuiaElement().getUfConselhoProfissionalExec().isNull()) {
			NString service = Services.getDescricao("NM_UF", "CEP_UF",
					"CD_UF = '" + getGuiaElement().getUfConselhoProfissionalExec() + "'", false);

			if (service.isNull()) {
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0128"), "W", NBool.True);
			} else {
				getGuiaElement().setDspDsUfConselhoProfissionalExec(service);
			}
		} else {
			getGuiaElement().setDspDsUfConselhoProfissionalExec(NString.getNull());
		}
	}

	@ValidationTrigger(item = "CD_ESPECIALIDADE_EXECUTANTE")
	public void cd_especialidade_executante_ValidationTrigger() {
		if (!getGuiaElement().getCdEspecialidadeExecutante().isNull()) {
			getGuiaElement().setDspDsEspecialidadeExecutante(getTask().getServices().getDescricaoEspecialidadePrestador(
					getGuiaElement().getCdEspecialidadeExecutante(), getGuiaElement().getCdPrestadorExecutorPf()));

			if (getGuiaElement().getDspDsEspecialidadeExecutante().isNull()) {
				getTask().getMv2000().msgAlert(
						ResourceManager.getString("guia.msg0103", this.getGuiaElement().getCdEspecialidadeExecutante()),
						"E", NBool.True);
			}
		} else {
			getGuiaElement().setDspDsEspecialidadeExecutante(NString.getNull());
		}
	}
	
	private void abrirNovaAbaChatUnimed(String url){
		Task task = (Task)Task.getCurrent();
		task.addCommand(task.getCommandDescriptorFactory().createShowDocCommand(task, url, CHAT_INTERCAMBIO));
	}
	
	private boolean isEndPointSSO(){
		return !Services.getDescricao("DS_CAMINHO_SSO_CHAT_UNIMED_WS","DBAMV", "MULTI_EMPRESAS_MV_SAUDE", "CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA", false).isNull();
	}
	
	private boolean isGuiaProrrogacaoInternacao(){
		return (NString.toStr("P")).equals(getGuiaElement().getDspTpGuia());
	}

	@ValidationTrigger(item = "DSP_CD_ECOG")
	public void dsp_cd_ecog_ValidationTrigger() {
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (guiaElement != null && !guiaElement.getDspCdEcog().isNull()) {
			guiaElement.setDsEcog(this.getTask().getServices().getDescricaoEcog(guiaElement.getDspCdEcog(), true));
			setCdEcogGuia(guiaElement.getDspCdEcog());
		} else {
			guiaElement.setDsEcog(NString.getNull());
		}
	}
	
	public void setCdEcogGuia(NString codigo) {
		getGuiaElement().setCdEcog(obterEcogEmVigencia(NNumber.toNumber(codigo)));
	}
	
	private NNumber obterEcogEmVigencia(NNumber cdTiss) {
		NNumber retorno = NNumber.getNull();

		StringBuilder sqlConsulta = new StringBuilder();
		sqlConsulta.append("SELECT ECOG.CD_TIPO_ECOG FROM DBAPS.MVS_TIPO_ECOG ECOG ");
		sqlConsulta.append("WHERE ECOG.DT_INICIO_VIGENCIA IN (SELECT MAX(E.DT_INICIO_VIGENCIA) ");
		sqlConsulta.append("FROM DBAPS.MVS_TIPO_ECOG E ");
		sqlConsulta.append("WHERE ECOG.CD_TISS = E.CD_TISS ");
		sqlConsulta.append("AND E.DT_INICIO_VIGENCIA <= SYSDATE) ");
		sqlConsulta.append("AND ECOG.CD_TISS = :PCD_TISS ");

		DataCursor cursor = new DataCursor(sqlConsulta.toString());
		cursor.addParameter("PCD_TISS", cdTiss);

		try {
			cursor.open();
			ResultSet rs = cursor.fetchInto();

			if (rs != null) {
				retorno = rs.getNumber("CD_TIPO_ECOG");
			}
		} catch (Exception ex) {
			logger.error(new LogTraceEvent(this, new LogTraceMessage("msgErro"), ex, LEVEL.ERROR));
		} finally {
			cursor.close();
		}

		return retorno;
	}
	
	private NNumber obterEcogSalva(NNumber cdTipoEcog){
		NNumber retorno = NNumber.getNull();
		
		StringBuilder sqlConsulta = new StringBuilder();
		sqlConsulta.append("SELECT ECOG.CD_TISS FROM DBAPS.MVS_TIPO_ECOG ECOG ");
		sqlConsulta.append("WHERE ECOG.DT_INICIO_VIGENCIA IN (SELECT MAX(E.DT_INICIO_VIGENCIA) ");
		sqlConsulta.append("FROM DBAPS.MVS_TIPO_ECOG E ");
		sqlConsulta.append("WHERE ECOG.CD_TISS = E.CD_TISS ");
		sqlConsulta.append("AND E.DT_INICIO_VIGENCIA <= SYSDATE) ");
		sqlConsulta.append("AND ECOG.CD_TIPO_ECOG = :PCD_TIPO_ECOG ");
		
		DataCursor cursor = new DataCursor(sqlConsulta.toString());
		cursor.addParameter("PCD_TIPO_ECOG", cdTipoEcog);
		
		try {
			cursor.open();
			ResultSet rs = cursor.fetchInto();
			
			if(rs != null){
				retorno = rs.getNumber("CD_TISS");
			}
		} catch (Exception ex) {
			logger.error(new LogTraceEvent(this, new LogTraceMessage("msgErro"), ex, LEVEL.ERROR));
		} finally {
			cursor.close();
		}
		
		return retorno;
	}
	
	private void camposSolicitacaoInternacao(NString tpGuia) {
		if ((NString.toStr("I")).equals(tpGuia)) {
			setItemValue("GUIA.TP_CARATER_SOLIC_INTER", NNumber.toNumber(0));
			setItemValue("GUIA.TP_INTERNACAO", NNumber.toNumber(0));
			setItemValue("GUIA.CD_REGIME_INTERNACAO", NNumber.toNumber(0));
		}
	}

	@ActionTrigger(item = "BTN_IMPRIMIR_ANEXO_SIT_INICIAL_ODONTO", action = "imprimir_anexo_sit_inicial_odonto_click")
	public void btn_imprimir_anexo_sit_inicial_odonto_click() {
		if (getGuiaElement().getNrGuia().isNull()) {
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0143"), "W", NBool.True);
		} else {
			getTask().getModal().getPkgImprime().parametro(NString.toStr("P_NR_GUIA"),
					Lib.toChar(getGuiaElement().getNrGuia()));
			getTask().getModal().getPkgImprime().abrir(
					NString.toStr("Impressão do Anexo da Guia de Tratamento Odontológico"),
					NString.toStr("mvsaude/r_anexo_situacao_inicial_30401"), NString.toStr(null), NBool.False,
					NBool.True, NBool.True);
		}

	}

	/**
	 * Método que chama uma tela modal de Consulta Prestadores Externos
	 * 
	 * */
	@ActionTrigger(item = "BTN_PREST_EXTERNO", action = "btnPrestExterno_click")
	public void btn_prest_externo_click() {
		ItemServices.goItem("FILTRO_PREST_EXTERNO.CD_PREST_EXTERNO");
		TaskServices.executeQuery("PREST_EXTERNO");
		
	}

}
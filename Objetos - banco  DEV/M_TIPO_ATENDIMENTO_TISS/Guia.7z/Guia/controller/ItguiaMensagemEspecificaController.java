package br.com.mv.soul.mvsaude.forms.Guia.controller;

import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaAuditoriaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaMensagemEspecificaAdapter;
import br.com.mv.soul.mvsaude.libs.Services;
import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.AfterRowDelete;
import morphis.foundations.core.appdatalayer.events.AfterRowInsert;
import morphis.foundations.core.appdatalayer.events.BeforeRowDelete;
import morphis.foundations.core.appdatalayer.events.BeforeRowInsert;
import morphis.foundations.core.appdatalayer.events.BeforeRowUpdate;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
	

public class ItguiaMensagemEspecificaController extends DefaultBlockController {

	public ItguiaMensagemEspecificaController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}
	
	public ItguiaMensagemEspecificaAdapter getItguiaMensagemEspecificaElement(){
		return (ItguiaMensagemEspecificaAdapter) this.getFormModel().getItguiaMensagemEspecifica().getRowAdapter(true);
	}
	
	public ItguiaAuditoriaAdapter getItguiaAuditoriaElement(){
		return (ItguiaAuditoriaAdapter) this.getFormModel().getItguiaAuditoria().getRowAdapter(true);
	}

	@AfterQuery
	public void itguia_mensagem_especifica_AfterQuery(RowAdapterEvent rowAdapterEvent) {
		this.cd_ptu_mensagem_especifica_validation();
	}

	@BeforeRowInsert
	public void itguia_mensagem_especifica_BeforeRowInsert(RowAdapterEvent rowAdapterEvent) {
		ItguiaMensagemEspecificaAdapter row = (ItguiaMensagemEspecificaAdapter)rowAdapterEvent.getRow();
		qtdMensagemEspecifica(row);
		qtdDuplicadoMensagemEspecifica(row);
	}

	@BeforeRowUpdate
	public void itguia_mensagem_especifica_BeforeRowUpdate(RowAdapterEvent rowAdapterEvent) {
		ItguiaMensagemEspecificaAdapter row = (ItguiaMensagemEspecificaAdapter)rowAdapterEvent.getRow();
		qtdMensagemEspecifica(row);
		qtdDuplicadoMensagemEspecifica(row);
	}

	@BeforeRowDelete
	public void itguia_mensagem_especifica_BeforeRowDelete(RowAdapterEvent rowAdapterEvent) {}

	/**
	 * Não permite cadastrar mais de 4 mensagens especificas
	 * @author anderson.santos
	 * @since 01/02/2017
	 * @param row ItguiaMensagemEspecificaAdapter
	 */
	public void qtdMensagemEspecifica(ItguiaMensagemEspecificaAdapter row){
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"), "N");
		if (snOperadoraUnimed.equals("S")) {
			NNumber reg = BlockServices.getCurrentRecord("ITGUIA_MENSAGEM_ESPECIFICA");
			NNumber qtd = new NNumber(0);
			BlockServices.firstRecord();
			while (true) {
				if(!row.getRow().getStatus().toString().equals("DELETED")){
					qtd = qtd.add(1);
					if (qtd.greater(4)) {
						getTask().getMv2000().msgAlert(NString.toStr("")
								.append("Operação inválida!")
								.append(Lib.chr(10))
								.append("Motivo..: Não é permitido cadastrar mais de 4 mensagens.").toString(),
								"W", /*W = Atenção, I = Informação, E = Erro */
								NBool.True /*bloquear/travar?*/);
					}
				}
				if ( BlockServices.isInLastRecord() ) break;
				BlockServices.nextRecord(); 
			} 
			BlockServices.setCurrentRecord(reg);
		}
	}
	
	/**
	 * Verifica se existe algum registro duplicado.
	 * @author anderson.santos
	 * @since 01/02/2017
	 * @param row
	 */
	public void qtdDuplicadoMensagemEspecifica(ItguiaMensagemEspecificaAdapter row){
		if (!row.getRow().getStatus().toString().equals("DELETED")) {
			NNumber reg = BlockServices.getCurrentRecord("ITGUIA_MENSAGEM_ESPECIFICA");
			BlockServices.firstRecord();
			while (true) {
				if(!getItguiaMensagemEspecificaElement().getRow().getStatus().equals("DELETED") && !reg.equals(BlockServices.getCurrentRecord("ITGUIA_MENSAGEM_ESPECIFICA"))){
					if(row.getCdPtuMensagemEspecifica().equals(getItguiaMensagemEspecificaElement().getCdPtuMensagemEspecifica())){
						getTask().getMv2000().msgAlert(NString.toStr("")
								.append("Operação inválida!")
								.append(Lib.chr(10))
								.append("Motivo..: O código ["+row.getCdPtuMensagemEspecifica()+"] foi encontrato mais de uma vez.").toString(),
								"W", /*W = Atenção, I = Informação, E = Erro */
								NBool.True /*bloquear/travar?*/);
					}
				}
				if ( BlockServices.isInLastRecord() ) break;
				BlockServices.nextRecord(); 
			} 
			BlockServices.setCurrentRecord(reg);
		}
	}

	@AfterRowInsert
	public void itguia_mensagem_especifica_AfterRowInsert(RowAdapterEvent rowAdapterEvent) {
		if (Services.exist("ITGUIA_MENSAGEM_ESPECIFICA", "CD_ITGUIA = "+getItguiaAuditoriaElement().getCdItguia(), false)) {
			getItguiaAuditoriaElement().setTpResposta(NString.toStr("Auditada"));
		}else{
			if(getItguiaAuditoriaElement().getTpStatus().equals(4)){
				getItguiaAuditoriaElement().setTpResposta(NString.toStr("Auditada"));
			}else{
				getItguiaAuditoriaElement().setTpResposta(NString.toStr("Pendente"));
			}
		}
	}

	@AfterRowDelete
	public void itguia_mensagem_especifica_AfterRowDelete(RowAdapterEvent rowAdapterEvent) {
		if (Services.exist("ITGUIA_MENSAGEM_ESPECIFICA", "CD_ITGUIA = "+getItguiaAuditoriaElement().getCdItguia(), false)) {
			getItguiaAuditoriaElement().setTpResposta(NString.toStr("Auditada"));
		}else{
			getItguiaAuditoriaElement().setTpResposta(NString.toStr("Pendente"));
		}
	}
	
	@ValidationTrigger(item = "CD_PTU_MENSAGEM_ESPECIFICA")
	public void cd_ptu_mensagem_especifica_validation() {
		if (!getItguiaMensagemEspecificaElement().getCdPtuMensagemEspecifica().isNull()) {
			NString dsMensagem = NString.getNull();
			dsMensagem = Services.getDescricao("DS_MENSAGEM", "PTU_MENSAGEM_ESPECIFICA",
					"CD_PTU_MENSAGEM_ESPECIFICA = " + getItguiaMensagemEspecificaElement().getCdPtuMensagemEspecifica()
							+ " AND CD_PTU_MENSAGEM_ESPECIFICA BETWEEN 2001 AND 2999",
					false);
			if (!dsMensagem.isNull()) {
				getItguiaMensagemEspecificaElement().setDspDsPtuMensagemEspecifica(dsMensagem);
			} else {
				getTask().getMv2000().msgAlert(
						NString.toStr("").append("Operação inválida!").append(Lib.chr(10))
								.append("Motivo..: O código informado não foi encontrato.").toString(),
						"W", /* W = Atenção, I = Informação, E = Erro */
						NBool.True /* bloquear/travar? */);
			}
		} else {
			getItguiaMensagemEspecificaElement().setDspDsPtuMensagemEspecifica(NString.getNull());
		}
	}
}

package br.com.mv.soul.mvsaude.forms.Guia.controller;

import static morphis.foundations.core.appsupportlib.Lib.isNull;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.setBlockWhereClause;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.goItem;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.enterQuery;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.getMode;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.getUser;
import static morphis.foundations.core.types.Types.toBool;
import static morphis.foundations.core.types.Types.toNumber;
import static morphis.foundations.core.types.Types.toStr;
import static morphis.foundations.core.util.globals.Globals.setGlobal;

import java.util.EventObject;

import br.com.mv.soul.common.dbservices.PkgMv2000;
import br.com.mv.soul.common.forms.controller.DefaultFormController;
import br.com.mv.soul.common.localization.ResourceManager;
import br.com.mv.soul.flavor.runtime.action.ViewTrigger;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.services.GuiaServices;
import br.com.mv.soul.mvsaude.libs.Services;
import morphis.foundations.core.appdatalayer.data.DataCommand;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.ITask;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.MessageServices;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.ViewServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.events.TaskEnded;
import morphis.foundations.core.appsupportlib.runtime.events.TaskStarted;
import morphis.foundations.core.appsupportlib.runtime.events.TaskStartedPre;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;

public class GuiaFormController extends DefaultFormController {

	public GuiaFormController(ITask task) {

		super(task);
	}

	@Override
	public GuiaTask getTask() {

		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {

		return this.getTask().getModel();
	}
	
	@ActionTrigger(action = "getBlockDetail")
	public void getBlockDetail(){
		Services.getBlockDetail();
	}
	
	public GuiaAdapter getGuiaElement(){
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}

	@ActionTrigger(action = "Guia_search", function = KeyFunction.SEARCH)
	public void Guia_search() {

		getFormModel().getGuia().setWhereClause("");
		
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"), "N");
		NString snCortesia = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
		
		/* Cleber Kellmane - Devido a incompatibilidade da versão 16 do framework publicada em 12/09/2012, foi necessário criar um campo virtual
		 * para que possamos não exibir o numero da guia quando a mesma não estiver autorizada.
		 */
		ItemServices.setItemDisplayAsPassword("GUIA.NR_GUIA", false);
		/**
		 * @author anderson.santos
		 * @since 11/01/2017 11:33
		 * Foi criado para ter o controle sobre os campos que aparecem para realizar a consulta quando a guia e eventual ou normal.  
		 */
		this.getTask().getServices().exibirCamposOperadoraUnimed(snOperadoraUnimed.toString(),snCortesia.toString());
		GuiaServices.chkCamposBeneficiario(snCortesia.toString(),getGuiaElement());

		
		if (getMode().notEquals("ENTER-QUERY")) {
			enterQuery();
			this.getTask().getServices().exibeAlerta(false);
		}

	}

	@TaskStarted
	public void Guia_TaskStarted(EventObject args) {
		super.taskStarted(args);
		

		ViewServices.hideView("CANVAS_PRORROGACAO");
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		
		NString snEmissaoAvulsa = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
		NString snExibeValorProced = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_EXIBE_VALOR_PROCED"), "N");
				
		this.getFormModel().setParam("CD_USUARIO_ID", Services.getDescricao("USER_ID", "SYS", "USER_USERS", "1 = 1", false));
		
		this.getTask().getServices().exibeValorProced(Lib.isNull(this.getFormModel().getParam("P_SN_EXIBE_VALOR_PROCED"),snExibeValorProced).toString());

		setGlobal("HELP_ID", getTask().getAutentica().veAutorizacao(toNumber(null)));
		setGlobal("CD_USUARIO", toStr(null));
		setGlobal("NM_USUARIO", toStr(null));

		this.getFormModel().setParam("CHAMA_AUTORIZ", toStr(null));
		this.getFormModel().setParam("PRORROGACAO", toStr(null));
		this.getFormModel().setParam("PERMITE_ALT", toStr("N"));

		setGlobal("NR_GUIA", toStr(null));
		
		this.getFormModel().setParam("CD_MULTI_EMPRESA", toStr(PkgMv2000.leEmpresa()));
		this.getFormModel().setParam("CD_USUARIO", getUser());
		this.getTask().getServices().prcLbRegimeInternacao();
		this.getTask().getServices().prcLbTipoDoenca();
		this.getTask().getServices().prcLbUnidadeTempoDoenca();
		this.getTask().getServices().prcLbIndicadorAcidente();
		this.getTask().getServices().prcLbTipoAtendimentoTiss();
		this.getTask().getServices().prcLbTipoSaidaGuiaSadt();
		this.getTask().getServices().prcLbTipoConsulta();

		if (!this.getFormModel().getParam("NR_GUIA", NNumber.class).isNull()) {
			setBlockWhereClause("GUIA", toStr("GUIA.NR_GUIA = ").append(this.getFormModel().getParam("NR_GUIA", NNumber.class)));
			TaskServices.executeQuery("GUIA");
		} else {
			guiaElement.setCdMatricula(NNumber.getNull());
			guiaElement.setCdMatAlternativa(NString.getNull());
			guiaElement.setDspNmSegurado(NString.getNull());
		}

		/**
		 * @PDA 469002
		 * @author diego.nobre
		 * @since 2012-03-13
		 */
		if (!this.getFormModel().getParam("NR_GUIA_EXTERNA", NNumber.class).isNull()) {
			setBlockWhereClause("GUIA", toStr("GUIA.NR_GUIA_EXTERNA = ").append(this.getFormModel().getParam("NR_GUIA_EXTERNA", NNumber.class)));
			TaskServices.executeQuery("GUIA");
		}

		if (isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N").equals("S")) {
			setBlockWhereClause("GUIA"," CD_CORTESIA IS NOT NULL AND CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA ");
			
			ItemServices.setItemVisible("GUIA.DS_DESTINO_CORTESIA", true);
			
			ItemServices.setItemEnabled("GUIA.CD_CORTESIA", true);
			ItemServices.setItemEnabled("GUIA.CD_PLANO_PGTO_CORTESIA", true);
			ItemServices.setItemEnabled("GUIA.CD_MATRICULA_RESPONSAVEL", true);
			ItemServices.setItemEnabled("GUIA.CD_EMPRESA_RESPONSAVEL", true);
			ItemServices.setItemEnabled("GUIA.SN_AVISTA", false);
			ItemServices.setItemEnabled("GUIA.DS_DESTINO_CORTESIA", true);
			
			ItemServices.setItemRequired("GUIA.CD_CORTESIA", true);			
			
			ItemServices.setItemNavigable("GUIA.DS_DESTINO_CORTESIA", true);
			ItemServices.setItemNavigable("GUIA.NR_CARTEIRA_BENEFICIARIO", true);
			ItemServices.setItemNavigable("GUIA.CD_BENEFICIARIO_TRANSITO", true);
			ItemServices.setItemNavigable("GUIA.CD_CORTESIA", true);
			ItemServices.setItemNavigable("GUIA.CD_PLANO_PGTO_CORTESIA", true);
			ItemServices.setItemNavigable("GUIA.CD_MATRICULA_RESPONSAVEL", true);
			ItemServices.setItemNavigable("GUIA.CD_EMPRESA_RESPONSAVEL", true);
			
			ItemServices.setItemInsertAllowed("GUIA.NR_CARTEIRA_BENEFICIARIO", true);
			ItemServices.setItemInsertAllowed("GUIA.CD_BENEFICIARIO_TRANSITO", true);
			ItemServices.setItemInsertAllowed("GUIA.DS_DESTINO_CORTESIA", true);
			ItemServices.setItemInsertAllowed("GUIA.CD_CORTESIA", true);
			ItemServices.setItemInsertAllowed("GUIA.CD_PLANO_PGTO_CORTESIA", true);
			ItemServices.setItemInsertAllowed("GUIA.CD_MATRICULA_RESPONSAVEL", true);
			ItemServices.setItemInsertAllowed("GUIA.CD_EMPRESA_RESPONSAVEL", true);

			
			if (this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED").equals("S")) {
				goItem(NString.toStr("GUIA.TP_SEXO"));
				goItem(toStr("GUIA.NR_CARTEIRA_BENEFICIARIO"));
				ItemServices.setItemEnabled("GUIA.BTN_BENEFICIARIOS", false);
				ItemServices.setItemEnabled("ITGUIA.SN_PACOTE_PTU", true);
			}else{
				goItem(NString.toStr("GUIA.TP_SEXO"));
				goItem(toStr("GUIA.DS_DESTINO_CORTESIA"));
				ItemServices.setItemEnabled("GUIA.BTN_BENEFICIARIOS", true);
				
				/**
				 * Botões do PTU
				 */
				ItemServices.setItemEnabled("ITGUIA.SN_PACOTE_PTU", false);
			}
			
		} else {
			ItemServices.setItemEnabled("ITGUIA.SN_PACOTE_PTU", false);
			setBlockWhereClause("GUIA", " CD_CORTESIA IS NULL AND CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA ");
		}
		
		this.getTask().getServices().exibirCamposOperadoraUnimed(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED").toString(),snEmissaoAvulsa.toString());		

		// Global carregada na tela de entrada do call center
		NString editar = Lib.isNull(this.getFormModel().getParam("P_EDITAR", NString.class), toStr("N"));
		
		if (!this.getFormModel().getParam("P_CD_AUTORIZADOR_CALL", NNumber.class).isNull() && editar.equals("N")) {

			guiaElement.setCdAutorizador(this.getFormModel().getParam("P_CD_AUTORIZADOR_CALL", NNumber.class));
			guiaElement.setCdMatricula(this.getFormModel().getParam("P_CD_MATRICULA_CALL", NNumber.class));

			this.getFormModel().setParam("P_CD_MATRICULA_CALL", NNumber.getNull());

			if (!guiaElement.getCdMatricula().isNull()){

				ItemServices.validateItem("GUIA.CD_MATRICULA", true);
			}

			ItemServices.validateItem("GUIA.CD_AUTORIZADOR", true);
		}else if(!this.getFormModel().getParam("P_CD_MATRICULA_CALL", NNumber.class).isNull() && editar.equals("N")){
			
			guiaElement.setCdMatricula(this.getFormModel().getParam("P_CD_MATRICULA_CALL", NNumber.class));
			
			this.getFormModel().setParam("P_CD_MATRICULA_CALL", NNumber.getNull());
			
			if (!guiaElement.getCdMatricula().isNull()){
				ItemServices.validateItem("GUIA.CD_MATRICULA", true);
			}
			
		}

		//Desabilitar o botão de negativa de autorização caso tela tenha sido chamada pela tela de negativa
		if (!this.getFormModel().getParam("P_NEGATIVA_GUIA", NNumber.class).isNull()) {
			ItemServices.setItemEnabled("GUIA.BTN_NEGATIVA_GUIA", false);
		}

		if (guiaElement != null && guiaElement.getCdAutorizador().isNull()) {
			this.getTask().getServices().prcGetAutorizador(guiaElement);
		}
		
		getTask().getServices().verificaBotaoExcluirAnexo();
		
		((GuiaController)this.getTask().getFormController().getBlockController("GUIA")).sn_ordem_servico_change();
		((GuiaController)this.getTask().getFormController().getBlockController("GUIA")).camposSolicitacoes(guiaElement.getDspTpGuia());
		this.getTask().getServices().exibirGridRateioFachest();
		
	}

	@ActionTrigger(action = "Guia_WhenWindowClosed")
	public void Guia_WhenWindowClosed() {

		goItem(toStr("GUIA.CD_MATRICULA"));
	}

	@ActionTrigger(action = "Guia_save", function = KeyFunction.SAVE)
	public void Guia_save() {

		NString snEmissaoAvulsa = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"), "N");
		
		if (snEmissaoAvulsa.equals("S")) {
			if (getGuiaElement() != null && getGuiaElement().getCdMatriculaResponsavel().isNull() && getGuiaElement().getCdPlanoPgtoCortesia().isNull() && getGuiaElement().getDsDestinoCortesia().isNull()) {
				getTask().getMv2000().msgAlert(toStr("Para emitir guia avulsa é necessário informar o nome do Beneficiário Intercâmbio/Eventual/Favorecido!"), toStr("E"), toBool(NBool.True));
			}
			
			if (snOperadoraUnimed.equals("S") && getGuiaElement() != null && getGuiaElement().getNrCarteiraBeneficiario().isNull() ) {
				
				getGuiaElement().setTpOrigem(NString.toStr("AV"));
				getGuiaElement().setDspTpOrigem(toStr("Avulsa/Intercâmbio"));	
			}else if(snOperadoraUnimed.equals("S") && getGuiaElement() != null && !getGuiaElement().getNrCarteiraBeneficiario().isNull() && ( !getGuiaElement().getTpOrigem().equals("PTU") && !getGuiaElement().getTpOrigem().equals("WS") ) ){
				getGuiaElement().setTpOrigem(NString.toStr("PTU"));
				getGuiaElement().setDspTpOrigem(toStr("PTU"));
			}
			

		}
		
		if (getGuiaElement().getDtVencimento().clearTime().lesser(getGuiaElement().getDtEmissao().clearTime())) {
			if (!((getTask().getMv2000().msgAlertSn(toStr("Data do Vencimento da Guia não pode ser anterior a Data da Emissão. Deseja continuar?"), toStr("I"), toStr("Sim/Não")))).toBoolean()) {
				throw new ApplicationException();
			}
		}
		if (getGuiaElement().getDtPrevExecucao().clearTime().greater(getGuiaElement().getDtVencimento().clearTime())) {
			if (!((getTask().getMv2000().msgAlertSn(toStr("Data da Previsão da Execução da Guia Não pode ser Maior que a Data de Vencimento. Deseja continuar?"), toStr("I"), toStr("SIm/Não")))).toBoolean()) {
				throw new ApplicationException();
			}
		}			
		
		verificarCamposAnexos(getGuiaElement());
		this.getTask().getServices().setDtAltaInternacao(getGuiaElement().getNrGuia(), this.getFormModel().getCgCtrl().getDspDtAltaInternacao());
		this.getTask().getServices().setDtExecucaoInternacao(getGuiaElement().getNrGuia(), this.getFormModel().getCgCtrl().getDspDtExecucaoInternacao(), snOperadoraUnimed);
		
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if(guiaElement.getDspSnDsSenhaAutorizacao().equals("S") && guiaElement.getDsSenhaAutorizador().isNull() ){
			ItemServices.goItem("GUIA.DS_SENHA_AUTORIZADOR");
        	getTask().getMv2000().msgAlert(ResourceManager.getString("Atenção! Informe a senha para salvar a Guia."), "W", NBool.True);
		}
		
		TaskServices.commitTask();
		
	}

	public void verificarCamposAnexos(GuiaAdapter guiaElement) { 
		//Se a guia for de Quimioterapia
		if (guiaElement.getDspTpGuia().equals(toStr("Q"))) {
			StringBuilder camposQuimio = new StringBuilder();

			if (guiaElement.getNrGuiaTem().isNull() && ( !getGuiaElement().getTpOrigem().equals("PTU") && !getGuiaElement().getTpOrigem().equals("WS") ) ) {
				if (("").equals(camposQuimio.toString())) {
					camposQuimio.append("Guia Referenciada");
				} else {
					camposQuimio.append(", Guia Referenciada");
				}
			}

			if (guiaElement.getNmProfissionalSolicitante().isNull() && !getGuiaElement().getTpOrigem().equals("PTU") ) {
				if (("").equals(camposQuimio.toString())) {
					camposQuimio.append("Nome do Profissional Solicitante");
				} else {
					camposQuimio.append(", Nome do Profissional Solicitante");
				}
			}

			if (guiaElement.getNrTelefoneProfissional().isNull() && !getGuiaElement().getTpOrigem().equals("PTU") ) {
				if (("").equals(camposQuimio.toString())) {
					camposQuimio.append("Telefone do Profissional Solicitante");
				} else {
					camposQuimio.append(", Telefone do Profissional Solicitante");
				}
			}

			if (guiaElement.getNrPesoBeneficiario().isNull()) {
				if (("").equals(camposQuimio.toString())) {
					camposQuimio.append("Peso");
				} else {
					camposQuimio.append(", Peso");
				}
			}

			if (guiaElement.getNrAlturaBeneficiario().isNull()) {
				if (("").equals(camposQuimio.toString())) {
					camposQuimio.append("Altura");
				} else {
					camposQuimio.append(", Altura");
				}
			}

			if (guiaElement.getNrSuperficieCorporal().isNull()) {
				if (("").equals(camposQuimio.toString())) {
					camposQuimio.append("Superficie Corporal");
				} else {
					camposQuimio.append(", Superficie Corporal");
				}
			}

			if (guiaElement.getCdEstadiamento().isNull()) {
				if (("").equals(camposQuimio.toString())) {
					camposQuimio.append("Estadiamento");
				} else {
					camposQuimio.append(", Estadiamento");
				}
			}

			if (guiaElement.getCdQuimioterapia().isNull()) {
				if (("").equals(camposQuimio.toString())) {
					camposQuimio.append("Tipo Quimioterapia");
				} else {
					camposQuimio.append(", Tipo Quimioterapia");
				}
			}

			if (guiaElement.getCdFinalidade().isNull()) {
				if (("").equals(camposQuimio.toString())) {
					camposQuimio.append("Finalidade");
				} else {
					camposQuimio.append(", Finalidade");
				}
			}

			if (guiaElement.getCdEcog().isNull()) {
				if (("").equals(camposQuimio.toString())) {
					camposQuimio.append("ECOG");
				} else {
					camposQuimio.append(", ECOG");
				}
			}

			if (guiaElement.getNrCicloPrevisto().isNull()) {
				if (("").equals(camposQuimio.toString())) {
					camposQuimio.append("Ciclos Previsto");
				} else {
					camposQuimio.append(", Ciclos Previsto");
				}
			}

			if (guiaElement.getNrCicloAtual().isNull()) {
				if (("").equals(camposQuimio.toString())) {
					camposQuimio.append("Ciclos Atual");
				} else {
					camposQuimio.append(", Ciclos Atual");
				}
			}

			if (guiaElement.getNrIntervaloCiclo().isNull()) {
				if (("").equals(camposQuimio.toString())) {
					camposQuimio.append("Intervalo entre Ciclos");
				} else {
					camposQuimio.append(", Intervalo entre Ciclos");
				}
			}

			if (!("").equals(camposQuimio.toString())) {
				getTask().getMv2000().msgAlert(toStr(ResourceManager.getString("guia.msg0136", camposQuimio)), toStr("E"), toBool(NBool.True));
			}
			//Se a guia for de Radioterapia
		} else if (guiaElement.getDspTpGuia().equals(toStr("R"))) {
			StringBuilder camposRadio = new StringBuilder();

			if (guiaElement.getNrGuiaTem().isNull() && ( !getGuiaElement().getTpOrigem().equals("PTU") && !getGuiaElement().getTpOrigem().equals("WS") ) ) {
				if (("").equals(camposRadio.toString())) {
					camposRadio.append("Guia Referenciada");
				} else {
					camposRadio.append(", Guia Referenciada");
				}
			}

			if (guiaElement.getCdEstadiamento().isNull()) {
				if (("").equals(camposRadio.toString())) {
					camposRadio.append("Estadiamento");
				} else {
					camposRadio.append(", Estadiamento");
				}
			}

			if (guiaElement.getCdFinalidade().isNull()) {
				if (("").equals(camposRadio.toString())) {
					camposRadio.append("Finalidade");
				} else {
					camposRadio.append(", Finalidade");
				}
			}

			if (guiaElement.getCdEcog().isNull()) {
				if (("").equals(camposRadio.toString())) {
					camposRadio.append("ECOG");
				} else {
					camposRadio.append(", ECOG");
				}
			}

			if (guiaElement.getNrCamposIrradiacao().isNull()) {
				if (("").equals(camposRadio.toString())) {
					camposRadio.append("Nr Campos Irradiação");
				} else {
					camposRadio.append(", Nr Campos Irradiação");
				}
			}

			if (guiaElement.getNrDoseRadioterapicoDia().isNull()) {
				if (("").equals(camposRadio.toString())) {
					camposRadio.append("Dose por dia");
				} else {
					camposRadio.append(", Dose por dia");
				}
			}

			if (guiaElement.getNrDoseRadioterapicoTotal().isNull()) {
				if (("").equals(camposRadio.toString())) {
					camposRadio.append("Dose total");
				} else {
					camposRadio.append(", Dose total");
				}
			}

			if (guiaElement.getDtInicioAdministracao().isNull() && !getGuiaElement().getTpOrigem().equals("PTU")) {
				if (("").equals(camposRadio.toString())) {
					camposRadio.append("Data Inicio Administração");
				} else {
					camposRadio.append(", Data Inicio Administração");
				}
			}

			if (guiaElement.getNrDiasAutorizacao().isNull()) {
				if (("").equals(camposRadio.toString())) {
					camposRadio.append("Dias Autorização");
				} else {
					camposRadio.append(", Dias Autorização");
				}
			}

			if (guiaElement.getNmProfissionalSolicitante().isNull() && ( !getGuiaElement().getTpFluxoPtuWs().equals("SERVER") && !getGuiaElement().getTpOrigem().equals("PTU") )) {
				if (("").equals(camposRadio.toString())) {
					camposRadio.append("Profissional Solicitante");
				} else {
					camposRadio.append(", Profissional Solicitante");
				}
			}

			if (guiaElement.getNrTelefoneProfissional().isNull() && ( !getGuiaElement().getTpFluxoPtuWs().equals("SERVER") && !getGuiaElement().getTpOrigem().equals("PTU") )) {
				if (("").equals(camposRadio.toString())) {
					camposRadio.append("Telefone do Profissional Solicitante");
				} else {
					camposRadio.append(", Telefone do Profissional Solicitante");
				}
			}

			if (!("").equals(camposRadio.toString())) {
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0137", camposRadio), toStr("E"), toBool(NBool.True));
			}
			//Se a guia for de OPME
		} else if (guiaElement.getDspTpGuia().equals(toStr("O"))) {
			StringBuilder camposOpme = new StringBuilder();

			// numero da guia referencia é obrigatório.
			if (guiaElement.getNrGuiaTem().isNull() && ( !getGuiaElement().getTpOrigem().equals("PTU") && !getGuiaElement().getTpOrigem().equals("WS") ) ) {
				if (("").equals(camposOpme.toString())) {
					camposOpme.append("N° da guia referenciada");
				} else {
					camposOpme.append(", N° da guia referenciada");
				}
			}

			if (guiaElement.getNmProfissionalSolicitante().isNull() && ( !getGuiaElement().getTpFluxoPtuWs().equals("SERVER") && !getGuiaElement().getTpOrigem().equals("PTU") ) ) {
				if (("").equals(camposOpme.toString())) {
					camposOpme.append("Profissional Solicitante");
				} else {
					camposOpme.append(", Profissional Solicitante");
				}
			}

			if (guiaElement.getNrTelefoneProfissional().isNull() && ( !getGuiaElement().getTpFluxoPtuWs().equals("SERVER") && !getGuiaElement().getTpOrigem().equals("PTU") ) ) {
				if (("").equals(camposOpme.toString())) {
					camposOpme.append("Telefone do Profissional Solicitante");
				} else {
					camposOpme.append(", Telefone do Profissional Solicitante");
				}
			}

			if (guiaElement.getDsJustificativaTecnica().isNull()) {
				if (("").equals(camposOpme.toString())) {
					camposOpme.append("Justificativa Técnica");
				} else {
					camposOpme.append(", Justificativa Técnica");
				}
			}

			if (!("").equals(camposOpme.toString())) {
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0138", camposOpme), toStr("E"), toBool(NBool.True));
			}
		} else if(NString.toStr("P").equals(guiaElement.getDspTpGuia())){ //PRORROGAÇÃO DE INTERNAÇÃO
			StringBuilder camposProrrogacao = new StringBuilder();
			
			if(guiaElement.getNrGuiaTem().isNull()){
				camposProrrogacao.append("Guia Referenciada");
			}
			
			if(!("").equals(camposProrrogacao.toString())){
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0135", camposProrrogacao.toString()), toStr("E"), toBool(NBool.True));
			}
		}
		
	}

	@TaskEnded
	public void guia_TaskEnded(EventObject eventObject) {		
		if (!getGuiaElement().getNrGuia().isNull() && !getGuiaElement().getDtRegistroLocado().isNull()) {
			DataCommand cAtualizaLocado = new DataCommand("UPDATE DBAPS.GUIA SET DT_REGISTRO_LOCADO = NULL WHERE NR_GUIA = :P_NR_GUIA");
			cAtualizaLocado.addParameter("P_NR_GUIA", getGuiaElement().getNrGuia());
			cAtualizaLocado.execute();
		}
	}


	@ActionTrigger(action = "guia_create", function = KeyFunction.CREATE_RECORD)
	public void guia_create() {

		getFormModel().getCgCtrl().setDspVlTotalFranquia(NNumber.getNull());
		getFormModel().getCgCtrl().setDspVlTotalProcedimento(NNumber.getNull());

		this.getFormModel().setParam("P_CD_MATRICULA_CALL", NNumber.getNull());
		BlockServices.createRecord();

	}

	@ViewTrigger(context={"TAB_PRORROGACAO"})
	@ActionTrigger(action = "tab_prorrogacao_change", function=KeyFunction.WHEN_TAB_PAGE_CHANGED)
	public void tab_prorrogacao_change() {
		
	}

	@ViewTrigger(context={"CNV_TAB_GUIA"})
	@ActionTrigger(action = "cnv_tab_guia_change", function=KeyFunction.WHEN_TAB_PAGE_CHANGED)
	public void cnv_tab_guia_change() {
		NString nmAba = ViewServices.getCanvasTopMostTabPage("CNV_TAB_GUIA");
		if (nmAba.equals("PAGE_PROCEDIMENTOS")) {
			ItemServices.goItem("ITGUIA.CD_PROCEDIMENTO");
		}
		if (nmAba.equals("PAGE_DADOS")) {
			ItemServices.goItem("GUIA.NR_GUIA_EXTERNA");
		}
		if (nmAba.equals("PAGE_DIAGNOSTICO")) {
			ItemServices.goItem("GUIA.DS_DIAGNOSTICO");
		}
		if (nmAba.equals("PAGE_ALTERACAO")) {
			ItemServices.goItem("GUIA.CD_VERSAO_TISS");
		}
		if (nmAba.equals("PAGE_CORTESIA")) {
			ItemServices.goItem("GUIA.DT_NASCIMENTO");
		}
		if (nmAba.equals("PAGE_OBSERVACOES")) {
			ItemServices.goItem("GUIA.DS_AUDITORIA");
			if (Services.exist("ITGUIA", "NR_GUIA = " + getGuiaElement().getNrGuia() , false)) {				
				BlockServices.getBlockController("ITGUIA_AUDITORIA").getInteractionRulesStrategy().executeQuery();
			}
		}else if(nmAba.equals("PAGE_OCORRENCIAS")){
			ItemServices.goItem("GUIA_OCORRENCIA.ABREVIACAO_OCORRENCIA");
			if (Services.exist("GUIA_HISTORICO_RESPONSAVEL", "NR_GUIA = " + getGuiaElement().getNrGuia() , false)) {
				BlockServices.getBlockController("GUIA_HISTORICO_RESPONSAVEL").getInteractionRulesStrategy().executeQuery();
			}
			if (Services.exist("GUIA_OCORRENCIA", "NR_GUIA = " + getGuiaElement().getNrGuia() , false)) {
				BlockServices.getBlockController("GUIA_OCORRENCIA").getInteractionRulesStrategy().executeQuery();
			}
		}else if(nmAba.equals("PAGE_CHAT")){
			ItemServices.goItem("CHAT_MENSAGEM.DS_MENSAGEM");
			if (!getGuiaElement().getNrGuia().isNull()) {
				String whereClause = "NR_GUIA = " + getGuiaElement().getNrGuia() + " AND CD_PRESTADOR = " + Lib.isNull(getGuiaElement().getCdPrestadorExecutor(), getGuiaElement().getCdPrestador());
				NString cdChat = Services.getDescricao("CD_CHAT", "CHAT", whereClause, false);
				if (!cdChat.isNull()) {

					DataCommand dataCommand = new DataCommand("UPDATE DBAPS.CHAT_MENSAGEM SET TS_VISUALIZACAO = SYSDATE WHERE TP_ORIGEM = 'P' AND TS_VISUALIZACAO IS NULL AND CD_CHAT =  :PCD_CHAT ");
					dataCommand.addParameter("PCD_CHAT",cdChat);
					dataCommand.execute();
					BlockServices.getBlockController("CHAT_MENSAGEM").getInteractionRulesStrategy().executeQuery();

				}
			}
		}else if(nmAba.equals("PAGE_LOG")){
			ItemServices.goItem("LOG_AUTORIZA.DT_ACAO");
			if (!getGuiaElement().getNrGuia().isNull()) {
				
				if(!getGuiaElement().getCdPtuMensagemOrigem().isNull() && Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"), "N").equals("S")){
					if(getGuiaElement().getTpFluxoPtuWs().equals("CLIENT")){
						BlockServices.setWhereClauseParameter("LOG_TRANSACAO_PTU_ONLINE", "PNR_TRANSACAO_PRESTADORA", getGuiaElement().getCdPtuMensagemOrigem());
					}else{
						BlockServices.setWhereClauseParameter("LOG_TRANSACAO_PTU_ONLINE", "PNR_TRANSACAO_PRESTADORA", getGuiaElement().getCdPtuMensagemDestino());	
					}
					BlockServices.getBlockController("LOG_TRANSACAO_PTU_ONLINE").getInteractionRulesStrategy().executeQuery();
				}

				BlockServices.getBlockController("LOG_AUTORIZA").getInteractionRulesStrategy().executeQuery();
			}
		}else if(nmAba.equals("PAGE_REEMBOLSO")){
			ItemServices.goItem("GUIA.CD_PRESTADOR_EXTERNO");
		}else if(nmAba.equals("PAGE_ANEXOS")){
			ItemServices.goItem("GUIA_ANEXO.DS_ARQUIVO");
			if (Services.exist("GUIA_ANEXO", "NR_GUIA = " + getGuiaElement().getNrGuia() , false)) {
				BlockServices.getBlockController("GUIA_ANEXO").getInteractionRulesStrategy().executeQuery();
			}
			
		}else if(nmAba.equals("PAGE_ODONTO")){
			ItemServices.goItem("GUIA.DT_TERMINO_TRATAMENTO");
			((GuiaController)this.getTask().getFormController().getBlockController("GUIA")).sn_pericia_inicial_change();
			((GuiaController)this.getTask().getFormController().getBlockController("GUIA")).sn_pericia_final_change();
		}else if(nmAba.equals("PAGE_HISTORICO_AUT")){
			ItemServices.goItem("HISTORICO_AUT.NR_GUIA");
		}else if(nmAba.equals("PAGE_SOLICITACAO")){
			if (getGuiaElement().getDspTpGuia().equals("O")) {
				ItemServices.goItem("GUIA.DS_JUSTIFICATIVA_TECNICA");
			}else if(getGuiaElement().getDspTpGuia().equals("Q")){
				ItemServices.goItem("GUIA.NR_PESO_BENEFICIARIO");
			}else if(getGuiaElement().getDspTpGuia().equals("R")){
				ItemServices.goItem("GUIA.DT_DIAGNOSTICO");
			}
		}else if (nmAba.equals("PAGE_TAXAS")) {
			ItemServices.goItem("ITGUIA_TAXA.CD_PROCEDIMENTO");
			TaskServices.executeQuery("ITGUIA_TAXA");
			MessageServices.clearMessage();
		}
	
	}

	@TaskStartedPre
	public void guia_TaskStartedPre(EventObject eventObject) {
		super.taskStartedPre(eventObject);
		ResultSet rsConfiguracoes = null;
		
		try{
			rsConfiguracoes = this.getTask().getServices().getMultiEmpresasMvSaude();
			this.getTask().getServices().configuracoesUruguai(Lib.isNull(rsConfiguracoes.getStr("TP_PAIS"),"BRA"));
			if (rsConfiguracoes != null && rsConfiguracoes.hasData()) {
				
				this.getFormModel().setParam("P_SN_EXIBE_VALOR_PROCED", rsConfiguracoes.getStr("SN_EXIBE_VALOR_PROCED"));
				this.getFormModel().setParam("P_SN_ALERTA_AUTOMATICO", rsConfiguracoes.getStr("SN_ALERTA_AUTOMATICO"));
				this.getFormModel().setParam("SN_VALIDA_CADASTRO", rsConfiguracoes.getStr("SN_VALIDA_CADASTRO"));
				this.getFormModel().setParam("SN_DTGUIA_FUTURA", rsConfiguracoes.getStr("SN_DTGUIA_FUTURA"));
				this.getFormModel().setParam("NR_DIAS_VENCIMENTO_DA_GUIA", rsConfiguracoes.getStr("NR_DIAS_VENCIMENTO_DA_GUIA"));
				this.getFormModel().setParam("SN_OBRIGA_CPF_TITULAR", rsConfiguracoes.getStr("SN_OBRIGA_CPF_TITULAR"));
				this.getFormModel().setParam("SN_OBRIGA_CPF_DEP", rsConfiguracoes.getStr("SN_OBRIGA_CPF_DEP"));
				this.getFormModel().setParam("SN_OBRIGA_END_RESIDENCIAL", rsConfiguracoes.getStr("SN_OBRIGA_END_RESIDENCIAL"));
				this.getFormModel().setParam("P_DS_SERVIDOR_EMAIL", rsConfiguracoes.getStr("DS_SERVIDOR_EMAIL"));
				this.getFormModel().setParam("P_SN_OBRIGAR_CID", rsConfiguracoes.getStr("SN_OBRIGAR_CID"));
				
				if (this.getTask().getServices().mapaMultiEmpresaMvSaude != null) {
										
					this.getTask().getServices().mapaMultiEmpresaMvSaude.put("DS_SERVIDOR_EMAIL", rsConfiguracoes.getStr("DS_SERVIDOR_EMAIL"));
					this.getTask().getServices().mapaMultiEmpresaMvSaude.put("SN_OBRIGAR_CID", rsConfiguracoes.getStr("SN_OBRIGAR_CID"));
					this.getTask().getServices().mapaMultiEmpresaMvSaude.put("SN_LIBERA_GUIA_SEM_PAGAMENTO", rsConfiguracoes.getStr("SN_LIBERA_GUIA_SEM_PAGAMENTO"));
					this.getTask().getServices().mapaMultiEmpresaMvSaude.put("SN_OPERADORA_UNIMED", rsConfiguracoes.getStr("SN_OPERADORA_UNIMED"));
					this.getTask().getServices().mapaMultiEmpresaMvSaude.put("SN_GUIA_AUTORIZA_AUTOMATICO", rsConfiguracoes.getStr("SN_GUIA_AUTORIZA_AUTOMATICO"));
					this.getTask().getServices().mapaMultiEmpresaMvSaude.put("CD_UNIMED", rsConfiguracoes.getStr("CD_UNIMED"));
					this.getTask().getServices().mapaMultiEmpresaMvSaude.put("ATEND_GUIA_OBG_LOCAL", Lib.isNull(Services.getDescricao("VALOR", "MVS_CONFIGURACAO", "CHAVE = 'ATEND_GUIA_OBG_LOCAL' AND CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA", false), "N"));
					this.getTask().getServices().mapaMultiEmpresaMvSaude.put("TP_DATA_VENCIMENTO_GUIA", rsConfiguracoes.getStr("TP_DATA_VENCIMENTO_GUIA"));
					this.getTask().getServices().mapaMultiEmpresaMvSaude.put("NR_DIAS_VENCIMENTO_DA_GUIA", rsConfiguracoes.getStr("NR_DIAS_VENCIMENTO_DA_GUIA"));
					this.getTask().getServices().mapaMultiEmpresaMvSaude.put("SN_GUIA_AVULSA", Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N") );
					this.getTask().getServices().mapaMultiEmpresaMvSaude.put("DS_SERVIDOR_EMAIL", rsConfiguracoes.getStr("DS_SERVIDOR_EMAIL"));
					this.getTask().getServices().mapaMultiEmpresaMvSaude.put("SN_ENVIO_AUTO_SMS_LIBERA_GUIA", rsConfiguracoes.getStr("SN_ENVIO_AUTO_SMS_LIBERA_GUIA"));
					this.getTask().getServices().mapaMultiEmpresaMvSaude.put("SN_EXIBE_VALOR_PROCED", rsConfiguracoes.getStr("SN_EXIBE_VALOR_PROCED"));
					
				}
								
				ItemServices.goItem("GUIA.CD_MATRICULA");
				if (this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED").equals("S")) {
					ItemServices.goItem("GUIA.CD_MAT_ALTERNATIVA");
//					ItemServices.setItemFormatMask("GUIA.CD_MAT_ALTERNATIVA",Beneficiario.getMascaraUnimed());
//					ItemServices.setItemFormatMask("GUIA.NR_CARTEIRA_BENEFICIARIO",Beneficiario.getMascaraUnimed());
				}
				
				this.getTask().getServices().isReciprocidade(rsConfiguracoes.getString("SN_RECIPROCIDADE"));
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@ActionTrigger(action = "tab_page_change")
	public void tab_prorrogacao_tab_page_change() {
		NString nmAba = ViewServices.getCanvasTopMostTabPage("TAB_PRORROGACAO");
		if (nmAba.equals("PRORROGACAO")) {
			ItemServices.goItem("GUIA_PRORROGACAO.NR_DIAS_PRORROGADOS");
		}
		if (nmAba.equals("PRORROGACAO_TOTALIZADOR")) {
			ItemServices.goItem("GUIA.NR_GUIA_EXTERNA");
		}
	}

	@ActionTrigger(function = KeyFunction.CLEAR_FORM, action = "clear_form")
	public void guia_clear_form() {
		this.getTask().getServices().removerPiscaAlerta();
		TaskServices.clearTask();
	}

	@ActionTrigger(action = "tab_page_change")
	public void cnv_tab_odontologia_tab_page_change() {
		NString nmAba = ViewServices.getCanvasTopMostTabPage("CNV_TAB_ODONTOLOGIA");
		if (("PAGE_ODONTOLOGIA").equals(nmAba)) {
			ItemServices.goItem("GUIA.DT_TERMINO_TRATAMENTO");
		} else if (("ANEXO_SITUACAO_INICIAL").equals(nmAba)) {
			ItemServices.goItem("GUIA.NR_GUIA_ANEXO");
		}
	}
	
}

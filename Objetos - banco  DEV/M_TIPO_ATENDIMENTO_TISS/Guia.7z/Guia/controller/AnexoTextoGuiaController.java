package br.com.mv.soul.mvsaude.forms.Guia.controller;

import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import br.com.mv.soul.common.localization.ResourceManager;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class AnexoTextoGuiaController extends DefaultBlockController {

	public AnexoTextoGuiaController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}
	
	public GuiaAdapter getGuiaElement(){
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}

	@ActionTrigger(item = "BTN_OK", action = "btn_ok_click")
	public void btn_ok_click() {

		ItemServices.setItemValue("GUIA.DS_ANEXO_TEXTO", this.getFormModel().getAnexoTextoGuia().getDspDsAnexoTexto());
		ItemServices.goItem("GUIA.DS_ANEXO_TEXTO");
		//MULTI-IDIOMA: MSG_0006 - EDIÇÃO DO COMPLEMENTO COM GUIA AUTORIZADA
		NString dsFuncionalidade = NString.toStr(ResourceManager.getString("guia.msg0006"));
		TaskServices.commitTask();
		
		this.getTask().getServices().insertLog(getGuiaElement().getNrGuia()
											  , dsFuncionalidade
											  , NNumber.getNull()
											  , NString.getNull()
											  , this.getFormModel().getAnexoTextoGuia().getDspDsAnexoTextoAntigo()
											  , this.getFormModel().getAnexoTextoGuia().getDspDsAnexoTexto());
		
	}

	@ActionTrigger(item = "BTN_VOLTAR", action = "btn_voltar_click")
	public void btn_voltar_click() {
		ItemServices.goItem("GUIA.DS_ANEXO_TEXTO");
	}
}

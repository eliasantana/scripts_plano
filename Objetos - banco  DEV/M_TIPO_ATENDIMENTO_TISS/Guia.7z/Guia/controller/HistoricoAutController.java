package br.com.mv.soul.mvsaude.forms.Guia.controller;

import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.BeforeQuery;
import morphis.foundations.core.appdatalayer.events.QueryEvent;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;

import static morphis.foundations.core.appsupportlib.runtime.BlockServices.getBlockWhereClause;

import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.FiltroHistoricoAut;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.HistoricoAutAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaAdapter;
import br.com.mv.soul.mvsaude.libs.Services;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NString;
import br.com.mv.soul.common.localization.ResourceManager;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
	

public class HistoricoAutController extends DefaultBlockController {

	public HistoricoAutController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}
	
	public ItguiaAdapter getItguiaElement(){
		return (ItguiaAdapter) this.getFormModel().getItguia().getRowAdapter(true);
	}	

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}
	
	public GuiaAdapter getGuiaElement(){
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}
	
	public HistoricoAutAdapter getHistoricoAutElement(){
		return (HistoricoAutAdapter) this.getFormModel().getHistoricoAut().getRowAdapter(true);
	}
	
	FiltroHistoricoAut filtroElement = (FiltroHistoricoAut) getFormModel().getFiltroHistoricoAut();

	@BeforeQuery
	public void historico_aut_BeforeQuery(QueryEvent queryEvent) {
		NString snOperadoraUnimed = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		if (!getGuiaElement().getCdMatricula().isNull()) {		
			BlockServices.setBlockWhereClause("HISTORICO_AUT", "CD_MATRICULA = :PCD_MATRICULA ");
			BlockServices.setWhereClauseParameter("HISTORICO_AUT", "PCD_MATRICULA", getGuiaElement().getCdMatricula());
		}else if(snOperadoraUnimed.equals("S") && !getGuiaElement().getNrCarteiraBeneficiario().isNull()){
			BlockServices.setBlockWhereClause("HISTORICO_AUT", "NR_CARTEIRA_BENEFICIARIO = :PNR_CARTEIRA_BENEFICIARIO ");
			BlockServices.setWhereClauseParameter("HISTORICO_AUT", "PNR_CARTEIRA_BENEFICIARIO", getGuiaElement().getNrCarteiraBeneficiario());
		}else if(!getGuiaElement().getDsDestinoCortesia().isNull()){
			BlockServices.setBlockWhereClause("HISTORICO_AUT", "DS_DESTINO_CORTESIA = :PDS_DESTINO_CORTESIA ");
			BlockServices.setWhereClauseParameter("HISTORICO_AUT", "PDS_DESTINO_CORTESIA", getGuiaElement().getDsDestinoCortesia());
		}
		
	}

	@AfterQuery
	public void historico_aut_AfterQuery(RowAdapterEvent rowAdapterEvent) {
		HistoricoAutAdapter historicoAutAdapter = (HistoricoAutAdapter)rowAdapterEvent.getRow();
		if (!historicoAutAdapter.getCdEspecialidade().isNull()) {
			historicoAutAdapter.setDspDsEspecialidade(Services.getDescricao("DS_ESPECIALIDADE", "ESPECIALIDADE", "CD_ESPECIALIDADE = ".concat(historicoAutAdapter.getCdEspecialidade().toString()), false));
		}
		
		if (!historicoAutAdapter.getCdPrestadorExecutor().isNull()) {
			historicoAutAdapter.setDspNmPrestadorExecutor(Services.getDescricao("NM_PRESTADOR", "PRESTADOR", "CD_PRESTADOR = ".concat(historicoAutAdapter.getCdPrestadorExecutor().toString()), false));
		}
		
		cd_unimed_solicitante_ValidationTrigger();
		
	}

	@ActionTrigger(item = "BTN_CONSULTAR_HISTORICO_AUT", action = "btn_consultar_historico_aut_click")
	public void btn_consultar_historico_aut_click() {
		if (getGuiaElement().getCdMatricula().isNull() && getGuiaElement().getNrCarteiraBeneficiario().isNull() && getGuiaElement().getDsDestinoCortesia().isNull()) {
			//MULTI-IDIOMA: MSG_0084 - Não foi possivel identificar o tipo de beneficiário para realizar a busca. 
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0084"), "W", NBool.True);
		}
		
		NString sqlClause = NString.getNull();
		sqlClause = sqlClause.append("SELECT DECODE(SN_VALIDA_REST_CARENCIA, 'N', NULL, 'S', NR_GUIA) AS NR_GUIA,"
				+ " NR_GUIA AS NR_GUIA_ORIGINAL, NR_TRANSACAO,DT_EMISSAO DT_EMISSAO_HIST, DBAPS.FNC_STATUS_GUIA(NR_GUIA) TP_STATUS, CD_UNIMED_SOLICITANTE, CD_ESPECIALIDADE,"
				+ " CD_PRESTADOR_EXECUTOR, SN_VALIDA_REST_CARENCIA, TP_CARATER_SOLIC_INTER,"
				+ " DT_AUTORIZACAO, SN_ATENDIMENTO_RECEM_NATO, NR_PROTOCOLO,DS_DESTINO_CORTESIA,CD_MATRICULA,NR_CARTEIRA_BENEFICIARIO"
				+ " FROM DBAPS.GUIA");
		
		BlockServices.setBlockQueryDataSourceName("HISTORICO_AUT", sqlClause);
		BlockServices.getBlockController("HISTORICO_AUT").getInteractionRulesStrategy().executeQuery();
	
	}
	
	
	@ActionTrigger(item = "BTN_CONSULTAR_HISTORICO_AUT_REL", action = "btn_consultar_historico_aut_rel_click")
	public void btn_consultar_historico_aut_rel_click() {
		if (getGuiaElement().getCdMatricula().isNull() && getGuiaElement().getNrCarteiraBeneficiario().isNull() && getGuiaElement().getDsDestinoCortesia().isNull()) {
			//MULTI-IDIOMA: MSG_0084 - Não foi possivel identificar o tipo de beneficiário para realizar a busca. 
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0084"), "W", NBool.True);
		}
		
		NString sqlClause = NString.getNull();
		sqlClause = sqlClause.append("SELECT DECODE(SN_VALIDA_REST_CARENCIA, 'N', NULL, 'S', GUIA.NR_GUIA) AS NR_GUIA, "
				+ " GUIA.NR_GUIA AS NR_GUIA_ORIGINAL, NR_TRANSACAO,DT_EMISSAO DT_EMISSAO_HIST, DBAPS.FNC_STATUS_GUIA(GUIA.NR_GUIA) TP_STATUS, CD_UNIMED_SOLICITANTE, "
				+ " CD_ESPECIALIDADE, CD_PRESTADOR_EXECUTOR, SN_VALIDA_REST_CARENCIA, TP_CARATER_SOLIC_INTER,"
				+ " DT_AUTORIZACAO, SN_ATENDIMENTO_RECEM_NATO, NR_PROTOCOLO,DS_DESTINO_CORTESIA,CD_MATRICULA,NR_CARTEIRA_BENEFICIARIO, ITGUIA.CD_PROCEDIMENTO"
				+ " FROM DBAPS.GUIA, DBAPS.ITGUIA WHERE ITGUIA.NR_GUIA = GUIA.NR_GUIA "
				+ " AND ITGUIA.CD_PROCEDIMENTO = '"+ getItguiaElement().getCdProcedimento() +"'");
		
		BlockServices.setBlockQueryDataSourceName("HISTORICO_AUT", sqlClause);
		BlockServices.getBlockController("HISTORICO_AUT").getInteractionRulesStrategy().executeQuery();
	}

	@ActionTrigger(item = "BTN_PESQUISAR_PROCEDIMENTO", action = "btn_pesquisar_procedimento_click")
	public void btn_pesquisar_procedimento_click() {
		if (getGuiaElement().getCdMatricula().isNull() && getGuiaElement().getNrCarteiraBeneficiario().isNull() && getGuiaElement().getDsDestinoCortesia().isNull()) {
			//MULTI-IDIOMA: MSG_0084 - Não foi possivel identificar o tipo de beneficiário para realizar a busca. 
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0084"), "W", NBool.True);
		}
		
		NString sqlClause = NString.getNull();
		sqlClause = sqlClause.append("SELECT DECODE(SN_VALIDA_REST_CARENCIA, 'N', NULL, 'S', GUIA.NR_GUIA) AS NR_GUIA, "
				+ " GUIA.NR_GUIA AS NR_GUIA_ORIGINAL, NR_TRANSACAO,DT_EMISSAO DT_EMISSAO_HIST, DBAPS.FNC_STATUS_GUIA(GUIA.NR_GUIA) TP_STATUS, CD_UNIMED_SOLICITANTE, "
				+ " CD_ESPECIALIDADE, CD_PRESTADOR_EXECUTOR, SN_VALIDA_REST_CARENCIA, TP_CARATER_SOLIC_INTER,"
				+ " DT_AUTORIZACAO, SN_ATENDIMENTO_RECEM_NATO, NR_PROTOCOLO,DS_DESTINO_CORTESIA,CD_MATRICULA,NR_CARTEIRA_BENEFICIARIO, ITGUIA.CD_PROCEDIMENTO"
				+ " FROM DBAPS.GUIA, DBAPS.ITGUIA WHERE ITGUIA.NR_GUIA = GUIA.NR_GUIA "
				+ " AND ITGUIA.CD_PROCEDIMENTO = '"+  filtroElement.getCdProcedimento() +"'");
		
		BlockServices.setBlockQueryDataSourceName("HISTORICO_AUT", sqlClause);
		BlockServices.getBlockController("HISTORICO_AUT").getInteractionRulesStrategy().executeQuery();
	}	
	
	
	
	

	@ActionTrigger(item = "NR_GUIA", action = "nr_guia_doubleClick")
	public void nr_guia_doubleClick() {


		if (getHistoricoAutElement().getNrGuiaOriginal().isNull()) {
			//MULTI-IDIOMA: MSG_0009 - Informe o número da guia.
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0009"), "W", NBool.True );
		}

		this.getTask().getServices().abrirTelaGuia(getHistoricoAutElement().getNrGuiaOriginal());
	}

	@ValidationTrigger(item = "CD_UNIMED_SOLICITANTE")
	public void cd_unimed_solicitante_ValidationTrigger() {
		
		validationCdUnimedSolicitante(getHistoricoAutElement().getCdUnimedSolicitante(), true);
		
	}
	
	public void validationCdUnimedSolicitante(NString cdUnimedSolicitante, boolean validate) {
		if (!cdUnimedSolicitante.isNull()) {
			NString service = Services.getDescricao("DS_UNIMED", "DBAPS", "UNIMED", "CD_UNIMED = " + cdUnimedSolicitante, false);
			if (validate && service.isNull()) {
				String msg_01 = ResourceManager.getString("mPtuParametros.guiaHistoricoAut.msg01");
				getTask().getMv2000().msgAlert(msg_01, "W", NBool.True);
			} else {
				getHistoricoAutElement().setDspDsUnimedSolicitante(service);
			}
		} else {
			getHistoricoAutElement().setDspDsUnimedSolicitante(NString.getNull());
		}

	}
}

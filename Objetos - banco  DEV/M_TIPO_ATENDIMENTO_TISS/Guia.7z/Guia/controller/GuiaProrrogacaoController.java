package br.com.mv.soul.mvsaude.forms.Guia.controller;

import static morphis.foundations.core.appsupportlib.Lib.isNull;
import static morphis.foundations.core.appsupportlib.Lib.toChar;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.deleteRecord;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.firstRecord;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.isInLastRecord;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.nextRecord;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.setBlockDeleteAllowed;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemEnabled;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.goBlock;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.hideView;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.showView;
import static morphis.foundations.core.types.Types.toBool;
import static morphis.foundations.core.types.Types.toNumber;
import static morphis.foundations.core.types.Types.toStr;

import java.util.EventObject;
import java.util.Hashtable;

import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.BeforeRowInsert;
import morphis.foundations.core.appdatalayer.events.BeforeRowUpdate;
import morphis.foundations.core.appdatalayer.events.DeleteDetails;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.MessageServices;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.appsupportlib.runtime.events.RecordCreated;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.common.libs.DbUtils.DataList;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaProrrogacaoAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.services.GuiaServices;
import br.com.mv.soul.mvsaude.forms.Guia.services.PkgMvsGuia;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.util.Ref;
import br.com.mv.soul.common.localization.ResourceManager;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	
import br.com.mv.soul.flavor.runtime.action.ViewTrigger;


public class GuiaProrrogacaoController extends DefaultBlockController
{

	public GuiaProrrogacaoController(IFormController parentController,
			String name)
	{
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask()
	{
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel()
	{
		return this.getTask().getModel();
	}
	
	public GuiaAdapter getGuiaElement(){
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}
	
	public GuiaProrrogacaoAdapter getGuiaProrrogacaoElement(){
		return (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
	}

	@AfterQuery
	public void guiaProrrogacao_AfterQuery(RowAdapterEvent args) {

		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) args.getRow();

		if (!guiaProrrogacaoElement.getCdAutorizador().isNull()) {
			guiaProrrogacaoElement.setDspNmAutorizador(getTask().getMPkgMvsAutorizador().getMPkgMvsAutorizador()
					.fRetornaDescricao(guiaProrrogacaoElement.getCdAutorizador(),
							toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)),
							this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.False),
							toBool(NBool.False)));
		}
		if (!guiaProrrogacaoElement.getCdMotCancelamentoGuia().isNull()) {
			guiaProrrogacaoElement.setDspDsMotCancelamentoGuia(getTask().getMPkgMvsMotCancelaGuia()
					.getMPkgMvsMotCancelaGuia().fRetornaDescricao(guiaProrrogacaoElement.getCdMotCancelamentoGuia(),
							toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)),
							this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.False),
							toBool(NBool.False)));
		}

		this.getTask().getServices().prcTipAcomodacao(toStr("S"), NBool.False);

		if (guiaProrrogacaoElement.getSnAutorizado().equals("N")) {
			ItemServices.setItemStyleClass("GUIA_PRORROGACAO.DSP_SN_AUTORIZADO", BlockServices.getCurrentRecord("GUIA_PRORROGACAO").toInt32(), "Vermelho");
			guiaProrrogacaoElement.setDspSnAutorizado(toStr("Não"));
		} else {
			ItemServices.setItemStyleClass("GUIA_PRORROGACAO.DSP_SN_AUTORIZADO", BlockServices.getCurrentRecord("GUIA_PRORROGACAO").toInt32(), "Verde");
			guiaProrrogacaoElement.setDspSnAutorizado(toStr("Sim"));
		}
	}

	@ActionTrigger(action = "guiaProrrogacao_deleteRecord", function = KeyFunction.DELETE_RECORD)
	public void guiaProrrogacao_deleteRecord() {

		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);

		if (!guiaProrrogacaoElement.getSqGuiaProrrogacao().isNull()) {
			getTask().getMv2000().msgAlert(toStr("Não é possível excluir uma prorrogação. Utilize a opção ").append("'").append("3 - Cancelar").append("'").append("."), toStr("E"), toBool(NBool.True));
		} else {
			deleteRecord();
		}
	}

	@ViewTrigger(context={"CANVAS_PRORROGACAO", "PRORROGACAO"})
	@ActionTrigger(action = "guiaProrrogacao_recordChange", function=KeyFunction.RECORD_CHANGE)
	public void guiaProrrogacao_recordChange() {

		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		ItemServices.setItemEnabled("GUIA_PRORROGACAO.BTN_IMPRIME_PRORROGA", !guiaProrrogacaoElement.getSqGuiaProrrogacao().isNull());

		if (guiaProrrogacaoElement.getSnAutorizado().equals("N")) {
			ItemServices.setItemStyleClass("GUIA_PRORROGACAO.DSP_SN_AUTORIZADO", BlockServices.getCurrentRecord("GUIA_PRORROGACAO").toInt32(), "Vermelho");
		} else {
			ItemServices.setItemStyleClass("GUIA_PRORROGACAO.DSP_SN_AUTORIZADO", BlockServices.getCurrentRecord("GUIA_PRORROGACAO").toInt32(), "Verde");
		}

		this.getTask().getServices().prcHabilitaBotoes(guiaProrrogacaoElement, guiaElement, toStr("S"));

		TaskServices.executeQuery("GUIA_PRORROGACAO_TOT");
		MessageServices.clearMessage();
	}

	@DeleteDetails
	public void guiaProrrogacao_DeleteDetails(RowAdapterEvent args)
	{

		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) args
				.getRow();
		PkgMvsGuia.pBOcdmGuiaProrrogacao(guiaProrrogacaoElement);
	}

	@BeforeRowInsert
	public void guiaProrrogacao_BeforeRowInsert(RowAdapterEvent args) {

		String sqlcprorrogacao = "SELECT NVL(MAX(SQ_GUIA_PRORROGACAO), 0) + 1 " + 
								" FROM DBAPS.GUIA_PRORROGACAO " + 
								" WHERE GUIA_PRORROGACAO.NR_GUIA = :GUIA_NR_GUIA ";
		
			DataCursor cprorrogacao = new DataCursor(sqlcprorrogacao);
			
			NNumber seqProrrogacao = NNumber.toNumber(0);
			NNumber seqProrrogacaoMax = NNumber.toNumber(0);
			
			try {

				cprorrogacao.addParameter("GUIA_NR_GUIA", getGuiaElement().getNrGuia());
				cprorrogacao.open();
				
				ResultSet cprorrogacaoResults = cprorrogacao.fetchInto();
				
				if (cprorrogacaoResults != null) {
					seqProrrogacao = cprorrogacaoResults.getNumber(0);
				}
				
				IDBBusinessObject manager = getFormModel().getGuiaProrrogacao();
				for (int i = 0; i < manager.getTotalCount(); i++) {

					GuiaProrrogacaoAdapter row = (GuiaProrrogacaoAdapter) manager.getRow(i);

					if(!row.getSqGuiaProrrogacao().isNull()){
						if(seqProrrogacaoMax.lesser(row.getSqGuiaProrrogacao()) || seqProrrogacaoMax.equals(row.getSqGuiaProrrogacao())){
							seqProrrogacaoMax = row.getSqGuiaProrrogacao().add(1);
						}
					}
				}
				
				if(seqProrrogacao.greater(seqProrrogacaoMax)){
					getGuiaProrrogacaoElement().setSqGuiaProrrogacao(seqProrrogacao);
				}else{
					getGuiaProrrogacaoElement().setSqGuiaProrrogacao(seqProrrogacaoMax);
				}

								
				if (isNull(getGuiaProrrogacaoElement().getNrDiasProrrogados(), 0).notEquals(0)) {
					this.getFormModel().setParam("PRORROGACAO", toStr("S"));
					//getGuiaProrrogacaoElement().setSnAutorizado(toStr("N"));
					ItemServices.setItemStyleClass("GUIA_PRORROGACAO.DSP_SN_AUTORIZADO",BlockServices.getCurrentRecord("GUIA_PRORROGACAO").toInt32(), "Vermelho");
				} else {
					//MULTI-IDIOMA: MSG_0058 - Número de dias prorrogados não informado.
					getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0058"), "E", NBool.True);
				}
				
				this.getTask().getServices().prcHabilitaBotoes(getGuiaProrrogacaoElement(), getGuiaElement(), toStr("S"));
				
			} finally {
				cprorrogacao.close();
			}
	}

	@RecordCreated
	public void guiaProrrogacao_RecordCreated(EventObject args) {

		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (guiaElement != null
				&& guiaProrrogacaoElement != null
				&& !guiaElement.getCdTipAcomodacao().isNull() 
				&& !guiaElement.getDspDsTipAcomodacao().isNull()) {

			guiaProrrogacaoElement.setCdTipAcomodacao(guiaElement.getCdTipAcomodacao());
			guiaProrrogacaoElement.setDspTipAcomodacao(guiaElement.getDspDsTipAcomodacao());

		}
		if (guiaProrrogacaoElement.getSnAutorizado().equals("N"))
		{
			ItemServices.setItemStyleClass("GUIA_PRORROGACAO.DSP_SN_AUTORIZADO",BlockServices.getCurrentRecord("GUIA_PRORROGACAO").toInt32(), "Vermelho");
			guiaProrrogacaoElement.setDspSnAutorizado(toStr("Não"));
		}
		else
		{
			ItemServices.setItemStyleClass("GUIA_PRORROGACAO.DSP_SN_AUTORIZADO",BlockServices.getCurrentRecord("GUIA_PRORROGACAO").toInt32(), "Verde");
			guiaProrrogacaoElement.setDspSnAutorizado(toStr("Sim"));
		}
	}

	@ValidationTrigger(item = "CD_TIP_ACOMODACAO")
	public void cdTipAcomodacao_validate() {
		NString snEmisaoAvulsa = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
	
		if(snEmisaoAvulsa.equals("N")) {
			this.getTask().getServices().prcTipAcomodacao(toStr("S"), NBool.True);			
		}else if(snEmisaoAvulsa.equals("S")){
			if (!getGuiaProrrogacaoElement().getCdTipAcomodacao().isNull()) {
				ResultSet resultSet = this.getTask().getServices().cdTipoAcomodocacao_validate(getGuiaProrrogacaoElement().getCdTipAcomodacao(), getGuiaElement().getDspCdPlano());
				try{
					if(resultSet != null && resultSet.hasData()){
						getGuiaProrrogacaoElement().setDspTipAcomodacao(resultSet.getStr("DS_TIP_ACOMODACAO"));
					}
				}catch(Exception ex){
					ex.printStackTrace();
				}finally{
					if(resultSet != null){resultSet.close();}
				}
			}
		}
		
	}

	@ValidationTrigger(item = "CD_MOT_CANCELAMENTO_GUIA")
	public void cdMotCancelamentoGuia_validate() {

		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);

		guiaProrrogacaoElement.setDspDsMotCancelamentoGuia(getTask().getMPkgMvsMotCancelaGuia().getMPkgMvsMotCancelaGuia().fRetornaDescricao(guiaProrrogacaoElement.getCdMotCancelamentoGuia(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.True), toBool(NBool.True)));

	}

	@ActionTrigger(action = "btnRetorna_click", item = "BTN_RETORNA")
	public void btnRetorna_click() {

		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);

		setBlockDeleteAllowed("GUIA_PRORROGACAO", true);
		
		goBlock(toStr("GUIA_PRORROGACAO"));
		firstRecord();
	
		while (true) {
			if (isInLastRecord()) {
				if (guiaProrrogacaoElement.getSqGuiaProrrogacao().isNull()) {
					deleteRecord();
				}
				break;
			}
			if (guiaProrrogacaoElement.getSqGuiaProrrogacao().isNull()) {
				deleteRecord();
				firstRecord();
			}
			nextRecord();
		}
		setBlockDeleteAllowed("GUIA_PRORROGACAO", false);
		hideView("CANVAS_PRORROGACAO");
		goBlock(toStr("ITGUIA"));
		goBlock(toStr("GUIA"));

	}

	@SuppressWarnings({ "unused", "rawtypes" })
	@ActionTrigger(action = "btnImprimeProrroga_click", item = "BTN_IMPRIME_PRORROGA")
	public void btnImprimeProrroga_click() {

		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		Hashtable plId = null;
		NString nmProgramaProrrogacao = NString.getNull();
		Ref<DataList> vlstParamret = new Ref<DataList>(new DataList());
		if (!guiaProrrogacaoElement.getCdMotCancelamentoGuia().isNull()) {
			getTask().getMv2000().msgAlert(toStr("Prorrogação cancelada."), toStr("E"), toBool(NBool.True));
		}
		getTask().getMPkgMvsTipoAtendimento().getMPkgMvsTipoAtendimento().pRetornaDados(guiaElement.getCdTipoAtendimento(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.True), toBool(NBool.True), vlstParamret);
		nmProgramaProrrogacao = vlstParamret.val.getStr("DS_PROGRAMA_GUIA_PRORROGACAO", NBool.False);
		if (nmProgramaProrrogacao.isNull()) {
			getTask().getMv2000().chamaMensagem(toStr("Atenção"), toStr("Não existe programa de Prorrogação especificado para este tipo de Guia!"), toBool(NBool.True));
		}

		NString relatorio = NString.getNull();
		String sqlcTiss = "SELECT ITEM_TIPO_ATENDIMENTO.DS_PROGRAMA_DA_GUIA " +
				"FROM DBAPS.TIPO_ATENDIMENTO, DBAPS.ITEM_TIPO_ATENDIMENTO " +
				"WHERE TIPO_ATENDIMENTO.CD_TIPO_ATENDIMENTO = ITEM_TIPO_ATENDIMENTO.CD_TIPO_ATENDIMENTO " +
				"AND TIPO_ATENDIMENTO.CD_TIPO_ATENDIMENTO = :P_CD_TIPO_ATENDIMENTO " +
				"AND ITEM_TIPO_ATENDIMENTO.CD_VERSAO_TISS = NVL(:P_CD_VERSAO_TISS,'2.02.03')";
		DataCursor dcTiss = new DataCursor(sqlcTiss);
		dcTiss.addParameter("P_CD_TIPO_ATENDIMENTO",guiaElement.getCdTipoAtendimento());
		dcTiss.addParameter("P_CD_VERSAO_TISS",guiaElement.getCdVersaoTiss());

		try {
			dcTiss.open();
			ResultSet rsTiss = dcTiss.fetchInto();

			if (rsTiss != null) {
				relatorio = rsTiss.getStr(0);
			}
		} finally {
			dcTiss.close();
		}

		NString rep = NString.getNull();
		if (relatorio.isNull()) {
			rep = toStr("/mvsaude/").append(toStr(guiaElement.getDspDsProgramaDaGuia().replace(".REP", "")));
		} else {
			rep = toStr("/mvsaude/").append(toStr(relatorio.replace(".REP", "")));
		}

		getTask().getModal().getPkgImprime().parametro(toStr("DESNAME"), toStr(null));
		getTask().getModal().getPkgImprime().parametro(toStr("P_NR_GUIA"), toChar(guiaProrrogacaoElement.getNrGuia()));

		getTask().getModal().getPkgImprime().abrir(toStr("Impressão da Guia de Prorrogação"), rep, toStr(null), toBool(NBool.False), toBool(NBool.True), toBool(NBool.False));

	}

	@ActionTrigger(action = "btnAnalisar_click", item = "BTN_ANALISAR")
	public void btnAnalisar_click() {

		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);

		NNumber nretorno = NNumber.getNull();

		if (!guiaProrrogacaoElement.getCdMotCancelamentoGuia().isNull()) {
			getTask().getMv2000().msgAlert(toStr("Prorrogação cancelada."), toStr("E"), toBool(NBool.True));
		}

		this.getFormModel().setParam("SN_ANALISE_EXECUTADA", toStr("S"));
		TaskServices.commitTask(true);

		nretorno = this.getTask().getServices().fncAnalisarGuia(guiaProrrogacaoElement.getNrGuia(), guiaProrrogacaoElement.getSqGuiaProrrogacao(), toStr("S"));
		
		this.getTask().getServices().recarregarTela(getGuiaElement().getNrGuia());
		
		if (nretorno.equals(-(1))) {
			getTask().getMv2000().msgAlert(toStr("Análise da solicitação concluída com restrições!"), toStr("W"), toBool(NBool.False));
		} else if (nretorno.equals(0)) {
			//MULTI-IDIOMA: MSG_0008 - Guia Autorizada.
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0008"), toStr("I"), toBool(NBool.False));
		} else {
			getTask().getMv2000().msgAlert(toStr("Análise concluída. A guia será autorizada automaticamente após pagamento no caixa."), toStr("I"), toBool(NBool.False));
		}
		this.getFormModel().setParam("SN_ANALISE_EXECUTADA", toStr("N"));

	}
	
	@ActionTrigger(action = "btnSenha_click", item = "BTN_SENHA")
	public void btnSenha_click() {

		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		TaskServices.commitTask(true);
		
		if (guiaProrrogacaoElement.getSqGuiaProrrogacao().isNull()) {
			getTask().getMv2000().msgAlert(toStr("Prorrogação não cadastrada."), toStr("E"), toBool(NBool.True));
		}

		if (!guiaProrrogacaoElement.getCdMotCancelamentoGuia().isNull()) {
			getTask().getMv2000().msgAlert(toStr("Prorrogação cancelada."), toStr("E"), toBool(NBool.True));
		}

		getFormModel().getCgCtrl().setDspDsLiberacao(toStr("Liberacao da Guia de Prorrogação"));
		getFormModel().getCgCtrl().setDsSenhaAutorizacaoSemBase(toStr(null));
		getFormModel().getCgCtrl().setCdAutorizadorOpe(guiaElement.getCdAutorizador());
		getFormModel().getCgCtrl().setDspNmAutorizadorOpe(guiaElement.getDspNmAutorizador());
		
		ResultSet rs = GuiaServices.getAutorizadorLogado();
		
		if(rs != null){
			getFormModel().getCgCtrl().setCdAutorizadorOpe(rs.getNumber("CD_AUTORIZADOR"));
			getFormModel().getCgCtrl().setDspNmAutorizadorOpe(rs.getStr("NM_AUTORIZADOR"));	
		}
		
		getFormModel().getCgCtrl().setSnCancelaAutorizacao(toStr("N"));
		getFormModel().getCgCtrl().setCdMotCancelamento(toNumber(null));
		getFormModel().getCgCtrl().setDspDsMotCancelamento(toStr(null));
		
		this.getFormModel().setParam("CHAMA_AUTORIZ", toStr("P"));
		this.getTask().getServices().configuraSolicitacaoSenha(NString.toStr("P"));

	}

	@ActionTrigger(action = "btnCancelar_click", item = "BTN_CANCELAR")
	public void btnCancelar_click() {

		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if (guiaProrrogacaoElement.getSqGuiaProrrogacao().isNull()) {
			getTask().getMv2000().msgAlert(toStr("Prorrogação não cadastrada."), toStr("E"), toBool(NBool.True));
		}

		if (!guiaProrrogacaoElement.getCdMotCancelamentoGuia().isNull()) {
			getTask().getMv2000().msgAlert(toStr("Prorrogação cancelada."), toStr("E"), toBool(NBool.True));
		}

		getFormModel().getCgCtrl().setDspDsLiberacao(toStr("Negativa/Cancelamento da Guia de Prorrogação"));
		getFormModel().getCgCtrl().setDsSenhaAutorizacaoSemBase(toStr(null));
		getFormModel().getCgCtrl().setCdAutorizadorOpe(guiaElement.getCdAutorizador());
		getFormModel().getCgCtrl().setDspNmAutorizadorOpe(guiaElement.getDspNmAutorizador());
		
		ResultSet rs = GuiaServices.getAutorizadorLogado();
		
		if(rs != null){
			getFormModel().getCgCtrl().setCdAutorizadorOpe(rs.getNumber("CD_AUTORIZADOR"));
			getFormModel().getCgCtrl().setDspNmAutorizadorOpe(rs.getStr("NM_AUTORIZADOR"));	
		}
		
		getFormModel().getCgCtrl().setSnCancelaAutorizacao(toStr("N"));
		getFormModel().getCgCtrl().setCdMotCancelamento(toNumber(null));
		getFormModel().getCgCtrl().setDspDsMotCancelamento(toStr(null));

		this.getFormModel().setParam("CHAMA_AUTORIZ", toStr("R"));

		this.getTask().getServices().configuraSolicitacaoSenha(NString.toStr("R"));

	}

	@BeforeRowUpdate
	public void guia_prorrogacao_BeforeRowUpdate(RowAdapterEvent rowAdapterEvent) {

		GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);

		if (guiaProrrogacaoElement.getNrDiasProrrogados().isNull() || guiaProrrogacaoElement.getNrDiasProrrogados().equals(0)) {
			this.getTask().getMv2000().msgAlert(toStr("Favor informar a quantidade de dias a ser prorrogado!"), toStr("E"), toBool(NBool.False));
		}

	}

}

package br.com.mv.soul.mvsaude.forms.Guia.controller;

import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.common.localization.ResourceManager;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaExecucaoAdapter;
import br.com.mv.soul.mvsaude.libs.Services;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
import morphis.foundations.core.appdatalayer.data.DbManager;
	

public class ItguiaExecucaoController extends DefaultBlockController {

	public ItguiaExecucaoController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}
	
	public ItguiaExecucaoAdapter getItguiaExecucaoElement(){
		return (ItguiaExecucaoAdapter) this.getFormModel().getItguiaExecucao().getRowAdapter(true);
	}
	
	public GuiaAdapter getGuiaElement(){
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}

	@ValidationTrigger(item = "CD_PRESTADOR_EXECUTOR")
	public void cd_prestador_executor_validation() {}

	@ValidationTrigger(item = "CD_AUTORIZADOR")
	public void cd_autorizador_validation() {}

	@ActionTrigger(item = "BTN_VOLTAR_ITGUIA_EXECUCAO", action = "btn_voltar_itguia_execucao_click")
	public void btn_voltar_itguia_execucao_click() {
		ItemServices.goItem("ITGUIA.BTN_ITGUIA_EXECUCAO");
	}

	@AfterQuery
	public void itguia_execucao_AfterQuery(RowAdapterEvent rowAdapterEvent) {

		if (!getItguiaExecucaoElement().getCdPrestadorExecutor().isNull()) {
			getItguiaExecucaoElement().setDspNmPrestador(Services.getDescricao("NM_PRESTADOR", "PRESTADOR", "CD_PRESTADOR = " +getItguiaExecucaoElement().getCdPrestadorExecutor(), false) );
		}
		
		if (!getItguiaExecucaoElement().getCdAutorizador().isNull()) {
			getItguiaExecucaoElement().setDspNmAutorizador(Services.getDescricao("NM_AUTORIZADOR", "AUTORIZADOR", "CD_AUTORIZADOR = " +getItguiaExecucaoElement().getCdAutorizador(), false) );
		}
		
	}

	@ActionTrigger(item = "BTN_IMPRIME_RECIBO_EXECUCAO", action = "btn_imprime_recibo_execucao_click")
	public void btn_imprime_recibo_execucao_click() {

		if (!getGuiaElement().getNrGuia().isNull() && !getItguiaExecucaoElement().getCdItguia().isNull()) {
			getTask().getModal().getPkgImprime().parametro(NString.toStr("DESNAME"), NString.toStr(null));
			getTask().getModal().getPkgImprime().parametro(NString.toStr("PNR_GUIA"), getGuiaElement().getNrGuia());
			getTask().getModal().getPkgImprime().parametro(NString.toStr("PCD_ITGUIA"), getItguiaExecucaoElement().getCdItguia());
			getTask().getModal().getPkgImprime().abrir(NString.toStr("Impressão do Recibo de Execução"), NString.toStr("mvsaude/r_recibo_execucao"), NString.toStr(null), NBool.False, NBool.True, NBool.True);
		}
	}

	@ActionTrigger(item = "BTN_CANCELAR_EXECUCAO", action = "btn_cancelar_execucao_ActionTrigger")
	public void btn_cancelar_execucao_ActionTrigger() {
		
		if (!getItguiaExecucaoElement().getDtCancelamento().isNull()) {
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0117"), "W", NBool.True);
		}
		
		boolean cancelar = getTask().getMv2000().msgAlertSn(ResourceManager.getString("guia.msg0118"), NString.toStr("W"), ResourceManager.getString("guia.msg0057")).toBoolean();

		if (cancelar) {
			getItguiaExecucaoElement().setDtCancelamento(DbManager.getDBDateTime());
			getItguiaExecucaoElement().setCdUsuario(NString.toStr(DbManager.getUser()));
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0119"), "I", NBool.False);
			TaskServices.commitTask(true);
		}
		
	}
}

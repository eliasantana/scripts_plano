package br.com.mv.soul.mvsaude.forms.Guia.controller;

import java.io.File;
import java.util.EventObject;

import morphis.foundations.core.appdatalayer.data.DataCommand;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.BeforeQuery;
import morphis.foundations.core.appdatalayer.events.BeforeRowDelete;
import morphis.foundations.core.appdatalayer.events.BeforeRowInsert;
import morphis.foundations.core.appdatalayer.events.BeforeRowUpdate;
import morphis.foundations.core.appdatalayer.events.QueryComplete;
import morphis.foundations.core.appdatalayer.events.QueryEvent;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.MessageServices;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.ChatMensagemAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.libs.Services;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import br.com.mv.soul.common.localization.ResourceManager;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import br.com.mv.soul.flavor.runtime.action.ViewTrigger;

public class ChatMensagemController extends DefaultBlockController {

	public ChatMensagemController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}
	
	public GuiaAdapter getGuiaElement(){
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}
	
	public ChatMensagemAdapter getChatMensagemElement(){
		return (ChatMensagemAdapter) this.getFormModel().getChatMensagem().getRowAdapter(true);
	}

	@BeforeRowInsert
	public void chat_mensagem_BeforeRowInsert(RowAdapterEvent rowAdapterEvent) {
		
		ChatMensagemAdapter chatMensagemElement  = ( ChatMensagemAdapter ) rowAdapterEvent.getRow();
		
		if (getGuiaElement().getCdPrestadorExecutor().isNull() && getGuiaElement().getCdPrestador().isNull()) {
			//MULTI-IDIOMA: MSG_0040 - Informe um Prestador para inicializar o Chat.
			String msg = ResourceManager.getString("guia.msg0040");
			getTask().getMv2000().msgAlert(msg, "W", NBool.True);
		}
		
		if (chatMensagemElement.getDsMensagem().isNull()) {
			//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0089", ItemServices.getItemLabel("CHAT_MENSAGEM.DS_MENSAGEM")), "W", NBool.True);
		}
		
		String whereClause = "NR_GUIA = " + getGuiaElement().getNrGuia() + " AND CD_PRESTADOR = " + Lib.isNull(getGuiaElement().getCdPrestadorExecutor(),getGuiaElement().getCdPrestador());
		NNumber cdChat = NNumber.toNumber(Services.getDescricao("CD_CHAT", "CHAT", whereClause, false));

		if (cdChat.isNull()) {
			cdChat = NNumber.toNumber(Services.getDescricao("DBAPS.SEQ_CHAT.NEXTVAL", "SYS","DUAL", "1 = 1", false));
			String sqlCommand = "INSERT INTO DBAPS.CHAT (CD_CHAT, CD_PRESTADOR, NR_GUIA) VALUES (:PCD_CHAT,:PCD_PRESTADOR,:PNR_GUIA) ";
			DataCommand command = new DataCommand(sqlCommand);
			command.addParameter("PCD_CHAT",cdChat);
			command.addParameter("PCD_PRESTADOR", Lib.isNull(getGuiaElement().getCdPrestadorExecutor(),getGuiaElement().getCdPrestador()) );
			command.addParameter("PNR_GUIA",getGuiaElement().getNrGuia());
			command.execute();
			
		}
		
		chatMensagemElement.setCdChat(cdChat);
		chatMensagemElement.setCdUsuario(NString.toStr(DbManager.getUser()));
		chatMensagemElement.setTsCriacao(DbManager.getDBDateTime());
		chatMensagemElement.setTsVisualizacao(NDate.getNull());
		chatMensagemElement.setSnAtendido(NString.toStr("N"));
		
		
		DataCommand dataCommand = new DataCommand("UPDATE DBAPS.CHAT_MENSAGEM SET TS_VISUALIZACAO = SYSDATE WHERE TP_ORIGEM = 'P' AND TS_VISUALIZACAO IS NULL AND CD_CHAT =  :PCD_CHAT ");
		dataCommand.addParameter("PCD_CHAT",cdChat);
		dataCommand.execute();
	}

	@BeforeRowUpdate
	public void chat_mensagem_BeforeRowUpdate(RowAdapterEvent rowAdapterEvent) {
		ChatMensagemAdapter chatMensagemElement  = ( ChatMensagemAdapter ) rowAdapterEvent.getRow();
		
		if (chatMensagemElement.getDsMensagem().isNull()) {
			//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0089", ItemServices.getItemLabel("CHAT_MENSAGEM.DS_MENSAGEM")), "W", NBool.True);
		}
	}

	@BeforeRowDelete
	public void chat_mensagem_BeforeRowDelete(RowAdapterEvent rowAdapterEvent) {}

	@BeforeQuery
	public void chat_mensagem_BeforeQuery(QueryEvent queryEvent) {
		
		BlockServices.setWhereClauseParameter("CHAT_MENSAGEM", "PNR_GUIA", getGuiaElement().getNrGuia());
		BlockServices.setWhereClauseParameter("CHAT_MENSAGEM", "PCD_PRESTADOR", Lib.isNull(getGuiaElement().getCdPrestadorExecutor(),getGuiaElement().getCdPrestador()));
	}

	@AfterQuery
	public void chat_mensagem_AfterQuery(RowAdapterEvent rowAdapterEvent) {
		ChatMensagemAdapter chatMensagemAdapter = (ChatMensagemAdapter)rowAdapterEvent.getRow();
		chatMensagemAdapter.setDspSnAnexo(NString.toStr("N"));
		if (!chatMensagemAdapter.getDsArquivo().isNull()) {
			chatMensagemAdapter.setDspSnAnexo(NString.toStr("S"));
		}
	}

	@QueryComplete
	public void chat_mensagem_QueryComplete(EventObject eventObject) {
	}

	@ActionTrigger(item = "BTN_SINCRONIZA_CHAT", action = "btn_sincroniza_chat_click")
	public void btn_sincroniza_chat_click() {
		String whereClause = "NR_GUIA = " + getGuiaElement().getNrGuia() + " AND CD_PRESTADOR = " + Lib.isNull(getGuiaElement().getCdPrestadorExecutor(),getGuiaElement().getCdPrestador());
		NString cdChat = Services.getDescricao("CD_CHAT", "CHAT", whereClause, false);
		if (!cdChat.isNull()) {
			
			DataCommand dataCommand = new DataCommand("UPDATE DBAPS.CHAT_MENSAGEM SET TS_VISUALIZACAO = SYSDATE WHERE TP_ORIGEM = 'P' AND TS_VISUALIZACAO IS NULL AND CD_CHAT =  :PCD_CHAT ");
			dataCommand.addParameter("PCD_CHAT",cdChat);
			dataCommand.execute();
			
			BlockServices.getBlockController("CHAT_MENSAGEM").getInteractionRulesStrategy().executeQuery();
			
		}
	}

	@ActionTrigger(item = "BTN_ANEXO", action = "btn_anexo_click")
	public void btn_anexo_click() {
		getChatMensagemElement().setDsArquivo(getChatMensagemElement().getBtnAnexo());
		if(getChatMensagemElement().getTpOrigem().equals("P")){
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0090"), "W", NBool.True);
		}
		
		if (getGuiaElement().getCdPrestadorExecutor().isNull() && getGuiaElement().getCdPrestador().isNull()) {
			String msg = ResourceManager.getString("guia.msg0040");
			getTask().getMv2000().msgAlert(msg, "W", NBool.True);
		}
		
		if (getChatMensagemElement().getDsMensagem().isNull()) {
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0089", ItemServices.getItemLabel("CHAT_MENSAGEM.DS_MENSAGEM")), "W", NBool.True);
		}
		
		String whereClause = "NR_GUIA = " + getGuiaElement().getNrGuia() + " AND CD_PRESTADOR = " + Lib.isNull(getGuiaElement().getCdPrestadorExecutor(),getGuiaElement().getCdPrestador());
		NString cdChat = Services.getDescricao("CD_CHAT", "CHAT", whereClause, false);
		
		if (cdChat.isNull()) {
			TaskServices.commitTask();
			cdChat = NString.toStr(getChatMensagemElement().getCdChat());
		}
		
		NString dsCaminhoPastaDb = Services.getDescricao("DS_CAMINHO_PASTA_BD","DBAMV","MULTI_EMPRESAS_MV_SAUDE", "CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA", false);
		dsCaminhoPastaDb = dsCaminhoPastaDb.append("autweb\\\\").append(Lib.isNull(getGuiaElement().getCdPrestadorExecutor(),getGuiaElement().getCdPrestador())).append("\\\\").append("chat").append("\\\\").append(cdChat).append("\\\\");
		
		try {
			getChatMensagemElement().setDspSnAnexo(NString.toStr("S"));
			NString nmArquivo = NString.toStr(Services.uploadFile(getChatMensagemElement().getDsArquivo().toString(), dsCaminhoPastaDb.toString(), true));
			getChatMensagemElement().setDsArquivo(nmArquivo);
			BlockServices.getBlockController("CHAT_MENSAGEM").getInteractionRulesStrategy().commit(true);
			MessageServices.clearMessage();
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0097",nmArquivo), NString.toStr("I"), NBool.False);
		} catch (Exception e) {
			e.printStackTrace();
			getTask().getMv2000().msgAlert(e.getMessage(), "E", NBool.True);
		}
		
	}

	@ActionTrigger(item = "BTN_REMOVER_ANEXO", action = "btn_remover_anexo_click")
	public void btn_remover_anexo_click() {
		
		if(getChatMensagemElement().getTpOrigem().equals("P")){
			//MULTI-IDIOMA: MSG_0091 - Não é possivel anexar ou remover arquivos quando a origem e do Prestador.
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0091"), "W", NBool.True);
		}

		NString dsCaminhoPastaDb = Services.getDescricao("DS_CAMINHO_PASTA_BD","DBAMV","MULTI_EMPRESAS_MV_SAUDE", "CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA", false);
		dsCaminhoPastaDb = dsCaminhoPastaDb.append("autweb\\\\").append(Lib.isNull(getGuiaElement().getCdPrestadorExecutor(),getGuiaElement().getCdPrestador())).append("\\\\").append("chat").append("\\\\").append(getChatMensagemElement().getCdChat()).append("\\\\").append(getChatMensagemElement().getDsArquivo());
		try {
			Services.deleteFile(dsCaminhoPastaDb.toString(), true);
			getChatMensagemElement().setDspSnAnexo(NString.toStr("N"));
			getChatMensagemElement().setDsArquivo(NString.getNull());
			BlockServices.getBlockController("CHAT_MENSAGEM").getInteractionRulesStrategy().commit(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@ActionTrigger(item = "BTN_DOWNLOAD_ANEXO", action = "btn_download_anexo_click")
	public void btn_download_anexo_click() {
		
		if(getChatMensagemElement().getDsArquivo().isNull()){
			//MULTI-IDIOMA: MSG_0090 - Mensagem não possui anexo.
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0090"), "W", NBool.True);
		}
		
		NString dsCaminhoPastaDb = Services.getDescricao("DS_CAMINHO_PASTA_BD","DBAMV","MULTI_EMPRESAS_MV_SAUDE", "CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA", false);
		dsCaminhoPastaDb = dsCaminhoPastaDb.append("autweb\\\\").append(Lib.isNull(getGuiaElement().getCdPrestadorExecutor(),getGuiaElement().getCdPrestador())).append("\\\\").append("chat").append("\\\\").append(getChatMensagemElement().getCdChat()).append("\\\\").append(getChatMensagemElement().getDsArquivo());
		File fileIn = new File(dsCaminhoPastaDb.toString());
		Services.downloadFile(fileIn);
		
	}

	@ViewTrigger(context={"PAGE_CHAT"})
	@ActionTrigger(action = "chat_mensagem_recordChange", function=KeyFunction.RECORD_CHANGE)
	public void chat_mensagem_recordChange() {
		getChatMensagemElement().setDspSnAnexo(NString.toStr("N"));
		if (!getChatMensagemElement().getDsArquivo().isNull()) {
			getChatMensagemElement().setDspSnAnexo(NString.toStr("S"));
		}
	}
}

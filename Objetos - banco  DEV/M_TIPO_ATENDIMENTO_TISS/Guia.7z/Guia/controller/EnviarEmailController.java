package br.com.mv.soul.mvsaude.forms.Guia.controller;



import static morphis.foundations.core.appsupportlib.runtime.ItemServices.goItem;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.hideView;
import static morphis.foundations.core.types.NString.toStr;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.dbservices.PkgMv2000;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.EnviarEmailAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NString;
import br.com.mv.soul.common.localization.ResourceManager;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import br.com.mv.soul.flavor.runtime.action.ViewTrigger;

public class EnviarEmailController extends DefaultBlockController {

	public EnviarEmailController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}

	public EnviarEmailAdapter getEnviarEmailElement() {
		return (EnviarEmailAdapter) this.getFormModel().getEnviarEmail().getRowAdapter(true);
	}
	
	public GuiaAdapter getGuiaElement() {

		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}

	@ActionTrigger(item = "BTN_ENVIAR_EMAIL_PRESTADOR", action = "btn_enviar_email_prestador_click")
	public void btn_enviar_email_prestador_click() {

		if (getEnviarEmailElement().getDspSnLocalAtendimento().equals("N") && getEnviarEmailElement().getDspSnPrestadorExecutante().equals("N") && getEnviarEmailElement().getDspSnPrestadorSolicitante().equals("N") && getEnviarEmailElement().getDspSnBeneficiario().equals("N") && getEnviarEmailElement().getDspSnAuditor().equals("N") && getEnviarEmailElement().getDspEmailPrestador().isNull()) {

			// MULTI-IDIOMA: MSG_0025 - Informe um email ou selecione uma opção.
			String msg = ResourceManager.getString("guia.msg0025");
			getTask().getMv2000().msgAlert(msg, "w", NBool.True);

		}

		NString _emails = this.getTask().getServices().getEmailsEnviados();
		NString _ServidorEmail = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("DS_SERVIDOR_EMAIL"), "");

		URLConnection connection = null;
		try {
			URL url = new URL(_ServidorEmail.append("?nrGuia=").append(getGuiaElement().getNrGuia().toString()).append("&tpAtendimento=").append(getGuiaElement().getCdTipoAtendimento()).append("&empresa=").append(PkgMv2000.leEmpresa()).append("&emailPrestador=").append(_emails).toString());
			connection = url.openConnection();
			connection.connect();

			BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));

			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				System.out.println(inputLine);
			}
			in.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		this.getTask().getServices().insereLogEnvioEmail();
		TaskServices.executeQuery("LOG_AUTORIZA");
		
		getTask().getMv2000().msgAlert("Processo de envio de E-mail concluido!", "I", NBool.False);

		hideView("CNV_EMAIL");
		goItem("GUIA.NR_GUIA");
	}	

	@ActionTrigger(item = "BTN_CANCELAR_ENVIAR_EMAIL", action = "btn_cancelar_enviar_email_click")
	public void btn_cancelar_enviar_email_click() {
		hideView("CNV_EMAIL");
		goItem("GUIA.NR_GUIA");
	}

	/**
	 * 
	 * @author Rosemere Mota
	 * @since 17/07/2014
	 * @return void
	 * Possibilita a validação de mais de um e-mail.
	 */
	public void validarEmail(EnviarEmailAdapter pEmails) {

		String email = pEmails.getDspEmailPrestador().toString();		

		String[] explode = email.split(",");

		for (int i = 0; i < explode.length; i++) {
			if (this.getTask().getServices().existeErroEmail(explode[i])){
				//MULTI-IDIOMA: MSG_0026 - E-mail informado com erro : [ %s ].
				String msg = ResourceManager.getString("guia.msg0026");
				getTask().getMv2000().msgAlert(msg, "E", NBool.True);				
			}			   	
		}		

	}

	@ViewTrigger
	@ActionTrigger(item = "DSP_EMAIL_PRESTADOR", action = "dsp_email_prestador_itemOut", function=KeyFunction.ITEM_OUT)
	public void dsp_email_prestador_itemOut() {

		EnviarEmailAdapter  emailAdapter = (EnviarEmailAdapter) this.getFormModel().getEnviarEmail().getRowAdapter(true);

		if (!emailAdapter.getDspEmailPrestador().isNull()) {

			this.validarEmail(emailAdapter);
		}

	}

	
}

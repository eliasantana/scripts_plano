package br.com.mv.soul.mvsaude.forms.Guia.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.util.logging.ILogger;
import morphis.foundations.core.util.logging.LoggerFactory;

import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.FiltroPrestExterno;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;

public class FiltroPrestExternoController extends DefaultBlockController {

	protected static ILogger logger = LoggerFactory.getInstance(CgCtrlController.class);
	
	FiltroPrestExterno filtroPrestExternoElement = (FiltroPrestExterno) getFormModel().getFiltroPrestExterno();
	
	
	public FiltroPrestExternoController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}

	@ActionTrigger(item = "BTN_FILTRO", action = "btn_filtro_click")
	public void btn_filtro_click() {
		String sqlBloco = "SELECT NVL(NR_CNPJ_CEI,NR_CPF) CPF_CNPJ  , DS_NOME  FROM DBAPS.PRESTADOR_EVENTUAL ";
		NString filtros = NString.getNull();
		
		if (!filtroPrestExternoElement.getCdPrestExterno().isNull()) {

			if (filtros.isEmpty()) {
				filtros = filtros.append("WHERE DS_NOME LIKE '%").append(filtroPrestExternoElement.getCdPrestExterno().append("%'"));
			} 

		}
		
		// recebendo os filtros na query do bloco
			sqlBloco += filtros;
			BlockServices.setBlockQueryDataSourceName("PREST_EXTERNO", sqlBloco);
			TaskServices.executeQuery("PREST_EXTERNO");  
		
		
		
	}
	
}
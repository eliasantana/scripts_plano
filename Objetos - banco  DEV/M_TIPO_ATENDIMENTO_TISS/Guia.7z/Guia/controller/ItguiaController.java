package br.com.mv.soul.mvsaude.forms.Guia.controller;

import static morphis.foundations.core.appsupportlib.Lib.isNull;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.goBlock;
import static morphis.foundations.core.types.Types.toBool;
import static morphis.foundations.core.types.Types.toNumber;
import static morphis.foundations.core.types.Types.toStr;

import java.util.Hashtable;

import org.jdesktop.databuffer.DataRow.DataRowStatus;

import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.common.localization.ResourceManager;
import br.com.mv.soul.flavor.runtime.action.ViewTrigger;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.CgCtrl;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaErrosAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.services.GuiaServices;
import br.com.mv.soul.mvsaude.forms.Guia.services.PkgMvsGuia;
import br.com.mv.soul.mvsaude.libs.Services;
import br.com.mv.soul.mvsaude.libs.Configuracao.Configuracao;
import morphis.foundations.core.appdatalayer.data.DataCommand;
import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.AfterRowInsert;
import morphis.foundations.core.appdatalayer.events.BeforeRowDelete;
import morphis.foundations.core.appdatalayer.events.BeforeRowInsert;
import morphis.foundations.core.appdatalayer.events.BeforeRowUpdate;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.MessageServices;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.ViewServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.appsupportlib.runtime.events.RecordRemoved;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;


public class ItguiaController extends DefaultBlockController
{

	public ItguiaController(IFormController parentController, String name)
	{

		super(parentController, name);
	}

	@Override
	public GuiaTask getTask()
	{

		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel()
	{

		return this.getTask().getModel();
	}
	
	public GuiaAdapter getGuiaElement(){
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}

	public ItguiaAdapter getItguiaElement(){
		return (ItguiaAdapter) this.getFormModel().getItguia().getRowAdapter(true);
	}
	
	public ItguiaErrosAdapter getItguiaErrosElement(){
		return (ItguiaErrosAdapter) this.getFormModel().getItguiaErros().getRowAdapter(true);
	}

	@AfterQuery
	public void itguia_AfterQuery(RowAdapterEvent args){
		
		ItguiaAdapter itguiaElement = (ItguiaAdapter) args.getRow();
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		CgCtrl controleElement = (CgCtrl) this.getFormModel().getCgCtrl();

		//Pinta os campos de amarelo quando existir ocorrência
		if (this.getTask().getServices().existeMotivo(itguiaElement.getNrGuia(), itguiaElement.getCdProcedimento())) {
		
			//Se o procedimento for de baixo risco, pinta de verde.
			if(getTask().getServices().isProcedimentoBaixoRisco(guiaElement.getDtEmissao(), itguiaElement.getCdProcedimento(), itguiaElement.getQtSolicitado())){
				ItemServices.setItemStyleClass("ITGUIA.CD_PROCEDIMENTO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "VerdeClaro");
			}else{
				ItemServices.setItemStyleClass("ITGUIA.CD_PROCEDIMENTO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "Amarelo");
			}
			
			this.getTask().getServices().pintarProcedimento(true);
		
		} else {

			//Se o procedimento for de baixo risco, pinta de verde.
			if(getTask().getServices().isProcedimentoBaixoRisco(guiaElement.getDtEmissao(), itguiaElement.getCdProcedimento(), itguiaElement.getQtSolicitado())){
				ItemServices.setItemStyleClass("ITGUIA.CD_PROCEDIMENTO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "VerdeClaro");
			}else{
				ItemServices.setItemStyleClass("ITGUIA.CD_PROCEDIMENTO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), "");
			}
		
			this.getTask().getServices().pintarProcedimento(false);
		}
		
		
		try{
			
			ResultSet rsProc = this.getTask().getServices().getInfoProcedimento(itguiaElement.getCdProcedimento());
			if(rsProc != null){
			
				if(Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N").equals("S")){
										
					if ( Lib.in(rsProc.getNumber("TP_TABELA"), NNumber.toNumber(0),NNumber.toNumber(4)).toBoolean() ) {
						ItemServices.setItemFormatMask("ITGUIA.QT_SOLIC_PREST", BlockServices.getBlockCurrentRecord("ITGUIA").toInt32(), NString.toStr("999"));						
						ItemServices.setItemFormatMask("ITGUIA.QT_SOLICITADO", BlockServices.getBlockCurrentRecord("ITGUIA").toInt32(), NString.toStr("999"));
					} else if ( Lib.in(rsProc.getNumber("TP_TABELA"), NNumber.toNumber(1),NNumber.toNumber(2),NNumber.toNumber(3)).toBoolean() ) {
						ItemServices.setItemFormatMask("ITGUIA.QT_SOLIC_PREST", BlockServices.getBlockCurrentRecord("ITGUIA").toInt32(), NString.toStr("999.9999"));						
						ItemServices.setItemFormatMask("ITGUIA.QT_SOLICITADO", BlockServices.getBlockCurrentRecord("ITGUIA").toInt32(), NString.toStr("999.9999"));						
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		

		if (!getItguiaElement().getCdMotivo().isNull()) {
			this.getTask().getServices().getMotivoGlosa(false);
		}
		
		if(this.getTask().getServices().isProcedimentoUniversal(itguiaElement.getCdProcedimento())){
			ItemServices.setItemEnabled("ITGUIA.DS_PROCEDIMENTO", true);
		}else{
			ItemServices.setItemEnabled("ITGUIA.DS_PROCEDIMENTO", false);
		}

		if (!itguiaElement.getCdProcedimento().isNull()) {
			try {
				this.getTask().getServices().prcProcedimento(itguiaElement.getCdProcedimento(), toStr("N"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (guiaElement.getNrGuia().isNull())
			return;

		/**
		 * Calcula valor por procedimento
		 */
		String sqlcFase = " "
				+ " SELECT QT_SOLICITADO * VL_PROCEDIMENTO VALOR , "
				+ " Nvl(QT_FRANQUIA,QT_SOLICITADO) * VL_FRANQUIA CO " 
				+ " FROM DBAPS.GUIA G "
				+ " ,DBAPS.ITGUIA IG " 
				+ " WHERE G.NR_GUIA = IG.NR_GUIA "
				+ " AND G.NR_GUIA = :P_GUIA "
				+ " AND IG.CD_PROCEDIMENTO = :P_PROCEDIMENTO"
				+ " AND IG.CD_ITGUIA = :P_CD_ITGUIA ";

		DataCursor cFase = new DataCursor(sqlcFase);
		cFase.addParameter("P_PROCEDIMENTO", itguiaElement.getCdProcedimento());
		cFase.addParameter("P_GUIA", guiaElement.getNrGuia());
		cFase.addParameter("P_CD_ITGUIA",itguiaElement.getCdItguia());
		cFase.open();
		ResultSet cFaseResult = cFase.fetchInto();
		if (cFaseResult != null) {

			itguiaElement.setDspVlTotalProcedimento(cFaseResult.getNumber(0));
			itguiaElement.setDspVlTotalFranquia(cFaseResult.getNumber(1));
		}
		cFase.close();
		cFaseResult = null;
		
		/**
		 * Calcula valor total
		 */
		String total = " SELECT SUM(QT_SOLICITADO * VL_PROCEDIMENTO) VALOR "
				+ " , SUM( NVL(QT_FRANQUIA,QT_SOLICITADO) * VL_FRANQUIA) CO "
				+ " FROM DBAPS.GUIA G , "
				+ " DBAPS.ITGUIA IG "
				+ " WHERE G.NR_GUIA = IG.NR_GUIA" 
				+ " AND G.NR_GUIA = :P_GUIA ";

		cFase = new DataCursor(total);
		cFase.addParameter("P_GUIA", guiaElement.getNrGuia());
		cFase.open();
		cFaseResult = cFase.fetchInto();
		if (cFaseResult != null) {
			controleElement.setDspVlTotalProcedimento(cFaseResult.getNumber(0));
			controleElement.setDspVlTotalFranquia(cFaseResult.getNumber(1));
		}
		cFase.close();

		itguiaElement.setValorOriginalProcedimento(itguiaElement.getVlProcedimento());

		/**
		 * Se a guia for de odontologia, buscar pelo código da região e da face
		 * @since 14/10/2013
		 */
		if (guiaElement.getDspTpGuia().equals("D")) {
			cd_regiao_dente_validation();
			cd_faces_dentes_odonto_validation();
		}
		
		ds_termo_unidade_medida_validation();
		if (!itguiaElement.getCdProcedimento().isNull()) {
			getItguiaElement().setDspTpNatureza(Services.getDescricao("TP_NATUREZA", "PROCEDIMENTO", "CD_PROCEDIMENTO = '".concat(itguiaElement.getCdProcedimento().toString()).concat("'"), false));
		}
		
	}

	@BeforeRowInsert
	public void itguia_BeforeRowInsert(RowAdapterEvent args) {

		String sqlcSeq = "SELECT DBAPS.SEQ_CD_ITGUIA.NEXTVAL FROM SYS.DUAL ";

		DataCursor cSeq = new DataCursor(sqlcSeq);
		ItguiaAdapter itGuiaElement = (ItguiaAdapter) args.getRow();

		if (getGuiaElement().getTpStatusAnalise().equals(toNumber(0))) {
			getGuiaElement().setSnValidaRestCarencia(toStr("N"));
			getGuiaElement().setDtAutorizacao(NDate.getNull());
		}

		// pda 404139
		if (itGuiaElement.getNrGuia().isNull()) {
			itGuiaElement.setNrGuia(getGuiaElement().getNrGuia());
		}

		if (itGuiaElement.getCdItguia().isNull()) {
			cSeq.open();
			ResultSet cSeqValor = cSeq.fetchInto();
			if (cSeqValor != null) {
				itGuiaElement.setCdItguia(cSeqValor.getNumber(0));
			}
		}

		if (getGuiaElement().getDspTpGuia().equals(toStr("O"))) {
			verificarCamposOpme(itGuiaElement);
		}
		
		if ( getItguiaElement().getCdViaAdministracao().isNull() 
				&& getGuiaElement().getDspTpGuia().equals("Q") 
					&& !getGuiaElement().getTpOrigem().equals("PTU") 
						&& !getGuiaElement().getTpFluxoPtuWs().equals("SERVER") ) {
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0089", ItemServices.getItemLabel("ITGUIA.CD_VIA_ADMINISTRACAO")), "W", NBool.True);
		}
		
		cSeq.close();
		
		itGuiaElement.setNrSqItemTiss(NNumber.toNumber(args.getRow().getIndex() + 1));
		
	}

	private void verificarCamposOpme(ItguiaAdapter itGuiaElement){
		NString snOperadoraUnimed = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		NString snEmissaoAvulsa = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
		
		String camposOpme = "";
		if(itGuiaElement.getSnPrestadorExecutorOpme().isNull() && (snEmissaoAvulsa.equals("N") && snOperadoraUnimed.equals("N"))){
			if(camposOpme.equals("")){
				camposOpme = "Prestador Executor da OPME, que indica se a OPME será paga pelo prestador ou pela operadora.";
			}else{
				camposOpme = camposOpme + ", Prestador Executor da OPME, que indica se a OPME será paga pelo prestador ou pela operadora.";
			}
		}
		/*
		 * Condicionado. Deve ser
           preenchido caso o material seja
           fornecido pelo prestador
           solicitante, conforme negociação
           entre as partes.
		 */
		if (snOperadoraUnimed.equals("S")) {
			if (itGuiaElement.getTpIndicadorAnexo().equals("3") && getGuiaElement().getTpOrigem().equals("PTU")) {				
				if(itGuiaElement.getNrOrdemPreferencia().isNull()){
					if(camposOpme.equals("")){
						camposOpme = "\"Opção de preferência\"";
					}else{
						camposOpme = camposOpme + ", \"Opção de preferência\"";
					}
				}
			}else if(!getGuiaElement().getTpOrigem().equals("PTU")){
				if(itGuiaElement.getNrOrdemPreferencia().isNull()){
					if(camposOpme.equals("")){
						camposOpme = "\"Opção de preferência\"";
					}else{
						camposOpme = camposOpme + ", \"Opção de preferência\"";
					}
				}
			}
		}else if (snOperadoraUnimed.equals("N")){
			if(itGuiaElement.getNrOrdemPreferencia().isNull()){
				if(camposOpme.equals("")){
					camposOpme = "\"Opção de preferência\"";
				}else{
					camposOpme = camposOpme + ", \"Opção de preferência\"";
				}
			}
		}

		if (!itGuiaElement.getSnPrestadorExecutorOpme().isNull() && itGuiaElement.getSnPrestadorExecutorOpme().equals("S")){
			if(itGuiaElement.getNrAnvisa().isNull()){
				if(camposOpme.equals("")){
					camposOpme = "Nr Anvisa";
				}else{
					camposOpme = camposOpme + ", Nr Anvisa";
				}
			}

			if(itGuiaElement.getCdMaterialFabricante().isNull()){
				if(camposOpme.equals("")){
					camposOpme = "Material Fabricante";
				}else{
					camposOpme = camposOpme + ", Material Fabricante";
				}
			}
		}

		if(!camposOpme.equals("")){
			getTask().getMv2000().msgAlert(toStr("Erro: Para Tipo de Guia OPME, é necessário informar o(s) campo(s): "+camposOpme+ " nos procedimentos."),
					toStr("E"), toBool(NBool.True));
		}
	}

	@BeforeRowDelete
	public void itguia_BeforeRowDelete(RowAdapterEvent args)
	{

		ItguiaAdapter itguiaElement = (ItguiaAdapter) args.getRow();
		PkgMvsGuia.pBPdItguia(itguiaElement);
		
		String sqlCommand = "DELETE FROM DBAPS.ITGUIA_OCULOS WHERE NR_GUIA = :PNR_GUIA AND CD_ITGUIA = :PCD_ITGUIA ";
		DataCommand command = new DataCommand(sqlCommand);
		command.addParameter("PNR_GUIA", itguiaElement.getNrGuia() );
		command.addParameter("PCD_ITGUIA",itguiaElement.getCdItguia() );
		command.execute();
		
	}

	@ValidationTrigger(item = "CD_PROCEDIMENTO")
	public void cdProcedimento_validate(){
		NString cdProcedimentoDigitado = NString.getNull();
		NString tpMensalidade = NString.getNull();
		NString snOperadoraUnimed = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		NNumber tpTabela = NNumber.getNull();
		
		if (!getItguiaElement().getCdProcedimento().isNull()){

			cdProcedimentoDigitado = getItguiaElement().getCdProcedimento();
			
			if(getItguiaElement().getRowState().equals(DataRowStatus.INSERTED)){
				getGuiaElement().setDtUltimaAnalise(NDate.getNull());
			}

			//Alteracao feita a pedido de cleber. Migracao de Santos. Em 02/06/2014 - 10:50
			if (!NNumber.toNumber(ItemServices.getItemDataBaseValue("ITGUIA.CD_PROCEDIMENTO")).equals(NNumber.toNumber(cdProcedimentoDigitado))) {
				getItguiaElement().setTpStatus(NString.toStr("0"));
				getItguiaElement().setQtFranquia(NNumber.toNumber(0));
				getItguiaElement().setVlFranquia(NNumber.toNumber(0));
				getItguiaElement().setVlProcedimento(NNumber.toNumber(0));
				getItguiaElement().setDspVlTotalFranquia(NNumber.toNumber(0));
				getItguiaElement().setDspVlTotalProcedimento(NNumber.toNumber(0));
			}
			
			if (Lib.isNull(Configuracao.fncMvsRetornaValorConfig(toStr("SN_VERIFICAR_DE_PARA_GUIA")), 'N').equals("S")) {
				this.getTask().getServices().prcPrcAssociado(getItguiaElement(), getGuiaElement());
			}

			this.getTask().getServices().prcValidaProcedimentoInativo(cdProcedimentoDigitado);
			
			if (!getGuiaElement().getCdMatricula().isNull()) {
				tpMensalidade = Services.getDescricao("C.TP_MENSALIDADE","CONTRATO C, DBAPS.USUARIO U", "U.CD_CONTRATO = C.CD_CONTRATO AND U.CD_MATRICULA = " + getGuiaElement().getCdMatricula(), false);
				if (tpMensalidade.equals("C")) {
					getItguiaElement().setSnCobraCusto(NString.toStr("S"));
				}
			}
						
			this.getTask().getServices().prcProcedimento(cdProcedimentoDigitado,toStr("N"));

			try{
				
				ResultSet rsProc = this.getTask().getServices().getInfoProcedimento(cdProcedimentoDigitado);
				if(rsProc != null){
					
					tpTabela = rsProc.getNumber("TP_TABELA");
					getItguiaElement().setNrAnvisa(rsProc.getStr("NR_ANVISA"));
					getItguiaElement().setCdMaterialFabricante(rsProc.getStr("CD_MATERIAL_FABRICANTE"));
					getItguiaElement().setNrAutorizacaoFuncionamento(rsProc.getStr("NR_AUTORIZACAO_FUNCIONAMENTO"));
					getItguiaElement().setDspTpNatureza(rsProc.getStr("TP_NATUREZA"));
					
					if(snOperadoraUnimed.equals("S")){
						if(rsProc.getStr("TP_GRU_PRO").equals("OP")){
							getItguiaElement().setTpIndicadorAnexo(NString.toStr("3"));
						}
						if (rsProc.getStr("TP_GRU_PRO").equals("MD") && getGuiaElement().getDspTpGuia().equals("Q")) {
							getItguiaElement().setTpIndicadorAnexo(NString.toStr("1"));
						}
						
						if ( Lib.in(rsProc.getNumber("TP_TABELA"), NNumber.toNumber(0),NNumber.toNumber(4)).toBoolean() ) {
							ItemServices.setItemFormatMask("ITGUIA.QT_SOLIC_PREST", BlockServices.getBlockCurrentRecord("ITGUIA").toInt32(), NString.toStr("999"));						
							ItemServices.setItemFormatMask("ITGUIA.QT_SOLICITADO", BlockServices.getBlockCurrentRecord("ITGUIA").toInt32(), NString.toStr("999"));
						} else if ( Lib.in(rsProc.getNumber("TP_TABELA"), NNumber.toNumber(1),NNumber.toNumber(2),NNumber.toNumber(3)).toBoolean() ) {
							ItemServices.setItemFormatMask("ITGUIA.QT_SOLIC_PREST", BlockServices.getBlockCurrentRecord("ITGUIA").toInt32(), NString.toStr("999.9999"));						
							ItemServices.setItemFormatMask("ITGUIA.QT_SOLICITADO", BlockServices.getBlockCurrentRecord("ITGUIA").toInt32(), NString.toStr("999.9999"));						
						}
					}
					if(rsProc.getStr("SN_PROCED_UNIVERSAL").equals("S")){
						ItemServices.setItemEnabled("ITGUIA.DS_PROCEDIMENTO", true);
					}else{
						ItemServices.setItemEnabled("ITGUIA.DS_PROCEDIMENTO", false);
					}
					
				}
			}catch(Exception e){
				e.printStackTrace();
			}

			//verifica se o procedimento faz parte do rol da ANS se a configuração estiver como "S"
			if (Lib.isNull(Configuracao.fncMvsRetornaValorConfig(toStr("ATEND_SN_MSG_PROC_ROL_ANS")), 'N').equals("S")) {
				this.getTask().getServices().validaProcedimentoRolAns(getItguiaElement().getCdProcedimento());
			}

			// Verifica se existe Pacote para o Procedimento selecionado.
			// para abrir uma tela como os pacotes que o procedimento faz parte.
			// OP 30237 
			// Data 20/05/2015
			if(this.getTask().getServices().existePacote(getItguiaElement().getCdProcedimento(),getGuiaElement().getCdPrestadorExecutor()) == true ){
				ItemServices.goItem("PACOTE.CD_PROCEDIMENTO");
				TaskServices.executeQuery("PACOTE");
				MessageServices.clearMessage();
			}
		
			if(this.getTask().getServices().existeRegulacao(getItguiaElement().getCdProcedimento()) == true ){
				if(getTask().getMv2000().msgAlertSn(NString.toStr("Existe regulação para este procedimento! Deseja visualizar?"), NString.toStr("W"), NString.toStr("Sim/Não")).toBoolean()){
					ItemServices.goItem("PROCED_REGULACAO.CD_PROCED_TIPO_REGULACAO");
					TaskServices.executeQuery("PROCED_REGULACAO");
				}
			}
			
			this.getTask().getServices().validacoesPtuOnline(getGuiaElement(), getItguiaElement());
			this.getTask().getServices().permiteAcessoCampo(getItguiaElement(), tpTabela);
		} else {
			getItguiaElement().setDspDsProcedimento(NString.getNull());
		}
		
	}

	@ValidationTrigger(item = "QT_SOLIC_PREST")
	public void qtSolicPrest_validate(){
		
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"), "N");
		NString snEmissaoAvulsa = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N");
		if(snOperadoraUnimed.equals("S") && snEmissaoAvulsa.equals("S")){
			ItemServices.setItemEnabled("ITGUIA.QT_SOLICITADO", false);
		}
		if (Lib.isNull(getItguiaElement().getQtSolicitado(), 0).notEquals(isNull(getItguiaElement().getQtSolicPrest(), 0))){
			getItguiaElement().setQtSolicitado(getItguiaElement().getQtSolicPrest());
			qtSolicitado_validate();
		}
		vl_procedimento_validation();
	}

	@ValidationTrigger(item = "QT_SOLICITADO")
	public void qtSolicitado_validate() {

		CgCtrl controleElement = (CgCtrl) this.getFormModel().getCgCtrl();
		
				
		// Permite alterar a quantidade para itens com STATUS auditar que possui data de negação. (PEDIDO DE INSISTÊNCIA)  
		if(getItguiaElement().getDtNegacao().isNotNull() && getItguiaElement().getTpStatus().equals(3)){
		
			getTask().getMv2000().msgAlert("Não é possível alterar a quantidade pois este item está negado!", "W", NBool.False);
			
			getItguiaElement().setQtSolicitado(NNumber.toNumber(0));
			
		}else{
			
			if (isNull(getItguiaElement().getDspQtMaximaSolic(), 0).greater(0)) {
				if (getItguiaElement().getQtSolicitado().greater(getItguiaElement().getDspQtMaximaSolic())) {
					getTask().getMv2000().msgAlert(toStr("A quantidade informada não pode ser maior que a quantidade máxima por solicitação indicada no cadastro de procedimentos."), toStr("E"), toBool(NBool.True));
				}
			}
			
		}
		
		getItguiaElement().setDspVlTotalProcedimento(getItguiaElement().getQtSolicitado().multiply(getItguiaElement().getVlProcedimento()));
		getItguiaElement().setDspVlTotalFranquia(getItguiaElement().getQtSolicitado().multiply(getItguiaElement().getVlFranquia()));

		controleElement.setDspVlTotalProcedimento(toNumber(0));
		controleElement.setDspVlTotalFranquia(toNumber(0));
		IDBBusinessObject managerItGuia = getFormModel().getItguia();
		for (int p = 0; p < managerItGuia.getCount(); p++) {
			ItguiaAdapter rowItGuia = (ItguiaAdapter) managerItGuia.getRow(p);

			controleElement.setDspVlTotalProcedimento(controleElement.getDspVlTotalProcedimento().add(rowItGuia.getQtSolicitado().multiply(rowItGuia.getVlProcedimento())));
			controleElement.setDspVlTotalFranquia(controleElement.getDspVlTotalFranquia().add(rowItGuia.getQtSolicitado().multiply(rowItGuia.getVlFranquia())));
		}
		
	}

	@ActionTrigger(action = "btnTpStatus_click", item = "BTN_TP_STATUS")
	public void btnTpStatus_click()
	{
		getFormModel().getCgCtrl().setDspDsLiberacao(NString.toStr(ResourceManager.getString("guia.msg0142")));
		getFormModel().getCgCtrl().setDsSenhaAutorizacaoSemBase(toStr(null));
		getFormModel().getCgCtrl().setCdAutorizadorOpe(getGuiaElement().getCdAutorizador());
		getFormModel().getCgCtrl().setDspNmAutorizadorOpe(getGuiaElement().getDspNmAutorizador());
		
		ResultSet rs = GuiaServices.getAutorizadorLogado();
		
		if(rs != null){
			getFormModel().getCgCtrl().setCdAutorizadorOpe(rs.getNumber("CD_AUTORIZADOR"));
			getFormModel().getCgCtrl().setDspNmAutorizadorOpe(rs.getStr("NM_AUTORIZADOR"));	
		}
		
		getFormModel().getCgCtrl().setSnCancelaAutorizacao(toStr("N"));
		getFormModel().getCgCtrl().setCdMotCancelamento(toNumber(null));
		getFormModel().getCgCtrl().setDspDsMotCancelamento(toStr(null));
		getFormModel().getCgCtrl().setTpStatus(getGuiaElement().getTpStatus());
		this.getFormModel().setParam("CHAMA_AUTORIZ", toStr("S"));
		this.getTask().getServices().configuraSolicitacaoSenha(NString.toStr("S"));
	}

	// pda 404139
	@AfterRowInsert
	public void itguia_AfterRowInsert(RowAdapterEvent args){
		goBlock(toStr("GUIA"));
	}

	@ValidationTrigger(item = "VL_PROCEDIMENTO")
	public void vl_procedimento_validation()
	{

			ItguiaAdapter itguiaElement = (ItguiaAdapter) this.getFormModel().getItguia().getRowAdapter(true);

			if (!Lib.isNull(itguiaElement.getValorOriginalProcedimento(), 0).equals(itguiaElement.getVlProcedimento()) && getGuiaElement().getSnValidaRestCarencia().equals("S")){
				getFormModel().getCgCtrl().setDspDsLiberacao( toStr("Digite a Senha para Alteração do Valor do Procedimento"));
				getFormModel().getCgCtrl().setDsSenhaAutorizacaoSemBase(toStr(null));
				getFormModel().getCgCtrl().setCdAutorizadorOpe(getGuiaElement().getCdAutorizador());
				getFormModel().getCgCtrl().setDspNmAutorizadorOpe(getGuiaElement().getDspNmAutorizador());
				
				ResultSet rs = GuiaServices.getAutorizadorLogado();
				
				if(rs != null){
					getFormModel().getCgCtrl().setCdAutorizadorOpe(rs.getNumber("CD_AUTORIZADOR"));
					getFormModel().getCgCtrl().setDspNmAutorizadorOpe(rs.getStr("NM_AUTORIZADOR"));	
				}
				
				getFormModel().getCgCtrl().setSnCancelaAutorizacao(toStr("N"));
				getFormModel().getCgCtrl().setCdMotCancelamento(toNumber(null));
				getFormModel().getCgCtrl().setDspDsMotCancelamento(toStr(null));
				getFormModel().getCgCtrl().setTpStatus(getGuiaElement().getTpStatus());

				BlockServices.setBlockUpdateAllowed("IMP_GUIA", false);
				BlockServices.setBlockInsertAllowed("IMP_GUIA", false);
				BlockServices.setBlockDeleteAllowed("IMP_GUIA", false);

				BlockServices.setBlockUpdateAllowed("GUIA", false);
				BlockServices.setBlockDeleteAllowed("GUIA", false);

				/** V alteração do valor do procedimento */
				this.getFormModel().setParam("CHAMA_AUTORIZ", toStr("V"));
				this.getTask().getServices().configuraSolicitacaoSenha(NString.toStr("V"));
			}
			else{
				ItemServices.setItemIsValid("ITGUIA.VL_PROCEDIMENTO", true);
			}

			CgCtrl controleElement = (CgCtrl) this.getFormModel().getCgCtrl();

			itguiaElement.setDspVlTotalProcedimento(itguiaElement.getQtSolicitado().multiply(itguiaElement.getVlProcedimento()));
			itguiaElement.setDspVlTotalFranquia(itguiaElement.getQtSolicitado().multiply(itguiaElement.getVlFranquia()));

			controleElement.setDspVlTotalProcedimento(toNumber(0));
			controleElement.setDspVlTotalFranquia(toNumber(0));
			IDBBusinessObject managerItGuia = getFormModel().getItguia();
			for (int p = 0; p < managerItGuia.getCount(); p++) {
				ItguiaAdapter rowItGuia = (ItguiaAdapter) managerItGuia.getRow(p);

				controleElement.setDspVlTotalProcedimento(controleElement.getDspVlTotalProcedimento().add(rowItGuia.getQtSolicitado().multiply(rowItGuia.getVlProcedimento())));
				controleElement.setDspVlTotalFranquia(controleElement.getDspVlTotalFranquia().add(rowItGuia.getQtSolicitado().multiply(rowItGuia.getVlFranquia())));
			}
	}

	@ViewTrigger
	@ActionTrigger(item = "VL_PROCEDIMENTO", action = "vl_procedimento_itemIn", function=KeyFunction.ITEM_IN)
	public void vl_procedimento_itemIn() {
		ResultSet rsProc = this.getTask().getServices().getInfoProcedimento(getItguiaElement().getCdProcedimento());
		if(rsProc != null){
			this.getTask().getServices().permiteAcessoCampo(getItguiaElement(), rsProc.getNumber("TP_TABELA"));
		}
	}

	@ViewTrigger
	@ActionTrigger(item = "VL_PROCEDIMENTO", action = "vl_procedimento_itemOut", function=KeyFunction.ITEM_OUT)
	public void vl_procedimento_itemOut(){}

	public void sn_prestador_executor_opme_change() {
		snPrestadorExecutorOpme();
	}

	@ValidationTrigger(item = "SN_PRESTADOR_EXECUTOR_OPME")
	public void snPrestadorExecutorOpme() {
		ItguiaAdapter itguiaElement = (ItguiaAdapter) this.getFormModel().getItguia().getRowAdapter(true);
		if (!itguiaElement.getSnPrestadorExecutorOpme().isNull()) {


			boolean isPrestadorOpme = itguiaElement.getSnPrestadorExecutorOpme() != null && NString.toStr("S").equals(itguiaElement.getSnPrestadorExecutorOpme());
//			boolean isProcedimentoTabelaTussEOpme = this.getTask().getServices().fncTabelaTuss(itguiaElement.getCdProcedimento()).equals("19") && getGuiaElement().getDspTpGuia().equals("O");

			boolean habilitar = ( isPrestadorOpme  );

			ItemServices.setItemEnabled("ITGUIA.NR_AUTORIZACAO_FUNCIONAMENTO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), habilitar);
			ItemServices.setItemEnabled("ITGUIA.VL_SOLICITADO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), habilitar);
			ItemServices.setItemRequired("ITGUIA.NR_AUTORIZACAO_FUNCIONAMENTO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), habilitar);
			ItemServices.setItemRequired("ITGUIA.VL_SOLICITADO", BlockServices.getCurrentRecord("ITGUIA").toInt32(), habilitar);


			if (!habilitar) { 
				itguiaElement.setNrAutorizacaoFuncionamento(NString.getNull());
				itguiaElement.setVlSolicitado(NNumber.getNull());
			}

			if (itguiaElement.getSnPrestadorExecutorOpme().equals("N") && !itguiaElement.getCdProcedimento().isNull()) {
				String sqlcProcedimento = " SELECT * FROM DBAPS.PROCEDIMENTO WHERE CD_PROCEDIMENTO = :P_CD_PROCEDIMENTO ";
				DataCursor dcProc = new DataCursor(sqlcProcedimento);
				dcProc.addParameter("P_CD_PROCEDIMENTO",itguiaElement.getCdProcedimento());

				try{
					dcProc.open();
					ResultSet rsProc = dcProc.fetchInto();

					if(rsProc != null){
						itguiaElement.setNrAnvisa(rsProc.getStr("NR_ANVISA"));
						itguiaElement.setCdMaterialFabricante(rsProc.getStr("CD_MATERIAL_FABRICANTE"));
						itguiaElement.setNrAutorizacaoFuncionamento(rsProc.getStr("NR_AUTORIZACAO_FUNCIONAMENTO"));
					}
				}finally{
					dcProc.close();
				}
			}
		}
	}

	@BeforeRowUpdate
	public void itguia_BeforeRowUpdate(RowAdapterEvent rowAdapterEvent) {

		ItguiaAdapter itGuiaElement = (ItguiaAdapter) this.getFormModel().getItguia().getRowAdapter(true);

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		if(guiaElement.getDspTpGuia().equals(toStr("O"))){
			verificarCamposOpme(itGuiaElement);
		}
		
		if ( getItguiaElement().getCdViaAdministracao().isNull() 
				&& getGuiaElement().getDspTpGuia().equals("Q") 
					&& !getGuiaElement().getTpOrigem().equals("PTU") 
						&& !getGuiaElement().getTpFluxoPtuWs().equals("SERVER") ) {
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0089", ItemServices.getItemLabel("ITGUIA.CD_VIA_ADMINISTRACAO")), "W", NBool.True);
		}
		
		itGuiaElement.setNrSqItemTiss(NNumber.toNumber(rowAdapterEvent.getRow().getIndex() + 1));
		
	}

	@RecordRemoved
	public void itguia_RecordRemoved(RowAdapterEvent rowAdapterEvent) {
		ItguiaAdapter igItguiaElement = (ItguiaAdapter)rowAdapterEvent.getRow();

		if(BlockServices.isInFirstRecord() && BlockServices.isInLastRecord() && igItguiaElement.getCdProcedimento().isNull() && !getGuiaElement().getDspTpGuia().equals("R")){
			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Operação inválida!")
					.append(Lib.chr(10))
					.append("Motivo..: A guia não possui nenhum procedimento.")
					.append(Lib.chr(10))
					.append("Ação....: Informe pelo menos um procedimento.").toString(),
					"E", /*W = Atenção, I = Informação, E = Erro */
					NBool.True /*bloquear/travar?*/);
		}
		
		if(Services.exist("ITGUIA_MENSAGEM_ESPECIFICA", "CD_ITGUIA = " + igItguiaElement.getCdItguia(), false)){
			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Operação inválida!")
					.append(Lib.chr(10))
					.append("Motivo..: Não é possivel remover um item auditado.").toString(),
					"W", /*W = Atenção, I = Informação, E = Erro */
					NBool.True /*bloquear/travar?*/);
		}
		
		rowAdapterEvent.getRow().getRowState();
		ItguiaAdapter itguiaAdapter = (ItguiaAdapter)rowAdapterEvent.getRow();
		
		if(!itguiaAdapter.getNrSqItemTiss().isNull()){
			int posicaoRemovida = itguiaAdapter.getNrSqItemTiss().toInt32();
			IDBBusinessObject manager = getFormModel().getItguia();	
			for (int p = posicaoRemovida; p < manager.getTotalCount(); p++) {
				
				if (p > 0) {
					
					ItguiaAdapter row = (ItguiaAdapter) manager.getRow(p);
					if (manager.getRow(p).getRowState().equals(DataRowStatus.UNCHANGED)) {
						row.setNrSqItemTiss(row.getNrSqItemTiss().subtract(1));
					}
					
				}
			}
		}
		
	}

	@ValidationTrigger(item = "CD_MOTIVO")
    public void cd_motivo_validation() {
		
		if(!getItguiaElement().getCdMotivo().isNull()){
			this.getTask().getServices().getMotivoGlosa(true);
		}else{
			getItguiaElement().setDspDsMotivo(NString.getNull());
		}

    }

	@ViewTrigger(context={"CNV_NEGACAO", "PAGE_PROCEDIMENTOS"})
	@ActionTrigger(action = "itguia_recordChange", function=KeyFunction.RECORD_CHANGE)
	public void itguia_recordChange() {
		if(this.getTask().getServices().isProcedimentoUniversal(getItguiaElement().getCdProcedimento())){
			ItemServices.setItemEnabled("ITGUIA.DS_PROCEDIMENTO", true);
		}else{
			ItemServices.setItemEnabled("ITGUIA.DS_PROCEDIMENTO", false);
		}
		
		this.getTask().getServices().validacoesPtuOnline(getGuiaElement(), getItguiaElement());
		
		ResultSet rsProc = this.getTask().getServices().getInfoProcedimento(getItguiaElement().getCdProcedimento());
		if(rsProc != null){
			this.getTask().getServices().permiteAcessoCampo(getItguiaElement(), rsProc.getNumber("TP_TABELA"));
		}
	}

	@ValidationTrigger(item = "DS_TERMO_UNIDADE_MEDIDA")
	public void ds_termo_unidade_medida_validation() {
		if(!getItguiaElement().getDsTermoUnidadeMedida().isNull() || !getItguiaElement().getCdUnidadeMedida().isNull()){
			String sql = ""+
						 "SELECT CD_TERMO, DS_TERMO, DS_DETALHADA FROM DBAPS.MVS_UNIDADE_MEDIDA WHERE";
			if (!getItguiaElement().getDsTermoUnidadeMedida().isNull()) {
				sql += " DS_TERMO = :P_DS_TERMO ";
			}else if(!getItguiaElement().getCdUnidadeMedida().isNull()){
				sql += " CD_TERMO = :P_CD_TERMO ";
			}
				 
			DataCursor dataCursor = null;
			ResultSet resultSet   = null;
			
			try{
				dataCursor = new DataCursor(sql);
				if (!getItguiaElement().getDsTermoUnidadeMedida().isNull()) {
					dataCursor.addParameter("P_DS_TERMO",getItguiaElement().getDsTermoUnidadeMedida());	
				}else if(!getItguiaElement().getCdUnidadeMedida().isNull()){
					dataCursor.addParameter("P_CD_TERMO",getItguiaElement().getCdUnidadeMedida());
				}
				
				dataCursor.open();
				
				if(dataCursor.found()){
					resultSet = dataCursor.fetchInto();
					if (!getItguiaElement().getCdUnidadeMedida().equals(resultSet.getStr("CD_TERMO"))) {
						getItguiaElement().setCdUnidadeMedida(resultSet.getStr("CD_TERMO"));	
					}
					getItguiaElement().setDsTermoUnidadeMedida(resultSet.getStr("DS_TERMO"));
					getItguiaElement().setDspDsUnidadeMedida(resultSet.getStr("DS_DETALHADA"));
				}
				
			}finally{
				if(dataCursor != null){dataCursor.close();}
				if(resultSet != null){ resultSet.close();}
			}
		}
	}

	@ActionTrigger(item = "BTN_REGULACAO_PROCEDIMENTO", action = "btn_regulacao_procedimento_click")
	public void btn_regulacao_procedimento_click() {
		if(this.getTask().getServices().existeRegulacao(getItguiaElement().getCdProcedimento()) == true ){
			ItemServices.goItem("PROCED_REGULACAO.CD_PROCED_TIPO_REGULACAO");
			TaskServices.executeQuery("PROCED_REGULACAO");
		}
	}

	@ActionTrigger(item = "TP_INDICADOR_ANEXO", action = "tp_indicador_anexo_change")
	public void tp_indicador_anexo_change() {
		this.getTask().getServices().validacoesPtuOnline(getGuiaElement(), getItguiaElement());
	}

	@ActionTrigger(item = "BTN_ITGUIA_EXECUCAO", action = "btn_itguia_execucao_click")
	public void btn_itguia_execucao_click() {
		
		if(Services.exist("ITGUIA_EXECUCAO", "CD_ITGUIA = " + getItguiaElement().getCdItguia(), false)){
			ItemServices.goItem("ITGUIA_EXECUCAO.BTN_VOLTAR_ITGUIA_EXECUCAO");
		}else{
			//MULTI-IDIOMA: MSG_0045 - Não foi encontrado execuções do procedimento selecionado. 
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0045"), "W", NBool.True);
		}
	}

	@SuppressWarnings("rawtypes")
	@ActionTrigger(item = "BTN_UTILIZACAO", action = "btn_utilizacao_click")
	public void btn_utilizacao_click() {
		
		if (getGuiaElement().getCdMatricula().isNull()) {
			getTask().getMv2000().msgAlert("Beneficiário não encontrado.", "W", NBool.True);
		}
		
		if (getItguiaElement().getCdProcedimento().isNull()) {
			getTask().getMv2000().msgAlert("Procedimento não encontrado.", "W", NBool.True);
		}
		
		Hashtable plId = null;

		plId = TaskServices.getParameterList("P_C_VIDA_USUARIO");

		if (plId == null){
			plId = TaskServices.createParameterList("P_C_VIDA_USUARIO");
		}else{
			plId.clear();
		}

		TaskServices.addParameter(plId, "CD_MATRICULA", getGuiaElement().getCdMatricula());
		TaskServices.addParameter(plId, "CD_PROCEDIMENTO", getItguiaElement().getCdProcedimento());

		TaskServices.callTask("C_VIDA_USUARIO", TaskServices.HIDE, TaskServices.NO_REPLACE, TaskServices.NO_QUERY_ONLY, plId);
	}

	@ActionTrigger(item = "BTN_INFO_OCULOS", action = "btn_info_oculos_click")
	public void btn_info_oculos_click() {
		if (getItguiaElement().getDspTpNatureza().equals("20")) {
			ItemServices.goItem("ITGUIA_OCULOS.BTN_SALVAR_OCULOS");
		}else{
			//MULTI-IDIOMA: MSG_0082 - Funcionalidade não dispoínvel para a natureza do procedimento selecionado.
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0082"), "W", NBool.True);
		}
	}

	@ValidationTrigger(item = "CD_FACES_DENTES_ODONTO")
	public void cd_faces_dentes_odonto_validation() {
		
		if (!getItguiaElement().getCdFacesDentesOdonto().isNull()) {
			boolean isValid = false;
			char letters[] = getItguiaElement().getCdFacesDentesOdonto().toCharArray();

			for (int i = 0; i < letters.length; i++) {
				
				if (String.valueOf(letters[i]).toUpperCase().equals("O")) {// Oclusal
					isValid = true;
				} else if (String.valueOf(letters[i]).toUpperCase().equals("L")) {// Lingual
					isValid = true;
				} else if (String.valueOf(letters[i]).toUpperCase().equals("M")) {// Mesial
					isValid = true;
				} else if (String.valueOf(letters[i]).toUpperCase().equals("V")) {// Vestibular
					isValid = true;
				} else if (String.valueOf(letters[i]).toUpperCase().equals("D")) {// Distal
					isValid = true;
				} else if (String.valueOf(letters[i]).toUpperCase().equals("I")) {// Incisal
					isValid = true;
				} else if (String.valueOf(letters[i]).toUpperCase().equals("P")) {// Palatina
					isValid = true;
				} else {
					isValid = false;
				}
				
				if (!isValid) {
					//MULTI-IDIOMA: MSG_0085 - A face informada para o procedimento %s na posição %s é inválido. 
					getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0085", getItguiaElement().getCdProcedimento(), i+1 ), "W", NBool.True);
				}
			}
		}
	}

	@ActionTrigger(item = "BTN_PERICIA_ODONTO", action = "btn_pericia_odonto_click")
	public void btn_pericia_odonto_click() {
		if (getGuiaElement().getNrGuia().isNull()) {
			//MULTI-IDIOMA: MSG_0009 - Informe o número da guia.
			String MSG_0009 = ResourceManager.getString("guia.msg0009");
			getTask().getMv2000().msgAlert(MSG_0009, "W", NBool.True);
		}
		BlockServices.setBlockWhereClause("ITGUIA_PERICIA", "NR_GUIA = ".concat(getGuiaElement().getNrGuia().toString()));
		BlockServices.getBlockController("ITGUIA_PERICIA").getInteractionRulesStrategy().executeQuery();
		ItemServices.goItem("ITGUIA_PERICIA.BTN_VOLTAR");
	}

	@ValidationTrigger(item = "CD_REGIAO_DENTE")
	public void cd_regiao_dente_validation() {
		NString dsRegiaoDente = NString.getNull();
		if (!getItguiaElement().getCdRegiaoDente().isNull()) {
			dsRegiaoDente = Services.getDescricao("DS_REGIAO_DENTE", "MVS_REGIAO_DENTE", "CD_TISS = '".concat(getItguiaElement().getCdRegiaoDente().toString().concat("'")), false);
			if (dsRegiaoDente.isNull()) {
				//MULTI-IDIOMA: MSG_0144 - Valor do Dente/Região inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0144"), "W", NBool.False);
				return;
			}
		}
		getItguiaElement().setDsRegiaoDente(dsRegiaoDente);
	}

	@ActionTrigger(item = "BTN_NEGATIVA_ITEM", action = "btn_negativa_item_ActionTrigger")
	public void btn_negativa_item_ActionTrigger() {
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N"); 
		
		if(getItguiaElement().getCdMotivo().isNull()){
			getTask().getMv2000().msgAlert("O motivo é obrigatório!", "W", NBool.True);
		}
		
		if (this.getFormModel().getNegacaoItem().getSnAplicarNegativaTodos().equals("S")) {
			TaskServices.commitTask(true);
			this.getTask().getServices().insereLogNegacao(true);
			TaskServices.executeQuery("ITGUIA");
			this.getTask().getServices().negarTodosOsProcedimentoDaGuia(getGuiaElement(),getItguiaElement());
			if(snOperadoraUnimed.equals("S") && !getItguiaElement().getCdMotivoPtuOnline().isNull()){
				this.getTask().getServices().insertItGuiaMensagemEspecifica(getItguiaElement().getNrGuia(),getItguiaElement().getCdItguia(), getItguiaElement().getCdMotivoPtuOnline(),NString.toStr("S"));
			}
			
		}else if(this.getFormModel().getNegacaoItem().getSnAplicarNegativaTodos().equals("N")){
			
			getItguiaElement().setCdUsuarioNegacao(TaskServices.getUser());
			getItguiaElement().setDtNegacao(DbManager.getDBDateTime());
			getItguiaElement().setTpStatus(NString.toStr(3));
			
			getItguiaElement().setQtSolicitado(NNumber.toNumber(0));
			getItguiaElement().setVlProcedimento(NNumber.toNumber(0));
			
			if(snOperadoraUnimed.equals("S") && !getItguiaElement().getCdMotivoPtuOnline().isNull()){
				this.getTask().getServices().insertItGuiaMensagemEspecifica(getItguiaElement().getNrGuia(),getItguiaElement().getCdItguia(), getItguiaElement().getCdMotivoPtuOnline(),NString.toStr("N"));
			}
			
			TaskServices.commitTask(true);
			this.getTask().getServices().insereLogNegacao(true);
			
		}
		ItemServices.goItem("ITGUIA.CD_PROCEDIMENTO");
		TaskServices.executeQuery("ITGUIA");
	}
	
}

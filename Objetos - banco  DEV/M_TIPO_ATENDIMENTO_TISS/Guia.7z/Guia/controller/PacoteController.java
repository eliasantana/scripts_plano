package br.com.mv.soul.mvsaude.forms.Guia.controller;

import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.ViewServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.PacoteAdapter;
import br.com.mv.soul.mvsaude.libs.Services;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class PacoteController extends DefaultBlockController {

	public PacoteController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}
	
	public PacoteAdapter getPacoteElement(){
		return (PacoteAdapter) this.getFormModel().getPacote().getRowAdapter(true);
	}
	
	public ItguiaAdapter getItguiaElement(){
		return (ItguiaAdapter) this.getFormModel().getItguia().getRowAdapter(true);
	}

	@AfterQuery
    public void pacote_AfterQuery(RowAdapterEvent rowAdapterEvent) {

		NString dsProcedimento = Services.getDescricao("DS_PROCEDIMENTO", "DBAPS", "PROCEDIMENTO", "CD_PROCEDIMENTO = '"+getPacoteElement().getCdProcedimento()+"'", false);
		
		getPacoteElement().setDspDsProcedimento(dsProcedimento);		
    }

	@ActionTrigger(item = "BTN_SELECIONAR", action = "btn_selecionar_click")
    public void btn_selecionar_click() {

		getItguiaElement().setCdProcedimento(getPacoteElement().getCdProcedimento());
		
		ViewServices.hideView("CNV_PACOTES");
		ItemServices.goItem("ITGUIA.CD_PROCEDIMENTO");
		
		((ItguiaController)this.getTask().getFormController().getBlockController("ITGUIA")).cdProcedimento_validate();
		
    }

	@ActionTrigger(item = "BTN_CANCELAR", action = "btn_cancelar_click")
    public void btn_cancelar_click() {
		
		ItemServices.goItem("ITGUIA.CD_PROCEDIMENTO");
    }
}

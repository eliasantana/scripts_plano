package br.com.mv.soul.mvsaude.forms.Guia.controller;

import morphis.foundations.core.appdatalayer.events.BeforeRowInsert;
import morphis.foundations.core.appdatalayer.events.BeforeRowUpdate;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaOculosAdapter;
import morphis.foundations.core.types.NBool;
import br.com.mv.soul.common.localization.ResourceManager;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class ItguiaOculosController extends DefaultBlockController {

	public ItguiaOculosController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}
	
	
	public GuiaAdapter getGuiaElement(){
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}

	@BeforeRowInsert
	public void itguia_oculos_BeforeRowInsert(RowAdapterEvent rowAdapterEvent) {
		ItguiaOculosAdapter itguiaOculosAdapter = (ItguiaOculosAdapter)rowAdapterEvent.getRow();
		
		if (!getGuiaElement().getCdMatricula().isNull()) {
			itguiaOculosAdapter.setCdMatricula(getGuiaElement().getCdMatricula());
		}

		this.getTask().getServices().chkItGuiaOculos(itguiaOculosAdapter);
	}

	@ActionTrigger(item = "BTN_VOLTAR_OCULOS", action = "btn_voltar_oculos_click")
	public void btn_voltar_oculos_click() {
		ItemServices.goItem("ITGUIA.BTN_INFO_OCULOS");
	}

	@ActionTrigger(item = "BTN_SALVAR_OCULOS", action = "btn_salvar_oculos_click")
	public void btn_salvar_oculos_click() {
		BlockServices.getBlockController("ITGUIA_OCULOS").getInteractionRulesStrategy().commit(false);
		//MULTI-IDIOMA: MSG_0083 - Informações Salvas.
		getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0083"), "I", NBool.False);
		ItemServices.goItem("ITGUIA.BTN_INFO_OCULOS");
	}

	@BeforeRowUpdate
	public void itguia_oculos_BeforeRowUpdate(RowAdapterEvent rowAdapterEvent) {
		ItguiaOculosAdapter itguiaOculosAdapter = (ItguiaOculosAdapter)rowAdapterEvent.getRow();
		this.getTask().getServices().chkItGuiaOculos(itguiaOculosAdapter);
	}
}

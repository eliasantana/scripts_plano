package br.com.mv.soul.mvsaude.forms.Guia.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;

import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.common.localization.ResourceManager;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAnexoAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.libs.Services;
import morphis.foundations.core.appdatalayer.data.DataCommand;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.events.BeforeRowInsert;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.appsupportlib.util.io.ITextFile;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NString;
	

public class GuiaAnexoController extends DefaultBlockController {

	public GuiaAnexoController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}
	
	public GuiaAdapter getGuiaElement() {

		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}
	
	public GuiaAnexoAdapter getGuiaAnexoElement() {

		return (GuiaAnexoAdapter) this.getFormModel().getGuiaAnexo().getRowAdapter(true);
	}

	@SuppressWarnings("resource")
	private void copyFile(File in, File out) throws Exception {

		FileChannel sourceChannel = new FileInputStream(in).getChannel();
		FileChannel destinationChannel = new FileOutputStream(out).getChannel();
		sourceChannel.transferTo(0, sourceChannel.size(), destinationChannel);
		// or
		//  destinationChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
		sourceChannel.close();
		destinationChannel.close();
	}


	@ActionTrigger(action = "GuiaAnexo_save", function = KeyFunction.DELETE_RECORD)
	public void GuiaAnexo_Delete(){

		//criar msg do tipo sn para perguntar se o usuario deseja realmente excluir e informar que a ação não podera ser desfeita
		//msg deve ser invertida com o não no lugar do sim
		GuiaAnexoAdapter guiaAnexoElement = (GuiaAnexoAdapter) getFormModel().getGuiaAnexo().getRowAdapter(true);

		if(!guiaAnexoElement.getCdGuiaAnexo().isNull()){
			
			//MULTI-IDIOMA: MSG_0060 - Você deseja realmente excluir o anexo selecionado?
			String message = ResourceManager.getString("guia.msg0060");
			//MULTI-IDIOMA: MSG_0075 - Não/Sim
			String simNao = ResourceManager.getString("guia.msg0075");
			
			if (!getTask().getMv2000().msgAlertSn(message,NString.toStr("W"), simNao).toBoolean()){
				BlockServices.deleteRecord();	 
			} 
		}

	}

	/**
	 * Realiza o download do arquivo
	 * 
	 * @author Dellanio Alencar <francisco.alencar@mv.com.br>
	 * @since 14/12/2012
	 * @return void
	 */
	@ActionTrigger(item = "BTN_DOWN_ANEXO", action = "btn_down_anexo_click")
	public void btn_down_anexo_click() {
		GuiaAnexoAdapter guiaAnexoElement = (GuiaAnexoAdapter) getFormModel().getGuiaAnexo().getRowAdapter(true);

		if(!guiaAnexoElement.getDsArquivo().isNull()) {
			try{
				NString nmArquivo = guiaAnexoElement.getDsCaminho().append("\\\\").append(guiaAnexoElement.getDsArquivo());
				Services.downloadFile(new File(nmArquivo.toString()));
			} catch (Exception e) {
				this.getTask().getMv2000().msgAlert("Arquivo: " + guiaAnexoElement.getDsArquivo() + " não gerado no servidor. Erro: " + e.getMessage() , "E", NBool.True);
			}
		} else {
			//MULTI-IDIOMA: MSG_0062 - Você deve selecionar um arquivo para download.
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0062"), "E", NBool.True);
		}
	}

	@ActionTrigger(action="btnUploadAnexo_click", item="BTN_UPLOAD_ANEXO")
	public void btnUploadAnexo_click() {

		if (getGuiaElement() == null && getGuiaElement().getNrGuia().isNull()) {
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0066"), "W", NBool.False);
		}
		
		NString dsCaminhoPastaDb = Services.getDescricao("DS_CAMINHO_PASTA_BD", "DBAMV", "MULTI_EMPRESAS_MV_SAUDE", " CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA ", false);
		String nmArquivo;
		try {
			
			dsCaminhoPastaDb = dsCaminhoPastaDb.append("guias_anexos\\\\").append(Lib.isNull(getGuiaElement().getCdPrestadorExecutor().toString(), 0)).append("\\\\" + getGuiaElement().getNrGuia().toString());
			nmArquivo = Services.uploadFile(getGuiaAnexoElement().getBtnUploadAnexo().toString(), dsCaminhoPastaDb.toString(), true);

			String sql = "INSERT INTO DBAPS.GUIA_ANEXO (CD_GUIA_ANEXO, NR_GUIA, DS_CAMINHO, DS_ARQUIVO) VALUES (DBAPS.SEQ_GUIA_ANEXO.NEXTVAL, :P_NR_GUIA, :P_DS_CAMINHO, :P_DS_ARQUIVO)";
			DataCommand dataCommand = new DataCommand(sql);
			dataCommand.addParameter("P_NR_GUIA", getGuiaElement().getNrGuia());
			dataCommand.addParameter("P_DS_CAMINHO", dsCaminhoPastaDb);
			dataCommand.addParameter("P_DS_ARQUIVO", nmArquivo);
			dataCommand.execute();
			
			NString funcionalidade = new NString("ARQUIVO ANEXADO [ " + nmArquivo + " ] POR [ " + DbManager.getUser() + " ] DATA [ " + DbManager.getDBDateTime() + " ]");
			NString valorNovo = new NString("INCLUSÃO DO ANEXO : " + nmArquivo);
			this.getTask().getServices().insertLog(getGuiaElement().getNrGuia(), funcionalidade, null, null, null, valorNovo);

			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0097",nmArquivo), NString.toStr("I"), NBool.False);
			
		} catch (Exception e) {
			e.printStackTrace();
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0096",e.getMessage()), NString.toStr("E"), NBool.True);
		}finally{
			if (Services.exist("GUIA_ANEXO", "NR_GUIA = ".concat(getGuiaElement().getNrGuia().toString()), false)) {
				TaskServices.executeQuery("GUIA_ANEXO");
			}
		}
	}

	@ActionTrigger(item = "BTN_EXCLUIR_ANEXO", action = "btn_excluir_anexo_click")
	public void btn_excluir_anexo_click() {

		GuiaAnexoAdapter guiaAnexoElement = (GuiaAnexoAdapter) getFormModel().getGuiaAnexo().getRowAdapter(true);		

		if(!guiaAnexoElement.getCdGuiaAnexo().isNull()){
			//MULTI-IDIOMA: MSG_0074 - Você deseja realmente excluir o arquivo selecionado?
			String message = ResourceManager.getString("guia.msg0074");
			//MULTI-IDIOMA: MSG_0057 - Sim/Não
			String simNao = ResourceManager.getString("guia.msg0057");

			if(getTask().getMv2000().msgAlertSn(message, NString.toStr("W"), simNao).toBoolean()) {
				this.getTask().getServices().deletarGuiaAnexo(guiaAnexoElement);
			}

		}else{
			//MULTI-IDIOMA: MSG_0073 - Não existe arquivo para exclusão.
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0073"), "W", NBool.True);
		}

	}

	@ActionTrigger(item = "DS_ARQUIVO", action = "ds_arquivo_doubleClick")
	public void ds_arquivo_doubleClick() {

		GuiaAnexoAdapter guiaAnexoElement = (GuiaAnexoAdapter) getFormModel().getGuiaAnexo().getRowAdapter(true);

		ITextFile expfile = null;		

		if(!guiaAnexoElement.getDsArquivo().isNull()) {

			try{

				//Como o arquivo foi gerado no servidor de BD, é necessáriorio copiar para o servidor de aplicação e enviar para download.
				File fileIn = new File(guiaAnexoElement.getDsCaminho().append("\\\\").append(guiaAnexoElement.getDsArquivo()).toString());
				
				String textfileUrl = Services.copiaArquivo(fileIn);
				
				//especifico da tela
				this.getFormModel().getCgCtrl().setDspDsCaminhoAbrirBrowser(NString.toStr(textfileUrl));
				TaskServices.showDocument(textfileUrl, getGuiaAnexoElement().getDsArquivo().toString());
				
			} catch (Exception e) {
				this.getTask().getMv2000().msgAlert("Arquivo: " + guiaAnexoElement.getDsArquivo() + " não gerado no servidor. Erro: " + e.getMessage() , "E", NBool.True);
			}

		} else {
			this.getTask().getMv2000().msgAlert("Você deve selecionar um arquivo para abrir.", "W", NBool.True);
		}

	}

	@BeforeRowInsert
	public void guia_anexo_BeforeRowInsert(RowAdapterEvent rowAdapterEvent) {}

}

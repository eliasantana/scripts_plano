package br.com.mv.soul.mvsaude.forms.Guia.controller;

import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaPericiaAdapter;
import br.com.mv.soul.mvsaude.libs.Services;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class ItguiaPericiaController extends DefaultBlockController {

	public ItguiaPericiaController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}

	@ActionTrigger(item = "BTN_VOLTAR", action = "btn_voltar_click")
	public void btn_voltar_click() {
		ItemServices.goItem("ITGUIA.BTN_PERICIA_ODONTO");
	}

	@AfterQuery
	public void itguia_pericia_AfterQuery(RowAdapterEvent rowAdapterEvent) {
		ItguiaPericiaAdapter itguiaPericiaElement = (ItguiaPericiaAdapter)rowAdapterEvent.getRow();
		if (!itguiaPericiaElement.getCdProcedimento().isNull()) {
			itguiaPericiaElement.setDspDsProcedimento(Services.getDescricao("DS_PROCEDIMENTO", "PROCEDIMENTO", "CD_PROCEDIMENTO = '".concat(itguiaPericiaElement.getCdProcedimento().toString()).concat("'"), false));
		}
	}
}

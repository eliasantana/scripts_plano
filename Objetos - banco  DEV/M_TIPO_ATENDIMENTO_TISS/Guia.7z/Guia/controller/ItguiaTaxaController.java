package br.com.mv.soul.mvsaude.forms.Guia.controller;

import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import morphis.foundations.core.appdatalayer.events.BeforeQuery;
import morphis.foundations.core.appdatalayer.events.QueryEvent;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;

public class ItguiaTaxaController extends DefaultBlockController {

	public ItguiaTaxaController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}
	
	public GuiaAdapter getGuiaElement() {
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}

	@BeforeQuery
	public void itguia_taxa_BeforeQuery(QueryEvent queryEvent) {
		if(!getGuiaElement().getNrGuia().isNull()){
			queryEvent.setQueryParam("PNR_GUIA", getGuiaElement().getNrGuia());
		}
	}
	
}
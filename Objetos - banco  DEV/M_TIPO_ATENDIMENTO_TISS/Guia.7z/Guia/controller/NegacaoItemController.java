package br.com.mv.soul.mvsaude.forms.Guia.controller;

import morphis.foundations.core.appdatalayer.data.DataCommand;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.Task;
import morphis.foundations.core.appsupportlib.runtime.ITask;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IBlockController;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaMensagemEspecificaAdapter;
import br.com.mv.soul.mvsaude.libs.Services;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class NegacaoItemController extends DefaultBlockController {

	public NegacaoItemController(IFormController parentController, String name) {
		super(parentController, name);
	}
	
	public ItguiaMensagemEspecificaAdapter getItguiaMensagemEspecificaElement(){
		return (ItguiaMensagemEspecificaAdapter) this.getFormModel().getItguiaMensagemEspecifica().getRowAdapter(true);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}
	
	public GuiaAdapter getGuiaElement(){
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}

	public ItguiaAdapter getItguiaElement(){
		return (ItguiaAdapter) this.getFormModel().getItguia().getRowAdapter(true);
	}

	@ActionTrigger(item = "BTN_OK", action = "btn_ok_click")
	public void btn_ok_click() {

		boolean precisaPreencherCampos = false;
		NNumber cdAutorizador = this.getFormModel().getNegacaoItem().getDspCdAutorizador(); 
		NString dsSenha = this.getFormModel().getNegacaoItem().getDspDsSenha();
		
		if(cdAutorizador.isNull()){
			ItemServices.goItem("NEGACAO_ITEM.DSP_CD_AUTORIZADOR");
			precisaPreencherCampos = true;
		}else if(dsSenha.isNull()){
			ItemServices.goItem("NEGACAO_ITEM.DSP_DS_SENHA");
			precisaPreencherCampos = true;
		}

		if(precisaPreencherCampos){

			getTask().getMv2000().msgAlert("O autorizador e a senha devem estar preenchidos!", "W", NBool.False);

		}else{

			this.getTask().getServices().getAutorizadorNegacao(cdAutorizador, true);

			if(this.getTask().getServices().isSenhaAutorizadorValida(cdAutorizador, dsSenha)){

				ItemServices.setItemEnabled("NEGACAO_ITEM.BTN_CONFIRMAR", true);
				ItemServices.setItemEnabled("NEGACAO_ITEM.BTN_CANCELAR_NEGACAO", true);

				ItemServices.setItemEnabled("ITGUIA.CD_MOTIVO", true);

				ItemServices.goItem("ITGUIA.CD_MOTIVO");

				ItemServices.setItemEnabled("NEGACAO_ITEM.DSP_DS_SENHA", false);

			}else{
				
				ItemServices.goItem("NEGACAO_ITEM.DSP_DS_SENHA");

				ItemServices.setItemEnabled("NEGACAO_ITEM.BTN_CONFIRMAR", false);
				ItemServices.setItemEnabled("NEGACAO_ITEM.BTN_CANCELAR_NEGACAO", false);

				ItemServices.setItemEnabled("ITGUIA.CD_MOTIVO", false);
				
			}
		}

	}

	@ActionTrigger(item = "BTN_CONFIRMAR", action = "btn_confirmar_click")
	public void btn_confirmar_click() {
		
		
		
	}

	@ActionTrigger(item = "BTN_VOLTAR", action = "btn_voltar_click")
	public void btn_voltar_click() {

		ItemServices.goItem("ITGUIA.CD_PROCEDIMENTO");
		
		
		//LIMPA O BLOCO SEM PERGUNTAR SE QUER SALVAR (PERDE AS INFORMAÇÕES ALTERADAS POIS NÃO SALVA)
		ITask task = Task.getCurrent();
		String currentBlock = task.getCurrentBlock();

		if (task != null) {
			try {
				IBlockController blkController = task.getBlockController(currentBlock);
				if (blkController != null) {
					blkController.getInteractionRulesStrategy().clearModel();
				}

			} catch (ClassCastException e) {

			}
		}
		
		if (Services.exist("ITGUIA", "NR_GUIA = ".concat(getGuiaElement().getNrGuia().toString()), false)) {
			TaskServices.executeQuery("ITGUIA");			
		}
		
	}

	@ActionTrigger(item = "BTN_CANCELAR_NEGACAO", action = "btn_cancelar_negacao_click")
    public void btn_cancelar_negacao_click() {
		
		if(!getItguiaElement().getDtNegacao().isNull()){
			
			if(getTask().getMv2000().msgAlertSn(NString.toStr("Deseja cancelar a negação do item?"), NString.toStr("W"), NString.toStr("Sim/Não")).toBoolean()){
				
				if (this.getFormModel().getNegacaoItem().getSnAplicarNegativaTodos().equals("N")) {
					
					getItguiaElement().setTpStatus(NString.toStr(0));
					
					getItguiaElement().setCdUsuarioNegacao(NString.getNull());
					getItguiaElement().setDtNegacao(NDate.getNull());
					getItguiaElement().setCdMotivo(NNumber.getNull());
					getItguiaElement().setDspDsMotivo(NString.getNull());
					
					getItguiaElement().setQtSolicitado(NNumber.toNumber(1));
					
					TaskServices.commitTask(true);
					
				}else if(this.getFormModel().getNegacaoItem().getSnAplicarNegativaTodos().equals("S")){
					
					String sqlCommand = " UPDATE DBAPS.ITGUIA              " +
										"    SET CD_USUARIO_NEGACAO = NULL " +
										"      , CD_MOTIVO = NULL          " +
										"      , DT_NEGACAO = NULL         " +
										"      , TP_STATUS = 0             " +
										"      , QT_SOLICITADO = 1         " +
										"  WHERE NR_GUIA = :PNR_GUIA       " +
									    "    AND TP_STATUS = '3'   		   " ;
					DataCommand command = new DataCommand(sqlCommand);
					command.addParameter("PNR_GUIA", getGuiaElement().getNrGuia());
					command.execute();
				}
				this.getTask().getServices().insereLogNegacao(false);
				
				ItemServices.goItem("ITGUIA.CD_PROCEDIMENTO");
				
				TaskServices.executeQuery("ITGUIA");
				
			}
			
		}else{
			
			getTask().getMv2000().msgAlert("Não existe negativa para ser cancelada!", "W", NBool.True);
			
		}

	}

	@ValidationTrigger(item = "DSP_CD_AUTORIZADOR")
	public void dsp_cd_autorizador_validation() {

		NNumber cdAutorizador = this.getFormModel().getNegacaoItem().getDspCdAutorizador();
		
		this.getFormModel().getNegacaoItem().setDspNmAutorizador(NString.getNull());
		
		if(!cdAutorizador.isNull()){

			this.getFormModel().getNegacaoItem().setDspNmAutorizador(this.getTask().getServices().getAutorizadorNegacao(cdAutorizador, true));

		}

		ItemServices.setItemEnabled("NEGACAO_ITEM.DSP_DS_SENHA", true);

		this.getFormModel().getNegacaoItem().setDspDsSenha(NString.getNull());

		ItemServices.setItemEnabled("NEGACAO_ITEM.BTN_CONFIRMAR", false);
		ItemServices.setItemEnabled("NEGACAO_ITEM.BTN_CANCELAR_NEGACAO", false);

		ItemServices.setItemEnabled("ITGUIA.CD_MOTIVO", false);

	}
	
}

package br.com.mv.soul.mvsaude.forms.Guia.controller;

import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.BeforeQuery;
import morphis.foundations.core.appdatalayer.events.QueryEvent;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.SmsModeloAdapter;
import br.com.mv.soul.mvsaude.libs.Services;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class SmsModeloController extends DefaultBlockController {

	public SmsModeloController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}

	public SmsModeloAdapter getSmsModeloElement(){
		return (SmsModeloAdapter) this.getFormModel().getSmsModelo().getRowAdapter(true);
	}

	public GuiaAdapter getGuiaElement(){
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}

	@BeforeQuery
	public void sms_modelo_BeforeQuery(QueryEvent queryEvent) {
		
		NString vStatusGuia = this.getTask().getServices().fncStatusGuia(getGuiaElement().getNrGuia());
		String vSqlWhereStatusGuia = "";
		
		if(vStatusGuia.trim().equals("Autorizado")) {
			vSqlWhereStatusGuia = vSqlWhereStatusGuia + " AND SN_ENVIO_TOT_APROVADA = 'S' "; 
			
		}else if(vStatusGuia.trim().equals("Autorizado parcialmente")) {
			vSqlWhereStatusGuia = vSqlWhereStatusGuia + " AND SN_ENVIO_PARC_APROVADA = 'S' ";
			
		}else if(vStatusGuia.trim().equals("Negado")) {
			vSqlWhereStatusGuia = vSqlWhereStatusGuia + " AND SN_ENVIO_NEGADA = 'S' ";
			
		}else if(vStatusGuia.trim().equals("Cancelada")) {
			vSqlWhereStatusGuia = vSqlWhereStatusGuia + " AND SN_ENVIO_CANCELADA = 'S' ";
			
		}else {
			vSqlWhereStatusGuia = vSqlWhereStatusGuia + " ";
		}

		NString whereClause = BlockServices.getBlockWhereClause("SMS_MODELO");

		NNumber cdTipoAtendimento = Lib.isNull(getGuiaElement().getCdTipoAtendimento(), NNumber.getNull());
		NNumber cdPrestadorExecutor = Lib.isNull(getGuiaElement().getCdPrestadorExecutor(), NNumber.getNull());
		NNumber cdMotivoAutorizacao = Lib.isNull(getGuiaElement().getCdMotivoAutorizacao(), NNumber.getNull());
		
		whereClause = NString.getNull();
		
		whereClause = whereClause.append(" CD_SMS_MODELO IN (  SELECT CD_SMS_MODELO         ")
				.append("           FROM DBAPS.SMS_MODELO                                   ")
				.append("          WHERE CD_TIPO_ATENDIMENTO = :PCD_TIPO_ATENDIMENTO        ")
				.append("            AND CD_PRESTADOR = :PCD_PRESTADOR                      ")
				.append("            AND CD_MOTIVO_AUTORIZACAO = :PCD_MOTIVO_AUTORIZACAO    ")
				.append("            AND DT_INATIVACAO IS NULL                              ")
				.append("         UNION ALL                                                 ")
				.append("         SELECT CD_SMS_MODELO                                      ")
				.append("           FROM DBAPS.SMS_MODELO                                   ")
				.append("          WHERE CD_TIPO_ATENDIMENTO = :PCD_TIPO_ATENDIMENTO        ")
				.append("            AND CD_PRESTADOR = :PCD_PRESTADOR                      ")
				.append("            AND CD_MOTIVO_AUTORIZACAO IS NULL                      ")
				.append("            AND DT_INATIVACAO IS NULL                              ")
				.append("         UNION ALL                                                 ")
				.append("         SELECT CD_SMS_MODELO                                      ")
				.append("           FROM DBAPS.SMS_MODELO                                   ")
				.append("          WHERE CD_TIPO_ATENDIMENTO = :PCD_TIPO_ATENDIMENTO        ")
				.append("            AND CD_PRESTADOR IS NULL                               ")
				.append("            AND CD_MOTIVO_AUTORIZACAO IS NULL                      ")
				.append("            AND DT_INATIVACAO IS NULL                              ")
				.append("         UNION ALL                                                 ")
				.append("         SELECT CD_SMS_MODELO                                      ")
				.append("           FROM DBAPS.SMS_MODELO                                   ")
				.append("          WHERE CD_TIPO_ATENDIMENTO = :PCD_TIPO_ATENDIMENTO        ")
				.append("            AND CD_PRESTADOR IS NULL                               ")
				.append("            AND CD_MOTIVO_AUTORIZACAO = :PCD_MOTIVO_AUTORIZACAO    ")
				.append("            AND DT_INATIVACAO IS NULL                             )")
			    .append(" 			 AND DT_INATIVACAO IS NULL 								")
			    .append(vSqlWhereStatusGuia);
			    

		BlockServices.setBlockWhereClause("SMS_MODELO", whereClause);
		BlockServices.setWhereClauseParameter("SMS_MODELO", "PCD_TIPO_ATENDIMENTO", cdTipoAtendimento);
		BlockServices.setWhereClauseParameter("SMS_MODELO", "PCD_MOTIVO_AUTORIZACAO", cdMotivoAutorizacao);
		BlockServices.setWhereClauseParameter("SMS_MODELO", "PCD_PRESTADOR", cdPrestadorExecutor);

	}

	@ActionTrigger(item = "BTN_ENVIAR", action = "btn_enviar_click")
	public void btn_enviar_click() {
		NString nrTelefone = Lib.isNull(getGuiaElement().getNrDddSms().append(getGuiaElement().getNrCelularSms()),Services.getDescricao("NR_CELULAR", "USUARIO", " CD_MATRICULA = " + getGuiaElement().getCdMatricula(), false));

		NString msg = NString.getNull();
		int qtdSelecionados = 0;

		NNumber currentRecord = BlockServices.getCurrentRecord();
		BlockServices.firstRecord();

		while (true){
			if(getSmsModeloElement().getSnSelecionado().equals("S")){
				qtdSelecionados++;
			}
			if(qtdSelecionados > 1){
				msg = NString.toStr("Existe mais de um modelo selecionado.");
			}
			
			if(BlockServices.isInLastRecord()){
				break;
			}else{
				BlockServices.nextRecord();
			}
		}

		BlockServices.setCurrentRecord(currentRecord);
		
		
		if (qtdSelecionados == 0) {
			msg = NString.toStr("Selecione um modelo para fazer o envio da mensagem.");
		}
		
		if(!msg.isNull()){
			getTask().getMv2000().msgAlert(msg.toString(), "W", NBool.True);
		}else{
			this.getTask().getServices().insertSmsEnvio(getGuiaElement(), getSmsModeloElement().getDsSmsModelo(), getSmsModeloElement().getCdSmsModelo(), nrTelefone, getSmsModeloElement().getDsMensagem());
		}
		
		
		
	}

	@ActionTrigger(item = "BTN_CANCELAR", action = "btn_cancelar_click")
	public void btn_cancelar_click() {
		ItemServices.goItem("CG$CTRL", "BTN_ENVIO_SMS");
	}

	@AfterQuery
	public void sms_modelo_AfterQuery(RowAdapterEvent rowAdapterEvent) {
		SmsModeloAdapter smsModeloElement = (SmsModeloAdapter) rowAdapterEvent.getRow();
		NString dsMensagem = smsModeloElement.getDsMensagem();
		
		NString snOperadoraUnimed = Lib.isNull(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		NString snCortesia = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class), "N"); // Emissão Avulsa
		
		dsMensagem = NString.toStr(dsMensagem.replace("[CD_GUIA]", Lib.isNull(getGuiaElement().getNrGuia(),NString.getNull()).toString()));
		dsMensagem = NString.toStr(dsMensagem.replace("[DT_ATEND]", Lib.isNull(Lib.toChar(getGuiaElement().getDtPrevExecucao(),"DD/MM/YYYY"),NString.getNull()).toString()));
		dsMensagem = NString.toStr(dsMensagem.replace("[DT_AUTORIZACAO]", Lib.isNull(Lib.toChar(getGuiaElement().getDtAutorizacao(),"DD/MM/YYYY"),NString.getNull()).toString()));
		dsMensagem = NString.toStr(dsMensagem.replace("[NM_EXECUTANTE]", Lib.isNull(getGuiaElement().getDspNmExecutor(),NString.getNull()).toString()));
		dsMensagem = NString.toStr(dsMensagem.replace("[NM_LOCAL_EXECUCAO]", Lib.isNull(getGuiaElement().getDsEndereco(), NString.getNull()).toString() ) );
		dsMensagem = NString.toStr(dsMensagem.replace("[NM_SOLICITANTE]", Lib.isNull(getGuiaElement().getNmPrestador(),NString.getNull()).toString()));
		dsMensagem = NString.toStr(dsMensagem.replace("[NM_CLIENTE]", Lib.isNull(getGuiaElement().getDspNmSegurado(),NString.getNull()).toString()));
		dsMensagem = NString.toStr(dsMensagem.replace("[DT_VENCIMENTO]", Lib.isNull(Lib.toChar(getGuiaElement().getDtVencimento(),"DD/MM/YYYY"), NString.getNull()).toString()));
		
		if (snOperadoraUnimed.equals("S")) {
			if(snCortesia.equals("S")){
				dsMensagem = NString.toStr(dsMensagem.replace("[CD_CLIENTE]", Lib.isNull(getGuiaElement().getNrCarteiraBeneficiario(), NString.getNull()).toString()));
			}else{
				dsMensagem = NString.toStr(dsMensagem.replace("[CD_CLIENTE]", Lib.isNull(getGuiaElement().getCdMatAlternativa(), NString.getNull()).toString()));
			}
		}else{
			dsMensagem = NString.toStr(dsMensagem.replace("[CD_CLIENTE]", Lib.isNull(getGuiaElement().getCdMatricula(), NString.getNull()).toString()));
		}
		
		if (dsMensagem.getLength() > 150) {
			dsMensagem = NString.toStr(dsMensagem.substring(0,150));
		}
		smsModeloElement.setDspDsMensagem(dsMensagem);		
	}
}

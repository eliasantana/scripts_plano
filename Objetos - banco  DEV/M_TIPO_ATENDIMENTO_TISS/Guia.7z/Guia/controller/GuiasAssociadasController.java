package br.com.mv.soul.mvsaude.forms.Guia.controller;

import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.BeforeQuery;
import morphis.foundations.core.appdatalayer.events.QueryEvent;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiasAssociadasAdapter;
import br.com.mv.soul.mvsaude.libs.Services;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class GuiasAssociadasController extends DefaultBlockController {

	public GuiasAssociadasController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}

	public GuiaAdapter getGuiaElement() {
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}

	public GuiasAssociadasAdapter getGuiasAssociadasElement() {
		return (GuiasAssociadasAdapter) this.getFormModel().getGuiasAssociadas().getRowAdapter(true);
	}

	@BeforeQuery
	public void guias_associadas_BeforeQuery(QueryEvent queryEvent) {
		if (!getGuiaElement().getNrGuia().isNull()) {
			NString vQuery = NString.toStr("SELECT DECODE(SN_VALIDA_REST_CARENCIA, 'S' , NR_GUIA, NULL) NR_GUIA, NR_GUIA NR_GUIA_PROCEDIMENTO, CD_PRESTADOR_EXECUTOR, DT_AUTORIZACAO, CD_AUTORIZADOR, NR_GUIA_TEM, CD_TIPO_ATENDIMENTO, SN_VALIDA_REST_CARENCIA, NR_TRANSACAO FROM DBAPS.GUIA WHERE NR_GUIA_TEM =").append(getGuiaElement().getNrGuia());
			BlockServices.setBlockQueryDataSourceName("GUIAS_ASSOCIADAS", NString.toStr(vQuery));
		}
	}

	@ActionTrigger(action = "doubleClick")
	public void nr_guia_doubleClick() {
		NNumber nrGuia = Lib.isNull(getGuiasAssociadasElement().getNrGuia(), getGuiasAssociadasElement().getNrGuiaProcedimento());
		if(!nrGuia.isNull()){
			this.getTask().getServices().abrirTelaGuia(nrGuia);
			ItemServices.goItem("GUIAS_ASSOCIADAS.NR_GUIA");
		}
	}

	@ActionTrigger(item = "BTN_ABRIR_GUIA", action = "btn_abrir_guia_click")
	public void btn_abrir_guia_click() {
		NNumber nrGuia = Lib.isNull(getGuiasAssociadasElement().getNrGuia(), getGuiasAssociadasElement().getNrGuiaProcedimento());
		if(!nrGuia.isNull()){
			this.getTask().getServices().abrirTelaGuia(nrGuia);
			ItemServices.goItem("GUIAS_ASSOCIADAS.NR_GUIA");
		}
	}	

	@ActionTrigger(item = "BTN_VOLTAR", action = "btn_voltar_click")
	public void btn_voltar_click() {
		ItemServices.goItem("GUIA.NR_GUIA_TEM");
	}

	@AfterQuery
	public void guias_associadas_AfterQuery(RowAdapterEvent rowAdapterEvent) {
		GuiasAssociadasAdapter guiasAssociadasAdapter = (GuiasAssociadasAdapter)rowAdapterEvent.getRow();
		
		getGuiasAssociadasElement().setDspDsTpGuia(Services.getDescricao("DS_TIPO_ATENDIMENTO", "TIPO_ATENDIMENTO", "CD_TIPO_ATENDIMENTO = " + guiasAssociadasAdapter.getCdTipoAtendimento(), false));
		getGuiasAssociadasElement().setDspNmPrestador(Services.getDescricao("NM_PRESTADOR", "PRESTADOR", "CD_PRESTADOR = " + guiasAssociadasAdapter.getCdPrestadorExecutor(), false));
		getGuiasAssociadasElement().setDspNmAutorizador(Services.getDescricao("NM_AUTORIZADOR", "AUTORIZADOR", "CD_AUTORIZADOR = " + guiasAssociadasAdapter.getCdAutorizador(), false));
		ItemServices.setItemStyleClass("GUIAS_ASSOCIADAS.NR_GUIA", BlockServices.getCurrentRecord("GUIAS_ASSOCIADAS"), guiasAssociadasAdapter.getSnValidaRestCarencia().equals("S") ? "" : "PretoGuia" );

	}

	@ValidationTrigger(item = "CD_AUTORIZADOR")
	public void cd_autorizador_validation() {}


}

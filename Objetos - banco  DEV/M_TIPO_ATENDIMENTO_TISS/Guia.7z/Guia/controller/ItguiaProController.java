package br.com.mv.soul.mvsaude.forms.Guia.controller;

import static morphis.foundations.core.appsupportlib.Lib.isNull;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemEnabled;
import static morphis.foundations.core.types.Types.toBool;
import static morphis.foundations.core.types.Types.toStr;

import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.AfterRowInsert;
import morphis.foundations.core.appdatalayer.events.BeforeRowDelete;
import morphis.foundations.core.appdatalayer.events.BeforeRowInsert;
import morphis.foundations.core.appdatalayer.events.DeleteDetails;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaProAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.services.PkgMvsGuia;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	


public class ItguiaProController extends DefaultBlockController
{

    public ItguiaProController(IFormController parentController, String name)
    {
        super(parentController, name);
    }

    @Override
     public GuiaTask getTask()
    {
        return (GuiaTask) super.getTask();
    }

    public GuiaModel getFormModel()
    {
        return this.getTask().getModel();
    }

	@AfterQuery
	public void itguiaPro_AfterQuery(RowAdapterEvent args) {

		ItguiaProAdapter itguiaProElement = (ItguiaProAdapter) args.getRow();

		if (!itguiaProElement.getCdProcedimento().isNull()) {
			try {
				cdProcedimento_validate();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

    @BeforeRowDelete
    public void itguiaPro_BeforeRowDelete(RowAdapterEvent args)
    {

        ItguiaProAdapter itguiaProElement = (ItguiaProAdapter) args.getRow();
        PkgMvsGuia.pBPdItguiaPro(itguiaProElement);
    }

    @DeleteDetails
    public void itguiaPro_DeleteDetails(RowAdapterEvent args)
    {

        //
        // Begin default relation declare section
        //
        ItguiaProAdapter itguiaProElement = (ItguiaProAdapter) args.getRow();
        PkgMvsGuia.pBOcdmItguiaPro(itguiaProElement);
    }

    @ValidationTrigger(item = "CD_PROCEDIMENTO")
	public void cdProcedimento_validate() {

		// F2N_WARNING : Caution, the variable may be null.
		ItguiaProAdapter itguiaProElement = (ItguiaProAdapter) this.getFormModel().getItguiaPro().getRowAdapter(true);

		if (!itguiaProElement.getCdProcedimento().isNull()) {
			this.getTask().getServices().prcValidaProcedimentoInativo(itguiaProElement.getCdProcedimento());
			this.getTask().getServices().prcProcedimento(itguiaProElement.getCdProcedimento(), toStr("S"));
		}
	}

    @ValidationTrigger(item = "QT_SOLIC_PREST")
    public void qtSolicPrest_validate()
    {

        // F2N_WARNING : Caution, the variable may be null.
        ItguiaAdapter itguiaElement = (ItguiaAdapter) this.getFormModel()
                .getItguia().getRowAdapter(true);

        if (isNull(itguiaElement.getQtSolicitado(), 0).equals(0))
        {
            itguiaElement.setQtSolicitado(itguiaElement.getQtSolicPrest());
        }
    }

    @ValidationTrigger(item = "QT_SOLICITADO")
    public void qtSolicitado_validate()
    {

        // F2N_WARNING : Caution, the variable may be null.
        ItguiaAdapter itguiaElement = (ItguiaAdapter) this.getFormModel()
                .getItguia().getRowAdapter(true);

        if (isNull(itguiaElement.getDspQtMaximaSolic(), 0).greater(0))
        {
            if (itguiaElement.getQtSolicitado().greater(
                    itguiaElement.getDspQtMaximaSolic()))
            {
                getTask()
                        .getMv2000()
                        .msgAlert(
                                toStr("A quantidade informada não pode ser maior que a quantidade máxima por solicitação indicada no cadastro de procedimentos."),
                                toStr("E"), toBool(NBool.True));
            }
        }
    }

    // pda 404139
    @BeforeRowInsert
	public void itguiaPro_BeforeRowInsert(RowAdapterEvent args) {

		String sqlcSeq = "select DBAPS.SEQ_CD_ITGUIA.NEXTVAL from sys.dual ";
		DataCursor cSeq = new DataCursor(sqlcSeq);
		
		ItguiaProAdapter itGuiaProElement = (ItguiaProAdapter) this.getFormModel().getItguiaPro().getRowAdapter(true);
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		
		try {
			if (itGuiaProElement.getNrGuia().isNull()) {
				itGuiaProElement.setNrGuia(guiaElement.getNrGuia());
			}
			if (itGuiaProElement.getCdItguia().isNull()) {
				cSeq.open();
				ResultSet cSeqValor = cSeq.fetchInto();
				if (cSeqValor != null) {
					itGuiaProElement.setCdItguia(cSeqValor.getNumber(0));
				}
			}
		} finally {
			cSeq.close();
		}

	}

    // pda 404139
    @AfterRowInsert
    public void itguiaPro_AfterRowInsert(RowAdapterEvent args)
    {
        setItemEnabled("GUIA_PRORROGACAO.BTN_ANALISAR", true);
    }

}

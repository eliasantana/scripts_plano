package br.com.mv.soul.mvsaude.forms.Guia.controller;

import static morphis.foundations.core.types.NBool.toBool;
import static morphis.foundations.core.types.Types.toStr;

import java.util.HashMap;

import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.common.localization.ResourceManager;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaHonorarioAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.services.GuiaServices;
import br.com.mv.soul.mvsaude.libs.Services;
import morphis.foundations.core.appdatalayer.data.DataLayerException;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
	

public class GuiaHonorarioController extends DefaultBlockController {

	public GuiaHonorarioController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}
	
	public GuiaAdapter getGuiaElement(){
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}
	
	public GuiaHonorarioAdapter getGuiaHonorarioElement(){
		return (GuiaHonorarioAdapter) this.getFormModel().getGuiaHonorario().getRowAdapter(true);
	}

	@ActionTrigger(item = "BTN_GERAR", action = "btn_gerar_click")
	public void btn_gerar_click() {
		
		boolean erro = false;

		if(getGuiaElement().getDspTpGuia().equals("I") || getGuiaElement().getDspTpGuia().equals("S")){
			
			NNumber pNrGuiaTem = getGuiaElement().getNrGuia();
			NNumber pCdTipoAtendimento = NNumber.toNumber(Services.getDescricao("MIN(CD_TIPO_ATENDIMENTO)", "TIPO_ATENDIMENTO", "TP_GUIA = 'H'", false));
			HashMap<NNumber, NNumber> prestadores = new HashMap<NNumber, NNumber>();
			
			this.getTask().getServices().validaGeracaoHonorario();
			
			TaskServices.goBlock("GUIA_HONORARIO");
			BlockServices.firstRecord();
			while(true){
				
				NNumber pCdEspecialidade = getGuiaHonorarioElement().getDspCdEspecialidade();
				NNumber pCdPrestadorExecutor = getGuiaHonorarioElement().getDspCdPrestador();
				NNumber pCdAtiMed = getGuiaHonorarioElement().getDspCdAtiMed();
				
				try {
					
					if(!prestadores.containsKey(pCdPrestadorExecutor)){
						GuiaServices.prcGeraGuiaAssociada(pNrGuiaTem, pCdTipoAtendimento, pCdPrestadorExecutor, pCdAtiMed, pCdEspecialidade);
						prestadores.put(pCdPrestadorExecutor, pCdPrestadorExecutor);
					}
					
				} catch (DataLayerException e) {
					erro = true;
					String mensagemDeRetorno = ResourceManager.getString("guia.msg0011");
					getTask().getMv2000().msgAlert(mensagemDeRetorno, Services.TIPOMSGWARNING, NBool.False);
					
				} catch (Exception e) {
					erro = true;
					e.printStackTrace();
					getTask().getMv2000().msgAlert(e.getMessage(), Services.TIPOMSGWARNING, NBool.False);
				}
				
				if(BlockServices.isInLastRecord()){
					break;
				}else{
					BlockServices.nextRecord();
				}
			}
			
			if(!erro){
				
				BlockServices.clearBlock();
			
				if(getTask().getMv2000().msgAlertSn(NString.toStr("Geração efetuada com sucesso!\n\nDeseja visualizar as guias associadas?"), NString.toStr("W"), NString.toStr("Sim/Não")).toBoolean()){
					TaskServices.executeQuery("GUIAS_ASSOCIADAS");
					TaskServices.goBlock("GUIA");
					ItemServices.goItem("GUIAS_ASSOCIADAS.NR_GUIA");
				}else{
					TaskServices.goBlock("GUIA");
				}
			}
			
		}else{
			getTask().getMv2000().msgAlert("Para este tipo de guia não é possível gerar Honorários", "W", NBool.False);
		}
		
	}

	@ActionTrigger(item = "BTN_CANCELAR", action = "btn_cancelar_click")
	public void btn_cancelar_click() {
		
		BlockServices.clearBlock("GUIA_HONORARIO");
		ItemServices.goItem("GUIA.NR_GUIA");
		
	}

	@ValidationTrigger(item = "DSP_CD_PRESTADOR")
	public void dsp_cd_prestador_validation() {
		
		this.getTask().getServices().setPrestadorExecutorHonorario();
		
	}

	@ValidationTrigger(item = "DSP_CD_ATI_MED")
	public void dsp_cd_ati_med_validation() {
		
		if(!getGuiaHonorarioElement().getDspCdAtiMed().isNull()){
			
			NString dsAtiMed = Services.getDescricao("DS_ATI_MED", "ATI_MED", "CD_ATI_MED = " + getGuiaHonorarioElement().getDspCdAtiMed(), false);
			
			if(!dsAtiMed.isNull()){
				getGuiaHonorarioElement().setDspDsAtiMed(dsAtiMed);
			}else{
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Erro.....: Operação inválida!")
						.append(Lib.chr(10))
						.append("Motivo..: Esta atividade médica não existe.")
						.append(Lib.chr(10))
						.append("Ação....: Informe outra atividade médica.").toString(),
						"W", /*W = Atenção, I = Informação, E = Erro */
						NBool.True /*bloquear/travar?*/);
			}
			
		}else{
			getGuiaHonorarioElement().setDspDsAtiMed(NString.getNull());
		}
		
	}

	@ActionTrigger(item = "BTN_ADD", action = "btn_add_click")
	public void btn_add_click() {
		
		BlockServices.createRecord();
		
	}

	@ActionTrigger(item = "BTN_REMOVE", action = "btn_remove_click")
	public void btn_remove_click() {

		BlockServices.deleteRecord();
		
	}

	@ValidationTrigger(item = "DSP_CD_ESPECIALIDADE")
	public void dsp_cd_especialidade_validation() {
		
		if(!getGuiaHonorarioElement().getDspCdEspecialidade().isNull()){

			NString dsAtiMed = Services.getDescricao("DS_ESPECIALIDADE", "ESPECIALIDADE", "CD_ESPECIALIDADE = " + getGuiaHonorarioElement().getDspCdEspecialidade(), false);

			if(!dsAtiMed.isNull()){
				getGuiaHonorarioElement().setDspDsEspecialidade(dsAtiMed);
			}else{
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Erro.....: Operação inválida!")
						.append(Lib.chr(10))
						.append("Motivo..: Esta especialidade não existe.")
						.append(Lib.chr(10))
						.append("Ação....: Informe outra especialidade.").toString(),
						"W", /*W = Atenção, I = Informação, E = Erro */
						NBool.True /*bloquear/travar?*/);
			}

		}else{
			getGuiaHonorarioElement().setDspDsEspecialidade(NString.getNull());
		}
		
	}
}

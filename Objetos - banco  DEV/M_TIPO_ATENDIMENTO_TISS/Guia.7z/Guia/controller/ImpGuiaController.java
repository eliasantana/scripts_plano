package br.com.mv.soul.mvsaude.forms.Guia.controller;

import static morphis.foundations.core.appsupportlib.Lib.toChar;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.goItem;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.addParameter;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.createParameterList;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.executeAction;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.getParameterList;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.setParameter;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.hideView;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.showView;
import static morphis.foundations.core.types.Types.toBool;
import static morphis.foundations.core.types.Types.toStr;

import java.util.Hashtable;

import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	


public class ImpGuiaController extends DefaultBlockController
{

    public ImpGuiaController(IFormController parentController, String name)
    {
        super(parentController, name);
    }

    @Override
     public GuiaTask getTask()
    {
        return (GuiaTask) super.getTask();
    }

    public GuiaModel getFormModel()
    {
        return this.getTask().getModel();
    }

	@ActionTrigger(action = "impGuia_moveDown", function = KeyFunction.NEXT_RECORD)
	public void impGuia_moveDown() {

	}

    @SuppressWarnings("rawtypes")
	@ActionTrigger(action = "btOk_click", item = "BT_OK")
    public void btOk_click()
    {

        // F2N_WARNING : Caution, the variable may be null.
        GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia()
                .getRowAdapter(true);

        {
            Hashtable plId = null;
            plId = getParameterList("Pl_Report");
            if ((plId == null))
            {
                plId = createParameterList("PL_Report");
                addParameter(plId, "p_nr_guia", toChar(guiaElement.getNrGuia()));
            }
            else
            {
                setParameter(plId, "p_nr_guia", toChar(guiaElement.getNrGuia()));
            }
            getTask().getModal().getPkgImprime()
                    .parametro(toStr("DESNAME"), toStr(null));
            getTask()
                    .getModal()
                    .getPkgImprime()
                    .parametro(toStr("P_NR_GUIA"),
                            toChar(guiaElement.getNrGuia()));
            getTask()
                    .getModal()
                    .getPkgImprime()
                    .parametro(toStr("P_GUIA_PRESTADOR"),
                            getFormModel().getImpGuia().getCkImpPrestador());
            getTask()
                    .getModal()
                    .getPkgImprime()
                    .parametro(toStr("P_GUIA_CIRURGIAO"),
                            getFormModel().getImpGuia().getCkImpCirurgiao());
            getTask()
                    .getModal()
                    .getPkgImprime()
                    .parametro(toStr("P_GUIA_AUXILIAR1"),
                            getFormModel().getImpGuia().getCkImpAuxiliar1());
            getTask()
                    .getModal()
                    .getPkgImprime()
                    .parametro(toStr("P_GUIA_AUXILIAR2"),
                            getFormModel().getImpGuia().getCkImpAuxiliar2());
            getTask()
                    .getModal()
                    .getPkgImprime()
                    .parametro(toStr("P_GUIA_AUXILIAR3"),
                            getFormModel().getImpGuia().getCkImpAuxiliar3());
            getTask()
                    .getModal()
                    .getPkgImprime()
                    .parametro(toStr("P_GUIA_ANESTESISTA"),
                            getFormModel().getImpGuia().getCkImpAnestesista());
            // Pkg$Imprime.Parametro( 'P_TITULO', 'Relatório de Solicitação de
            // Produtos' );

            NString rep = toStr("/mvsaude/").append(
                    toStr(guiaElement.getDspDsProgramaDaGuia().replace(".REP",
                            "")));

            getTask()
                    .getModal()
                    .getPkgImprime()
                    .abrir(toStr("Emissão da Guia"), rep, toStr(null),
                            toBool(NBool.False), toBool(NBool.True),
                            toBool(NBool.False));

            // getTask().getModal().getPkgImprime().abrir(toStr("Emissão da Guia"),
            // guiaElement.getDspDsProgramaDaGuia());
            // RUN_PRODUCT(REPORTS,:GUIA.dsp_ds_programa_da_guia,SYNCHRONOUS,RUNTIME,FILESYSTEM,pl_id,NULL);
//CARE-VALIDATION: HideView without Go 
            hideView("CNV_IMPRIME_GUIAS");
            showView("CG$PAGE_1");
            goItem(toStr("GUIA.CD_MATRICULA"));
            executeAction("CLEAR_FORM");
        }
    }

    @ActionTrigger(action = "btCancelar_click", item = "BT_CANCELAR")
    public void btCancelar_click()
    {

//CARE-VALIDATION: HideView without Go 
        hideView("CNV_IMPRIME_GUIAS");
        showView("CG$PAGE_1");
        goItem(toStr("GUIA.CD_MATRICULA"));
    }

}

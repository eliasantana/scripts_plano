package br.com.mv.soul.mvsaude.forms.Guia.controller;

import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaAuditoriaAdapter;
import br.com.mv.soul.mvsaude.libs.Services;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class ItguiaAuditoriaController extends DefaultBlockController {

	public ItguiaAuditoriaController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}

	@ValidationTrigger(item = "CD_PROCEDIMENTO")
	public void cd_procedimento_validation() {

	}

	@AfterQuery
	public void itguia_auditoria_AfterQuery(RowAdapterEvent rowAdapterEvent) {
		ItguiaAuditoriaAdapter row = (ItguiaAuditoriaAdapter)rowAdapterEvent.getRow();
		if (!row.getCdProcedimento().isNull()) {
			row.setDspDsProcedimento(Services.getDescricao("DS_PROCEDIMENTO", "PROCEDIMENTO", "CD_PROCEDIMENTO = '"+ row.getCdProcedimento()+"'", false));
		}
		if (Services.exist("ITGUIA_MENSAGEM_ESPECIFICA", "CD_ITGUIA = "+row.getCdItguia(), false)) {
			row.setTpResposta(NString.toStr("Auditado"));
		}else{
			if (row.getTpStatus().equals("2")) {				
				row.setTpResposta(NString.toStr("Aguardando Resposta"));
			}
		}
		
	}
}

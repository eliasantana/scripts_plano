package br.com.mv.soul.mvsaude.forms.Guia.controller;

import static morphis.foundations.core.appsupportlib.Lib.in;
import static morphis.foundations.core.appsupportlib.Lib.isNull;
import static morphis.foundations.core.appsupportlib.Lib.toChar;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.firstRecord;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.isInLastRecord;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.nextRecord;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.setBlockInsertAllowed;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.setBlockUpdateAllowed;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.goItem;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemEnabled;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.commitTask;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.executeQuery;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.goBlock;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.hideView;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.showView;
import static morphis.foundations.core.types.Types.toBool;
import static morphis.foundations.core.types.Types.toNumber;
import static morphis.foundations.core.types.Types.toStr;
import static morphis.foundations.core.util.globals.Globals.setGlobal;

import java.util.Hashtable;

import br.com.mv.soul.common.dbservices.StoredProcedures;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.common.libs.DbUtils.DataList;
import br.com.mv.soul.common.localization.ResourceManager;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaProrrogacaoAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.ItguiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.services.GuiaServices;
import br.com.mv.soul.mvsaude.libs.Services;
import br.com.mv.soul.mvsaude.libs.WebService.WebService;
import morphis.foundations.core.appdatalayer.data.DataCommand;
import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.Globals;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.ViewServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.util.Ref;
import morphis.foundations.core.util.logging.ILogger;
import morphis.foundations.core.util.logging.LogTraceEvent;
import morphis.foundations.core.util.logging.LogTraceMessage;
import morphis.foundations.core.util.logging.LoggerFactory;
import morphis.foundations.core.util.logging.LogTraceEvent.LEVEL;
	

public class CgCtrlController extends DefaultBlockController
{

	protected static ILogger logger = LoggerFactory.getInstance(CgCtrlController.class);
	
	private Ref<NString> ptp_grupo_franquia_ref = new Ref<NString>(NString.getNull());

	public CgCtrlController(IFormController parentController, String name)
	{
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask()
	{
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel()
	{
		return this.getTask().getModel();
	}

	public GuiaAdapter getGuiaElement(){
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}

	public ItguiaAdapter getItguiaElement(){
		return (ItguiaAdapter) this.getFormModel().getItguia().getRowAdapter(true);
	}
	
	public GuiaProrrogacaoAdapter getGuiaProrrogacaoElement(){
		return (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
	}

	@ActionTrigger(action = "snCancelaAutorizacao_change", item = "SN_CANCELA_AUTORIZACAO")
	public void snCancelaAutorizacao_change()
	{

		if (isNull(getFormModel().getCgCtrl().getSnCancelaAutorizacao(), "N").equals("S")) {
			getFormModel().getCgCtrl().setCdMotCancelamento(NNumber.getNull());
			getFormModel().getCgCtrl().setDspDsMotCancelamento(NString.getNull());
			getFormModel().getCgCtrl().setDspDsObservacaoCancelamento(NString.getNull());
			ItemServices.setItemEnabled("CG$CTRL.CD_MOT_CANCELAMENTO", false);
			ItemServices.setItemEnabled("CG$CTRL.DSP_DS_OBSERVACAO_CANCELAMENTO", false);
		} else {
			ItemServices.setItemEnabled("CG$CTRL.CD_MOT_CANCELAMENTO", true);
			ItemServices.setItemEnabled("CG$CTRL.DSP_DS_OBSERVACAO_CANCELAMENTO", true);
			ItemServices.setItemEnabled("CG$CTRL.BTN_CD_MOT_CANCELAMENTO", true);
		}
	}

	@ValidationTrigger(item = "CD_AUTORIZADOR_OPE")
	public void cdAutorizadorOpe_validate(){
	
		/**
		 * Foi adicionado esse if porque estava abrindo a tela para realizar autorização
		 * Motivo desconhecido.
		 */
		if(!getFormModel().getCgCtrl().getCdAutorizadorOpe().isNull()) {
			String sql = "SELECT AUTORIZ.CD_AUTORIZADOR CD_AUTORIZADOR , AUTORIZ.NM_AUTORIZADOR NM_AUTORIZADOR "
					+ ", AUTORIZ.NR_NIVEL NR_NIVEL , AUTORIZ.DS_SENHA DS_SENHA , AUTORIZ.SN_AUTORIZA_PROCED "
					+ ", AUTORIZ.SN_AUTORIZA_GUIA , AUTORIZ.SN_AUTORIZA_LIMITE , AUTORIZ.SN_EXCLUI_GUIA "
					+ ", AUTORIZ.SN_EXCLUI_AGENDA , AUTORIZ.SN_AUTORIZA_PRORROGACAO , AUTORIZ.TP_AUTORIZADOR "
					+ ", AUTORIZ.CD_AUTORIZADOR CD_AUTORIZADOR, AUTORIZ.NM_AUTORIZADOR DSP_NM_AUTORIZADOR, "
					+ " AUTORIZ.NR_NIVEL DSP_NR_NIVEL, AUTORIZ.DS_SENHA DSP_DS_SENHA  FROM DBAPS.AUTORIZADOR AUTORIZ, "
					+ " DBAPS.ME_AUTORIZADOR ME_AUT  WHERE AUTORIZ.CD_AUTORIZADOR = ME_AUT.CD_AUTORIZADOR "
					+ " AND ME_AUT.CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA AND AUTORIZ.CD_AUTORIZADOR = :CD_AUTORIZADOR  "
					+ " ORDER BY AUTORIZ.NM_AUTORIZADOR ASC";

			DataCursor dataCursor = new DataCursor(sql);
			dataCursor.addParameter("CD_AUTORIZADOR", getFormModel().getCgCtrl().getCdAutorizadorOpe());
			dataCursor.open();
			ResultSet resultado = dataCursor.fetchInto();

			if (resultado != null) {
				ItemServices.setItemValue("CG$CTRL.DSP_NM_AUTORIZADOR_OPE", resultado.getString("DSP_NM_AUTORIZADOR"));
				this.getFormModel().getCgCtrl().setDspNmAutorizadorOpe(resultado.getStr("nm_autorizador"));
				this.getFormModel().getCgCtrl().setCdAutorizadorOpe(resultado.getNumber("cd_autorizador"));
				this.getFormModel().getCgCtrl().setDsSenhaAutorizadorOpe(resultado.getStr("ds_senha"));
			} else {

				//MULTI-IDIOMA: MSG_0007 - O autorizador informado não existe ou o parâmetro não foi informado.
				String msg = ResourceManager.getString("guia.msg0007");
				getTask().getMv2000().msgAlert(msg, "W", NBool.True);
			}
			dataCursor.close();
		}
	}

	@ValidationTrigger(item = "CD_MOT_CANCELAMENTO")
	public void cdMotCancelamento_validate() {
		
		if (!getFormModel().getCgCtrl().getCdMotCancelamento().isNull()) {

			String sql = "SELECT DS_MOT_CANCELAMENTO_GUIA , TP_MOTIVO " 
					+ " FROM DBAPS.MOT_CANCELAMENTO_GUIA " 
					+ " WHERE CD_MOT_CANCELAMENTO_GUIA = :PCD_MOT_CANCELAMENTO_GUIA";
			DataCursor cCursor = new DataCursor(sql);

			try {

				cCursor.addParameter("PCD_MOT_CANCELAMENTO_GUIA", getFormModel().getCgCtrl().getCdMotCancelamento() );
				cCursor.open(); 

				if(cCursor.found()){

					ResultSet rs = cCursor.fetchInto();
					getFormModel().getCgCtrl().setDspDsMotCancelamento(rs.getStr("DS_MOT_CANCELAMENTO_GUIA"));
					getFormModel().getCgCtrl().setDspTpMotCancelamento(rs.getStr("TP_MOTIVO"));

				}else{
					//MULTI-IDIOMA: MSG_0041 - Motivo de Cancelamento da Guia não cadastrado.
					String msg = ResourceManager.getString("guia.msg0041");
					getTask().getMv2000().msgAlert(msg, "W", NBool.True);
				}

			}finally {
				cCursor.close();
			}

		}else{
			getFormModel().getCgCtrl().setDspDsMotCancelamento(NString.getNull());
		}
	}


	@SuppressWarnings("unused")
	@ActionTrigger(action = "btnOk_click", item = "BTN_OK")
	public void btnOk_click() {
		/**
		 * O Parametro CHAMA_AUTORIZ pode ser os seguintes valores.
		 * 
		 * L = Liberação de Guia
		 * C = Negativa/Cancelamento de Guia
		 * R = Negativa/Cancelamento da Guia de Prorrogação
		 * A = Alteração do Prestador da Guia
		 * S = Alteração do Status da Guia
		 * P = Liberacao da Guia de Prorrogação
		 * V = Alteração do valor do procedimento
		 * PTU-I = PTU Online Insistência
		 * PTU-AI = PTU Online Comunicação de Internação ou Alta do Beneficiário 
		 */
		NString tpChamadaAutorizacao = this.getFormModel().getParam("CHAMA_AUTORIZ", NString.class);
		NString cdUsuario = this.getFormModel().getParam("CD_USUARIO", NString.class);
		NString snCortesia = Lib.isNull(this.getFormModel().getParam("PSN_CORTESIA", NString.class),"N");

		NString snLiberaGuiaSemPagamento = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_LIBERA_GUIA_SEM_PAGAMENTO"),"N");
		NString snOperadoraUnimed = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED"),"N");
		NString snEnvioAutoSmsLiberaGuia = Lib.isNull(getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_ENVIO_AUTO_SMS_LIBERA_GUIA"), "N");

		NString psqGuiaProrrogacao = NString.getNull();
		NNumber wNrNivel = NNumber.getNull();
		NString wSnExcluiGuia = NString.getNull();
		NString wSnAutorizaGuia = NString.getNull();
		NString wSnAutorizaLimite = NString.getNull();
		NString wSnAutorizaProrrogacao = NString.getNull();
		NDate wDtBaixado = NDate.getNull();
		NNumber nstatusant = NNumber.getNull();
		NNumber nstatusdep = NNumber.getNull();
		NNumber nnrnivelprocedimento = NNumber.getNull();
		NString cstatusant = NString.getNull();
		NString cstatusdep = NString.getNull();
		NString cmsg = NString.getNull();
		NString cdsfuncionalidade = NString.getNull();
		NNumber nrGuiaProrrogacao = NNumber.getNull();
		Ref<DataList> vlstParamret = new Ref<DataList>(new DataList());
		Ref<DataList> vlstParamret1 = new Ref<DataList>(new DataList());
		NBool gerarRecebimento = NBool.False;
		
		//--MENSAGENS
		//MULTI-IDIOMA: MSG_0009 - Informe o número da guia.
		String MSG_0009 = ResourceManager.getString("guia.msg0009");
		//MULTI-IDIOMA: MSG_0007 - O autorizador informado não existe ou o parâmetro não foi informado.
		String MSG_0007 = ResourceManager.getString("guia.msg0007");
		//MULTI-IDIOMA: MSG_1004 - Senha Inválida ou não Preenchida.
		String MSG_1004 = ResourceManager.getString("guia.msg1004");

		if (tpChamadaAutorizacao.equals("S")) {
			validarGuiaAutorizada();
		}

		if(snOperadoraUnimed.equals("S") && getGuiaElement().getCdMatricula().isNull() 
				&& !getGuiaElement().getCdUnimedOrigem().isNull()
				&& !getGuiaElement().getCdUnimedOrigem().equals(getGuiaElement().getCdUnimedExecutora())
				&& tpChamadaAutorizacao.equals("C")){

			try{

				if (getGuiaElement().getNrGuia().isNull()) {
					throw new Exception(MSG_0009);
				}

				if (getGuiaElement().getCdUnimedOrigem().equals(getGuiaElement().getCdUnimedExecutora())) { 
					//MULTI-IDIOMA: MSG_0013 - Não é possível realizar o cancelamento para Unimed Origem igual a Unimed Executora.
					String msg = ResourceManager.getString("guia.msg0013");
					getTask().getMv2000().msgAlert(msg, "W", NBool.True);
				}

				if (getFormModel().getCgCtrl().getDspDsObservacaoCancelamento().isNull() && getFormModel().getCgCtrl().getSnCancelaAutorizacao().equals("N")) {
					//MULTI-IDIOMA: MSG_0010 - Informe a Observação do Cancelamento.
					String msg = ResourceManager.getString("guia.msg0010");
					throw new Exception(msg);
				}

				if (getGuiaElement().getCdUnimedOrigem().isNull()) {
					//MULTI-IDIOMA: MSG_0012 - Informe a Unimed Origem.
					String msg = ResourceManager.getString("guia.msg0012");
					throw new Exception(msg);
				}
		
				if(!getGuiaElement().getCdPtuMensagemOrigem().isNull()){

					NString resposta = WebService.executaCancelamento(
							getGuiaElement().getCdUnimedExecutora(), 
							getFormModel().getCgCtrl().getCdMotCancelamento(), 
							getFormModel().getCgCtrl().getDspDsObservacaoCancelamento(), 
							getGuiaElement().getCdPtuMensagemOrigem(), 
							getGuiaElement().getCdPtuMensagemDestino(),
							getGuiaElement().getNrGuia());

					getTask().getMv2000().msgAlert(resposta.toString(), "I", NBool.False);

					ViewServices.hideView("CANVAS_PROCESSO");
					ItemServices.goItem("GUIA.NR_TRANSACAO");
					
					this.getTask().getServices().recarregarTela(getGuiaElement().getNrGuia());
					
					return;
				}
				
			}catch(Exception ex){
				getTask().getMv2000().msgAlert(	ex.getMessage(), "E", NBool.True );
			}
			
		}
		
		if (tpChamadaAutorizacao.equals("PTU-AI")) {
			NString resposta = NString.getNull();
			
			if (getFormModel().getCgCtrl().getTpPtuEvento().equals("I")) {
				getFormModel().getCgCtrl().setCdPtuMotivoEncerramento(NNumber.getNull());
			}else if (getFormModel().getCgCtrl().getTpPtuEvento().equals("A")) {
				if (getFormModel().getCgCtrl().getCdPtuMotivoEncerramento().isNull()) {
					getTask().getMv2000().msgAlert("O motivo de encerramento é obrigatório.", "W", NBool.True);
				}	
			}
			
			if (getFormModel().getCgCtrl().getDtPtuEvento().clearTime().greaterOrEquals(NDate.getNow())) {
				
			}
			
			String error = null;
			try {
				resposta = WebService.executaComunicacaoInternacaoAltaBeneficiario(getGuiaElement().getNrGuia(), getFormModel().getCgCtrl().getDtPtuEvento(), getFormModel().getCgCtrl().getTpPtuEvento(),getFormModel().getCgCtrl().getCdPtuMotivoEncerramento());
			} catch (Exception e) {
				e.printStackTrace();
				error = e.getMessage().toString();
			}

			ViewServices.hideView("CANVAS_PROCESSO");
			ItemServices.goItem("GUIA.NR_TRANSACAO");

			if (error != null) {
				getTask().getMv2000().msgAlert(error, "E", NBool.True);		
			}
			getTask().getMv2000().msgAlert(resposta.toString(), "I", NBool.False);		

		}
		
		if(tpChamadaAutorizacao.equals("PTU-I")){ // PTU - Insistência
			
			if (getFormModel().getCgCtrl().getDspDsMensagemLivre().isNull()) {
				ItemServices.goItem("CG$CTRL.DSP_DS_MENSAGEM_LIVRE");
				
				//MULTI-IDIOMA: MSG_0014 - Informe a mensagem para o Pedido de Insistência.
				String msg = ResourceManager.getString("guia.msg0014");
				getTask().getMv2000().msgAlert(msg, "W", NBool.True);
				
			}
			
			NString resposta = NString.getNull();
			String error = null;
			try {
				resposta = WebService.executaPedidoDeInsistencia(getGuiaElement().getCdPtuMensagemOrigem(), 
						getGuiaElement().getCdPtuMensagemDestino(), 
						getFormModel().getCgCtrl().getDspDsMensagemLivre(), 
						getGuiaElement().getNrGuia());
			} catch (Exception e) {
				e.printStackTrace();
				error = e.getMessage().toString();
			}
			
			ViewServices.hideView("CANVAS_PROCESSO");
			ItemServices.goItem("GUIA.NR_TRANSACAO");
			
			if (error != null) {
				getTask().getMv2000().msgAlert(error, "E", NBool.True);		
			}
			getTask().getMv2000().msgAlert(resposta.toString(), "I", NBool.False);		
			
		}else{

			String sql = "SELECT CD_MENS_CONTRATO FROM DBAPS.GUIA WHERE NR_GUIA = :P_NR_GUIA "; // AND CD_MENS_CONTRATO IS NULL
			DataCursor citguiaerros = new DataCursor(sql);
			int rowCount = 0;
			String sqlcnivelautoriza = "SELECT MAX(PRC.NR_NIVEL_AUTORIZACAO) " + 
					" FROM DBAPS.ITGUIA IG, DBAPS.PROCEDIMENTO PRC " + 
					" WHERE IG.NR_GUIA = :GUIA_NR_GUIA " + 
					" AND DBAPS.FNC_PROCEDIMENTO_ANALISE(IG.CD_PROCEDIMENTO, :GUIA_CD_PRESTADOR_EXECUTOR ) = PRC.CD_PROCEDIMENTO " + 
					" AND NVL(IG.SQ_GUIA_PRORROGACAO, - 1) = NVL(:P_PSQ_GUIA_PRORROGACAO, - 1) ";
			
			DataCursor cnivelautoriza = new DataCursor(sqlcnivelautoriza);

			try {
				if (Lib.in(tpChamadaAutorizacao, "C", "R").getValue()) {
					if (getFormModel().getCgCtrl().getCdMotCancelamento().isNull() && isNull(getFormModel().getCgCtrl().getSnCancelaAutorizacao(), "N").equals("N")) {
						goItem(toStr("CG$CTRL.CD_MOT_CANCELAMENTO"));
						
						//MULTI-IDIOMA: MSG_0015 - Motivo de cancelamento não informado.
						String msg = ResourceManager.getString("guia.msg0015");
						getTask().getMv2000().msgAlert(msg, toStr("E"), toBool(NBool.True));
					}
				}

				getTask().getMPkgMvsAutorizador().getMPkgMvsAutorizador().pRetornaDados(getFormModel().getCgCtrl().getCdAutorizadorOpe(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), cdUsuario, toBool(NBool.True), toBool(NBool.True), vlstParamret);
				getFormModel().getCgCtrl().setDsSenhaAutorizadorOpe(vlstParamret.val.getStr("DS_SENHA", NBool.True));
				wNrNivel = vlstParamret.val.getNumber("NR_NIVEL", NBool.False);
				wSnExcluiGuia = vlstParamret.val.getStr("SN_EXCLUI_GUIA", NBool.False);
				wSnAutorizaGuia = vlstParamret.val.getStr("SN_AUTORIZA_GUIA", NBool.False);
				wSnAutorizaLimite = vlstParamret.val.getStr("SN_AUTORIZA_LIMITE", NBool.False);
				wSnAutorizaProrrogacao = vlstParamret.val.getStr("SN_AUTORIZA_PRORROGACAO", NBool.False);

				if (getFormModel().getCgCtrl().getCdAutorizadorOpe().isNull()) {
					
					goItem(toStr("Cg$Ctrl.CD_AUTORIZADOR_OPE"));
					getTask().getMv2000().msgAlert(MSG_0007, toStr("E"), toBool(NBool.True));
					
				}

				if (getFormModel().getCgCtrl().getDsSenhaAutorizacaoSemBase().isNull() || !getFormModel().getCgCtrl().getDsSenhaAutorizacaoSemBase().equals(getFormModel().getCgCtrl().getDsSenhaAutorizadorOpe())) {
					goItem(toStr("Cg$Ctrl.DS_SENHA_AUTORIZACAO_SEM_BASE"));
					getTask().getMv2000().msgAlert(MSG_1004, toStr("E"), toBool(NBool.True));
				}

				getGuiaElement().setCdMotivoAutorizacao(getFormModel().getCgCtrl().getCdMotivoAutorizacao());

				if (!getGuiaElement().getCdMotivoAutorizacao().isNull()) {
					((GuiaController)this.getTask().getFormController().getBlockController("GUIA")).cd_motivo_autorizacao_validation();
				}
				citguiaerros.addParameter("P_NR_GUIA", getGuiaElement().getNrGuia());
				citguiaerros.open();
				ResultSet citguiaerrosResults = citguiaerros.fetchInto();
				Boolean cancelar = false;
				Boolean deletarMensContrato = false;
				int rowCountMensContrato = 0;

				/**
				 * No caso de "alteração de prestador" da guia não serão realizadas as checagens abaixo
				 * Regra indicada por Paulo Gustavo dia 21/08/2012 
				 */
				if (citguiaerrosResults != null && !citguiaerrosResults.getNumber(0).isNull() && !tpChamadaAutorizacao.equals("A")) {

					String sqlMens = "SELECT TP_QUITACAO, CD_MENS_CONTRATO, TP_RECEITA FROM DBAPS.MENS_CONTRATO WHERE CD_MENS_CONTRATO = :P_CD_MENS_CONTRATO ";

					DataCursor cMens = new DataCursor(sqlMens);
					cMens.addParameter("P_CD_MENS_CONTRATO", citguiaerrosResults.getNumber(0));
					cMens.open();
					ResultSet cMensResults = cMens.fetchInto();

					if (cMensResults != null && !cMensResults.getStr(0).isNull()) {

						if (!cMensResults.getStr(0).equals("A")) {
							//MULTI-IDIOMA: MSG_0017 - Essa guia não pode ser cancelada uma vez que, a mensalidade associada esta quitada ou parcialmente quitada.
							String msg = ResourceManager.getString("guia.msg0017");
							getTask().getMv2000().msgAlert(msg, "E", NBool.True);
						}

					} else {
						cancelar = true;
					}
					
					if (cMens != null && cMens.isOpen()) {
						cMens.close();
					}

					if (cMensResults != null && (!cMensResults.getStr(0).equals("A") || (cMensResults.getStr(0).equals("A") && !cMensResults.getStr(2).equals("O")))) {

						cancelar = false;

						//MULTI-IDIOMA: MSG_0018 - Guia associada a mensalidade %s. Para realizar o cancelamento é necessário cancelar a mensalisade na tela de \"Composição da Mensalidade.\" 
						String msg = ResourceManager.getString("guia.msg0018", cMensResults.getStr(1));
						getTask().getMv2000().msgAlert(msg, "W", NBool.True);

					} else {
						cancelar = true;
						deletarMensContrato = true;
					}

				} else {
					cancelar = true;
				}
				
				if (cancelar) {
					if ((tpChamadaAutorizacao.equals("A")) || (tpChamadaAutorizacao.equals("C")) || (tpChamadaAutorizacao.equals("R")) || (tpChamadaAutorizacao.equals("S"))) {
						if (!getGuiaElement().getNrGuia().isNull()) {
							getTask().getMPkgMvsContasMedicas().getMPkgMvsContasMedicas().pRetornaDadosGuia(toNumber(getGuiaElement().getNrGuia()), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), cdUsuario, toBool(NBool.False), toBool(NBool.False), vlstParamret1);
							wDtBaixado = vlstParamret1.val.getDate("DT_BAIXADO", NBool.False);
						}
						if (wDtBaixado.isNull() || tpChamadaAutorizacao.equals("R")) {
							if (wSnExcluiGuia.equals("N")) {
								goItem(toStr("Cg$Ctrl.CD_AUTORIZADOR_OPE"));
								//MULTI-IDIOMA: MSG_0019 - Autorizador não tem Permissão para alterações na Guia.
								String msg = ResourceManager.getString("guia.msg0019");
								getTask().getMv2000().msgAlert(msg, "W", NBool.True);
							}

							if (tpChamadaAutorizacao.equals("S")) {

								nstatusant = getGuiaElement().getTpStatus();
								cstatusant  = NString.toStr(getDescricaoStatus(nstatusant));
								nstatusdep = getFormModel().getCgCtrl().getTpStatus();
								NString snAplicaEmTodos = Lib.isNull(getFormModel().getCgCtrl().getDspSnAplicarTodos(), "N");

								if (nstatusdep.isNull()) {
									//MULTI-IDIOMA: MSG_0031 - Não foi selecionado nenhum status.
									String msg = ResourceManager.getString("guia.msg0031");
									getTask().getMv2000().msgAlert(msg, "W", NBool.True);
								}

								cstatusdep  = NString.toStr(getDescricaoStatus(nstatusdep));
								
								if (snAplicaEmTodos.equals("S")) {
									
									//MULTI-IDIOMA: MSG_0079 - ALTERAÇÃO DO STATUS DOS PROCEDIMENTOS PARA: %s
									String MSG_0079 = ResourceManager.getString("guia.msg0079",cstatusdep);
									cmsg = NString.toStr(MSG_0079);
									String sqlCommand = "UPDATE DBAPS.ITGUIA SET TP_STATUS = :P_TP_STATUS , QT_SOLICITADO = DECODE(QT_SOLICITADO,0,1,QT_SOLICITADO) WHERE NR_GUIA = :P_NR_GUIA ";
									if (nstatusdep.equals(3) || nstatusdep.equals(5)) {
										sqlCommand = "UPDATE DBAPS.ITGUIA SET TP_STATUS = :P_TP_STATUS, QT_SOLICITADO = 0 WHERE NR_GUIA = :P_NR_GUIA ";
									}
									DataCommand command = new DataCommand(sqlCommand);
									command.addParameter("P_TP_STATUS", getFormModel().getCgCtrl().getTpStatus());
									command.addParameter("P_NR_GUIA", getGuiaElement().getNrGuia());
									command.execute();
									
								}else{
									//MULTI-IDIOMA: MSG_0032 - ALTERAÇÃO DO STATUS DO PROCEDIMENTO %s DE %s PARA %s
									String MSG_32 = ResourceManager.getString("guia.msg0032",getItguiaElement().getCdProcedimento(),cstatusant,cstatusdep);
									cmsg = NString.toStr(MSG_32);									
									setBlockUpdateAllowed("ITGUIA", true);
									getItguiaElement().setTpStatus(toStr(getFormModel().getCgCtrl().getTpStatus()));
									getItguiaElement().setDspTpStatus(cstatusdep);
									if (nstatusdep.equals(3) || nstatusdep.equals(5)) {
										getItguiaElement().setQtSolicitado(NNumber.toNumber(0));
									}else{
										if(getItguiaElement().getQtSolicitado().equals(0)){
											getItguiaElement().setQtSolicitado(NNumber.toNumber(1));
										}
									}
								}

							} else if (getFormModel().getCgCtrl().getSnCancelaAutorizacao().equals("S")) {
								if (tpChamadaAutorizacao.equals("R")) {
									//MULTI-IDIOMA: MSG_0033 - CANCELAMENTO DA AUTORIZAÇÃO DA PRORROGAÇÃO %s - %s
									String MSG_33 = ResourceManager.getString("guia.msg0033", getGuiaProrrogacaoElement().getNrGuia(),getGuiaProrrogacaoElement().getSqGuiaProrrogacao());
									cmsg = NString.toStr(MSG_33);
								} else {
									//MULTI-IDIOMA: MSG_0034 - CANCELAMENTO DA AUTORIZAÇÃO.
									String MSG_34 = ResourceManager.getString("guia.msg0034");
									cmsg = NString.toStr(MSG_34);								
								}
							} else {
								if (tpChamadaAutorizacao.equals("A")) {
									//MULTI-IDIOMA: MSG_0078 - NENHUM(A)
									String MSG_0078 = ResourceManager.getString("guia.msg0078");
									//MULTI-IDIOMA: MSG_0035 - ALTERACAO DO PRESTADOR EXECUTOR: DE %s POR %s.
									String MSG_35 = ResourceManager.getString("guia.msg0035",Lib.isNull(NString.toStr(getGuiaElement().getCdPrestadorExecutor()), MSG_0078) ,getFormModel().getAlteracaoGuia().getCdPrestadorExecutorNovo());
									cmsg = NString.toStr(MSG_35);
								} else {									
									if (tpChamadaAutorizacao.equals("R")) {
										//MULTI-IDIOMA: MSG_0036 - CANCELAMENTO DA GUIA DE PRORROGAÇÃO %s - %s.
										String MSG_36 = ResourceManager.getString("guia.msg0036",getGuiaProrrogacaoElement().getNrGuia(),getGuiaProrrogacaoElement().getSqGuiaProrrogacao());
										cmsg = NString.toStr(MSG_36);
									} else {
										//MULTI-IDIOMA: MSG_0037 - CANCELAMENTO DA GUIA.
										String MSG_37 = ResourceManager.getString("guia.msg0037");
										cmsg = NString.toStr(MSG_37);
									}
								}
							}

							/*Na DBAPS.TRG_GUIA é realizada a modificação dos itens da guia para negar ou cancelar.*/
							this.getTask().getServices().insertLog(getGuiaElement().getNrGuia(), cmsg, getFormModel().getCgCtrl().getCdAutorizadorOpe(), null, null, null);

							if (tpChamadaAutorizacao.equals("C")) {
								setBlockUpdateAllowed("GUIA", true);
								/**
								 * Só fazer essa lógica quando for para remover a autorização
								 */
								if (getFormModel().getCgCtrl().getSnCancelaAutorizacao().equals("S")) {
									getGuiaElement().setSnValidaRestCarencia(NString.toStr("N"));
									getGuiaElement().setDtImpressaoGuia(NDate.getNull());
									getGuiaElement().setCdMotCancelamentoGuia(getFormModel().getCgCtrl().getCdMotCancelamento());
									getGuiaElement().setDspDsMotCancelamentoGuia(getFormModel().getCgCtrl().getDspDsMotCancelamento());
									getGuiaElement().setDtAutorizacao(NDate.getNull());									
								}

								if (getFormModel().getCgCtrl().getSnCancelaAutorizacao().equals("N")) {

									//PLANO-7529
									NString strExisteGuiasFilhasEmAnalise = this.getTask().getServices().existeGuiasFilhasEmAnalise(getGuiaElement().getNrGuia(),NString.toStr("S"));

									if(!strExisteGuiasFilhasEmAnalise.isEmpty() && strExisteGuiasFilhasEmAnalise.getValue().length() > 0){
										getTask().getMv2000().msgAlert(strExisteGuiasFilhasEmAnalise.toString(), "W", NBool.False);
									}

									this.getTask().getServices().negarOuCancelaGuiasFilhas(getGuiaElement().getNrGuia());
									//#PLANO-7529

								}								
								setBlockUpdateAllowed("GUIA", false);
							} else if (tpChamadaAutorizacao.equals("R")) {
								setBlockUpdateAllowed("GUIA_PRORROGACAO", true);
								if (isNull(getFormModel().getCgCtrl().getSnCancelaAutorizacao(), "N").equals("N")) {
									getGuiaProrrogacaoElement().setCdMotCancelamentoGuia(getFormModel().getCgCtrl().getCdMotCancelamento());
									getGuiaProrrogacaoElement().setDspDsMotCancelamentoGuia(getFormModel().getCgCtrl().getDspDsMotCancelamento());
								}
								getGuiaProrrogacaoElement().setSnAutorizado(toStr("N"));
							} else if (tpChamadaAutorizacao.equals("A")) {
									setBlockUpdateAllowed("GUIA", true);
									getGuiaElement().setCdPrestadorExecutor(getFormModel().getAlteracaoGuia().getCdPrestadorExecutorNovo());
									getGuiaElement().setDspNmExecutor(getFormModel().getAlteracaoGuia().getDspNmPrestadorExecutorNovo());
									getGuiaElement().setCdPrestadorEndereco(getFormModel().getAlteracaoGuia().getCdPrestadorEnderecoNovo());
									getGuiaElement().setDsEndereco(getFormModel().getAlteracaoGuia().getDspPrestadorEnderecoNovo());
									setBlockUpdateAllowed("GUIA", false);
							}
							commitTask(true);
							BlockServices.getBlockController("LOG_AUTORIZA").getInteractionRulesStrategy().executeQuery();
						} else {
							//MULTI-IDIOMA: MSG_0038 - Guia baixada não pode ser modificada!
							String MSG_38 = ResourceManager.getString("guia.msg0038");
							getTask().getMv2000().msgAlert(MSG_38, NString.toStr("E"), NBool.toBool(NBool.True));
						}
						hideView("CANVAS_PROCESSO");
						if (tpChamadaAutorizacao.equals("R")) {
							goItem(toStr("GUIA_PRORROGACAO.CD_TIP_ACOMODACAO"));
						} else {
							if (isNull(snCortesia, "N").equals("S")) {
								goItem(toStr("GUIA.DS_DESTINO_CORTESIA"));
							} else {
								goItem(toStr("GUIA.CD_MATRICULA"));
							}
						}
					} else if ((tpChamadaAutorizacao.equals("V"))) {
						this.getTask().getServices().insertLog( getGuiaElement().getNrGuia()
								, NString.toStr("ALTERACAO DO VALOR DA GUIA")
								, getFormModel().getCgCtrl().getCdAutorizadorOpe()
								, getItguiaElement().getCdProcedimento()
								, NString.toStr(getItguiaElement().getValorOriginalProcedimento())
								, NString.toStr(getItguiaElement().getVlProcedimento()));

						ItemServices.setItemIsValid("ITGUIA.VL_PROCEDIMENTO", true);
						getItguiaElement().setValorOriginalProcedimento(getItguiaElement().getVlProcedimento());

						hideView("CANVAS_PROCESSO");
						showView("CNV_TAB_GUIA");
						goItem(toStr("ITGUIA.CD_PROCEDIMENTO"));
						goBlock(toStr("LOG_AUTORIZA"));
						commitTask(true);
						executeQuery();
						goBlock(toStr("ITGUIA"));

					} else {
						if (this.getFormModel().getParam("PRORROGACAO", NString.class).equals("V")) {
							if (getFormModel().getCgCtrl().getDsSenhaAutorizacaoSemBase().equals(getFormModel().getCgCtrl().getDsSenhaAutorizadorOpe())) {
								nrGuiaProrrogacao = NNumber.toNumber(Services.getDescricao(" NVL(MAX(SQ_GUIA_PRORROGACAO), 0) + 1 ", "GUIA_PRORROGACAO", "NR_GUIA = " + getGuiaElement().getNrGuia(), false));
								goBlock(toStr("GUIA_PRORROGACAO"));
								firstRecord();
								while (true) {
									if (getGuiaProrrogacaoElement().getSqGuiaProrrogacao().isNull()) {
										if (isNull(getGuiaProrrogacaoElement().getNrDiasProrrogados(), 0).notEquals(0)) {
											this.getFormModel().setParam("PRORROGACAO", toStr("S"));
											getGuiaProrrogacaoElement().setCdAutorizador(getFormModel().getCgCtrl().getCdAutorizadorOpe());
											getGuiaProrrogacaoElement().setDspNmAutorizador(getFormModel().getCgCtrl().getDspNmAutorizadorOpe());
											getGuiaProrrogacaoElement().setSqGuiaProrrogacao(nrGuiaProrrogacao);
											nrGuiaProrrogacao = nrGuiaProrrogacao.add(1);
										} else {
											//MULTI-IDIOMA: MSG_0058 - Número de dias prorrogados não informado. 
											getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0058"), "E", NBool.True);
										}
									}
									if (isInLastRecord()) {
										break;
									}
									nextRecord();
								}
								commitTask();

								firstRecord();
								goItem(toStr("GUIA_PRORROGACAO.NR_DIAS_PRORROGADOS"));
								hideView("CANVAS_PRORROGACAO");
								goBlock(toStr("ITGUIA"));
								goBlock(toStr("GUIA"));
								showView("CNV_TAB_GUIA");
								goItem(toStr("ITGUIA.CD_PROCEDIMENTO"));
							}
						} else {
							nnrnivelprocedimento = toNumber(0);
							if (tpChamadaAutorizacao.equals("P")) {
								if (wSnAutorizaProrrogacao.notEquals("S")) {
									goItem(toStr("Cg$Ctrl.CD_AUTORIZADOR_OPE"));
									getTask().getMv2000().msgAlert(toStr("Autorizador Não tem Permissão para Prorrogar Internação"), toStr("E"), toBool(NBool.True));
								}
								psqGuiaProrrogacao = toStr(getGuiaProrrogacaoElement().getSqGuiaProrrogacao());
								cnivelautoriza.addParameter("GUIA_NR_GUIA", getGuiaElement().getNrGuia());
								cnivelautoriza.addParameter("P_PSQ_GUIA_PRORROGACAO", psqGuiaProrrogacao);
								cnivelautoriza.addParameter("GUIA_CD_PRESTADOR_EXECUTOR", getGuiaElement().getCdPrestadorExecutor());
								cnivelautoriza.open();
								ResultSet cnivelautorizaResults = cnivelautoriza.fetchInto();
								if (cnivelautorizaResults != null) {
									nnrnivelprocedimento = cnivelautorizaResults.getNumber(0);
								}
								cnivelautoriza.close();
							} else {
								if (wSnAutorizaGuia.notEquals("S")) {
									goItem(toStr("CG$CTRL.CD_AUTORIZADOR_OPE"));
									getTask().getMv2000().msgAlert(toStr("Erro: Autorizador não tem Permissão para Liberação da Guia"), toStr("E"), toBool(NBool.True));
								}
								psqGuiaProrrogacao = null;
								cnivelautoriza.addParameter("GUIA_NR_GUIA", getGuiaElement().getNrGuia());
								cnivelautoriza.addParameter("P_PSQ_GUIA_PRORROGACAO", psqGuiaProrrogacao);
								cnivelautoriza.addParameter("GUIA_CD_PRESTADOR_EXECUTOR", getGuiaElement().getCdPrestadorExecutor());
								cnivelautoriza.open();
								ResultSet cnivelautorizaResults = cnivelautoriza.fetchInto();
								if (cnivelautorizaResults != null) {
									nnrnivelprocedimento = cnivelautorizaResults.getNumber(0);
								}
								cnivelautoriza.close();
							}
							
							NNumber nrNivelGlosa = Lib.isNull(NNumber.toNumber(Services.getDescricao("MAX(MG.NR_NIVEL_LIBERACAO) NR_NIVEL_LIBERACAO", "ITGUIA_ERROS IE , DBAPS.MOTIVO_GLOSA MG", "IE.CD_MOTIVO = MG.CD_MOTIVO AND IE.NR_GUIA = ".concat(getGuiaElement().getNrGuia().toString()), false)),0);
							
							if (isNull(nnrnivelprocedimento, 0).greater(isNull(wNrNivel, 0))) {								
								//MULTI-IDIOMA: MSG_0046 - Este Procedimento necessita de um autorizador com nível acima do já Indicado.
								getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0046_1"), "W", NBool.True);
							}else if(isNull(nrNivelGlosa, 0).greater(isNull(wNrNivel, 0))){
								//MULTI-IDIOMA: MSG_0046 - Está Glosa necessita de um autorizador com nível acima do já Indicado.
								getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0046_2"), "W", NBool.True);
							}
							
							if (tpChamadaAutorizacao.equals("P")) {
								cdsfuncionalidade = toStr("LIBERACAO DE GUIA DE PRORROGAÇÃO ").append(toChar(getGuiaProrrogacaoElement().getNrGuia())).append("-").append(toChar(getGuiaProrrogacaoElement().getSqGuiaProrrogacao()));
								getGuiaProrrogacaoElement().setSnAutorizado(toStr("S"));
								getGuiaProrrogacaoElement().setCdAutorizador(getFormModel().getCgCtrl().getCdAutorizadorOpe());
								getGuiaProrrogacaoElement().setDspNmAutorizador(getFormModel().getCgCtrl().getDspNmAutorizadorOpe());
							} else {
								if (getGuiaElement().getDtPrevExecucao().isNull()) {
									getGuiaElement().setDtPrevExecucao(DbManager.getDBDateTime());
								}
								getGuiaElement().setDsSenhaAutorizacao(getFormModel().getCgCtrl().getDsSenhaAutorizacaoSemBase());
								
								if (getGuiaElement().getSnAvista().equals("N")) {
									
									setBlockUpdateAllowed("GUIA", true);
									setBlockInsertAllowed("GUIA", true);
									getGuiaElement().setDtAutorizacao(DbManager.getDBDateTime());
									
									if (this.getTask().getServices().mapaMultiEmpresaMvSaude.get("TP_DATA_VENCIMENTO_GUIA").equals("DA")) {//Data de Autorização
										NDate dtVencimentoDaGuia = DbManager.getDBDateTime().add(NNumber.toNumber(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("NR_DIAS_VENCIMENTO_DA_GUIA")));
										getGuiaElement().setDtVencimento(dtVencimentoDaGuia);
									}else if(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("TP_DATA_VENCIMENTO_GUIA").equals("DE")) {//Data de Emissão
										getGuiaElement().setDtVencimento(getGuiaElement().getDtEmissao().add(NNumber.toNumber(this.getTask().getServices().mapaMultiEmpresaMvSaude.get("NR_DIAS_VENCIMENTO_DA_GUIA"))));
									}

									//PLANO-4298
									if (!getGuiaElement().getCdMatricula().isNull()) {
										if (!getGuiaElement().getDspDtDesligamentoProgramada().clearTime().lesser(getGuiaElement().getDtEmissao().clearTime()) 
												&& getGuiaElement().getDtVencimento().clearTime().greater(getGuiaElement().getDspDtDesligamentoProgramada().clearTime()) 
													&& !getGuiaElement().getDspDtDesligamentoProgramada().isNull() ) {
											
											getGuiaElement().setDtVencimento(getGuiaElement().getDspDtDesligamentoProgramada());
											
										}
									}
									//#PLANO-4298
									
									//PLANO-7529
									NString strExisteGuiasFilhasEmAnalise = this.getTask().getServices().existeGuiasFilhasEmAnalise(getGuiaElement().getNrGuia(),NString.toStr("S"));
									if(!strExisteGuiasFilhasEmAnalise.isEmpty() && strExisteGuiasFilhasEmAnalise.getValue().length() > 0){
										getTask().getMv2000().msgAlert(strExisteGuiasFilhasEmAnalise.toString(), "W", NBool.True);
									}

									NString strExisteGuiasPaisEmAnalise = this.getTask().getServices().existeGuiasPaisNegadas(getGuiaElement().getNrGuiaTem(),NString.toStr("S"));
									if(!strExisteGuiasPaisEmAnalise.isEmpty() && strExisteGuiasPaisEmAnalise.getValue().length() > 0){
										getTask().getMv2000().msgAlert(strExisteGuiasPaisEmAnalise.toString(), "W", NBool.True);
									}
									//#PLANO-7529
									
									getGuiaElement().setDtUltimaAutorizacao(DbManager.getDBDateTime());								
									getGuiaElement().setSnValidaRestCarencia(toStr("S"));
									if (getGuiaElement().getDspTpGuia().equals("D")) {
										if (getGuiaElement().getDtLiberacaoGto().isNull() && getGuiaElement().getCdOcorrenciaPericiaInicial().isNull() && getGuiaElement().getCdOcorrenciaPericiaInicial().isNull()) {
											getGuiaElement().setDtLiberacaoGto(DbManager.getDBDateTime());
										}
									}
									setItemEnabled("GUIA.BTN_EMISSAO_DA_GUIA", true);
									setItemEnabled("GUIA.BTN_TP_STATUS", false);
								
								}
								
								setItemEnabled("GUIA.BTN_SENHA", false);
								setGlobal("BTN_SENHA", toStr("S"));
								cdsfuncionalidade = toStr("LIBERACAO DE GUIA");
								StoredProcedures.fncRetornaGrupoFranquia(getGuiaElement().getCdMatricula(), ptp_grupo_franquia_ref);
								// Criar CD_CON_REC caso não tenha
								// e se a guia for do tipo custo operacional, (ou seja, o campo "a vista" = "sim")
								if (getGuiaElement().getSnAvista().equals("S") || 
										(isNull(snCortesia, "N").equals("S") && ptp_grupo_franquia_ref.val.equals("2"))) {
									if(snLiberaGuiaSemPagamento.equals("S")) {
										getGuiaElement().setSnValidaRestCarencia(toStr("S"));
										if (getGuiaElement().getDspTpGuia().equals("D")) {
											if (getGuiaElement().getDtLiberacaoGto().isNull() && getGuiaElement().getCdOcorrenciaPericiaInicial().isNull() && getGuiaElement().getCdOcorrenciaPericiaInicial().isNull()) {
												getGuiaElement().setDtLiberacaoGto(DbManager.getDBDateTime());
											}
										}
									} else {
										getGuiaElement().setSnValidaRestCarencia(toStr("N"));
									}
									gerarRecebimento = NBool.True;

								}
								// aqui vamos alterar o status do procedimento
								// e colocar a senha como sendo o código da guia
								this.getTask().getServices().prcAutorizaItens(getGuiaElement(),snOperadoraUnimed);
							}

							this.getTask().getServices().insertLog(getGuiaElement().getNrGuia(), cdsfuncionalidade, getFormModel().getCgCtrl().getCdAutorizadorOpe(), null, null, null);

							commitTask(true);
							if (Services.exist("ITGUIA", "NR_GUIA = ".concat(getGuiaElement().getNrGuia().toString()), false)) {
								BlockServices.getBlockController("ITGUIA").getInteractionRulesStrategy().executeQuery();								
							}
							setBlockUpdateAllowed("GUIA", false);

							if (gerarRecebimento.getValue()) {
								if (StoredProcedures.fncMvsGeraRecebimento(getGuiaElement().getNrGuia(), getGuiaElement().getCdMatricula(), getGuiaElement().getCdMultiEmpresa()).equals(1)) {

									if(snLiberaGuiaSemPagamento.equals("S")) {
										//MULTI-IDIOMA: MSG_0047 - Guia liberada. Favor comparecer ao caixa para pagamento.
										getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0047"), "I", NBool.False);
									} else {
										//MULTI-IDIOMA: MSG_0048 - A guia foi liberada mas será autorizada automaticamente após o pagamento no caixa.
										getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0048"), "I", NBool.False);
									}
								} else {
									getGuiaElement().setSnValidaRestCarencia(toStr("S"));
									if (getGuiaElement().getDspTpGuia().equals("D")) {
										if (getGuiaElement().getDtLiberacaoGto().isNull() && getGuiaElement().getCdOcorrenciaPericiaInicial().isNull() && getGuiaElement().getCdOcorrenciaPericiaInicial().isNull()) {
											getGuiaElement().setDtLiberacaoGto(DbManager.getDBDateTime());
										}
									}
								}
							}

						}

						hideView("CANVAS_PROCESSO");

						if (tpChamadaAutorizacao.equals("L")) {

							if (gerarRecebimento.getValue()) {
								getFormModel().getGuia().setWhereClause("NR_GUIA = " + getGuiaElement().getNrGuia());
								commitTask(true);
								executeQuery("GUIA");
							}

							if (isNull(snCortesia, "N").equals("S")) {
								goItem(toStr("GUIA.DS_DESTINO_CORTESIA"));
							} else {
								goItem(toStr("GUIA.CD_MATRICULA"));
							}

						} else {
							goItem(toStr("GUIA_PRORROGACAO.CD_TIP_ACOMODACAO"));
							goBlock(toStr("GUIA_PRORROGACAO"));
							((GuiaProrrogacaoController) this.getTask().getBlockController("GUIA_PRORROGACAO")).guiaProrrogacao_AfterQuery(new RowAdapterEvent(getGuiaProrrogacaoElement()));
						}
					}

					//Se a mensalidade vinculada a guia for do tipo 'O' e esteja Aberta, deletar a mens_contrato e o lote
					if (deletarMensContrato) {
						NNumber cdProcessCb = NNumber.getNull();

						//Consultar o lote de cobrança da mensalidade
						String sqlcMens = "SELECT CD_PROCESS_CB FROM DBAPS.MENS_CONTRATO WHERE CD_MENS_CONTRATO = :P_CD_MENS_CONTRATO";
						DataCursor dcMens = new DataCursor(sqlcMens);
						dcMens.addParameter("P_CD_MENS_CONTRATO", citguiaerrosResults.getNumber(0));

						try {
							dcMens.open();
							ResultSet rsMens = dcMens.fetchInto();

							if (rsMens != null) {
								cdProcessCb = rsMens.getNumber(0);
							}
						} catch (Exception e) {
							//MULTI-IDIOMA: MSG_0052 - Não foi possível consultar a mensalidade, motivo : %s .
							getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0052", e.getMessage()), "E", NBool.True);
						} finally {
							dcMens.close();
						}

						if (!cdProcessCb.isNull()) {
							//Retirando o lote de cobrança da mensalidade
							String sqlUpdateMens = "UPDATE DBAPS.MENS_CONTRATO SET CD_PROCESS_CB = NULL WHERE CD_MENS_CONTRATO = :P_CD_MENS_CONTRATO";
							DataCommand dcUpdateMens = new DataCommand(sqlUpdateMens);
							dcUpdateMens.addParameter("P_CD_MENS_CONTRATO", citguiaerrosResults.getNumber(0));

							try {
								dcUpdateMens.execute();
							} catch (Exception e) {
								//MULTI-IDIOMA: MSG_0049 -  Erro ao retirar o lote de cobrança da mensalidade, motivo : %s. 
								getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0049", e.getMessage()), "E", NBool.True);
							}

							//Excluindo o lote de cobrança
							String sqlDeleteLote = "DELETE FROM DBAPS.PROCESS_CB WHERE CD_PROCESS_CB = :P_CD_PROCESS_CB";
							DataCommand dcDeleteLote = new DataCommand(sqlDeleteLote);
							dcDeleteLote.addParameter("P_CD_PROCESS_CB", cdProcessCb);

							try {
								dcDeleteLote.execute();
							} catch (Exception e) {
								//MULTI-IDIOMA: MSG_0050 - Erro ao remover lote de cobrança, motivo %s . 
								getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0050", e.getMessage()), "E", NBool.True);
							}
						}

						//Excluindo a mens_contrato
						String sqlDeletarMens = "DELETE FROM DBAPS.MENS_CONTRATO WHERE CD_MENS_CONTRATO = :P_CD_MENS_CONTRATO";
						DataCommand dcDeletarMens = new DataCommand(sqlDeletarMens);
						dcDeletarMens.addParameter("P_CD_MENS_CONTRATO", citguiaerrosResults.getNumber(0));

						try {
							dcDeletarMens.execute();
						} catch (Exception e) {
							//MULTI-IDIOMA: MSG_0051 - Erro ao remover mensalidade, motivo: %s .
							getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0051", e.getMessage()), "E", NBool.True);
						}
					}
				}
			} finally {
				cnivelautoriza.close();
				citguiaerros.close();
			}

			/**
			 * Habilita o botão de envio de e-mail apenas se a guia estiver autorizada
			 * @since 16/04/2013
			 */
			getTask().getServices().verificaBotaoEmailGuia();
			getTask().getServices().verificaBotaoSms();
			getTask().getServices().verificaDsCancelamentoGuia();
		}
		
		//PLANO-6774
		ViewServices.hideWindow("WIN_SENHA");
		ItemServices.goItem("GUIA.NR_GUIA");
		//PLANO-6774
		
		if (!tpChamadaAutorizacao.equals("P") && !tpChamadaAutorizacao.equals("R")) {
			TaskServices.commitTask(true);
			this.getTask().getServices().recarregarTela(getGuiaElement().getNrGuia());
		
		}
		
		//PLANO-6182
		if(tpChamadaAutorizacao.equals("L") && snEnvioAutoSmsLiberaGuia.equals("S") && getGuiaElement().getSnValidaRestCarencia().equals("S")) {
			try{
				((CgCtrlController)this.getTask().getFormController().getBlockController("CG$CTRL")).btn_envio_sms_click();
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		//#PLANO-6182
		this.getFormModel().setParam("CHAMA_AUTORIZ",NString.getNull());
		
		this.getTask().getServices().chkItGuiaTaxas(getGuiaElement());
	}

	@ActionTrigger(action = "btnCancelar_click", item = "BTN_CANCELAR")
	public void btnCancelar_click() {

		getFormModel().getCgCtrl().setDsSenhaAutorizacaoSemBase(toStr(null));

		this.getFormModel().setParam("PRORROGACAO", toStr("N"));
//CARE-VALIDATION: HideView without Go 
		hideView("CANVAS_PROCESSO");

		if (in(this.getFormModel().getParam("CHAMA_AUTORIZ", NString.class), "P", "R").getValue()) {

			goItem(toStr("ITGUIA_PRO.CD_PROCEDIMENTO"));

		} else if (this.getFormModel().getParam("CHAMA_AUTORIZ", NString.class).getValue().equals("V")) {

//CARE-VALIDATION: HideView without Go 
			hideView("CANVAS_PRORROGACAO");
			showView("CNV_TAB_GUIA");
			goItem(toStr("ITGUIA.VL_PROCEDIMENTO"));
			ItemServices.setItemIsValid("ITGUIA.VL_PROCEDIMENTO", false);

		} else {

			goItem(toStr("GUIA.CD_MATRICULA"));
			hideView("CANVAS_PRORROGACAO");
			showView("CNV_TAB_GUIA");
			goItem(toStr("ITGUIA.CD_PROCEDIMENTO"));

		}
	}

	@ActionTrigger(action = "btnEmiteGuia_click", item = "BTN_EMITE_GUIA")
	public void btnEmiteGuia_click() {

		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);

		this.getTask().getServices().prcEmiteGuia(guiaElement);
	}

	@ActionTrigger(action = "btnRetorna_click", item = "BTN_RETORNA")
	public void btnRetorna_click() {

		goItem(toStr("guia.cd_matricula"));
	}

	@ActionTrigger(item = "BTN_ALTERA_FRANQUIA", action = "btn_altera_franquia_click")
	public void btn_altera_franquia_click() {

		String msg = "";

		if(Lib.isNull(getItguiaElement().getVlProcedimento(), 0).equals(0)){
			msg = msg + "\n - O procedimento não tem valor.";
		}
		if(!getGuiaElement().getCdMensContrato().isNull()){
			msg = msg + "\n - A guia já foi faturada.";
		}
		if(!getGuiaElement().getDtBaixado().isNull()){
			msg = msg + "\n - A guia já foi lançada no contas médicas.";
		}
		if(!getGuiaElement().getCdMotCancelamentoGuia().isNull()){
			msg = msg + "\n - A guia está cancelada."; 
		}
		if(getGuiaElement().getSnValidaRestCarencia().equals("S")){
			msg = msg + "\n - A guia está autorizada.";
		}

		TaskServices.commitTask(true);

		if(msg != ""){
			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Atenção! Valor da franquia não pode ser alterado.")
					.append(Lib.chr(10))
					.append(Lib.chr(10))
					.append("Motivo(s):"+msg).toString(),
					"W", /*W = Aten??o, I = Informa??o, E = Erro */
					NBool.True /*bloquear/travar?*/);

		}

		try {

			NString tabela = NString.toStr("ITGUIA");
			NNumber nrGuia = getGuiaElement().getNrGuia();
			NString cdProcedimento = getItguiaElement().getCdProcedimento();
			NNumber cdAutorizador = getGuiaElement().getCdAutorizador();

			@SuppressWarnings("rawtypes")
			Hashtable plId = TaskServices.getParameterList("M_ALTERA_FRANQUIA_CTAMED");

			if (plId == null){
				plId = TaskServices.createParameterList("M_ALTERA_FRANQUIA_CTAMED");
			}else{
				TaskServices.deleteParameter("M_ALTERA_FRANQUIA_CTAMED", "P_SN_EDITAVEL");
				TaskServices.deleteParameter("M_ALTERA_FRANQUIA_CTAMED", "P_TABELA");
				TaskServices.deleteParameter("M_ALTERA_FRANQUIA_CTAMED", "P_NR_GUIA");
				TaskServices.deleteParameter("M_ALTERA_FRANQUIA_CTAMED", "P_CD_PROCEDIMENTO");
				TaskServices.deleteParameter("M_ALTERA_FRANQUIA_CTAMED", "P_CD_AUTORIZADOR");
			}

			TaskServices.addParameter(plId, "P_TABELA", tabela);
			TaskServices.addParameter(plId, "P_NR_GUIA", nrGuia);
			TaskServices.addParameter(plId, "P_CD_PROCEDIMENTO", cdProcedimento);
			TaskServices.addParameter(plId, "P_CD_AUTORIZADOR", cdAutorizador);

			TaskServices.callTask("M_ALTERA_FRANQUIA_CTAMED", TaskServices.HIDE, TaskServices.NO_REPLACE, TaskServices.NO_QUERY_ONLY, plId);

			if(Globals.getGlobal("SN_FRANQUIA_ALTERADA").equals("S")){

				getItguiaElement().setVlFranquia(NNumber.toNumber(Globals.getGlobal("VL_FRANQUIA")));
				getItguiaElement().setDspVlTotalFranquia(getItguiaElement().getQtSolicitado().multiply(getItguiaElement().getVlFranquia()));
				getItguiaElement().setDsJustificativaAltFranq(Globals.getGlobal("DS_JUSTIFICATIVA_ALT_FRANQ"));
				getItguiaElement().setDtAlteracaoFranquia(NDate.toDate(Globals.getGlobal("DT_ALTERACAO_FRANQUIA")));
				getItguiaElement().setCdUsuarioAlteracaoFranquia(Globals.getGlobal("CD_USUARIO_ALTERACAO_FRANQUIA"));

				TaskServices.commitTask(true);

				String sql = "INSERT INTO DBAPS.LOG_AUTORIZA          " +
						"              (NR_GUIA,                      " +
						"               DS_FUNCIONALIDADE,            " +
						"               NM_USUARIO_ORACLE,            " +
						"               DT_ACAO,                      " +
						"               CD_AUTORIZADOR,               " +
						"               CD_LOG_AUTORIZA,              " +
						"               CD_PROCEDIMENTO,              " +
						"               DS_VALOR_ANTIGO,              " +
						"               DS_VALOR_NOVO)                " +
						"            VALUES                           " +
						"              (:P_NR_GUIA,                   " +
						"               :P_MSG,                       " +
						"               USER,                         " +
						"               SYSDATE,                      " +
						"               :P_CD_AUTORIZADOR,            " +
						"               SEQ_LOG_AUTORIZA.NEXTVAL,     " +
						"               :P_CD_PROCEDIMENTO,           " +
						"               :P_VALOR_ANTERIOR,            " +
						"               :P_VALOR_NOVO)                ";
				DataCommand command = new DataCommand(sql);

				command.addParameter("P_NR_GUIA", getGuiaElement().getNrGuia());
				command.addParameter("P_MSG", "ALTERACAO DA FRANQUIA");
				command.addParameter("P_CD_AUTORIZADOR", Globals.getGlobal("CD_AUTORIZADOR"));
				command.addParameter("P_CD_PROCEDIMENTO", getItguiaElement().getCdProcedimento());

				StringBuilder sbOld = new StringBuilder();
				sbOld.append("Franquia: ").append(Globals.getGlobal("VL_FRANQUIA_OLD"));
				sbOld.append(Lib.chr(10));
				sbOld.append("Justificativa: ").append(Globals.getGlobal("DS_JUSTIFICATIVA_ALT_FRANQ_OLD"));
				command.addParameter("P_VALOR_ANTERIOR", sbOld);

				StringBuilder sbNew = new StringBuilder();
				sbNew.append("Franquia: ").append(Globals.getGlobal("VL_FRANQUIA"));
				sbNew.append(Lib.chr(10));
				sbNew.append("Justificativa: ").append(Globals.getGlobal("DS_JUSTIFICATIVA_ALT_FRANQ"));
				command.addParameter("P_VALOR_NOVO", sbNew);

				command.execute();

				TaskServices.executeQuery("LOG_AUTORIZA");
			}

		} catch (Exception e) {

			e.printStackTrace();

			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Erro.....: Erro durante o processo de alteração de franquia!")
					.append(Lib.chr(10))
					.append("Motivo..: "+e.getMessage())
					.append(Lib.chr(10))
					.append("Ação....: Contactar o setor de informática.").toString(),
					"W", /*W = Atenção, I = Informação, E = Erro */
					NBool.False/*bloquear/travar?*/);

		}

	}

	@ActionTrigger(item = "BTN_NEGAR_ITEM", action = "btn_negar_item_click")
	public void btn_negar_item_click() {

		ItemServices.goItem("ITGUIA.CD_PROCEDIMENTO");

		String msg = "";

		if(!getGuiaElement().getCdMensContrato().isNull()){
			msg = msg + "\n - A guia já foi faturada.";
		}
		if(!getGuiaElement().getDtBaixado().isNull()){
			msg = msg + "\n - A guia já foi lançada no contas médicas.";
		}
		if(!getGuiaElement().getCdMotCancelamentoGuia().isNull()){
			msg = msg + "\n - A guia está cancelada."; 
		}
		if(getGuiaElement().getSnValidaRestCarencia().equals("S")){
			msg = msg + "\n - A guia está autorizada.";
		}

		TaskServices.commitTask(true);

		if(msg != ""){
			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Atenção! Item não pode ser negado!")
					.append(Lib.chr(10))
					.append(Lib.chr(10))
					.append("Motivo(s):"+msg).toString(),
					"W", /*W = Aten??o, I = Informa??o, E = Erro */
					NBool.True /*bloquear/travar?*/);

		}

		ItemServices.setItemEnabled("NEGACAO_ITEM.DSP_DS_SENHA", true);

		this.getFormModel().getNegacaoItem().setDspDsSenha(NString.getNull());

		ItemServices.setItemEnabled("NEGACAO_ITEM.BTN_CONFIRMAR", false);
		ItemServices.setItemEnabled("NEGACAO_ITEM.BTN_CANCELAR_NEGACAO", false);

		ItemServices.setItemEnabled("ITGUIA.CD_MOTIVO", false);

		this.getFormModel().getNegacaoItem().setSnAplicarNegativaTodos(NString.toStr("N"));
		ResultSet rs = GuiaServices.getAutorizadorLogado();

		if(rs != null){

			this.getFormModel().getNegacaoItem().setDspCdAutorizador(rs.getNumber("CD_AUTORIZADOR"));

			this.getFormModel().getNegacaoItem().setDspNmAutorizador(this.getTask().getServices().getAutorizadorNegacao(rs.getNumber("CD_AUTORIZADOR"), false));

			ItemServices.goItem("NEGACAO_ITEM.DSP_DS_SENHA");

		}else{

			ItemServices.goItem("NEGACAO_ITEM.DSP_CD_AUTORIZADOR");

		}
	}

	@ActionTrigger(item = "BTN_EDITAR_ANEXO_TEXTO", action = "btn_editar_anexo_texto_click")
	public void btn_editar_anexo_texto_click() {
		
		boolean isUpdateAllowed = BlockServices.getBlockUpdateAllowed("GUIA").toBoolean();

		if(isUpdateAllowed){
			ItemServices.goItem("GUIA.DS_ANEXO_TEXTO");
		}else{
			ItemServices.setItemValue("ANEXO_TEXTO_GUIA.DSP_DS_ANEXO_TEXTO", getGuiaElement().getDsAnexoTexto());
			ItemServices.setItemValue("ANEXO_TEXTO_GUIA.DSP_DS_ANEXO_TEXTO_ANTIGO", getGuiaElement().getDsAnexoTexto());
			ItemServices.goItem("ANEXO_TEXTO_GUIA.DSP_DS_ANEXO_TEXTO");
		}
		
	}

	@ActionTrigger(item = "BTN_EXIBIR_GUIA_REFERENCIADA", action = "btn_exibir_guia_referenciada_click")
	public void btn_exibir_guia_referenciada_click() {
		if (getGuiaElement().getNrGuia().isNull()) {
			getTask().getMv2000().msgAlert("É preciso salvar a Guia, pois a mesma não foi salva.", "W", NBool.True);
		}
		if (Services.exist("GUIA", "NR_GUIA_TEM = " + getGuiaElement().getNrGuia(), false)) {			
			TaskServices.executeQuery("GUIAS_ASSOCIADAS");
			ItemServices.goItem("GUIAS_ASSOCIADAS.NR_GUIA");
		}else{
			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Operação inválida!")
					.append(Lib.chr(10))
					.append("Motivo..: Não foi possivel encontrar registros vinculados a guia principal.").toString(),
					"W", /*W = Atenção, I = Informação, E = Erro */
					NBool.True /*bloquear/travar?*/);
		}
	}

	@ActionTrigger(item = "BTN_GERAR_GUIA_HONORARIO", action = "btn_gerar_guia_honorario_click")
	public void btn_gerar_guia_honorario_click() {
		
		if(getGuiaElement().getSnValidaRestCarencia().equals("S")){
			if(getGuiaElement().getDspTpGuia().equals("I") || getGuiaElement().getDspTpGuia().equals("S")){
	
				this.getTask().getServices().validaProcedimentosHonorarios();
				
				ItemServices.goItem("GUIA_HONORARIO.DSP_CD_PRESTADOR");
				BlockServices.clearBlock();
			}else{
				getTask().getMv2000().msgAlert("Para este tipo de guia não é possível gerar Honorários", "W", NBool.False);
			}
		}else{
			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Erro.....: Operação inválida!")
					.append(Lib.chr(10))
					.append("Motivo..: A guia não está autorizada.")
					.append(Lib.chr(10))
					.append("Ação....: Autorize a guia para realizar esta operação.").toString(),
					"W", /*W = Atenção, I = Informação, E = Erro */
					NBool.False /*bloquear/travar?*/);
		}
	}

	@ActionTrigger(item = "BTN_CANCELAR_LEITURA_MAGNETICA", action = "btn_cancelar_leitura_magnetica_click")
    public void btn_cancelar_leitura_magnetica_click() {
		ItemServices.goItem("GUIA.CD_MATRICULA");
    }
	

	@ActionTrigger(item = "BTN_ENVIO_SMS", action = "btn_envio_sms_click")
	public void btn_envio_sms_click() {
		NString nrTelefone = Lib.isNull(getGuiaElement().getNrDddSms().append(getGuiaElement().getNrCelularSms()),Services.getDescricao("NR_CELULAR", "USUARIO", " CD_MATRICULA = " + getGuiaElement().getCdMatricula(), false));

		NNumber cdTipoAtendimento = Lib.isNull(getGuiaElement().getCdTipoAtendimento(), NNumber.getNull());
		NNumber cdPrestadorExecutor = Lib.isNull(getGuiaElement().getCdPrestadorExecutor(), NNumber.getNull());
		NNumber cdMotivoAutorizacao = Lib.isNull(getGuiaElement().getCdMotivoAutorizacao(), NNumber.getNull());
		int qtdRegistros = 0;
		
		NString vStatusGuia = this.getTask().getServices().fncStatusGuia(getGuiaElement().getNrGuia());
		String vSqlWhereStatusGuia = "";
		
		if(vStatusGuia.trim().equals("Autorizado")) {
			vSqlWhereStatusGuia = vSqlWhereStatusGuia + " AND SN_ENVIO_TOT_APROVADA = 'S' "; 
			
		}else if(vStatusGuia.trim().equals("Autorizado parcialmente")) {
			vSqlWhereStatusGuia = vSqlWhereStatusGuia + " AND SN_ENVIO_PARC_APROVADA = 'S' ";
			
		}else if(vStatusGuia.trim().equals("Negado")) {
			vSqlWhereStatusGuia = vSqlWhereStatusGuia + " AND SN_ENVIO_NEGADA = 'S' ";
			
		}else if(vStatusGuia.trim().equals("Cancelada")) {
			vSqlWhereStatusGuia = vSqlWhereStatusGuia + " AND SN_ENVIO_CANCELADA = 'S' ";
			
		}else {
			vSqlWhereStatusGuia = vSqlWhereStatusGuia + " ";
		}		

		String sql = ""
				+" SELECT *                                                          "
				+"   FROM (SELECT CD_SMS_MODELO,                                     "
				+"                DS_SMS_MODELO,                                     "
				+"                DS_MENSAGEM,                 						 "
				+" 				  SN_ENVIO_TOT_APROVADA,                             "
				+" 				  SN_ENVIO_PARC_APROVADA, 							 "  
				+" 				  SN_ENVIO_NEGADA,  								 "
				+" 				  SN_ENVIO_CANCELADA,								 "
				+"                1 PRIORIDADE                                       "
				+"           FROM DBAPS.SMS_MODELO                                   "
				+"          WHERE CD_TIPO_ATENDIMENTO = :PCD_TIPO_ATENDIMENTO        "
				+"            AND CD_PRESTADOR = :PCD_PRESTADOR                      "
				+"            AND CD_MOTIVO_AUTORIZACAO = :PCD_MOTIVO_AUTORIZACAO    "
				+            vSqlWhereStatusGuia
				+"            AND DT_INATIVACAO IS NULL                              "
				+"         UNION ALL                                                 "
				+"         SELECT CD_SMS_MODELO,                                     "
				+"                DS_SMS_MODELO,                                     "
				+"                DS_MENSAGEM, 										 "
				+"                SN_ENVIO_TOT_APROVADA,							 "
				+"                SN_ENVIO_PARC_APROVADA,						   	 "
				+"				  SN_ENVIO_NEGADA,        							 "
				+"  			  SN_ENVIO_CANCELADA,								 "
				+"                2 PRIORIDADE                                       "
				+"           FROM DBAPS.SMS_MODELO                                   "
				+"          WHERE CD_TIPO_ATENDIMENTO = :PCD_TIPO_ATENDIMENTO        "
				+"            AND CD_PRESTADOR = :PCD_PRESTADOR                      "
				+"            AND CD_MOTIVO_AUTORIZACAO IS NULL                      "
				+            vSqlWhereStatusGuia
				+"            AND DT_INATIVACAO IS NULL                              "
				+"         UNION ALL                                                 "
				+"         SELECT CD_SMS_MODELO,                                     "
				+"                DS_SMS_MODELO,                                     "
				+"                DS_MENSAGEM,										 "
				+"				SN_ENVIO_TOT_APROVADA,						         "
				+"				SN_ENVIO_PARC_APROVADA, 							 "
				+"				SN_ENVIO_NEGADA,									 "
				+"				SN_ENVIO_CANCELADA,                        			 "
				+"                3 PRIORIDADE                                       "
				+"           FROM DBAPS.SMS_MODELO                                   "
				+"          WHERE CD_TIPO_ATENDIMENTO = :PCD_TIPO_ATENDIMENTO        "
				+"            AND CD_PRESTADOR IS NULL                               "
				+"            AND CD_MOTIVO_AUTORIZACAO IS NULL                      "
				+            vSqlWhereStatusGuia
				+"            AND DT_INATIVACAO IS NULL                              "
				+"         UNION ALL                                                 "
				+"         SELECT CD_SMS_MODELO,                                     "
				+"                DS_SMS_MODELO,                                     "
				+"                DS_MENSAGEM,										 "
				+"	               SN_ENVIO_TOT_APROVADA,							 "
				+"	               SN_ENVIO_PARC_APROVADA,							 "
				+"         		   SN_ENVIO_NEGADA,									 "
				+"	 	 		   SN_ENVIO_CANCELADA,								 "
				+"                4 PRIORIDADE                                       "
				+"           FROM DBAPS.SMS_MODELO                                   "
				+"          WHERE CD_TIPO_ATENDIMENTO = :PCD_TIPO_ATENDIMENTO        "
				+"            AND CD_PRESTADOR IS NULL                               "
				+"            AND CD_MOTIVO_AUTORIZACAO = :PCD_MOTIVO_AUTORIZACAO    "
				+            vSqlWhereStatusGuia    
				+"            AND DT_INATIVACAO IS NULL)                             "
				+"  ORDER BY PRIORIDADE                                              ";

		DataCursor dataCursor = null;
		ResultSet resultSet = null;

		dataCursor = new DataCursor(sql);
		dataCursor.addParameter("PCD_TIPO_ATENDIMENTO",cdTipoAtendimento);
		dataCursor.addParameter("PCD_PRESTADOR",cdPrestadorExecutor);
		dataCursor.addParameter("PCD_MOTIVO_AUTORIZACAO",cdMotivoAutorizacao);
		dataCursor.open();

		vStatusGuia = this.getTask().getServices().fncStatusGuia(getGuiaElement().getNrGuia());
		
		if (dataCursor.found()) {
			resultSet = dataCursor.fetchInto();
			qtdRegistros = dataCursor.getRowCount();

			if (qtdRegistros == 1) {
				this.getTask().getServices().insertSmsEnvio(getGuiaElement(), resultSet.getStr("DS_SMS_MODELO"), resultSet.getNumber("CD_SMS_MODELO"), nrTelefone, resultSet.getStr("DS_MENSAGEM"));
			}
			if (qtdRegistros >= 2) {
				TaskServices.executeQuery("SMS_MODELO");
				ItemServices.goItem("SMS_MODELO.BTN_ENVIAR");
			}
			
		}else{
			getTask().getMv2000().msgAlert(NString.toStr("")
					.append("Operação inválida!")
					.append(Lib.chr(10))
					.append("Motivo..: Não foi encontrado um modelo cadastrado atendimento.")
					.append(Lib.chr(10))
					.append("Ação....: Verifique o cadastro em Atendimento / Tabelas - Autorização de Guias / Modelos de SMS.").toString(),
					"W", /*W = Atenção, I = Informação, E = Erro */
					NBool.False /*bloquear/travar?*/);				
			
		}
		
		if (dataCursor != null  && dataCursor.isOpen()) {
			dataCursor.close();
		}
	}

	@ValidationTrigger(item = "CD_MOTIVO_AUTORIZACAO")
	public void cd_motivo_autorizacao_validation() {
		boolean msg = false;
		if (!getFormModel().getCgCtrl().getCdMotivoAutorizacao().isNull()) {
			String sql = " SELECT CD_MOTIVO_AUTORIZACAO, DS_MOTIVO_AUTORIZACAO "
					+ " FROM DBAPS.MOTIVO_AUTORIZACAO WHERE CD_MOTIVO_AUTORIZACAO = :PCD_MOTIVO_AUTORIZACAO "
					+ " AND DT_INATIVACAO IS NULL ";

			DataCursor dataCursor = null;
			ResultSet resultSet = null;
			try{
				dataCursor = new DataCursor(sql);
				dataCursor.addParameter("PCD_MOTIVO_AUTORIZACAO",getFormModel().getCgCtrl().getCdMotivoAutorizacao());
				dataCursor.open();

				if (dataCursor.found()) {
					resultSet = dataCursor.fetchInto();				
					getFormModel().getCgCtrl().setDspDsMotivoAutorizacao(resultSet.getStr("DS_MOTIVO_AUTORIZACAO"));
				}else {
					msg = true;
				}

			}catch(Exception ex){
				ex.printStackTrace();
			}finally {
				if(dataCursor != null) dataCursor.close();
			}

			if (msg) {
				getTask().getMv2000().msgAlert(NString.toStr("")
						.append("Operação inválida!")
						.append(Lib.chr(10))
						.append("Motivo..: O motivo de autorização informação não existe ou está inativo.")
						.append(Lib.chr(10))
						.append("Ação....: Verifique o motivo de autorização informado..").toString(),
						"W", /*W = Atenção, I = Informação, E = Erro */
						NBool.True /*bloquear/travar?*/);
			}
		}else {
			getFormModel().getCgCtrl().setDspDsMotivoAutorizacao(NString.getNull());
		}
	}
	
	/**
	 * Informe o código do status e retorna as seguintes descrições
	 * 0 = Nenhum
	 * 1 = Em análise (Administrativa)
	 * 2 = Em análise (Auditoria médica)
	 * 3 = Negado
	 * 4 = Liberado
	 * @param tpStatus
	 * @return "Nenhum","Em Análise","Aguardando auditoria médica","Negado" e "Liberado"
	 */
	public String getDescricaoStatus(NNumber tpStatus) {
		if (tpStatus.equals(0)) {
			return "Nenhum";
		} else if (tpStatus.equals(1)) {
			return "Em Análise";
		} else if (tpStatus.equals(2)) {
			return "Aguardando auditoria médica";
		} else if (tpStatus.equals(3)) {
			return "Negado";
		} else if (tpStatus.equals(5)) {
			return "Cancelado";
		} else {
			return "Liberado";
		}
	}

	@ActionTrigger(item = "BTN_CONF_ALTERACAO_OBSERVACAO", action = "btn_conf_alteracao_observacao_click")
	public void btn_conf_alteracao_observacao_click() {
		this.getTask().getServices().insertLog( getGuiaElement().getNrGuia()
					  , NString.toStr("ALTERACA DA OBSERVAÇÃO")
					  , this.getFormModel().getNegacaoItem().getDspCdAutorizador()
					  , NString.getNull()
					  , getGuiaElement().getDsObservacao()
					  , this.getFormModel().getCgCtrl().getDspDsObservacao());
		try{
			BlockServices.setBlockUpdateAllowed("GUIA", true);
			getGuiaElement().setDsObservacao(this.getFormModel().getCgCtrl().getDspDsObservacao());
			commitTask(true);
		}finally{
			BlockServices.setBlockUpdateAllowed("GUIA", snValidaRestCarencia().equals("N"));
		}
		ItemServices.goItem("GUIA.BTN_ALTERAR_OBSERVACAO");
		
		this.getTask().getServices().recarregarTela(getGuiaElement().getNrGuia());
		
	}

	@ActionTrigger(item = "BTN_VOLT_ALTERACAO_OBSERVACAO", action = "btn_volt_alteracao_observacao_click")
	public void btn_volt_alteracao_observacao_click() {
		ItemServices.goItem("GUIA.BTN_ALTERAR_OBSERVACAO");
	}

	@ValidationTrigger(item = "CD_PTU_MOTIVO_ENCERRAMENTO")
	public void cd_ptu_motivo_encerramento_validation() {
		NString dsPtuMotivoEncerramento = NString.getNull();
		if (!getFormModel().getCgCtrl().getCdPtuMotivoEncerramento().isNull()) {
			dsPtuMotivoEncerramento = Services.getDescricao("DS_MOTIVO_ALTA", "MOTIVO_ALTA", "CD_PTU = " + getFormModel().getCgCtrl().getCdPtuMotivoEncerramento(), false);
			if (dsPtuMotivoEncerramento.isNull()) {
				//MULTI-IDIOMA: MSG_0080 - Valor do %s inválido.
				getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0080", ItemServices.getItemLabel("CG$CTRL.CD_PTU_MOTIVO_ENCERRAMENTO")), "W", NBool.False);
				return;
			}
		}
		
		getFormModel().getCgCtrl().setDsPtuMotivoEncerramento(dsPtuMotivoEncerramento);
	}
	
	private void validarGuiaAutorizada() {
		if (getTask().getServices().isGuiaAutorizada(getGuiaElement())) {
			getTask().getMv2000().msgAlert(ResourceManager.getString("guia.msg0140"), "E", NBool.True);
		}
	}

	@ActionTrigger(item = "BTN_CONF_ALTER_JUSTIFI_OPERADORA", action = "btn_conf_alter_justifi_operadora_click")
	public void btn_conf_alter_justifi_operadora_click() {
		try {
			BlockServices.setBlockUpdateAllowed("GUIA", true);
			getGuiaElement()
					.setDsJustificativaOperadora(this.getFormModel().getCgCtrl().getDspDsJustificativaOperadora());
			commitTask(true);
		} catch (Exception ex) {
			logger.error(new LogTraceEvent(this, new LogTraceMessage("msgErro"), ex, LEVEL.ERROR));
		} finally {
			BlockServices.setBlockUpdateAllowed("GUIA", snValidaRestCarencia().equals("N"));
		}
		ItemServices.goItem("GUIA.BTN_ALTERAR_JUSTIFICATIVA_OPERADORA");
		this.getTask().getServices().recarregarTela(getGuiaElement().getNrGuia());
	}

	@ActionTrigger(item = "BTN_VOLT_ALTER_JUSTIFI_OPERADORA", action = "btn_volt_alter_justifi_operadora_click")
	public void btn_volt_alter_justifi_operadora_click() {
		ItemServices.goItem("GUIA.BTN_ALTERAR_JUSTIFICATIVA_OPERADORA");
	}

	public NString snValidaRestCarencia() {
		return Lib.isNull(getGuiaElement().getSnValidaRestCarencia(), NString.toStr("N"));
	}

}

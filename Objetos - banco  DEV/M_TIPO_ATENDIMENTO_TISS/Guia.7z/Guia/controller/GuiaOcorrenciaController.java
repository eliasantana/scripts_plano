package br.com.mv.soul.mvsaude.forms.Guia.controller;

import static morphis.foundations.core.types.Types.toBool;
import static morphis.foundations.core.types.Types.toStr;

import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.BeforeRowDelete;
import morphis.foundations.core.appdatalayer.events.BeforeRowInsert;
import morphis.foundations.core.appdatalayer.events.BeforeRowUpdate;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.TaskServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.appsupportlib.runtime.events.RecordRemoved;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaOcorrenciaAdapter;
import morphis.foundations.core.types.NBool;
import br.com.mv.soul.common.localization.ResourceManager;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import br.com.mv.soul.flavor.runtime.action.ViewTrigger;

public class GuiaOcorrenciaController extends DefaultBlockController {

	public GuiaOcorrenciaController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	 public GuiaModel getFormModel() {
		return getTask().getModel();
	}
	 
	 public GuiaOcorrenciaAdapter getGuiaOcorrenciaElement(){
		return (GuiaOcorrenciaAdapter) this.getFormModel().getGuiaOcorrencia().getRowAdapter(true);
	}

    @BeforeRowInsert
	public void guia_ocorrencia_BeforeRowInsert(RowAdapterEvent rowAdapterEvent) {

		GuiaOcorrenciaAdapter guiaOcorrenciaElement = (GuiaOcorrenciaAdapter) rowAdapterEvent.getRow();

		guiaOcorrenciaElement.setCdUsuario(TaskServices.getUser());
		guiaOcorrenciaElement.setDtInclusao(DbManager.getDBDateTime());

		if (guiaOcorrenciaElement.getDsObservacao().isNull()) {
			//MULTI-IDIOMA: MSG_0021 - Informe o campo \"Observação\" no histórico da ocorrências.
			String msg = ResourceManager.getString("guia.msg0021");
			getTask().getMv2000().msgAlert(msg, "E", NBool.True);
		}

		if (guiaOcorrenciaElement.getCdClassificacaoOcorGuia().isNull()) {
			//MULTI-IDIOMA: MSG_0022 - Informe a classificação no histórico da ocorrências ou a classificação informada não e válida.
			String msg = ResourceManager.getString("guia.msg0022");
			getTask().getMv2000().msgAlert(msg, "E", NBool.True);
		}

	}

    @AfterQuery
	public void guia_ocorrencia_AfterQuery(RowAdapterEvent rowAdapterEvent) {
		carregaClassificacaoOcorrencia((GuiaOcorrenciaAdapter) rowAdapterEvent.getRow(), false);
	}

    /**
     * Carrega os dados da classificação das ocorrencias
     *
     * @PDA 
     * @author elton.soares
     * @since 09/12/2013
     * @param guiaOcorrenciaElement
     * @return void
     */
	public void carregaClassificacaoOcorrencia(GuiaOcorrenciaAdapter guiaOcorrenciaElement, boolean validate) {

		if (guiaOcorrenciaElement != null) {

			if (!validate) {
				String sClassificacaoOcorrencia = ""
												+ " SELECT ABREVIACAO_DESCRICAO, DS_CLASSIFICACAO_OCOR_GUIA, TP_CLASS_OCORRENCIA_GUIA "
												+ " FROM DBAPS.CLASSIFICACAO_OCORRENCIA_GUIA WHERE CD_CLASSIFICACAO_OCOR_GUIA = :CD_CLASSIFICACAO_OCOR_GUIA ";
				DataCursor cClassificacaoOcorrencia = new DataCursor(sClassificacaoOcorrencia);

				try {
					cClassificacaoOcorrencia.addParameter("CD_CLASSIFICACAO_OCOR_GUIA", guiaOcorrenciaElement.getCdClassificacaoOcorGuia());
					cClassificacaoOcorrencia.open();
					if (cClassificacaoOcorrencia.hasData()) {
						ResultSet rClassificacaoOcorrencia = cClassificacaoOcorrencia.fetchInto();

						guiaOcorrenciaElement.setAbreviacaoOcorrencia(rClassificacaoOcorrencia.getStr("ABREVIACAO_DESCRICAO"));
						guiaOcorrenciaElement.setDsClassificacao(rClassificacaoOcorrencia.getStr("DS_CLASSIFICACAO_OCOR_GUIA"));
						guiaOcorrenciaElement.setTpOcorrencia(rClassificacaoOcorrencia.getStr("TP_CLASS_OCORRENCIA_GUIA"));
					}
				} finally {
					cClassificacaoOcorrencia.close();
				}
			} else if (!guiaOcorrenciaElement.getAbreviacaoOcorrencia().isNull()) {
				String sClassificacaoOcorrenciaAbreviacao = ""
														  + " SELECT CD_CLASSIFICACAO_OCOR_GUIA, DS_CLASSIFICACAO_OCOR_GUIA, TP_CLASS_OCORRENCIA_GUIA " 
														  + " FROM DBAPS.CLASSIFICACAO_OCORRENCIA_GUIA  WHERE ABREVIACAO_DESCRICAO = :ABREVIACAO_DESCRICAO ";
				DataCursor cClassificacaoOcorrenciaAbreviacao = new DataCursor(sClassificacaoOcorrenciaAbreviacao);

				try {
					cClassificacaoOcorrenciaAbreviacao.addParameter("ABREVIACAO_DESCRICAO", guiaOcorrenciaElement.getAbreviacaoOcorrencia());
					cClassificacaoOcorrenciaAbreviacao.open();
					if (cClassificacaoOcorrenciaAbreviacao.hasData()) {
						ResultSet rClassificacaoOcorrencia = cClassificacaoOcorrenciaAbreviacao.fetchInto();

						guiaOcorrenciaElement.setCdClassificacaoOcorGuia(rClassificacaoOcorrencia.getNumber("CD_CLASSIFICACAO_OCOR_GUIA"));
						guiaOcorrenciaElement.setDsClassificacao(rClassificacaoOcorrencia.getStr("DS_CLASSIFICACAO_OCOR_GUIA"));
						guiaOcorrenciaElement.setTpOcorrencia(rClassificacaoOcorrencia.getStr("TP_CLASS_OCORRENCIA_GUIA"));
					} else if (validate) {
						//MULTI-IDIOMA: MSG_0022 - Informe a classificação no histórico da ocorrências ou a classificação informada não e válida.
						String msg = ResourceManager.getString("guia.msg0022");
						throw new ApplicationException(msg);
					}
				} catch (Exception e) {
					if (validate) {
						getTask().getMv2000().msgAlert(toStr(e.getMessage()), toStr("E"), toBool(NBool.True));
					}
				} finally {
					cClassificacaoOcorrenciaAbreviacao.close();
				}

			}
		}
	}

    @ValidationTrigger(item = "CD_CLASSIFICACAO_OCOR_GUIA")
	public void cd_classificacao_ocor_guia_validation() {

		if (!getGuiaOcorrenciaElement().getCdClassificacaoOcorGuia().isNull()) {

			String sql = "SELECT DS_CLASSIFICACAO_OCOR_GUIA, TP_CLASS_OCORRENCIA_GUIA FROM DBAPS.CLASSIFICACAO_OCORRENCIA_GUIA WHERE CD_MULTI_EMPRESA = DBAMV.PKG_MV2000.LE_EMPRESA AND CD_CLASSIFICACAO_OCOR_GUIA = :P_CD_CLASSIFICACAO_OCOR_GUIA";
			DataCursor cCursor = new DataCursor(sql);

			try {

				cCursor.addParameter("P_CD_CLASSIFICACAO_OCOR_GUIA", getGuiaOcorrenciaElement().getCdClassificacaoOcorGuia());
				cCursor.open();

				if (cCursor.found()) {
					ResultSet rs = cCursor.fetchInto();
					getGuiaOcorrenciaElement().setDsClassificacao(rs.getStr("DS_CLASSIFICACAO_OCOR_GUIA"));
					getGuiaOcorrenciaElement().setTpOcorrencia(rs.getStr("TP_CLASS_OCORRENCIA_GUIA"));
				} else {
					//MULTI-IDIOMA: MSG_0022 - Informe a classificação no histórico da ocorrências ou a classificação informada não e válida.
					String msg = ResourceManager.getString("guia.msg0022");
					getTask().getMv2000().msgAlert(msg, "E", NBool.True);
				}

			} finally {
				cCursor.close();
			}
		}
	}

    @BeforeRowDelete
    public void guia_ocorrencia_BeforeRowDelete(RowAdapterEvent rowAdapterEvent){}

    @BeforeRowUpdate
	public void guia_ocorrencia_BeforeRowUpdate(RowAdapterEvent rowAdapterEvent) {

		GuiaOcorrenciaAdapter guiaOcorrenciaElement = (GuiaOcorrenciaAdapter) rowAdapterEvent.getRow();

		if (guiaOcorrenciaElement.getDsObservacao().isNull()) {
			//MULTI-IDIOMA: MSG_0021 - Informe o campo \"Observação\" no histórico da ocorrências.
			String msg = ResourceManager.getString("guia.msg0021");
			getTask().getMv2000().msgAlert(msg, "E", NBool.True);
		}

		if (guiaOcorrenciaElement.getCdClassificacaoOcorGuia().isNull()) {
			//MULTI-IDIOMA: MSG_0022 - Informe a classificação no histórico da ocorrências ou a classificação informada não e válida.
			String msg = ResourceManager.getString("guia.msg0022");
			getTask().getMv2000().msgAlert(msg, "E", NBool.True);
		}
	}

    @RecordRemoved
	public void guia_ocorrencia_RecordRemoved(RowAdapterEvent rowAdapterEvent) {

		GuiaOcorrenciaAdapter guiaOcorrenciaElement = (GuiaOcorrenciaAdapter) rowAdapterEvent.getRow();

		if (!guiaOcorrenciaElement.getCdUsuario().equals(TaskServices.getUser()) && !guiaOcorrenciaElement.getCdUsuario().isNull()) {
			//MULTI-IDIOMA: MSG_0023 - Somente o usuário que realizou o lançamento pode remover o registro.
			String msg = ResourceManager.getString("guia.msg0023");
			getTask().getMv2000().msgAlert(msg, toStr("W"), toBool(NBool.True));
		}

	}
    
    @ViewTrigger(context={"PAGE_OCORRENCIAS"})
    @ActionTrigger(action = "guia_ocorrencia_recordChange", function=KeyFunction.RECORD_CHANGE)
	public void guia_ocorrencia_recordChange() {

		GuiaOcorrenciaAdapter guiaOcorrenciaElement = (GuiaOcorrenciaAdapter) this.getFormModel().getGuiaOcorrencia().getRowAdapter(true);

		if (guiaOcorrenciaElement.getCdUsuario().equals(TaskServices.getUser()) || guiaOcorrenciaElement.getCdUsuario().isNull()) {
			ItemServices.setItemUpdateAllowed("GUIA_OCORRENCIA.DS_OBSERVACAO", guiaOcorrenciaElement.getIndex() + 1, true);
			ItemServices.setItemInsertAllowed("GUIA_OCORRENCIA.DS_OBSERVACAO", guiaOcorrenciaElement.getIndex() + 1, true);
		} else {
			ItemServices.setItemUpdateAllowed("GUIA_OCORRENCIA.DS_OBSERVACAO", guiaOcorrenciaElement.getIndex() + 1, false);
			ItemServices.setItemInsertAllowed("GUIA_OCORRENCIA.DS_OBSERVACAO", guiaOcorrenciaElement.getIndex() + 1, false);
		}

	}

    @ValidationTrigger(item = "ABREVIACAO_OCORRENCIA")
	public void abreviacao_ocorrencia_validation() {
		GuiaOcorrenciaAdapter guiaOcorrenciaElement = (GuiaOcorrenciaAdapter) this.getFormModel().getGuiaOcorrencia().getRowAdapter(true);
		carregaClassificacaoOcorrencia(guiaOcorrenciaElement, true);
	} 
}

package br.com.mv.soul.mvsaude.forms.Guia.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;

import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.FiltroPrestExterno;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.PrestExternoAdapter;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.ViewServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;

public class PrestExternoController extends DefaultBlockController {

	public PrestExternoController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	public GuiaModel getFormModel() {
		return getTask().getModel();
	}
	
	public PrestExternoAdapter getPrestadorExternoElement() {
		return (PrestExternoAdapter) this.getFormModel().getPrestExterno().getRowAdapter(true);
	}
	
	public GuiaAdapter getGuiaElement() {
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}
    
	public FiltroPrestExterno  getFiltroPrestExternoElement() {
		return (FiltroPrestExterno) this.getFormModel().getFiltroPrestExterno().getItems();
	}
	
	@ActionTrigger(item = "BTN_CANCELAR", action = "btn_cancelar_click")
	public void btn_cancelar_click() {
		ViewServices.hideView("CNV_PRESTADOR_EXTERNO");
		ItemServices.goItem("GUIA.CD_PRESTADOR");
	}

	@ActionTrigger(item = "BTN_OK", action = "btn_ok_click")
	public void btn_ok_click() {
		restornaDsPrestExterno();
	}

	@ActionTrigger(item = "CPF_CNPJ", action = "cpf_cnpj_click")
	public void cpf_cnpj_doubleClick() {
		//restornaDsPrestExterno();
	}

	@ActionTrigger(item = "DS_NOME", action = "ds_nome_click")
	public void ds_nome_doubleClick() {
		//restornaDsPrestExterno();
		
	}

	
	public void restornaDsPrestExterno(){
	 if(!getPrestadorExternoElement().getDsNome().isNull()){
		 getGuiaElement().setNmPrestador(getPrestadorExternoElement().getDsNome());           
		 getGuiaElement().setCdPrestador(NNumber.getNull());
		 ViewServices.hideView("CNV_PRESTADOR_EXTERNO");
		 ItemServices.goItem("GUIA.NM_PRESTADOR"); 
	 }
	}
	
}
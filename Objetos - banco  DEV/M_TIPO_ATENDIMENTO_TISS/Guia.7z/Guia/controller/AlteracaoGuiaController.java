package br.com.mv.soul.mvsaude.forms.Guia.controller;

import static morphis.foundations.core.types.Types.toBool;
import static morphis.foundations.core.types.Types.toNumber;
import static morphis.foundations.core.types.Types.toStr;

import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import morphis.foundations.core.appsupportlib.runtime.ItemServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.services.GuiaServices;
import br.com.mv.soul.mvsaude.forms.Guia.services.PkgMvsGuia;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import br.com.mv.soul.common.localization.ResourceManager;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	


public class AlteracaoGuiaController extends DefaultBlockController
{

     public AlteracaoGuiaController(IFormController parentController, String name)
    {
         super(parentController, name);
    }

    @Override
    public GuiaTask getTask()
    {
        return (GuiaTask) super.getTask();
    }

    public GuiaModel getFormModel()
    {
        return this.getTask().getModel();
    }
    
    public GuiaAdapter getGuiaElement(){
		return (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
	}

    @ValidationTrigger(item = "CD_PRESTADOR_EXECUTOR_NOVO")
    public void cdPrestadorExecutorNovo_validate()
    {
    	if(!getFormModel().getAlteracaoGuia().getCdPrestadorExecutorNovo().isNull()){    		
    		PkgMvsGuia.pIWviAgCdPrestadorExec();
    		
    		String sEnderecoPrestador = " SELECT PE.CD_PRESTADOR_ENDERECO, PE.DS_ENDERECO || ' Nº ' ||  " 
    								  + "        PE.NR_ENDERECO ||  ' '  || PE.DS_COMPLEMENTO || ' - '  || " 
    								  + "        PE.DS_BAIRRO   || ' - ' || PE.DS_MUNICIPIO   || ' - '  || PE.CD_UF DS_ENDERECO " 
    								  + "   FROM DBAPS.PRESTADOR_ENDERECO PE,                           "
    								  + "        DBAPS.PRESTADOR_ENDERECO_ESPL PEE                      "
    								  + "  WHERE PE.CD_PRESTADOR      = :CD_PRESTADOR_EXECUTOR          "
    								  + "  	 AND PE.CD_PRESTADOR_ENDERECO = PEE.CD_PRESTADOR_ENDERECO "
    								  + "    AND (PEE.CD_ESPECIALIDADE = :CD_ESPECIALIDADE OR :CD_ESPECIALIDADE IS NULL ) ";
    		DataCursor cEnderecoPrestador = new DataCursor(sEnderecoPrestador);

    		NNumber cdPrestadorEndereco;
    		NString dsEndereco;

    		try {
    			cEnderecoPrestador.addParameter("CD_PRESTADOR_EXECUTOR", getFormModel().getAlteracaoGuia().getCdPrestadorExecutorNovo());
    			cEnderecoPrestador.addParameter("CD_ESPECIALIDADE", getGuiaElement().getCdEspecialidade());

    			cEnderecoPrestador.open();
    			ResultSet rEnderecoPrestador = cEnderecoPrestador.fetchInto();
    			int count = 0;
    			if (cEnderecoPrestador.hasData()) {
    				while (true) {
    					cdPrestadorEndereco = rEnderecoPrestador.getNumber("CD_PRESTADOR_ENDERECO");
    					dsEndereco = rEnderecoPrestador.getStr("DS_ENDERECO");
    					rEnderecoPrestador = cEnderecoPrestador.fetchInto();
    					count++;
    					if (!cEnderecoPrestador.hasData()) {
    						break;
    					}
    				}
    				if (count == 1) {
    					getFormModel().getAlteracaoGuia().setCdPrestadorEnderecoNovo(cdPrestadorEndereco);
    					getFormModel().getAlteracaoGuia().setDspPrestadorEnderecoNovo(dsEndereco);
    				}
    			}

    		} catch (Exception e) {
    			getTask().getMv2000().msgAlert("Erro: " + e.getMessage(), "E", toBool(NBool.True));
    		} finally {
    			cEnderecoPrestador.close();
    		}
    		
    	}else{
    		getFormModel().getAlteracaoGuia().setDspNmPrestadorExecutorNovo(NString.getNull());
    	}
    }

    @SuppressWarnings("unused")
	@ActionTrigger(action = "btnAlteracao_click", item = "BTN_ALTERACAO")
	public void btnAlteracao_click() {
    	
		GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
		NNumber nnrregistroatual = NNumber.getNull();
		
		if (getFormModel().getAlteracaoGuia().getCdPrestadorExecutorNovo().isNull()) {
			
			//MULTI-IDIOMA: MSG_0001 - Prestador não informado.
			String msg = ResourceManager.getString("guia.msg0001");
			getTask().getMv2000().msgAlert(msg, toStr("E"), toBool(NBool.True));
			
		}
		
		if (guiaElement.getCdPrestadorExecutor().equals(getFormModel().getAlteracaoGuia().getCdPrestadorExecutorNovo())) {
			
			//MULTI-IDIOMA: MSG_0002 - Novo prestador não pode ser igual ao prestador executor atual.
			String msg = ResourceManager.getString("guia.msg0002");
			getTask().getMv2000().msgAlert(msg, toStr("E"), toBool(NBool.True));
			
		}
		
		if (guiaElement.getSnValidaRestCarencia().equals("N")) {
			
			//MULTI-IDIOMA: MSG_0003 - Utilize esta opção quando a guia estiver autorizada.
			String msg = ResourceManager.getString("guia.msg0003");
			getTask().getMv2000().msgAlert(msg, toStr("E"), toBool(NBool.True));
			
		} else if (!guiaElement.getCdMotCancelamentoGuia().isNull()) {
			
			//MULTI-IDIOMA: MSG_0004 - Utilize esta opção quando a guia não estiver cancelada.
			String msg = ResourceManager.getString("guia.msg0004" );
			getTask().getMv2000().msgAlert(msg, toStr("E"), toBool(NBool.True));
			
		}
		
		//MULTI-IDIOMA: MSG_0005 - Digite a Senha de Alteração da Guia
		String msg = ResourceManager.getString("guia.msg0005" );
		
		this.getFormModel().setParam("PERMITE_ALT", toStr("S"));
		getFormModel().getCgCtrl().setDspDsLiberacao(NString.toStr(msg));
		getFormModel().getCgCtrl().setDsSenhaAutorizacaoSemBase(toStr(null));
		
		getFormModel().getCgCtrl().setCdAutorizadorOpe(guiaElement.getCdAutorizador());
		getFormModel().getCgCtrl().setDspNmAutorizadorOpe(guiaElement.getDspNmAutorizador());
		
		ResultSet rs = GuiaServices.getAutorizadorLogado();
		
		if(rs != null){
			getFormModel().getCgCtrl().setCdAutorizadorOpe(rs.getNumber("CD_AUTORIZADOR"));
			getFormModel().getCgCtrl().setDspNmAutorizadorOpe(rs.getStr("NM_AUTORIZADOR"));	
		}
		
		getFormModel().getCgCtrl().setCdMotCancelamento(toNumber(null));
		getFormModel().getCgCtrl().setDspDsMotCancelamento(toStr(null));
		this.getFormModel().setParam("CHAMA_AUTORIZ", toStr("A"));
		this.getTask().getServices().configuraSolicitacaoSenha(NString.toStr("A"));
	}

	@ValidationTrigger(item = "CD_PRESTADOR_ENDERECO_NOVO")
	public void cd_prestador_endereco_novo_validation() {
		
		String sEnderecoPrestador = " SELECT PE.CD_PRESTADOR_ENDERECO, PE.DS_ENDERECO || ' Nº ' ||  " 
								  + "        PE.NR_ENDERECO ||  ' '  || PE.DS_COMPLEMENTO || ' - '  || " 
								  + "        PE.DS_BAIRRO   || ' - ' || PE.DS_MUNICIPIO   || ' - '  || PE.CD_UF DS_ENDERECO" 
								  + "   FROM DBAPS.PRESTADOR_ENDERECO PE,                           " 
								  + "        DBAPS.PRESTADOR_ENDERECO_ESPL PEE                      " 
								  + "  WHERE PE.CD_PRESTADOR_ENDERECO = PEE.CD_PRESTADOR_ENDERECO   " 
								  + "    AND PE.CD_PRESTADOR      = :CD_PRESTADOR_EXECUTOR          " 
								  + "    AND (PEE.CD_ESPECIALIDADE = :CD_ESPECIALIDADE OR :CD_ESPECIALIDADE IS NULL ) " 
								  + "    AND PE.CD_PRESTADOR_ENDERECO = :CD_PRESTADOR_ENDERECO      ";
		DataCursor cEnderecoPrestador = new DataCursor(sEnderecoPrestador);

		if (!getFormModel().getAlteracaoGuia().getCdPrestadorExecutorNovo().isNull() && !getFormModel().getAlteracaoGuia().getCdPrestadorEnderecoNovo().isNull()) {
			try {
				cEnderecoPrestador.addParameter("CD_PRESTADOR_EXECUTOR", getFormModel().getAlteracaoGuia().getCdPrestadorExecutorNovo());
				cEnderecoPrestador.addParameter("CD_ESPECIALIDADE", getGuiaElement().getCdEspecialidade());
				cEnderecoPrestador.addParameter("CD_PRESTADOR_ENDERECO", getFormModel().getAlteracaoGuia().getCdPrestadorEnderecoNovo());

				cEnderecoPrestador.open();
				if (cEnderecoPrestador.hasData()) {
					ResultSet rEnderecoPrestador = cEnderecoPrestador.fetchInto();

					getFormModel().getAlteracaoGuia().setDspPrestadorEnderecoNovo(rEnderecoPrestador.getStr("DS_ENDERECO"));

					if (this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED") != null && this.getTask().getServices().mapaMultiEmpresaMvSaude.get("SN_OPERADORA_UNIMED").equals("S")) {
						ItemServices.setItemIsValid("GUIA.CD_REDE_REFERENCIADA", true);
						this.getTask().getServices().getRedeReferenciadaPrestador(getFormModel().getAlteracaoGuia().getCdPrestadorEnderecoNovo(), NNumber.getNull(), false);
					}
				} else {
					throw new ApplicationException("Código do endereço informado não existe para o prestador e especialidade informados.");
				}
			} catch (Exception e) {
				getTask().getMv2000().msgAlert("Erro: " + e.getMessage(), "E", toBool(NBool.True));
			} finally {
				cEnderecoPrestador.close();
			}

		}
		
	}

}

package br.com.mv.soul.mvsaude.forms.Guia.controller;

import static morphis.foundations.core.appsupportlib.Globals.getGlobal;
import static morphis.foundations.core.appsupportlib.Globals.setGlobal;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.goItem;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.executeQuery;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.goBlock;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.hideView;
import static morphis.foundations.core.types.Types.toNumber;
import static morphis.foundations.core.types.Types.toStr;

import morphis.foundations.core.appsupportlib.runtime.BlockServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaProrrogacaoAdapter;
import br.com.mv.soul.mvsaude.forms.Guia.model.MensContratoAdapter;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class MConRecFormsController extends DefaultBlockController {

	public MConRecFormsController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public GuiaTask getTask() {
		return (GuiaTask) super.getTask();
	}

	 public GuiaModel getFormModel() {
		return getTask().getModel();
	}

    @ActionTrigger(item = "BTN_CANCELAR", action = "btn_cancelar_click")
    public void btn_cancelar_click()
    {
        hideView("CNV_EMAIL");
        goItem("GUIA.NR_GUIA");
        
        GuiaAdapter guiaElement = (GuiaAdapter) this.getFormModel().getGuia().getRowAdapter(true);
        MensContratoAdapter mensContratoElement = (MensContratoAdapter) this.getFormModel().getMensContrato().getRowAdapter(true);
        GuiaProrrogacaoAdapter guiaProrrogacaoElement = (GuiaProrrogacaoAdapter) this.getFormModel().getGuiaProrrogacao().getRowAdapter(true);
        
        setGlobal("NR_GUIA", guiaElement.getNrGuia());
        goBlock(toStr("GUIA"));
        BlockServices.setBlockWhereClause("GUIA", "NR_GUIA = "+toNumber(getGlobal("NR_GUIA")));
        executeQuery();
        /**
         * PDA 521677
         */
        if (mensContratoElement.getTpQuitacao().equals("Q"))
        {
            /**
             * Ao retornar do FNFI se a mensalidade for quitada deve ser desabilitado o botao de analisar e habilitar o de
             * emissao e retirar a mascara ******** do NR_GUIA.
             */
            this.getTask().getServices().prcHabilitaBotoes(guiaProrrogacaoElement, guiaElement, toStr("N"));
        }
    }
}

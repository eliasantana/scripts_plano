package br.com.mv.soul.mvsaude.forms.Guia.controller;

import static morphis.foundations.core.types.Types.toBool;
import static morphis.foundations.core.types.Types.toNumber;

import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.Guia.GuiaTask;
import br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel;
import br.com.mv.soul.mvsaude.forms.Guia.model.LogAutorizaAdapter;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	


public class LogAutorizaController extends DefaultBlockController
{

    public LogAutorizaController(IFormController parentController, String name)
    {
        super(parentController, name);
    }

    @Override
     public GuiaTask getTask()
    {
        return (GuiaTask) super.getTask();
    }

    public GuiaModel getFormModel()
    {
        return this.getTask().getModel();
    }

    @AfterQuery
	public void logAutoriza_AfterQuery(RowAdapterEvent args) {
		LogAutorizaAdapter logAutorizaElement = (LogAutorizaAdapter) args.getRow();

		if (!logAutorizaElement.getCdAutorizadorLog().isNull()) {
			logAutorizaElement.setDspDsAutorizadorLog(getTask().getMPkgMvsAutorizador().getMPkgMvsAutorizador().fRetornaDescricao(logAutorizaElement.getCdAutorizadorLog(), toNumber(this.getFormModel().getParam("CD_MULTI_EMPRESA", NString.class)), this.getFormModel().getParam("CD_USUARIO", NString.class), toBool(NBool.False), toBool(NBool.False)));
		}
	}

}

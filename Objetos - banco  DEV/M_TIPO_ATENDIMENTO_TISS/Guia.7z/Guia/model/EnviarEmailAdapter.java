package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class EnviarEmailAdapter extends BaseRowAdapter {

	public EnviarEmailAdapter(DataRow row, IDBBusinessObject businessObject) {
		 super(row, businessObject);
	}
	
	//Data Columns
	
	
	
	
	
	public NString getDspEmailPrestador() {
		NString v = new NString((String) this.getValue("DSP_EMAIL_PRESTADOR"));
		return v;
	}

	public void setDspEmailPrestador(NString value) {
		this.setValue("DSP_EMAIL_PRESTADOR", value.getValue());
	}

	public NString getDspUrlEmailGuia() {
		NString v = new NString((String) this.getValue("DSP_URL_EMAIL_GUIA"));
		return v;
	}

	public void setDspUrlEmailGuia(NString value) {
		this.setValue("DSP_URL_EMAIL_GUIA", value.getValue());
	}

	

	

	public NString getDspEmailLocalAtendimento() {
		NString v = new NString(
				(String) this.getValue("DSP_EMAIL_LOCAL_ATENDIMENTO"));
		return v;
	}

	public void setDspEmailLocalAtendimento(NString value) {
		this.setValue("DSP_EMAIL_LOCAL_ATENDIMENTO", value.getValue());
	}

	

	

	public NString getDspEmailPrestadorExecutante() {
		NString v = new NString(
				(String) this.getValue("DSP_EMAIL_PRESTADOR_EXECUTANTE"));
		return v;
	}

	public void setDspEmailPrestadorExecutante(NString value) {
		this.setValue("DSP_EMAIL_PRESTADOR_EXECUTANTE", value.getValue());
	}

	

	

	public NString getDspEmailPrestadorSolicitante() {
		NString v = new NString(
				(String) this.getValue("DSP_EMAIL_PRESTADOR_SOLICITANTE"));
		return v;
	}

	public void setDspEmailPrestadorSolicitante(NString value) {
		this.setValue("DSP_EMAIL_PRESTADOR_SOLICITANTE", value.getValue());
	}

	

	

	public NString getDspEmailBeneficiario() {
		NString v = new NString(
				(String) this.getValue("DSP_EMAIL_BENEFICIARIO"));
		return v;
	}

	public void setDspEmailBeneficiario(NString value) {
		this.setValue("DSP_EMAIL_BENEFICIARIO", value.getValue());
	}

	public NString getDspSnLocalAtendimento() {
		NString v = new NString(
				(String) this.getValue("DSP_SN_LOCAL_ATENDIMENTO"));
		return v;
	}

	public void setDspSnLocalAtendimento(NString value) {
		this.setValue("DSP_SN_LOCAL_ATENDIMENTO", value.getValue());
	}

	

	

	

	

	

	

	public NString getDspSnPrestadorExecutante() {
		NString v = new NString(
				(String) this.getValue("DSP_SN_PRESTADOR_EXECUTANTE"));
		return v;
	}

	public void setDspSnPrestadorExecutante(NString value) {
		this.setValue("DSP_SN_PRESTADOR_EXECUTANTE", value.getValue());
	}

	public NString getDspSnPrestadorSolicitante() {
		NString v = new NString(
				(String) this.getValue("DSP_SN_PRESTADOR_SOLICITANTE"));
		return v;
	}

	public void setDspSnPrestadorSolicitante(NString value) {
		this.setValue("DSP_SN_PRESTADOR_SOLICITANTE", value.getValue());
	}

	public NString getDspSnBeneficiario() {
		NString v = new NString(
				(String) this.getValue("DSP_SN_BENEFICIARIO"));
		return v;
	}

	public void setDspSnBeneficiario(NString value) {
		this.setValue("DSP_SN_BENEFICIARIO", value.getValue());
	}

	public NString getDspSnAuditor() {
		NString v = new NString((String) this.getValue("DSP_SN_AUDITOR"));
		return v;
	}

	public void setDspSnAuditor(NString value) {
		this.setValue("DSP_SN_AUDITOR", value.getValue());
	}

	public NString getDspEmailAuditor() {
		NString v = new NString((String) this.getValue("DSP_EMAIL_AUDITOR"));
		return v;
	}

	public void setDspEmailAuditor(NString value) {
		this.setValue("DSP_EMAIL_AUDITOR", value.getValue());
	}

	

	

}

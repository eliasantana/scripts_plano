package br.com.mv.soul.mvsaude.forms.Guia.model;

import java.util.Date;
import java.math.BigDecimal;
import org.jdesktop.databuffer.DataRow;
//import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.types.*;
import morphis.foundations.core.appsupportlib.model.*;
import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;

public class ItguiaRateioCopartAdapter extends BaseRowAdapter {

	public ItguiaRateioCopartAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getCdItguia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_ITGUIA"));
		return v;
	}
	
	public void setCdItguia(NNumber value) {
		this.setValue("CD_ITGUIA", value.getValue());
	}

	public NNumber getCdPlano() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PLANO"));
		return v;
	}
	
	public void setCdPlano(NNumber value) {
		this.setValue("CD_PLANO", value.getValue());
	}

	public NNumber getVlRateio() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_RATEIO"));
		return v;
	}
	
	public void setVlRateio(NNumber value) {
		this.setValue("VL_RATEIO", value.getValue());
	}

}
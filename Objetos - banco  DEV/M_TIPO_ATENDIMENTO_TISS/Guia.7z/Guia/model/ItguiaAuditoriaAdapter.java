package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class ItguiaAuditoriaAdapter extends BaseRowAdapter {

	public ItguiaAuditoriaAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getNrGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA"));
		return v;
	}
	
	public void setNrGuia(NNumber value) {
		this.setValue("NR_GUIA", value.getValue());
	}

	public NNumber getCdItguia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_ITGUIA"));
		return v;
	}
	
	public void setCdItguia(NNumber value) {
		this.setValue("CD_ITGUIA", value.getValue());
	}

	public NString getTpStatus() {
		NString v = new NString((String)this.getValue("TP_STATUS"));
		return v;
	}
	
	public void setTpStatus(NString value) {
		this.setValue("TP_STATUS", value.getValue());
	}

	public NString getDsMensagemEspecifica() {
		NString v = new NString((String)this.getValue("DS_MENSAGEM_ESPECIFICA"));
		return v;
	}
	
	public void setDsMensagemEspecifica(NString value) {
		this.setValue("DS_MENSAGEM_ESPECIFICA", value.getValue());
	}
	
	public NString getCdProcedimento() {

		NString v = new NString((String) this.getValue("CD_PROCEDIMENTO"));
		return v;
	}

	public void setCdProcedimento(NString value) {

		this.setValue("CD_PROCEDIMENTO", value.getValue());
	}

	public NString getDspDsProcedimento() {

		NString v = new NString((String) this.getValue("DSP_DS_PROCEDIMENTO"));
		return v;
	}

	public void setDspDsProcedimento(NString value) {

		this.setValue("DSP_DS_PROCEDIMENTO", value.getValue());
	}

	public NString getTpResposta() {

		NString v = new NString((String) this.getValue("TP_RESPOSTA"));
		return v;
	}

	public void setTpResposta(NString value) {

		this.setValue("TP_RESPOSTA", value.getValue());
	}

}

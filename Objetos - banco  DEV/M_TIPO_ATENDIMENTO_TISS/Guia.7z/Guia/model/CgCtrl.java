package br.com.mv.soul.mvsaude.forms.Guia.model;

import static morphis.foundations.core.types.Types.toNumber;
import static morphis.foundations.core.types.Types.toStr;

import morphis.foundations.core.appsupportlib.model.SimpleBusinessObject;
import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	


public class CgCtrl extends SimpleBusinessObject
{
	public CgCtrl() {
		super();
	}

	 public CgCtrl(SimpleBusinessObjectConfiguration configuration, String name) {
		super(configuration, name);
	}
	

	



	public NString getDspDsLiberacao() {
		return toStr(super.getValue("DSP_DS_LIBERACAO"));
	}
	
	public void setDspDsLiberacao(NString value) {
		super.setValue("DSP_DS_LIBERACAO", value);
	}
	


	public NNumber getCdAutorizadorOpe() {
		return toNumber(super.getValue("CD_AUTORIZADOR_OPE"));
	}
	
	public void setCdAutorizadorOpe(NNumber value) {
		super.setValue("CD_AUTORIZADOR_OPE", value);
	}
	


	public NString getDspNmAutorizadorOpe() {
		return toStr(super.getValue("DSP_NM_AUTORIZADOR_OPE"));
	}
	
	public void setDspNmAutorizadorOpe(NString value) {
		super.setValue("DSP_NM_AUTORIZADOR_OPE", value);
	}
	


	public NString getDsSenhaAutorizacaoSemBase() {
		return toStr(super.getValue("DS_SENHA_AUTORIZACAO_SEM_BASE"));
	}
	
	public void setDsSenhaAutorizacaoSemBase(NString value) {
		super.setValue("DS_SENHA_AUTORIZACAO_SEM_BASE", value);
	}
	


	public NString getDsSenhaAutorizadorOpe() {
		return toStr(super.getValue("DS_SENHA_AUTORIZADOR_OPE"));
	}
	
	public void setDsSenhaAutorizadorOpe(NString value) {
		super.setValue("DS_SENHA_AUTORIZADOR_OPE", value);
	}
	


	public NString getSnCancelaAutorizacao() {
		return toStr(super.getValue("SN_CANCELA_AUTORIZACAO"));
	}
	
	public void setSnCancelaAutorizacao(NString value) {
		super.setValue("SN_CANCELA_AUTORIZACAO", value);
	}
	


	public NNumber getCdMotCancelamento() {
		return toNumber(super.getValue("CD_MOT_CANCELAMENTO"));
	}
	
	public void setCdMotCancelamento(NNumber value) {
		super.setValue("CD_MOT_CANCELAMENTO", value);
	}
	


	public NString getDspDsMotCancelamento() {
		return toStr(super.getValue("DSP_DS_MOT_CANCELAMENTO"));
	}
	
	public void setDspDsMotCancelamento(NString value) {
		super.setValue("DSP_DS_MOT_CANCELAMENTO", value);
	}
	


	public NNumber getTpStatus() {
		return toNumber(super.getValue("TP_STATUS"));
	}
	
	public void setTpStatus(NNumber value) {
		super.setValue("TP_STATUS", value);
	}
	


	public NString getCgAt() {
		return toStr(super.getValue("CG$AT"));
	}
	
	public void setCgAt(NString value) {
		super.setValue("CG$AT", value);
	}
	


	public NString getCgPage1List() {
		return toStr(super.getValue("CG$PAGE_1_LIST"));
	}
	
	public void setCgPage1List(NString value) {
		super.setValue("CG$PAGE_1_LIST", value);
	}
	


	public NString getDummyPage() {
		return toStr(super.getValue("DUMMY_PAGE"));
	}
	
	public void setDummyPage(NString value) {
		super.setValue("DUMMY_PAGE", value);
	}
	


	public NString getRootWindowPage() {
		return toStr(super.getValue("ROOT_WINDOW_PAGE"));
	}
	
	public void setRootWindowPage(NString value) {
		super.setValue("ROOT_WINDOW_PAGE", value);
	}
	


	public NString getCgLastCanvas() {
		return toStr(super.getValue("CG$LAST_CANVAS"));
	}
	
	public void setCgLastCanvas(NString value) {
		super.setValue("CG$LAST_CANVAS", value);
	}
	


	public NNumber getDspVlTotalProcedimento() {
		return toNumber(super.getValue("DSP_VL_TOTAL_PROCEDIMENTO"));
	}
	
	public void setDspVlTotalProcedimento(NNumber value) {
		super.setValue("DSP_VL_TOTAL_PROCEDIMENTO", value);
	}
	


	public NNumber getDspVlTotalFranquia() {
		return toNumber(super.getValue("DSP_VL_TOTAL_FRANQUIA"));
	}
	
	public void setDspVlTotalFranquia(NNumber value) {
		super.setValue("DSP_VL_TOTAL_FRANQUIA", value);
	}

	public NNumber getCdMotivoDesligamentoMens() {
		return toNumber(super.getValue("CD_MOTIVO_DESLIGAMENTO_MENS"));
	}

	public void setCdMotivoDesligamentoMens(NNumber value) {
		super.setValue("CD_MOTIVO_DESLIGAMENTO_MENS", value);
	}

	public NString getDsMotivoDesligamentoMens() {
		return toStr(super.getValue("DS_MOTIVO_DESLIGAMENTO_MENS"));
	}

	public void setDsMotivoDesligamentoMens(NString value) {
		super.setValue("DS_MOTIVO_DESLIGAMENTO_MENS", value);
	}

	public NString getDspDsCaminhoAbrirBrowser() {

		return toStr(super.getValue("DSP_DS_CAMINHO_ABRIR_BROWSER"));
	}

	public void setDspDsCaminhoAbrirBrowser(NString value) {

		super.setValue("DSP_DS_CAMINHO_ABRIR_BROWSER", value);
	}

	public NNumber getCdMotivoAutorizacao() {

		return toNumber(super.getValue("CD_MOTIVO_AUTORIZACAO"));
	}

	public void setCdMotivoAutorizacao(NNumber value) {

		super.setValue("CD_MOTIVO_AUTORIZACAO", value);
	}

	public NString getDspDsMotivoAutorizacao() {

		return toStr(super.getValue("DSP_DS_MOTIVO_AUTORIZACAO"));
	}

	public void setDspDsMotivoAutorizacao(NString value) {

		super.setValue("DSP_DS_MOTIVO_AUTORIZACAO", value);
	}

	public NString getDspDsObservacaoCancelamento() {

		return toStr(super.getValue("DSP_DS_OBSERVACAO_CANCELAMENTO"));
	}

	public void setDspDsObservacaoCancelamento(NString value) {

		super.setValue("DSP_DS_OBSERVACAO_CANCELAMENTO", value);
	}

	public NString getDspDsMensagemLivre() {

		return toStr(super.getValue("DSP_DS_MENSAGEM_LIVRE"));
	}

	public void setDspDsMensagemLivre(NString value) {

		super.setValue("DSP_DS_MENSAGEM_LIVRE", value);
	}

	public NString getDspTpMotCancelamento() {

		return toStr(super.getValue("DSP_TP_MOT_CANCELAMENTO"));
	}

	public void setDspTpMotCancelamento(NString value) {

		super.setValue("DSP_TP_MOT_CANCELAMENTO", value);
	}

	public NDate getDspDtAltaInternacao() {

		return NDate.toDate(super.getValue("DSP_DT_ALTA_INTERNACAO"));
	}

	public void setDspDtAltaInternacao(NDate value) {

		super.setValue("DSP_DT_ALTA_INTERNACAO", value);
	}

	public NString getDspDsObservacao() {

		return toStr(super.getValue("DSP_DS_OBSERVACAO"));
	}

	public void setDspDsObservacao(NString value) {

		super.setValue("DSP_DS_OBSERVACAO", value);
	}

	public NString getDspSnAplicarTodos() {

		return toStr(super.getValue("DSP_SN_APLICAR_TODOS"));
	}

	public void setDspSnAplicarTodos(NString value) {

		super.setValue("DSP_SN_APLICAR_TODOS", value);
	}

	public NDate getDtPtuEvento() {

		return NDate.toDate(super.getValue("DT_PTU_EVENTO"));
	}

	public void setDtPtuEvento(NDate value) {

		super.setValue("DT_PTU_EVENTO", value);
	}

	public NString getTpPtuEvento() {

		return toStr(super.getValue("TP_PTU_EVENTO"));
	}

	public void setTpPtuEvento(NString value) {

		super.setValue("TP_PTU_EVENTO", value);
	}

	public NNumber getCdPtuMotivoEncerramento() {

		return toNumber(super.getValue("CD_PTU_MOTIVO_ENCERRAMENTO"));
	}

	public void setCdPtuMotivoEncerramento(NNumber value) {

		super.setValue("CD_PTU_MOTIVO_ENCERRAMENTO", value);
	}

	public NString getDsPtuMotivoEncerramento() {

		return toStr(super.getValue("DS_PTU_MOTIVO_ENCERRAMENTO"));
	}

	public void setDsPtuMotivoEncerramento(NString value) {

		super.setValue("DS_PTU_MOTIVO_ENCERRAMENTO", value);
	}
	
	public NDate getDspDtExecucaoInternacao() {
		return NDate.toDate(super.getValue("DSP_DT_EXECUCAO_INTERNACAO"));
	}

	public void setDspDtExecucaoInternacao(NDate value) {
		super.setValue("DSP_DT_EXECUCAO_INTERNACAO", value);
	}

	public NString getDspDsJustificativaOperadora() {
		return toStr(super.getValue("DSP_DS_JUSTIFICATIVA_OPERADORA"));
	}

	public void setDspDsJustificativaOperadora(NString value) {
		super.setValue("DSP_DS_JUSTIFICATIVA_OPERADORA", value);
	}

}





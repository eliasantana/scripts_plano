package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class ItguiaMensagemEspecificaAdapter extends BaseRowAdapter {

	public ItguiaMensagemEspecificaAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getCdItguiaMensagemEspecifica() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_ITGUIA_MENSAGEM_ESPECIFICA"));
		return v;
	}
	
	public void setCdItguiaMensagemEspecifica(NNumber value) {
		this.setValue("CD_ITGUIA_MENSAGEM_ESPECIFICA", value.getValue());
	}

	public NNumber getCdItguia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_ITGUIA"));
		return v;
	}
	
	public void setCdItguia(NNumber value) {
		this.setValue("CD_ITGUIA", value.getValue());
	}

	public NNumber getCdPtuMensagemEspecifica() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PTU_MENSAGEM_ESPECIFICA"));
		return v;
	}
	
	public void setCdPtuMensagemEspecifica(NNumber value) {
		this.setValue("CD_PTU_MENSAGEM_ESPECIFICA", value.getValue());
	}
	
	

	

	public NString getDspDsPtuMensagemEspecifica() {

		NString v = new NString((String) this.getValue("DSP_DS_PTU_MENSAGEM_ESPECIFICA"));
		return v;
	}

	public void setDspDsPtuMensagemEspecifica(NString value) {

		this.setValue("DSP_DS_PTU_MENSAGEM_ESPECIFICA", value.getValue());
	}

}

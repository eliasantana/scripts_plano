package br.com.mv.soul.mvsaude.forms.Guia.model;

import static morphis.foundations.core.types.Types.toStr;

import morphis.foundations.core.appsupportlib.model.SimpleBusinessObject;
import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	


public class ImpGuia extends SimpleBusinessObject
{
	public ImpGuia() {
		 super();
	}

	public ImpGuia(SimpleBusinessObjectConfiguration configuration, String name) {
		super(configuration, name);
	}
	

	



	public NString getCkImpPrestador() {
		return toStr(super.getValue("CK_IMP_PRESTADOR"));
	}
	
	public void setCkImpPrestador(NString value) {
		super.setValue("CK_IMP_PRESTADOR", value);
	}
	


	public NString getCkImpCirurgiao() {
		return toStr(super.getValue("CK_IMP_CIRURGIAO"));
	}
	
	public void setCkImpCirurgiao(NString value) {
		super.setValue("CK_IMP_CIRURGIAO", value);
	}
	


	public NString getCkImpAuxiliar1() {
		return toStr(super.getValue("CK_IMP_AUXILIAR1"));
	}
	
	public void setCkImpAuxiliar1(NString value) {
		super.setValue("CK_IMP_AUXILIAR1", value);
	}
	


	public NString getCkImpAuxiliar2() {
		return toStr(super.getValue("CK_IMP_AUXILIAR2"));
	}
	
	public void setCkImpAuxiliar2(NString value) {
		super.setValue("CK_IMP_AUXILIAR2", value);
	}
	


	public NString getCkImpAuxiliar3() {
		return toStr(super.getValue("CK_IMP_AUXILIAR3"));
	}
	
	public void setCkImpAuxiliar3(NString value) {
		super.setValue("CK_IMP_AUXILIAR3", value);
	}
	


	public NString getCkImpAnestesista() {
		return toStr(super.getValue("CK_IMP_ANESTESISTA"));
	}
	
	public void setCkImpAnestesista(NString value) {
		super.setValue("CK_IMP_ANESTESISTA", value);
	}
	



}





package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class ItguiaExecucaoAdapter extends BaseRowAdapter {

	public ItguiaExecucaoAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getCdItguiaExecucao() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_ITGUIA_EXECUCAO"));
		return v;
	}
	
	public void setCdItguiaExecucao(NNumber value) {
		this.setValue("CD_ITGUIA_EXECUCAO", value.getValue());
	}

	public NNumber getQtExec() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("QT_EXEC"));
		return v;
	}
	
	public void setQtExec(NNumber value) {
		this.setValue("QT_EXEC", value.getValue());
	}

	public NDate getDtExecucao() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_EXECUCAO"));
		return v;
	}
	
	public void setDtExecucao(NDate value) {
		this.setValue("DT_EXECUCAO", value.getValue());
	}

	public NNumber getCdPrestadorExecutor() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PRESTADOR_EXECUTOR"));
		return v;
	}
	
	public void setCdPrestadorExecutor(NNumber value) {
		this.setValue("CD_PRESTADOR_EXECUTOR", value.getValue());
	}

	public NNumber getCdAutorizador() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_AUTORIZADOR"));
		return v;
	}
	
	public void setCdAutorizador(NNumber value) {
		this.setValue("CD_AUTORIZADOR", value.getValue());
	}

	public NNumber getCdItguia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_ITGUIA"));
		return v;
	}
	
	public void setCdItguia(NNumber value) {
		this.setValue("CD_ITGUIA", value.getValue());
	}
	
	public NString getDspNmAutorizador() {

		NString v = new NString((String) this.getValue("DSP_NM_AUTORIZADOR"));
		return v;
	}

	public void setDspNmAutorizador(NString value) {

		this.setValue("DSP_NM_AUTORIZADOR", value.getValue());
	}

	public NString getDspNmPrestador() {

		NString v = new NString((String) this.getValue("DSP_NM_PRESTADOR"));
		return v;
	}

	public void setDspNmPrestador(NString value) {

		this.setValue("DSP_NM_PRESTADOR", value.getValue());
	}

	public NDate getDtCancelamento() {

		NDate v = new NDate((java.util.Date) this.getValue("DT_CANCELAMENTO"));
		return v;
	}

	public void setDtCancelamento(NDate value) {

		this.setValue("DT_CANCELAMENTO", value.getValue());
	}

	public NString getCdUsuario() {

		NString v = new NString((String) this.getValue("CD_USUARIO"));
		return v;
	}

	public void setCdUsuario(NString value) {

		this.setValue("CD_USUARIO", value.getValue());
	}

}

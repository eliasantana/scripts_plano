package br.com.mv.soul.mvsaude.forms.Guia.model;

import java.math.BigDecimal;
import java.util.Date;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
	

public class GuiaAdapter extends BaseRowAdapter {

	public GuiaAdapter(DataRow row, IDBBusinessObject businessObject) {
		 super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getCdMultiEmpresa() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_MULTI_EMPRESA"));
		return v;
	}
	
	public void setCdMultiEmpresa(NNumber value) {
		this.setValue("CD_MULTI_EMPRESA", value.getValue());
	}

	public NNumber getNrGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA"));
		return v;
	}
	
	public void setNrGuia(NNumber value) {
		this.setValue("NR_GUIA", value.getValue());
	}
    
	public NNumber getCdMatricula() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_MATRICULA"));
		return v;
	}
	
	public void setCdMatricula(NNumber value) {
		this.setValue("CD_MATRICULA", value.getValue());
	}

	public NString getDspNmSegurado() {
		NString v = new NString((String)this.getValue("DSP_NM_SEGURADO"));
		return v;
	}
	
	public void setDspNmSegurado(NString value) {
		this.setValue("DSP_NM_SEGURADO", value.getValue());
	}

	public NString getNrGuiaPrestador() {
		NString v = new NString((String)this.getValue("NR_GUIA_PRESTADOR"));
		return v;
	}
	
	public void setNrGuiaPrestador(NString value) {
		this.setValue("NR_GUIA_PRESTADOR", value.getValue());
	}

	public NNumber getNrGuiaExterna() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA_EXTERNA"));
		return v;
	}
	
	public void setNrGuiaExterna(NNumber value) {
		this.setValue("NR_GUIA_EXTERNA", value.getValue());
	}

	public NString getDspTpContrato() {
		NString v = new NString((String)this.getValue("DSP_TP_CONTRATO"));
		return v;
	}
	
	public void setDspTpContrato(NString value) {
		this.setValue("DSP_TP_CONTRATO", value.getValue());
	}

	public NNumber getDspCdGrupoFranquia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_CD_GRUPO_FRANQUIA"));
		return v;
	}
	
	public void setDspCdGrupoFranquia(NNumber value) {
		this.setValue("DSP_CD_GRUPO_FRANQUIA", value.getValue());
	}

	public NString getDspTpGrupoFranquia() {
		NString v = new NString((String)this.getValue("DSP_TP_GRUPO_FRANQUIA"));
		return v;
	}
	
	public void setDspTpGrupoFranquia(NString value) {
		this.setValue("DSP_TP_GRUPO_FRANQUIA", value.getValue());
	}

	public NString getDspSnAvista() {
		NString v = new NString((String)this.getValue("DSP_SN_AVISTA"));
		return v;
	}
	
	public void setDspSnAvista(NString value) {
		this.setValue("DSP_SN_AVISTA", value.getValue());
	}

	public NNumber getDspCdPlano() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_CD_PLANO"));
		return v;
	}
	
	public void setDspCdPlano(NNumber value) {
		this.setValue("DSP_CD_PLANO", value.getValue());
	}

	public NNumber getCdPlano() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PLANO"));
		return v;
	}
	
	public void setCdPlano(NNumber value) {
		this.setValue("CD_PLANO", value.getValue());
	}

	public NString getDspDsPlano() {
		NString v = new NString((String)this.getValue("DSP_DS_PLANO"));
		return v;
	}
	
	public void setDspDsPlano(NString value) {
		this.setValue("DSP_DS_PLANO", value.getValue());
	}

	public NNumber getNrGuiaTem() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA_TEM"));
		return v;
	}
	
	public void setNrGuiaTem(NNumber value) {
		this.setValue("NR_GUIA_TEM", value.getValue());
	}

	public NNumber getCdGrupoFranquia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_GRUPO_FRANQUIA"));
		return v;
	}
	
	public void setCdGrupoFranquia(NNumber value) {
		this.setValue("CD_GRUPO_FRANQUIA", value.getValue());
	}

	public NNumber getDspCdGrupoFranquiaUsuario() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_CD_GRUPO_FRANQUIA_USUARIO"));
		return v;
	}
	
	public void setDspCdGrupoFranquiaUsuario(NNumber value) {
		this.setValue("DSP_CD_GRUPO_FRANQUIA_USUARIO", value.getValue());
	}

	public NString getDspDsGrupoFranquia() {
		NString v = new NString((String)this.getValue("DSP_DS_GRUPO_FRANQUIA"));
		return v;
	}
	
	public void setDspDsGrupoFranquia(NString value) {
		this.setValue("DSP_DS_GRUPO_FRANQUIA", value.getValue());
	}

	public NString getSnAvista() {
		NString v = new NString((String)this.getValue("SN_AVISTA"));
		return v;
	}
	
	public void setSnAvista(NString value) {
		this.setValue("SN_AVISTA", value.getValue());
	}

	public NString getDspTpMensalidade() {
		NString v = new NString((String)this.getValue("DSP_TP_MENSALIDADE"));
		return v;
	}
	
	public void setDspTpMensalidade(NString value) {
		this.setValue("DSP_TP_MENSALIDADE", value.getValue());
	}

	public NString getDspTpSexo() {
		NString v = new NString((String)this.getValue("DSP_TP_SEXO"));
		return v;
	}
	
	public void setDspTpSexo(NString value) {
		this.setValue("DSP_TP_SEXO", value.getValue());
	}

	public NNumber getDspCdMatriculaTem() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_CD_MATRICULA_TEM"));
		return v;
	}
	
	public void setDspCdMatriculaTem(NNumber value) {
		this.setValue("DSP_CD_MATRICULA_TEM", value.getValue());
	}

	public NDate getDspDtNascimento() {
		NDate v = new NDate((java.util.Date)this.getValue("DSP_DT_NASCIMENTO"));
		return v;
	}
	
	public void setDspDtNascimento(NDate value) {
		this.setValue("DSP_DT_NASCIMENTO", value.getValue());
	}

	public NNumber getDspCdEmpresa() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_CD_EMPRESA"));
		return v;
	}
	
	public void setDspCdEmpresa(NNumber value) {
		this.setValue("DSP_CD_EMPRESA", value.getValue());
	}

	public NNumber getCdTipoAtendimento() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_TIPO_ATENDIMENTO"));
		return v;
	}
	
	public void setCdTipoAtendimento(NNumber value) {
		this.setValue("CD_TIPO_ATENDIMENTO", value.getValue());
	}

	public NString getDspDsTipoAtendimento() {
		NString v = new NString((String)this.getValue("DSP_DS_TIPO_ATENDIMENTO"));
		return v;
	}
	
	public void setDspDsTipoAtendimento(NString value) {
		this.setValue("DSP_DS_TIPO_ATENDIMENTO", value.getValue());
	}

	public NNumber getCdTipAcomodacao() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_TIP_ACOMODACAO"));
		return v;
	}
	
	public void setCdTipAcomodacao(NNumber value) {
		this.setValue("CD_TIP_ACOMODACAO", value.getValue());
	}

	public NString getDspDsTipAcomodacao() {
		NString v = new NString((String)this.getValue("DSP_DS_TIP_ACOMODACAO"));
		return v;
	}
	
	public void setDspDsTipAcomodacao(NString value) {
		this.setValue("DSP_DS_TIP_ACOMODACAO", value.getValue());
	}

	public NNumber getCdTipoConsulta() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_TIPO_CONSULTA"));
		return v;
	}
	
	public void setCdTipoConsulta(NNumber value) {
		this.setValue("CD_TIPO_CONSULTA", value.getValue());
	}

	public NString getDspSnPrestador() {
		NString v = new NString((String)this.getValue("DSP_SN_PRESTADOR"));
		return v;
	}
	
	public void setDspSnPrestador(NString value) {
		this.setValue("DSP_SN_PRESTADOR", value.getValue());
	}

	public NString getDspSnTpInternacao() {
		NString v = new NString((String)this.getValue("DSP_SN_TP_INTERNACAO"));
		return v;
	}
	
	public void setDspSnTpInternacao(NString value) {
		this.setValue("DSP_SN_TP_INTERNACAO", value.getValue());
	}

	public NString getDspTpGuia() {
		NString v = new NString((String)this.getValue("DSP_TP_GUIA"));
		return v;
	}
	
	public void setDspTpGuia(NString value) {
		this.setValue("DSP_TP_GUIA", value.getValue());
	}

	public NString getDspSnDsSenhaAutorizacao() {
		NString v = new NString((String)this.getValue("DSP_SN_DS_SENHA_AUTORIZACAO"));
		return v;
	}
	
	public void setDspSnDsSenhaAutorizacao(NString value) {
		this.setValue("DSP_SN_DS_SENHA_AUTORIZACAO", value.getValue());
	}

	public NString getDspSnNrDiasAutorizacao() {
		NString v = new NString((String)this.getValue("DSP_SN_NR_DIAS_AUTORIZACAO"));
		return v;
	}
	
	public void setDspSnNrDiasAutorizacao(NString value) {
		this.setValue("DSP_SN_NR_DIAS_AUTORIZACAO", value.getValue());
	}

	public NString getDspDsProgramaDaGuia() {
		NString v = new NString((String)this.getValue("DSP_DS_PROGRAMA_DA_GUIA"));
		return v;
	}
	
	public void setDspDsProgramaDaGuia(NString value) {
		this.setValue("DSP_DS_PROGRAMA_DA_GUIA", value.getValue());
	}

	public NNumber getDspCdGrupoFaixaEtaria() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_CD_GRUPO_FAIXA_ETARIA"));
		return v;
	}
	
	public void setDspCdGrupoFaixaEtaria(NNumber value) {
		this.setValue("DSP_CD_GRUPO_FAIXA_ETARIA", value.getValue());
	}

	public NNumber getDspCdFaixaEtaria() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_CD_FAIXA_ETARIA"));
		return v;
	}
	
	public void setDspCdFaixaEtaria(NNumber value) {
		this.setValue("DSP_CD_FAIXA_ETARIA", value.getValue());
	}

	public NNumber getDspCdContrato() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_CD_CONTRATO"));
		return v;
	}
	
	public void setDspCdContrato(NNumber value) {
		this.setValue("DSP_CD_CONTRATO", value.getValue());
	}

	public NString getDspNmSegurado2() {
		NString v = new NString((String)this.getValue("DSP_NM_SEGURADO2"));
		return v;
	}
	
	public void setDspNmSegurado2(NString value) {
		this.setValue("DSP_NM_SEGURADO2", value.getValue());
	}

	public NString getDspSnAtivo() {
		NString v = new NString((String)this.getValue("DSP_SN_ATIVO"));
		return v;
	}
	
	public void setDspSnAtivo(NString value) {
		this.setValue("DSP_SN_ATIVO", value.getValue());
	}

	public NNumber getCdPrestador() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PRESTADOR"));
		return v;
	}
	
	public void setCdPrestador(NNumber value) {
		this.setValue("CD_PRESTADOR", value.getValue());
	}

	public NString getNmPrestador() {
		NString v = new NString((String)this.getValue("NM_PRESTADOR"));
		return v;
	}
	
	public void setNmPrestador(NString value) {
		this.setValue("NM_PRESTADOR", value.getValue());
	}

	public NString getDspTpPrestador() {
		NString v = new NString((String)this.getValue("DSP_TP_PRESTADOR"));
		return v;
	}
	
	public void setDspTpPrestador(NString value) {
		this.setValue("DSP_TP_PRESTADOR", value.getValue());
	}

	public NString getNmContato() {
		NString v = new NString((String)this.getValue("NM_CONTATO"));
		return v;
	}
	
	public void setNmContato(NString value) {
		this.setValue("NM_CONTATO", value.getValue());
	}

	public NNumber getCdPrestadorSolicitante() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PRESTADOR_SOLICITANTE"));
		return v;
	}
	
	public void setCdPrestadorSolicitante(NNumber value) {
		this.setValue("CD_PRESTADOR_SOLICITANTE", value.getValue());
	}

	public NNumber getCdEspecialidadeSolicitante() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_ESPECIALIDADE_SOLICITANTE"));
		return v;
	}
	
	public void setCdEspecialidadeSolicitante(NNumber value) {
		this.setValue("CD_ESPECIALIDADE_SOLICITANTE", value.getValue());
	}

	public NString getDspEspecialidadeSolicitante() {
		NString v = new NString((String)this.getValue("DSP_ESPECIALIDADE_SOLICITANTE"));
		return v;
	}
	
	public void setDspEspecialidadeSolicitante(NString value) {
		this.setValue("DSP_ESPECIALIDADE_SOLICITANTE", value.getValue());
	}

	public NNumber getCdPrestadorSolicitado() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PRESTADOR_SOLICITADO"));
		return v;
	}
	
	public void setCdPrestadorSolicitado(NNumber value) {
		this.setValue("CD_PRESTADOR_SOLICITADO", value.getValue());
	}

	public NString getNmPrestadorSolicitado() {
		NString v = new NString((String)this.getValue("NM_PRESTADOR_SOLICITADO"));
		return v;
	}
	
	public void setNmPrestadorSolicitado(NString value) {
		this.setValue("NM_PRESTADOR_SOLICITADO", value.getValue());
	}

	public NString getTpCaraterSolicInter() {
		NString v = new NString((String)this.getValue("TP_CARATER_SOLIC_INTER"));
		return v;
	}
	
	public void setTpCaraterSolicInter(NString value) {
		this.setValue("TP_CARATER_SOLIC_INTER", value.getValue());
	}

	public NString getTpInternacao() {
		NString v = new NString((String)this.getValue("TP_INTERNACAO"));
		return v;
	}
	
	public void setTpInternacao(NString value) {
		this.setValue("TP_INTERNACAO", value.getValue());
	}

	public NNumber getCdRegimeInternacao() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_REGIME_INTERNACAO"));
		return v;
	}
	
	public void setCdRegimeInternacao(NNumber value) {
		this.setValue("CD_REGIME_INTERNACAO", value.getValue());
	}

	public NDate getDtEmissao() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_EMISSAO"));
		return v;
	}
	
	public void setDtEmissao(NDate value) {
		this.setValue("DT_EMISSAO", value.getValue());
	}

	public NDate getDtVencimento() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_VENCIMENTO"));
		return v;
	}
	
	public void setDtVencimento(NDate value) {
		this.setValue("DT_VENCIMENTO", value.getValue());
	}

	public NDate getDtPrevExecucao() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_PREV_EXECUCAO"));
		return v;
	}
	
	public void setDtPrevExecucao(NDate value) {
		this.setValue("DT_PREV_EXECUCAO", value.getValue());
	}

	public NNumber getCdEspecialidade() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_ESPECIALIDADE"));
		return v;
	}
	
	public void setCdEspecialidade(NNumber value) {
		this.setValue("CD_ESPECIALIDADE", value.getValue());
	}

	public NString getDspDsEspecialidade() {
		NString v = new NString((String)this.getValue("DSP_DS_ESPECIALIDADE"));
		return v;
	}
	
	public void setDspDsEspecialidade(NString value) {
		this.setValue("DSP_DS_ESPECIALIDADE", value.getValue());
	}

	public NNumber getCdPrestadorExecutor() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PRESTADOR_EXECUTOR"));
		return v;
	}
	
	public void setCdPrestadorExecutor(NNumber value) {
		this.setValue("CD_PRESTADOR_EXECUTOR", value.getValue());
	}

	public NString getDspNmExecutor() {
		NString v = new NString((String)this.getValue("DSP_NM_EXECUTOR"));
		return v;
	}
	
	public void setDspNmExecutor(NString value) {
		this.setValue("DSP_NM_EXECUTOR", value.getValue());
	}

	public NNumber getCdPrestadorExecutorPf() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PRESTADOR_EXECUTOR_PF"));
		return v;
	}
	
	public void setCdPrestadorExecutorPf(NNumber value) {
		this.setValue("CD_PRESTADOR_EXECUTOR_PF", value.getValue());
	}

	public NString getCdProcedimentoPrincipal() {
		NString v = new NString((String)this.getValue("CD_PROCEDIMENTO_PRINCIPAL"));
		return v;
	}
	
	public void setCdProcedimentoPrincipal(NString value) {
		this.setValue("CD_PROCEDIMENTO_PRINCIPAL", value.getValue());
	}

	public NString getDspDsProcedimentoPrincipal() {
		NString v = new NString((String)this.getValue("DSP_DS_PROCEDIMENTO_PRINCIPAL"));
		return v;
	}
	
	public void setDspDsProcedimentoPrincipal(NString value) {
		this.setValue("DSP_DS_PROCEDIMENTO_PRINCIPAL", value.getValue());
	}

	public NString getCdCid() {
		NString v = new NString((String)this.getValue("CD_CID"));
		return v;
	}
	
	public void setCdCid(NString value) {
		this.setValue("CD_CID", value.getValue());
	}

	public NString getDspDsCid() {
		NString v = new NString((String)this.getValue("DSP_DS_CID"));
		return v;
	}
	
	public void setDspDsCid(NString value) {
		this.setValue("DSP_DS_CID", value.getValue());
	}

	public NString getCdCid2() {
		NString v = new NString((String)this.getValue("CD_CID2"));
		return v;
	}
	
	public void setCdCid2(NString value) {
		this.setValue("CD_CID2", value.getValue());
	}

	public NString getDspDsCid2() {
		NString v = new NString((String)this.getValue("DSP_DS_CID2"));
		return v;
	}
	
	public void setDspDsCid2(NString value) {
		this.setValue("DSP_DS_CID2", value.getValue());
	}

	public NString getCdCid3() {
		NString v = new NString((String)this.getValue("CD_CID3"));
		return v;
	}
	
	public void setCdCid3(NString value) {
		this.setValue("CD_CID3", value.getValue());
	}

	public NString getDspDsCid3() {
		NString v = new NString((String)this.getValue("DSP_DS_CID3"));
		return v;
	}
	
	public void setDspDsCid3(NString value) {
		this.setValue("DSP_DS_CID3", value.getValue());
	}

	public NString getCdCid4() {
		NString v = new NString((String)this.getValue("CD_CID4"));
		return v;
	}
	
	public void setCdCid4(NString value) {
		this.setValue("CD_CID4", value.getValue());
	}

	public NString getDspDsCid4() {
		NString v = new NString((String)this.getValue("DSP_DS_CID4"));
		return v;
	}
	
	public void setDspDsCid4(NString value) {
		this.setValue("DSP_DS_CID4", value.getValue());
	}

	public NNumber getNrDiasSolicitacao() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_DIAS_SOLICITACAO"));
		return v;
	}
	
	public void setNrDiasSolicitacao(NNumber value) {
		this.setValue("NR_DIAS_SOLICITACAO", value.getValue());
	}

	public NNumber getNrDiasAutorizacao() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_DIAS_AUTORIZACAO"));
		return v;
	}
	
	public void setNrDiasAutorizacao(NNumber value) {
		this.setValue("NR_DIAS_AUTORIZACAO", value.getValue());
	}

	public NNumber getDspTotDiasAutorizados() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_TOT_DIAS_AUTORIZADOS"));
		return v;
	}
	
	public void setDspTotDiasAutorizados(NNumber value) {
		this.setValue("DSP_TOT_DIAS_AUTORIZADOS", value.getValue());
	}

	public NString getSnValidaRestCarencia() {
		NString v = new NString((String)this.getValue("SN_VALIDA_REST_CARENCIA"));
		return v;
	}
	
	public void setSnValidaRestCarencia(NString value) {
		this.setValue("SN_VALIDA_REST_CARENCIA", value.getValue());
	}

	public NDate getDtAutorizacao() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_AUTORIZACAO"));
		return v;
	}
	
	public void setDtAutorizacao(NDate value) {
		this.setValue("DT_AUTORIZACAO", value.getValue());
	}

	public NDate getDtBaixado() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_BAIXADO"));
		return v;
	}
	
	public void setDtBaixado(NDate value) {
		this.setValue("DT_BAIXADO", value.getValue());
	}

	public NString getDspSnFaturada() {
		NString v = new NString((String)this.getValue("DSP_SN_FATURADA"));
		return v;
	}
	
	public void setDspSnFaturada(NString value) {
		this.setValue("DSP_SN_FATURADA", value.getValue());
	}

	public NNumber getCdAutorizador() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_AUTORIZADOR"));
		return v;
	}
	
	public void setCdAutorizador(NNumber value) {
		this.setValue("CD_AUTORIZADOR", value.getValue());
	}

	public NString getDspNmAutorizador() {
		NString v = new NString((String)this.getValue("DSP_NM_AUTORIZADOR"));
		return v;
	}
	
	public void setDspNmAutorizador(NString value) {
		this.setValue("DSP_NM_AUTORIZADOR", value.getValue());
	}

	public NString getDsSenhaAutorizador() {
		NString v = new NString((String)this.getValue("DS_SENHA_AUTORIZADOR"));
		return v;
	}
	
	public void setDsSenhaAutorizador(NString value) {
		this.setValue("DS_SENHA_AUTORIZADOR", value.getValue());
	}

	public NNumber getCdFatura() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_FATURA"));
		return v;
	}
	
	public void setCdFatura(NNumber value) {
		this.setValue("CD_FATURA", value.getValue());
	}

	public NNumber getCdIdUsuario() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_ID_USUARIO"));
		return v;
	}
	
	public void setCdIdUsuario(NNumber value) {
		this.setValue("CD_ID_USUARIO", value.getValue());
	}

	public NString getDspDsSenha() {
		NString v = new NString((String)this.getValue("DSP_DS_SENHA"));
		return v;
	}
	
	public void setDspDsSenha(NString value) {
		this.setValue("DSP_DS_SENHA", value.getValue());
	}

	public NString getDsObservacao() {
		NString v = new NString((String)this.getValue("DS_OBSERVACAO"));
		return v;
	}
	
	public void setDsObservacao(NString value) {
		this.setValue("DS_OBSERVACAO", value.getValue());
	}

	public NString getDsDiagnostico() {
		NString v = new NString((String)this.getValue("DS_DIAGNOSTICO"));
		return v;
	}
	
	public void setDsDiagnostico(NString value) {
		this.setValue("DS_DIAGNOSTICO", value.getValue());
	}

	public NString getDsSenhaAutorizacao() {
		NString v = new NString((String)this.getValue("DS_SENHA_AUTORIZACAO"));
		return v;
	}
	
	public void setDsSenhaAutorizacao(NString value) {
		this.setValue("DS_SENHA_AUTORIZACAO", value.getValue());
	}

	public NNumber getDspNrNivel() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_NR_NIVEL"));
		return v;
	}
	
	public void setDspNrNivel(NNumber value) {
		this.setValue("DSP_NR_NIVEL", value.getValue());
	}

	public NNumber getDspNrNivelAutorizacao() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_NR_NIVEL_AUTORIZACAO"));
		return v;
	}
	
	public void setDspNrNivelAutorizacao(NNumber value) {
		this.setValue("DSP_NR_NIVEL_AUTORIZACAO", value.getValue());
	}

	public NString getFlegAutorizador() {
		NString v = new NString((String)this.getValue("FLEG_AUTORIZADOR"));
		return v;
	}
	
	public void setFlegAutorizador(NString value) {
		this.setValue("FLEG_AUTORIZADOR", value.getValue());
	}

	public NNumber getDspCdAutorizaTerc() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_CD_AUTORIZA_TERC"));
		return v;
	}
	
	public void setDspCdAutorizaTerc(NNumber value) {
		this.setValue("DSP_CD_AUTORIZA_TERC", value.getValue());
	}

	public NString getDspSnCdAutoriza() {
		NString v = new NString((String)this.getValue("DSP_SN_CD_AUTORIZA"));
		return v;
	}
	
	public void setDspSnCdAutoriza(NString value) {
		this.setValue("DSP_SN_CD_AUTORIZA", value.getValue());
	}

	public NNumber getMrrCdMatricula() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("MRR_CD_MATRICULA"));
		return v;
	}
	
	public void setMrrCdMatricula(NNumber value) {
		this.setValue("MRR_CD_MATRICULA", value.getValue());
	}

	public NString getMrrDspNmSegurado() {
		NString v = new NString((String)this.getValue("MRR_DSP_NM_SEGURADO"));
		return v;
	}
	
	public void setMrrDspNmSegurado(NString value) {
		this.setValue("MRR_DSP_NM_SEGURADO", value.getValue());
	}

	public NNumber getMrrDspCdPlano() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("MRR_DSP_CD_PLANO"));
		return v;
	}
	
	public void setMrrDspCdPlano(NNumber value) {
		this.setValue("MRR_DSP_CD_PLANO", value.getValue());
	}

	public NString getMrrDspDsPlano() {
		NString v = new NString((String)this.getValue("MRR_DSP_DS_PLANO"));
		return v;
	}
	
	public void setMrrDspDsPlano(NString value) {
		this.setValue("MRR_DSP_DS_PLANO", value.getValue());
	}

	public NNumber getMrrCdTipoAtendimento() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("MRR_CD_TIPO_ATENDIMENTO"));
		return v;
	}
	
	public void setMrrCdTipoAtendimento(NNumber value) {
		this.setValue("MRR_CD_TIPO_ATENDIMENTO", value.getValue());
	}

	public NString getMrrDspDsTipoAtendimento() {
		NString v = new NString((String)this.getValue("MRR_DSP_DS_TIPO_ATENDIMENTO"));
		return v;
	}
	
	public void setMrrDspDsTipoAtendimento(NString value) {
		this.setValue("MRR_DSP_DS_TIPO_ATENDIMENTO", value.getValue());
	}

	public NNumber getMrrCdEspecialidade() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("MRR_CD_ESPECIALIDADE"));
		return v;
	}
	
	public void setMrrCdEspecialidade(NNumber value) {
		this.setValue("MRR_CD_ESPECIALIDADE", value.getValue());
	}

	public NString getMrrDspDsEspecialidade() {
		NString v = new NString((String)this.getValue("MRR_DSP_DS_ESPECIALIDADE"));
		return v;
	}
	
	public void setMrrDspDsEspecialidade(NString value) {
		this.setValue("MRR_DSP_DS_ESPECIALIDADE", value.getValue());
	}

	public NNumber getMrrCdPrestadorExecutor() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("MRR_CD_PRESTADOR_EXECUTOR"));
		return v;
	}
	
	public void setMrrCdPrestadorExecutor(NNumber value) {
		this.setValue("MRR_CD_PRESTADOR_EXECUTOR", value.getValue());
	}

	public NString getMrrDspNmExecutor() {
		NString v = new NString((String)this.getValue("MRR_DSP_NM_EXECUTOR"));
		return v;
	}
	
	public void setMrrDspNmExecutor(NString value) {
		this.setValue("MRR_DSP_NM_EXECUTOR", value.getValue());
	}

	public NNumber getProrrDspNrGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("PRORR_DSP_NR_GUIA"));
		return v;
	}
	
	public void setProrrDspNrGuia(NNumber value) {
		this.setValue("PRORR_DSP_NR_GUIA", value.getValue());
	}

	public NNumber getProrrDspCdMatricula() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("PRORR_DSP_CD_MATRICULA"));
		return v;
	}
	
	public void setProrrDspCdMatricula(NNumber value) {
		this.setValue("PRORR_DSP_CD_MATRICULA", value.getValue());
	}

	public NString getProrrDspNmAssociado() {
		NString v = new NString((String)this.getValue("PRORR_DSP_NM_ASSOCIADO"));
		return v;
	}
	
	public void setProrrDspNmAssociado(NString value) {
		this.setValue("PRORR_DSP_NM_ASSOCIADO", value.getValue());
	}

	public NString getProrrDspNmPlano() {
		NString v = new NString((String)this.getValue("PRORR_DSP_NM_PLANO"));
		return v;
	}
	
	public void setProrrDspNmPlano(NString value) {
		this.setValue("PRORR_DSP_NM_PLANO", value.getValue());
	}

	public NString getProrrDspDsTipoAcomodacao() {
		NString v = new NString((String)this.getValue("PRORR_DSP_DS_TIPO_ACOMODACAO"));
		return v;
	}
	
	public void setProrrDspDsTipoAcomodacao(NString value) {
		this.setValue("PRORR_DSP_DS_TIPO_ACOMODACAO", value.getValue());
	}

	public NString getProrrDspNmPrestador() {
		NString v = new NString((String)this.getValue("PRORR_DSP_NM_PRESTADOR"));
		return v;
	}
	
	public void setProrrDspNmPrestador(NString value) {
		this.setValue("PRORR_DSP_NM_PRESTADOR", value.getValue());
	}

	public NString getProrrDspTipoGuia() {
		NString v = new NString((String)this.getValue("PRORR_DSP_TIPO_GUIA"));
		return v;
	}
	
	public void setProrrDspTipoGuia(NString value) {
		this.setValue("PRORR_DSP_TIPO_GUIA", value.getValue());
	}

	public NNumber getDspVlGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_VL_GUIA"));
		return v;
	}
	
	public void setDspVlGuia(NNumber value) {
		this.setValue("DSP_VL_GUIA", value.getValue());
	}

	public NString getSnSalvar() {
		NString v = new NString((String)this.getValue("SN_SALVAR"));
		return v;
	}
	
	public void setSnSalvar(NString value) {
		this.setValue("SN_SALVAR", value.getValue());
	}

	public NNumber getDspTotDiasProrrogados() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_TOT_DIAS_PRORROGADOS"));
		return v;
	}
	
	public void setDspTotDiasProrrogados(NNumber value) {
		this.setValue("DSP_TOT_DIAS_PRORROGADOS", value.getValue());
	}

	public NString getValidarprestadorexe() {
		NString v = new NString((String)this.getValue("VALIDARPRESTADOREXE"));
		return v;
	}
	
	public void setValidarprestadorexe(NString value) {
		this.setValue("VALIDARPRESTADOREXE", value.getValue());
	}

	public NString getTpOrigem() {
		NString v = new NString((String)this.getValue("TP_ORIGEM"));
		return v;
	}
	
	public void setTpOrigem(NString value) {
		this.setValue("TP_ORIGEM", value.getValue());
	}

	public NNumber getCdMotCancelamentoGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_MOT_CANCELAMENTO_GUIA"));
		return v;
	}
	
	public void setCdMotCancelamentoGuia(NNumber value) {
		this.setValue("CD_MOT_CANCELAMENTO_GUIA", value.getValue());
	}

	public NString getDspDsMotCancelamentoGuia() {
		NString v = new NString((String)this.getValue("DSP_DS_MOT_CANCELAMENTO_GUIA"));
		return v;
	}
	
	public void setDspDsMotCancelamentoGuia(NString value) {
		this.setValue("DSP_DS_MOT_CANCELAMENTO_GUIA", value.getValue());
	}

	public NNumber getCdMensContrato() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_MENS_CONTRATO"));
		return v;
	}
	
	public void setCdMensContrato(NNumber value) {
		this.setValue("CD_MENS_CONTRATO", value.getValue());
	}

	public NNumber getTpStatus() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TP_STATUS"));
		return v;
	}
	
	public void setTpStatus(NNumber value) {
		this.setValue("TP_STATUS", value.getValue());
	}

	public NString getDspTpStatus() {
		NString v = new NString((String)this.getValue("DSP_TP_STATUS"));
		return v;
	}
	
	public void setDspTpStatus(NString value) {
		this.setValue("DSP_TP_STATUS", value.getValue());
	}

	public NNumber getCdTipoDoenca() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_TIPO_DOENCA"));
		return v;
	}
	
	public void setCdTipoDoenca(NNumber value) {
		this.setValue("CD_TIPO_DOENCA", value.getValue());
	}

	public NNumber getNrTempoDoenca() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_TEMPO_DOENCA"));
		return v;
	}
	
	public void setNrTempoDoenca(NNumber value) {
		this.setValue("NR_TEMPO_DOENCA", value.getValue());
	}

	public NNumber getCdUnidadeTempoDoenca() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_UNIDADE_TEMPO_DOENCA"));
		return v;
	}
	
	public void setCdUnidadeTempoDoenca(NNumber value) {
		this.setValue("CD_UNIDADE_TEMPO_DOENCA", value.getValue());
	}

	public NNumber getCdIndicadorAcidente() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_INDICADOR_ACIDENTE"));
		return v;
	}
	
	public void setCdIndicadorAcidente(NNumber value) {
		this.setValue("CD_INDICADOR_ACIDENTE", value.getValue());
	}

	public NNumber getCdTipoAtendimentoTiss() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_TIPO_ATENDIMENTO_TISS"));
		return v;
	}
	
	public void setCdTipoAtendimentoTiss(NNumber value) {
		this.setValue("CD_TIPO_ATENDIMENTO_TISS", value.getValue());
	}

	public NNumber getCdTipoSaidaGuiaSadt() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_TIPO_SAIDA_GUIA_SADT"));
		return v;
	}
	
	public void setCdTipoSaidaGuiaSadt(NNumber value) {
		this.setValue("CD_TIPO_SAIDA_GUIA_SADT", value.getValue());
	}

	public NString getDsDestinoCortesia() {
		NString v = new NString((String)this.getValue("DS_DESTINO_CORTESIA"));
		return v;
	}
	
	public void setDsDestinoCortesia(NString value) {
		this.setValue("DS_DESTINO_CORTESIA", value.getValue());
	}

	public NDate getDtNascimento() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_NASCIMENTO"));
		return v;
	}
	
	public void setDtNascimento(NDate value) {
		this.setValue("DT_NASCIMENTO", value.getValue());
	}

	public NString getTpSexo() {
		NString v = new NString((String)this.getValue("TP_SEXO"));
		return v;
	}
	
	public void setTpSexo(NString value) {
		this.setValue("TP_SEXO", value.getValue());
	}

	public NNumber getCdCortesia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_CORTESIA"));
		return v;
	}
	
	public void setCdCortesia(NNumber value) {
		this.setValue("CD_CORTESIA", value.getValue());
	}

	public NString getDspDsCortesia() {
		NString v = new NString((String)this.getValue("DSP_DS_CORTESIA"));
		return v;
	}
	
	public void setDspDsCortesia(NString value) {
		this.setValue("DSP_DS_CORTESIA", value.getValue());
	}

	public NNumber getCdPlanoPgtoCortesia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PLANO_PGTO_CORTESIA"));
		return v;
	}
	
	public void setCdPlanoPgtoCortesia(NNumber value) {
		this.setValue("CD_PLANO_PGTO_CORTESIA", value.getValue());
	}

	public NString getDspDsPlanoCortesia() {
		NString v = new NString((String)this.getValue("DSP_DS_PLANO_CORTESIA"));
		return v;
	}
	
	public void setDspDsPlanoCortesia(NString value) {
		this.setValue("DSP_DS_PLANO_CORTESIA", value.getValue());
	}

	public NNumber getCdMatriculaResponsavel() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_MATRICULA_RESPONSAVEL"));
		return v;
	}
	
	public void setCdMatriculaResponsavel(NNumber value) {
		this.setValue("CD_MATRICULA_RESPONSAVEL", value.getValue());
	}

	public NNumber getCdEmpresaResponsavel() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_EMPRESA_RESPONSAVEL"));
		return v;
	}
	
	public void setCdEmpresaResponsavel(NNumber value) {
		this.setValue("CD_EMPRESA_RESPONSAVEL", value.getValue());
	}

	public NString getNmMatriculaResponsavel() {
		NString v = new NString((String)this.getValue("NM_MATRICULA_RESPONSAVEL"));
		return v;
	}
	
	public void setNmMatriculaResponsavel(NString value) {
		this.setValue("NM_MATRICULA_RESPONSAVEL", value.getValue());
	}

	public NString getNmEmpresaResponsavel() {
		NString v = new NString((String)this.getValue("NM_EMPRESA_RESPONSAVEL"));
		return v;
	}
	
	public void setNmEmpresaResponsavel(NString value) {
		this.setValue("NM_EMPRESA_RESPONSAVEL", value.getValue());
	}
	
	public NNumber getNrAutorizacaoReciprocidade() {
		NNumber v = new NNumber((BigDecimal) this
				.getValue("NR_AUTORIZACAO_RECIPROCIDADE"));
		return v;
	}

	public void setNrAutorizacaoReciprocidade(NNumber value) {
		this.setValue("NR_AUTORIZACAO_RECIPROCIDADE", value.getValue());
	}

	

	

	

	

	public NNumber getTpStatusAnalise()
	{
		NNumber v = new NNumber((BigDecimal) this.getValue("TP_STATUS_ANALISE"));
		return v;
	}

	public void setTpStatusAnalise(NNumber value)
	{
		this.setValue("TP_STATUS_ANALISE", value.getValue());
	}

	public NString getDsAnexoTexto() {
		NString v = new NString((String) this.getValue("DS_ANEXO_TEXTO"));
		return v;
	}

	public void setDsAnexoTexto(NString value) {
		this.setValue("DS_ANEXO_TEXTO", value.getValue());
	}

	

	

	public NString getDsUrlEmailGuia() {
		NString v = new NString((String) this.getValue("DSP_URL_EMAIL_GUIA"));
		return v;
	}

	public void setDsUrlEmailGuia(NString value) {
		this.setValue("DSP_URL_EMAIL_GUIA", value.getValue());
	}

	

	

	

	

	public NNumber getCdPrestadorEndereco()
    {
        NNumber v = new NNumber(
                (BigDecimal) this.getValue("CD_PRESTADOR_ENDERECO"));
        return v;
    }

    public void setCdPrestadorEndereco(NNumber value)
    {
        this.setValue("CD_PRESTADOR_ENDERECO", value.getValue());
    }

    public NString getDsEndereco()
    {
        NString v = new NString((String) this.getValue("DS_ENDERECO"));
        return v;
    }

    public void setDsEndereco(NString value)
    {
        this.setValue("DS_ENDERECO", value.getValue());
    }

    public NDate getDtEmissaoGuiaSolicitacao()
    {
        NDate v = new NDate(
                (Date) this.getValue("DT_EMISSAO_GUIA_SOLICITACAO"));
        return v;
    }

    public void setDtEmissaoGuiaSolicitacao(NDate value)
    {
        this.setValue("DT_EMISSAO_GUIA_SOLICITACAO", value.getValue());
    }

    public NString getTpGrupoFranquia() {
		NString v = new NString((String) this.getValue("TP_GRUPO_FRANQUIA"));
		return v;
	}

	public void setTpGrupoFranquia(NString value) {
		this.setValue("TP_GRUPO_FRANQUIA", value.getValue());
	}

	public NDate getDtTerminoTratamento() {
		NDate v = new NDate((Date) this.getValue("DT_TERMINO_TRATAMENTO"));
		return v;
	}

	public void setDtTerminoTratamento(NDate value) {
		this.setValue("DT_TERMINO_TRATAMENTO", value.getValue());
	}

	

	

	

	

	public NNumber getCdTipoAtendimentoOdonto() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("CD_TIPO_ATENDIMENTO_ODONTO"));
		return v;
	}

	public void setCdTipoAtendimentoOdonto(NNumber value) {
		this.setValue("CD_TIPO_ATENDIMENTO_ODONTO", value.getValue());
	}

	public NNumber getCdTipoFaturamentoOdonto() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("CD_TIPO_FATURAMENTO_ODONTO"));
		return v;
	}

	public void setCdTipoFaturamentoOdonto(NNumber value) {
		this.setValue("CD_TIPO_FATURAMENTO_ODONTO", value.getValue());
	}

	

	

	

	

	public NString getDsAuditoria() {
		NString v = new NString((String) this.getValue("DS_AUDITORIA"));
		return v;
	}

	public void setDsAuditoria(NString value) {
		this.setValue("DS_AUDITORIA", value.getValue());
	}

	public NString getSnAtendimentoRecemNato() {
		NString v = new NString(
				(String) this.getValue("SN_ATENDIMENTO_RECEM_NATO"));
		return v;
	}

	public void setSnAtendimentoRecemNato(NString value) {
		this.setValue("SN_ATENDIMENTO_RECEM_NATO", value.getValue());
	}

	

	

	

	

	public NString getDspTpGuiaTem() {
		NString v = new NString((String) this.getValue("DSP_TP_GUIA_TEM"));
		return v;
	}

	public void setDspTpGuiaTem(NString value) {
		this.setValue("DSP_TP_GUIA_TEM", value.getValue());
	}

	public NDate getDtRegistroLocado()
    {
        NDate v = new NDate((Date) this.getValue("DT_REGISTRO_LOCADO"));
        return v;
    }

    public void setDtRegistroLocado(NDate value)
    {
        this.setValue("DT_REGISTRO_LOCADO", value.getValue());
    }

    public NString getNmProfissionalSolicitante() {
		NString v = new NString(
				(String) this.getValue("NM_PROFISSIONAL_SOLICITANTE"));
		return v;
	}

	public void setNmProfissionalSolicitante(NString value) {
		this.setValue("NM_PROFISSIONAL_SOLICITANTE", value.getValue());
	}

	public NString getNrTelefoneProfissional() {
		NString v = new NString(
				(String) this.getValue("NR_TELEFONE_PROFISSIONAL"));
		return v;
	}

	public void setNrTelefoneProfissional(NString value) {
		this.setValue("NR_TELEFONE_PROFISSIONAL", value.getValue());
	}

	public NString getDsEmailProfissional() {
		NString v = new NString(
				(String) this.getValue("DS_EMAIL_PROFISSIONAL"));
		return v;
	}

	public void setDsEmailProfissional(NString value) {
		this.setValue("DS_EMAIL_PROFISSIONAL", value.getValue());
	}

	public NDate getDtDiagnostico() {
		NDate v = new NDate((Date) this.getValue("DT_DIAGNOSTICO"));
		return v;
	}

	public void setDtDiagnostico(NDate value) {
		this.setValue("DT_DIAGNOSTICO", value.getValue());
	}

	public NNumber getCdEstadiamento() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("CD_ESTADIAMENTO"));
		return v;
	}

	public void setCdEstadiamento(NNumber value) {
		this.setValue("CD_ESTADIAMENTO", value.getValue());
	}

	public NNumber getCdEcog() {
		NNumber v = new NNumber((BigDecimal) this.getValue("CD_ECOG"));
		return v;
	}

	public void setCdEcog(NNumber value) {
		this.setValue("CD_ECOG", value.getValue());
	}

	public NNumber getCdFinalidade() {
		NNumber v = new NNumber((BigDecimal) this.getValue("CD_FINALIDADE"));
		return v;
	}

	public void setCdFinalidade(NNumber value) {
		this.setValue("CD_FINALIDADE", value.getValue());
	}

	public NString getDsDiagnosticoCitoHisto() {
		NString v = new NString(
				(String) this.getValue("DS_DIAGNOSTICO_CITO_HISTO"));
		return v;
	}

	public void setDsDiagnosticoCitoHisto(NString value) {
		this.setValue("DS_DIAGNOSTICO_CITO_HISTO", value.getValue());
	}

	public NString getDsInformacoesRelevantes() {
		NString v = new NString(
				(String) this.getValue("DS_INFORMACOES_RELEVANTES"));
		return v;
	}

	public void setDsInformacoesRelevantes(NString value) {
		this.setValue("DS_INFORMACOES_RELEVANTES", value.getValue());
	}

	public NNumber getNrPesoBeneficiario() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("NR_PESO_BENEFICIARIO"));
		return v;
	}

	public void setNrPesoBeneficiario(NNumber value) {
		this.setValue("NR_PESO_BENEFICIARIO", value.getValue());
	}

	public NNumber getNrAlturaBeneficiario() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("NR_ALTURA_BENEFICIARIO"));
		return v;
	}

	public void setNrAlturaBeneficiario(NNumber value) {
		this.setValue("NR_ALTURA_BENEFICIARIO", value.getValue());
	}

	public NNumber getNrSuperficieCorporal() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("NR_SUPERFICIE_CORPORAL"));
		return v;
	}

	public void setNrSuperficieCorporal(NNumber value) {
		this.setValue("NR_SUPERFICIE_CORPORAL", value.getValue());
	}

	public NNumber getCdQuimioterapia() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("CD_QUIMIOTERAPIA"));
		return v;
	}

	public void setCdQuimioterapia(NNumber value) {
		this.setValue("CD_QUIMIOTERAPIA", value.getValue());
	}

	public NNumber getNrCicloPrevisto() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("NR_CICLO_PREVISTO"));
		return v;
	}

	public void setNrCicloPrevisto(NNumber value) {
		this.setValue("NR_CICLO_PREVISTO", value.getValue());
	}

	public NNumber getNrCicloAtual() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("NR_CICLO_ATUAL"));
		return v;
	}

	public void setNrCicloAtual(NNumber value) {
		this.setValue("NR_CICLO_ATUAL", value.getValue());
	}

	public NNumber getNrIntervaloCiclo() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("NR_INTERVALO_CICLO"));
		return v;
	}

	public void setNrIntervaloCiclo(NNumber value) {
		this.setValue("NR_INTERVALO_CICLO", value.getValue());
	}

	public NString getDsEstadiamento() {
		NString v = new NString((String) this.getValue("DS_ESTADIAMENTO"));
		return v;
	}

	public void setDsEstadiamento(NString value) {
		this.setValue("DS_ESTADIAMENTO", value.getValue());
	}

	public NString getDspQuimioterapia() {
		NString v = new NString((String) this.getValue("DSP_QUIMIOTERAPIA"));
		return v;
	}

	public void setDspQuimioterapia(NString value) {
		this.setValue("DSP_QUIMIOTERAPIA", value.getValue());
	}

	public NString getDsFinalidade() {
		NString v = new NString((String) this.getValue("DS_FINALIDADE"));
		return v;
	}

	public void setDsFinalidade(NString value) {
		this.setValue("DS_FINALIDADE", value.getValue());
	}

	public NString getDsEcog() {
		NString v = new NString((String) this.getValue("DS_ECOG"));
		return v;
	}

	public void setDsEcog(NString value) {
		this.setValue("DS_ECOG", value.getValue());
	}

	public NNumber getCdDiagnosticoImagem() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("CD_DIAGNOSTICO_IMAGEM"));
		return v;
	}

	public void setCdDiagnosticoImagem(NNumber value) {
		this.setValue("CD_DIAGNOSTICO_IMAGEM", value.getValue());
	}

	public NString getDsCirurgia() {
		NString v = new NString((String) this.getValue("DS_CIRURGIA"));
		return v;
	}

	public void setDsCirurgia(NString value) {
		this.setValue("DS_CIRURGIA", value.getValue());
	}

	public NDate getDtRealizacao() {
		NDate v = new NDate((Date) this.getValue("DT_REALIZACAO"));
		return v;
	}

	public void setDtRealizacao(NDate value) {
		this.setValue("DT_REALIZACAO", value.getValue());
	}

	public NString getDsAreaIrradiada() {
		NString v = new NString((String) this.getValue("DS_AREA_IRRADIADA"));
		return v;
	}

	public void setDsAreaIrradiada(NString value) {
		this.setValue("DS_AREA_IRRADIADA", value.getValue());
	}

	public NDate getDtAplicacao() {
		NDate v = new NDate((Date) this.getValue("DT_APLICACAO"));
		return v;
	}

	public void setDtAplicacao(NDate value) {
		this.setValue("DT_APLICACAO", value.getValue());
	}

	public NNumber getNrCamposIrradiacao() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("NR_CAMPOS_IRRADIACAO"));
		return v;
	}

	public void setNrCamposIrradiacao(NNumber value) {
		this.setValue("NR_CAMPOS_IRRADIACAO", value.getValue());
	}

	public NNumber getNrDoseRadioterapicoDia() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("NR_DOSE_RADIOTERAPICO_DIA"));
		return v;
	}

	public void setNrDoseRadioterapicoDia(NNumber value) {
		this.setValue("NR_DOSE_RADIOTERAPICO_DIA", value.getValue());
	}

	public NNumber getNrDoseRadioterapicoTotal() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("NR_DOSE_RADIOTERAPICO_TOTAL"));
		return v;
	}

	public void setNrDoseRadioterapicoTotal(NNumber value) {
		this.setValue("NR_DOSE_RADIOTERAPICO_TOTAL", value.getValue());
	}

	

	

	public NDate getDtInicioAdministracao() {
		NDate v = new NDate((Date) this.getValue("DT_INICIO_ADMINISTRACAO"));
		return v;
	}

	public void setDtInicioAdministracao(NDate value) {
		this.setValue("DT_INICIO_ADMINISTRACAO", value.getValue());
	}

	public NString getDsDiagnosticoImagem() {
		NString v = new NString(
				(String) this.getValue("DS_DIAGNOSTICO_IMAGEM"));
		return v;
	}

	public void setDsDiagnosticoImagem(NString value) {
		this.setValue("DS_DIAGNOSTICO_IMAGEM", value.getValue());
	}

	public NString getDsEspecificacaoMaterial() {
		NString v = new NString(
				(String) this.getValue("DS_ESPECIFICACAO_MATERIAL"));
		return v;
	}

	public void setDsEspecificacaoMaterial(NString value) {
		this.setValue("DS_ESPECIFICACAO_MATERIAL", value.getValue());
	}

	public NString getDsJustificativaTecnica() {
		NString v = new NString(
				(String) this.getValue("DS_JUSTIFICATIVA_TECNICA"));
		return v;
	}

	public void setDsJustificativaTecnica(NString value) {
		this.setValue("DS_JUSTIFICATIVA_TECNICA", value.getValue());
	}

	

	

	

	

	

	

	public NString getDsQuimioterapia() {
		NString v = new NString((String) this.getValue("DS_QUIMIOTERAPIA"));
		return v;
	}

	public void setDsQuimioterapia(NString value) {
		this.setValue("DS_QUIMIOTERAPIA", value.getValue());
	}

	public NString getCdVersaoTiss() {
		NString v = new NString((String) this.getValue("CD_VERSAO_TISS"));
		return v;
	}

	public void setCdVersaoTiss(NString value) {
		this.setValue("CD_VERSAO_TISS", value.getValue());
	}

	public NDate getDtSugeridaInternacao() {
		NDate v = new NDate((Date) this.getValue("DT_SUGERIDA_INTERNACAO"));
		return v;
	}

	public void setDtSugeridaInternacao(NDate value) {
		this.setValue("DT_SUGERIDA_INTERNACAO", value.getValue());
	}

	public NString getSnPrevisaoUsoOpme() {
		NString v = new NString(
				(String) this.getValue("SN_PREVISAO_USO_OPME"));
		return v;
	}

	public void setSnPrevisaoUsoOpme(NString value) {
		this.setValue("SN_PREVISAO_USO_OPME", value.getValue());
	}

	public NString getSnPrevisaoUsoQuimio() {
		NString v = new NString(
				(String) this.getValue("SN_PREVISAO_USO_QUIMIO"));
		return v;
	}

	public void setSnPrevisaoUsoQuimio(NString value) {
		this.setValue("SN_PREVISAO_USO_QUIMIO", value.getValue());
	}

	public NString getDspTpOrigem() {
		NString v = new NString((String) this.getValue("DSP_TP_ORIGEM"));
		return v;
	}

	public void setDspTpOrigem(NString value) {
		this.setValue("DSP_TP_ORIGEM", value.getValue());
	}

	public NString getDspSnModificaFranquia() {

	    NString v = new NString((String) this.getValue("DSP_SN_MODIFICA_FRANQUIA"));
	    return v;
    }

	public void setDspSnModificaFranquia(NString value) {

	    this.setValue("DSP_SN_MODIFICA_FRANQUIA", value.getValue());
    }

	public NString getCdUsuarioEmissao() {

		NString v = new NString((String) this.getValue("CD_USUARIO_EMISSAO"));
		return v;
	}

	public void setCdUsuarioEmissao(NString value) {

		this.setValue("CD_USUARIO_EMISSAO", value.getValue());
	}

	public NDate getDtUltimaAutorizacao() {

		NDate v = new NDate((Date) this.getValue("DT_ULTIMA_AUTORIZACAO"));
		return v;
	}

	public void setDtUltimaAutorizacao(NDate value) {

		this.setValue("DT_ULTIMA_AUTORIZACAO", value.getValue());
	}

	public NNumber getCdAtiMed() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_ATI_MED"));
		return v;
	}

	public void setCdAtiMed(NNumber value) {

		this.setValue("CD_ATI_MED", value.getValue());
	}

	public NString getDspDsAtiMed() {

		NString v = new NString((String) this.getValue("DSP_DS_ATI_MED"));
		return v;
	}

	public void setDspDsAtiMed(NString value) {

		this.setValue("DSP_DS_ATI_MED", value.getValue());
	}

	

	

	

	

	public NString getNrProtocolo() {

	    NString v = new NString((String) this.getValue("NR_PROTOCOLO"));
	    return v;
    }

	public void setNrProtocolo(NString value) {

	    this.setValue("NR_PROTOCOLO", value.getValue());
    }

	public NString getDsIdade() {

		NString v = new NString((String) this.getValue("DS_IDADE"));
		return v;
	}

	public void setDsIdade(NString value) {

		this.setValue("DS_IDADE", value.getValue());
	}

	public NNumber getCdMotivoAutorizacao() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_MOTIVO_AUTORIZACAO"));
		return v;
	}

	public void setCdMotivoAutorizacao(NNumber value) {

		this.setValue("CD_MOTIVO_AUTORIZACAO", value.getValue());
	}

	public NString getDspDsMotivoAutorizacao() {

		NString v = new NString((String) this.getValue("DSP_DS_MOTIVO_AUTORIZACAO"));
		return v;
	}

	public void setDspDsMotivoAutorizacao(NString value) {

		this.setValue("DSP_DS_MOTIVO_AUTORIZACAO", value.getValue());
	}

	public NDate getHrPrevisao() {

		NDate v = new NDate((Date) this.getValue("HR_PREVISAO"));
		return v;
	}

	public void setHrPrevisao(NDate value) {

		this.setValue("HR_PREVISAO", value.getValue());
	}

	public NString getCdMatAlternativa() {

		NString v = new NString((String) this.getValue("CD_MAT_ALTERNATIVA"));
		return v;
	}

	public void setCdMatAlternativa(NString value) {

		this.setValue("CD_MAT_ALTERNATIVA", value.getValue());
	}

	public NString getDsObservacaoCancelamento() {

		NString v = new NString((String) this.getValue("DS_OBSERVACAO_CANCELAMENTO"));
		return v;
	}

	public void setDsObservacaoCancelamento(NString value) {

		this.setValue("DS_OBSERVACAO_CANCELAMENTO", value.getValue());
	}

	public NNumber getCdBeneficiarioTransito() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_BENEFICIARIO_TRANSITO"));
		return v;
	}

	public void setCdBeneficiarioTransito(NNumber value) {

		this.setValue("CD_BENEFICIARIO_TRANSITO", value.getValue());
	}

	public NString getNrCarteiraBeneficiario() {

		NString v = new NString((String) this.getValue("NR_CARTEIRA_BENEFICIARIO"));
		return v;
	}

	public void setNrCarteiraBeneficiario(NString value) {

		this.setValue("NR_CARTEIRA_BENEFICIARIO", value.getValue());
	}

	

	

	public NNumber getCdRedeReferenciada() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_REDE_REFERENCIADA"));
		return v;
	}

	public void setCdRedeReferenciada(NNumber value) {

		this.setValue("CD_REDE_REFERENCIADA", value.getValue());
	}

	public NString getDspDsRedeReferenciada() {

		NString v = new NString((String) this.getValue("DSP_DS_REDE_REFERENCIADA"));
		return v;
	}

	public void setDspDsRedeReferenciada(NString value) {

		this.setValue("DSP_DS_REDE_REFERENCIADA", value.getValue());
	}

	public NNumber getCdTipoInternacao() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_TIPO_INTERNACAO"));
		return v;
	}

	public void setCdTipoInternacao(NNumber value) {

		this.setValue("CD_TIPO_INTERNACAO", value.getValue());
	}

	public NString getDspDsTipoInternacao() {

		NString v = new NString((String) this.getValue("DSP_DS_TIPO_INTERNACAO"));
		return v;
	}

	public void setDspDsTipoInternacao(NString value) {

		this.setValue("DSP_DS_TIPO_INTERNACAO", value.getValue());
	}

	public NNumber getCdLiminar() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_LIMINAR"));
		return v;
	}

	public void setCdLiminar(NNumber value) {

		this.setValue("CD_LIMINAR", value.getValue());
	}

	public NString getCdUnimedExecutora() {
		NString v = new NString((String) this.getValue("CD_UNIMED_EXECUTORA"));
		return v;
	}

	public void setCdUnimedExecutora(NString value) {

		this.setValue("CD_UNIMED_EXECUTORA", value.getValue());
	}

	public NString getDspDsUnimedExecutora() {

		NString v = new NString((String) this.getValue("DSP_DS_UNIMED_EXECUTORA"));
		return v;
	}

	public void setDspDsUnimedExecutora(NString value) {

		this.setValue("DSP_DS_UNIMED_EXECUTORA", value.getValue());
	}

	public NNumber getCdClassificacaoMetastase() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_CLASSIFICACAO_METASTASE"));
		return v;
	}

	public void setCdClassificacaoMetastase(NNumber value) {

		this.setValue("CD_CLASSIFICACAO_METASTASE", value.getValue());
	}

	public NNumber getCdClassificacaoNodulo() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_CLASSIFICACAO_NODULO"));
		return v;
	}

	public void setCdClassificacaoNodulo(NNumber value) {

		this.setValue("CD_CLASSIFICACAO_NODULO", value.getValue());
	}

	public NNumber getCdClassificacaoTumor() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_CLASSIFICACAO_TUMOR"));
		return v;
	}

	public void setCdClassificacaoTumor(NNumber value) {

		this.setValue("CD_CLASSIFICACAO_TUMOR", value.getValue());
	}

	public NString getDspDsClassificacaoMetastase() {

		NString v = new NString((String) this.getValue("DSP_DS_CLASSIFICACAO_METASTASE"));
		return v;
	}

	public void setDspDsClassificacaoMetastase(NString value) {

		this.setValue("DSP_DS_CLASSIFICACAO_METASTASE", value.getValue());
	}

	public NString getDspDsClassificacaoNodulo() {

		NString v = new NString((String) this.getValue("DSP_DS_CLASSIFICACAO_NODULO"));
		return v;
	}

	public void setDspDsClassificacaoNodulo(NString value) {

		this.setValue("DSP_DS_CLASSIFICACAO_NODULO", value.getValue());
	}

	public NString getDspDsClassificacaoTumor() {

		NString v = new NString((String) this.getValue("DSP_DS_CLASSIFICACAO_TUMOR"));
		return v;
	}

	public void setDspDsClassificacaoTumor(NString value) {

		this.setValue("DSP_DS_CLASSIFICACAO_TUMOR", value.getValue());
	}

	public NString getCdUnimedOrigem() {

		NString v = new NString((String) this.getValue("CD_UNIMED_ORIGEM"));
		return v;
	}

	public void setCdUnimedOrigem(NString value) {

		this.setValue("CD_UNIMED_ORIGEM", value.getValue());
	}

	public NString getDspDsUnimedOrigem() {

		NString v = new NString((String) this.getValue("DSP_DS_UNIMED_ORIGEM"));
		return v;
	}

	public void setDspDsUnimedOrigem(NString value) {

		this.setValue("DSP_DS_UNIMED_ORIGEM", value.getValue());
	}

	public NString getDspTpAtendimentoUnimed() {

		NString v = new NString((String) this.getValue("DSP_TP_ATENDIMENTO_UNIMED"));
		return v;
	}

	public void setDspTpAtendimentoUnimed(NString value) {

		this.setValue("DSP_TP_ATENDIMENTO_UNIMED", value.getValue());
	}

	

	

	public NString getCdUnimedSolicitante() {

		NString v = new NString((String) this.getValue("CD_UNIMED_SOLICITANTE"));
		return v;
	}

	public void setCdUnimedSolicitante(NString value) {

		this.setValue("CD_UNIMED_SOLICITANTE", value.getValue());
	}

	public NString getDspDsUnimedSolicitante() {

		NString v = new NString((String) this.getValue("DSP_DS_UNIMED_SOLICITANTE"));
		return v;
	}

	public void setDspDsUnimedSolicitante(NString value) {

		this.setValue("DSP_DS_UNIMED_SOLICITANTE", value.getValue());
	}

	public NNumber getNrIdadeBeneficiario() {

		NNumber v = new NNumber((BigDecimal) this.getValue("NR_IDADE_BENEFICIARIO"));
		return v;
	}

	public void setNrIdadeBeneficiario(NNumber value) {

		this.setValue("NR_IDADE_BENEFICIARIO", value.getValue());
	}

	public NString getCdVersaoPtu() {

		NString v = new NString((String) this.getValue("CD_VERSAO_PTU"));
		return v;
	}

	public void setCdVersaoPtu(NString value) {

		this.setValue("CD_VERSAO_PTU", value.getValue());
	}

	public NNumber getNrViaCartao() {

		NNumber v = new NNumber((BigDecimal) this.getValue("NR_VIA_CARTAO"));
		return v;
	}

	public void setNrViaCartao(NNumber value) {

		this.setValue("NR_VIA_CARTAO", value.getValue());
	}

	public NString getCdUniSolicitEventual() {

		NString v = new NString((String) this.getValue("CD_UNI_SOLICIT_EVENTUAL"));
		return v;
	}

	public void setCdUniSolicitEventual(NString value) {

		this.setValue("CD_UNI_SOLICIT_EVENTUAL", value.getValue());
	}

	public NNumber getCdPrestSolicitEventual() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_PREST_SOLICIT_EVENTUAL"));
		return v;
	}

	public void setCdPrestSolicitEventual(NNumber value) {

		this.setValue("CD_PREST_SOLICIT_EVENTUAL", value.getValue());
	}

	public NString getCdUniExecEventual() {

		NString v = new NString((String) this.getValue("CD_UNI_EXEC_EVENTUAL"));
		return v;
	}

	public void setCdUniExecEventual(NString value) {

		this.setValue("CD_UNI_EXEC_EVENTUAL", value.getValue());
	}

	public NNumber getCdPrestExecEventual() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_PREST_EXEC_EVENTUAL"));
		return v;
	}

	public void setCdPrestExecEventual(NNumber value) {

		this.setValue("CD_PREST_EXEC_EVENTUAL", value.getValue());
	}

	public NString getNmPrestExecEventual() {

		NString v = new NString((String) this.getValue("NM_PREST_EXEC_EVENTUAL"));
		return v;
	}

	public void setNmPrestExecEventual(NString value) {

		this.setValue("NM_PREST_EXEC_EVENTUAL", value.getValue());
	}

	

	

	public NNumber getCdPtuMensOrdemServicoOri() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_PTU_MENS_ORDEM_SERVICO_ORI"));
		return v;
	}

	public void setCdPtuMensOrdemServicoOri(NNumber value) {

		this.setValue("CD_PTU_MENS_ORDEM_SERVICO_ORI", value.getValue());
	}

	public NNumber getCdPtuMensagemOrigem() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_PTU_MENSAGEM_ORIGEM"));
		return v;
	}

	public void setCdPtuMensagemOrigem(NNumber value) {

		this.setValue("CD_PTU_MENSAGEM_ORIGEM", value.getValue());
	}

	public NNumber getQtdDiasCiclo() {

		NNumber v = new NNumber((BigDecimal) this.getValue("QTD_DIAS_CICLO"));
		return v;
	}

	public void setQtdDiasCiclo(NNumber value) {

		this.setValue("QTD_DIAS_CICLO", value.getValue());
	}

	public NNumber getCdPtuMensagemDestino() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_PTU_MENSAGEM_DESTINO"));
		return v;
	}

	public void setCdPtuMensagemDestino(NNumber value) {

		this.setValue("CD_PTU_MENSAGEM_DESTINO", value.getValue());
	}

	public NString getNrCelularSms() {

		NString v = new NString((String) this.getValue("NR_CELULAR_SMS"));
		return v;
	}

	public void setNrCelularSms(NString value) {

		this.setValue("NR_CELULAR_SMS", value.getValue());
	}

	public NString getNrDddSms() {

		NString v = new NString((String) this.getValue("NR_DDD_SMS"));
		return v;
	}

	public void setNrDddSms(NString value) {

		this.setValue("NR_DDD_SMS", value.getValue());
	}

	public NString getTpFluxoPtuWs() {

		NString v = new NString((String) this.getValue("TP_FLUXO_PTU_WS"));
		return v;
	}

	public void setTpFluxoPtuWs(NString value) {

		this.setValue("TP_FLUXO_PTU_WS", value.getValue());
	}

	public NDate getDtPrevisaoAlta() {

		NDate v = new NDate((Date) this.getValue("DT_PREVISAO_ALTA"));
		return v;
	}

	public void setDtPrevisaoAlta(NDate value) {

		this.setValue("DT_PREVISAO_ALTA", value.getValue());
	}

	public NString getSnOrdemServico() {

		NString v = new NString((String) this.getValue("SN_ORDEM_SERVICO"));
		return v;
	}

	public void setSnOrdemServico(NString value) {

		this.setValue("SN_ORDEM_SERVICO", value.getValue());
	}

	public NString getNrTransacao() {

		NString v = new NString((String) this.getValue("NR_TRANSACAO"));
		return v;
	}

	public void setNrTransacao(NString value) {

		this.setValue("NR_TRANSACAO", value.getValue());
	}

	public NNumber getCdPtuMensOrdemServicoDes() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_PTU_MENS_ORDEM_SERVICO_DES"));
		return v;
	}

	public void setCdPtuMensOrdemServicoDes(NNumber value) {

		this.setValue("CD_PTU_MENS_ORDEM_SERVICO_DES", value.getValue());
	}

	public NNumber getNrTratamentoDia() {

		NNumber v = new NNumber((BigDecimal) this.getValue("NR_TRATAMENTO_DIA"));
		return v;
	}

	public void setNrTratamentoDia(NNumber value) {

		this.setValue("NR_TRATAMENTO_DIA", value.getValue());
	}

	public NNumber getCdPtuMensagemDecursoPrazo() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_PTU_MENSAGEM_DECURSO_PRAZO"));
		return v;
	}

	public void setCdPtuMensagemDecursoPrazo(NNumber value) {

		this.setValue("CD_PTU_MENSAGEM_DECURSO_PRAZO", value.getValue());
	}

	public NString getDspTpSituacaoAtual() {
		NString v = new NString((String) this.getValue("DSP_TP_SITUACAO_ATUAL"));
		return v;
	}

	public void setDspTpSituacaoAtual(NString value) {

		this.setValue("DSP_TP_SITUACAO_ATUAL", value.getValue());
	}

	public NString getSnLiminar() {

		NString v = new NString((String) this.getValue("SN_LIMINAR"));
		return v;
	}

	public void setSnLiminar(NString value) {

		this.setValue("SN_LIMINAR", value.getValue());
	}

	public NDate getDtImpressaoGuia() {

		NDate v = new NDate((Date) this.getValue("DT_IMPRESSAO_GUIA"));
		return v;
	}

	public void setDtImpressaoGuia(NDate value) {

		this.setValue("DT_IMPRESSAO_GUIA", value.getValue());
	}

	public NString getDspDsImpressaoGuia() {

		NString v = new NString((String) this.getValue("DSP_DS_IMPRESSAO_GUIA"));
		return v;
	}

	public void setDspDsImpressaoGuia(NString value) {

		this.setValue("DSP_DS_IMPRESSAO_GUIA", value.getValue());
	}

	public NString getDspDsGuiaTem() {

		NString v = new NString((String) this.getValue("DSP_DS_GUIA_TEM"));
		return v;
	}

	public void setDspDsGuiaTem(NString value) {

		this.setValue("DSP_DS_GUIA_TEM", value.getValue());
	}

	public NString getNrTelefoneFixo() {

		NString v = new NString((String) this.getValue("NR_TELEFONE_FIXO"));
		return v;
	}

	public void setNrTelefoneFixo(NString value) {

		this.setValue("NR_TELEFONE_FIXO", value.getValue());
	}

	public NString getDsTotem() {

		NString v = new NString((String) this.getValue("DS_TOTEM"));
		return v;
	}

	public void setDsTotem(NString value) {

		this.setValue("DS_TOTEM", value.getValue());
	}

	public NString getDsEmailBeneficiario() {

		NString v = new NString((String) this.getValue("DS_EMAIL_BENEFICIARIO"));
		return v;
	}

	public void setDsEmailBeneficiario(NString value) {

		this.setValue("DS_EMAIL_BENEFICIARIO", value.getValue());
	}

	

	

	

	

	public NDate getDtUltimaAnalise() {

		NDate v = new NDate((Date) this.getValue("DT_ULTIMA_ANALISE"));
		return v;
	}

	public void setDtUltimaAnalise(NDate value) {

		this.setValue("DT_ULTIMA_ANALISE", value.getValue());
	}

	public NDate getDtAltaInternacao() {

		NDate v = new NDate((Date) this.getValue("DT_ALTA_INTERNACAO"));
		return v;
	}

	public void setDtAltaInternacao(NDate value) {

		this.setValue("DT_ALTA_INTERNACAO", value.getValue());
	}

	public NDate getDtExecucaoInternacao() {

		NDate v = new NDate((Date) this.getValue("DT_EXECUCAO_INTERNACAO"));
		return v;
	}

	public void setDtExecucaoInternacao(NDate value) {

		this.setValue("DT_EXECUCAO_INTERNACAO", value.getValue());
	}

	public NDate getDspDtInclusaoBeneficiario() {

		NDate v = new NDate((Date) this.getValue("DSP_DT_INCLUSAO_BENEFICIARIO"));
		return v;
	}

	public void setDspDtInclusaoBeneficiario(NDate value) {

		this.setValue("DSP_DT_INCLUSAO_BENEFICIARIO", value.getValue());
	}

	public NString getDspDsPeriodoImplantacao() {

		NString v = new NString((String) this.getValue("DSP_DS_PERIODO_IMPLANTACAO"));
		return v;
	}

	public void setDspDsPeriodoImplantacao(NString value) {

		this.setValue("DSP_DS_PERIODO_IMPLANTACAO", value.getValue());
	}

	public NString getDspDsEmpresa() {

		NString v = new NString((String) this.getValue("DSP_DS_EMPRESA"));
		return v;
	}

	public void setDspDsEmpresa(NString value) {

		this.setValue("DSP_DS_EMPRESA", value.getValue());
	}

	public NString getDsTipAcomodacao() {

		NString v = new NString((String) this.getValue("DS_TIP_ACOMODACAO"));
		return v;
	}

	public void setDsTipAcomodacao(NString value) {

		this.setValue("DS_TIP_ACOMODACAO", value.getValue());
	}

	

	

	

	

	public NString getDspDsPrestadorExterno() {

		NString v = new NString((String) this.getValue("DSP_DS_PRESTADOR_EXTERNO"));
		return v;
	}

	public void setDspDsPrestadorExterno(NString value) {

		this.setValue("DSP_DS_PRESTADOR_EXTERNO", value.getValue());
	}

	public NString getDspDsProgramaAtendimento() {

		NString v = new NString((String) this.getValue("DSP_DS_PROGRAMA_ATENDIMENTO"));
		return v;
	}

	public void setDspDsProgramaAtendimento(NString value) {

		this.setValue("DSP_DS_PROGRAMA_ATENDIMENTO", value.getValue());
	}

	public NNumber getCdPrestadorExterno() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_PRESTADOR_EXTERNO"));
		return v;
	}

	public void setCdPrestadorExterno(NNumber value) {

		this.setValue("CD_PRESTADOR_EXTERNO", value.getValue());
	}

	public NNumber getCdProgramaAtendimento() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_PROGRAMA_ATENDIMENTO"));
		return v;
	}

	public void setCdProgramaAtendimento(NNumber value) {

		this.setValue("CD_PROGRAMA_ATENDIMENTO", value.getValue());
	}

	public NString getDspDsTipoAtendimentoOdonto() {

		NString v = new NString((String) this.getValue("DSP_DS_TIPO_ATENDIMENTO_ODONTO"));
		return v;
	}

	public void setDspDsTipoAtendimentoOdonto(NString value) {

		this.setValue("DSP_DS_TIPO_ATENDIMENTO_ODONTO", value.getValue());
	}

	public NString getDspDsTipoFaturamentoOdonto() {

		NString v = new NString((String) this.getValue("DSP_DS_TIPO_FATURAMENTO_ODONTO"));
		return v;
	}

	public void setDspDsTipoFaturamentoOdonto(NString value) {

		this.setValue("DSP_DS_TIPO_FATURAMENTO_ODONTO", value.getValue());
	}

	public NString getSnPericiaInicial() {

		NString v = new NString((String) this.getValue("SN_PERICIA_INICIAL"));
		return v;
	}

	public void setSnPericiaInicial(NString value) {

		this.setValue("SN_PERICIA_INICIAL", value.getValue());
	}

	public NNumber getCdOcorrenciaPericiaInicial() {
		NNumber v = new NNumber((BigDecimal) this.getValue("CD_OCORRENCIA_PERICIA_INICIAL"));
		return v;
	}

	public void setCdOcorrenciaPericiaInicial(NNumber value) {

		this.setValue("CD_OCORRENCIA_PERICIA_INICIAL", value.getValue());
	}

	public NString getSnPericiaFinal() {

		NString v = new NString((String) this.getValue("SN_PERICIA_FINAL"));
		return v;
	}

	public void setSnPericiaFinal(NString value) {

		this.setValue("SN_PERICIA_FINAL", value.getValue());
	}

	public NNumber getCdOcorrenciaPericiaFinal() {
		NNumber v = new NNumber((BigDecimal) this.getValue("CD_OCORRENCIA_PERICIA_FINAL"));
		return v;
	}

	public void setCdOcorrenciaPericiaFinal(NNumber value) {

		this.setValue("CD_OCORRENCIA_PERICIA_FINAL", value.getValue());
	}

	

	

	

	

	public NString getDsOcorrenciaPericiaInicial() {

		NString v = new NString((String) this.getValue("DS_OCORRENCIA_PERICIA_INICIAL"));
		return v;
	}

	public void setDsOcorrenciaPericiaInicial(NString value) {

		this.setValue("DS_OCORRENCIA_PERICIA_INICIAL", value.getValue());
	}

	public NString getDsOcorrenciaPericiaFinal() {

		NString v = new NString((String) this.getValue("DS_OCORRENCIA_PERICIA_FINAL"));
		return v;
	}

	public void setDsOcorrenciaPericiaFinal(NString value) {

		this.setValue("DS_OCORRENCIA_PERICIA_FINAL", value.getValue());
	}

	public NDate getDtLiberacaoGto() {

		NDate v = new NDate((Date) this.getValue("DT_LIBERACAO_GTO"));
		return v;
	}

	public void setDtLiberacaoGto(NDate value) {

		this.setValue("DT_LIBERACAO_GTO", value.getValue());
	}

	public NDate getDspDtDesligamentoProgramada() {
		NDate v = new NDate((Date) this.getValue("DSP_DT_DESLIGAMENTO_PROGRAMADA"));
		return v;
	}

	public void setDspDtDesligamentoProgramada(NDate value) {
		this.setValue("DSP_DT_DESLIGAMENTO_PROGRAMADA", value.getValue());
	}

	public NString getTpRedeMin() {

		NString v = new NString((String) this.getValue("TP_REDE_MIN"));
		return v;
	}

	public void setTpRedeMin(NString value) {

		this.setValue("TP_REDE_MIN", value.getValue());
	}

	public NString getDspCdPrestadorInterno() {
		NString v = new NString((String) this.getValue("DSP_CD_PRESTADOR_INTERNO"));
		return v;
	}

	public void setDspCdPrestadorInterno(NString value) {
		this.setValue("DSP_CD_PRESTADOR_INTERNO", value.getValue());
	}

	public NString getDspCdPrestadorExecutorInterno() {
		NString v = new NString((String) this.getValue("DSP_CD_PRESTADOR_EXECUTOR_INTERNO"));
		return v;
	}

	public void setDspCdPrestadorExecutorInterno(NString value) {
		this.setValue("DSP_CD_PRESTADOR_EXECUTOR_INTERNO", value.getValue());
	}

	public NString getDspCdPrestadorExecutorPfInterno() {
		NString v = new NString((String) this.getValue("DSP_CD_PRESTADOR_EXECUTOR_PF_INTERNO"));
		return v;
	}

	public void setDspCdPrestadorExecutorPfInterno(NString value) {
		this.setValue("DSP_CD_PRESTADOR_EXECUTOR_PF_INTERNO", value.getValue());
	}

	public NString getCdTissConselhoProfSol() {
		NString v = new NString((String) this.getValue("CD_TISS_CONSELHO_PROF_SOL"));
		return v;
	}

	public void setCdTissConselhoProfSol(NString value) {
		this.setValue("CD_TISS_CONSELHO_PROF_SOL", value.getValue());
	}

	public NString getDspDsSiglaConselhoProfissionalTiss() {
		NString v = new NString((String) this.getValue("DSP_DS_SIGLA_CONSELHO_PROFISSIONAL_TISS"));
		return v;
	}

	public void setDspDsSiglaConselhoProfissionalTiss(NString value) {
		this.setValue("DSP_DS_SIGLA_CONSELHO_PROFISSIONAL_TISS", value.getValue());
	}

	public NString getUfConselhoProfSolc() {
		NString v = new NString((String) this.getValue("UF_CONSELHO_PROF_SOLC"));
		return v;
	}

	public void setUfConselhoProfSolc(NString value) {
		this.setValue("UF_CONSELHO_PROF_SOLC", value.getValue());
	}

	public NString getNrRegConselhoProfSolic() {
		NString v = new NString((String) this.getValue("NR_REG_CONSELHO_PROF_SOLIC"));
		return v;
	}

	public void setNrRegConselhoProfSolic(NString value) {
		this.setValue("NR_REG_CONSELHO_PROF_SOLIC", value.getValue());
	}

	public NString getDspNmUf() {
		NString v = new NString((String) this.getValue("DSP_NM_UF"));
		return v;
	}

	public void setDspNmUf(NString value) {
		this.setValue("DSP_NM_UF", value.getValue());
	}

	public NString getCdIdentificacaoBeneficiario() {

		NString v = new NString((String) this.getValue("CD_IDENTIFICACAO_BENEFICIARIO"));
		return v;
	}

	public void setCdIdentificacaoBeneficiario(NString value) {

		this.setValue("CD_IDENTIFICACAO_BENEFICIARIO", value.getValue());
	}

	public NNumber getCdEtapaAutorizacao() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_ETAPA_AUTORIZACAO"));
		return v;
	}

	public void setCdEtapaAutorizacao(NNumber value) {

		this.setValue("CD_ETAPA_AUTORIZACAO", value.getValue());
	}

	public NString getCdMotAusenciaCodValidacao() {

		NString v = new NString((String) this.getValue("CD_MOT_AUSENCIA_COD_VALIDACAO"));
		return v;
	}

	public void setCdMotAusenciaCodValidacao(NString value) {

		this.setValue("CD_MOT_AUSENCIA_COD_VALIDACAO", value.getValue());
	}

	public NString getCdValidacao() {

		NString v = new NString((String) this.getValue("CD_VALIDACAO"));
		return v;
	}

	public void setCdValidacao(NString value) {

		this.setValue("CD_VALIDACAO", value.getValue());
	}

	public NString getDspDsIdentificacaoBeneficiario() {

		NString v = new NString((String) this.getValue("DSP_DS_IDENTIFICACAO_BENEFICIARIO"));
		return v;
	}

	public void setDspDsIdentificacaoBeneficiario(NString value) {

		this.setValue("DSP_DS_IDENTIFICACAO_BENEFICIARIO", value.getValue());
	}

	public NString getDspDsEtapaAutorizacao() {

		NString v = new NString((String) this.getValue("DSP_DS_ETAPA_AUTORIZACAO"));
		return v;
	}

	public void setDspDsEtapaAutorizacao(NString value) {

		this.setValue("DSP_DS_ETAPA_AUTORIZACAO", value.getValue());
	}

	public NString getDspDsMotAusenciaCodValidacao() {

		NString v = new NString((String) this.getValue("DSP_DS_MOT_AUSENCIA_COD_VALIDACAO"));
		return v;
	}

	public void setDspDsMotAusenciaCodValidacao(NString value) {

		this.setValue("DSP_DS_MOT_AUSENCIA_COD_VALIDACAO", value.getValue());
	}

	public NString getNmPrestadorExecutorPf() {
		NString v = new NString((String) this.getValue("NM_PRESTADOR_EXECUTOR_PF"));
		return v;
	}

	public void setNmPrestadorExecutorPf(NString value) {
		this.setValue("NM_PRESTADOR_EXECUTOR_PF", value.getValue());
	}

	public NString getCdTissConselhoProfiExecPf() {
		NString v = new NString((String) this.getValue("CD_TISS_CONSELHO_PROFI_EXEC_PF"));
		return v;
	}

	public void setCdTissConselhoProfiExecPf(NString value) {
		this.setValue("CD_TISS_CONSELHO_PROFI_EXEC_PF", value.getValue());
	}

	public NString getNrRegConselhoProfiExec() {
		NString v = new NString((String) this.getValue("NR_REG_CONSELHO_PROFI_EXEC"));
		return v;
	}

	public void setNrRegConselhoProfiExec(NString value) {
		this.setValue("NR_REG_CONSELHO_PROFI_EXEC", value.getValue());
	}

	public NString getUfConselhoProfissionalExec() {
		NString v = new NString((String) this.getValue("UF_CONSELHO_PROFISSIONAL_EXEC"));
		return v;
	}

	public void setUfConselhoProfissionalExec(NString value) {
		this.setValue("UF_CONSELHO_PROFISSIONAL_EXEC", value.getValue());
	}

	public NNumber getCdEspecialidadeExecutante() {
		NNumber v = new NNumber((BigDecimal) this.getValue("CD_ESPECIALIDADE_EXECUTANTE"));
		return v;
	}

	public void setCdEspecialidadeExecutante(NNumber value) {
		this.setValue("CD_ESPECIALIDADE_EXECUTANTE", value.getValue());
	}

	public NString getDspDsUfConselhoProfissionalExec() {
		NString v = new NString((String) this.getValue("DSP_DS_UF_CONSELHO_PROFISSIONAL_EXEC"));
		return v;
	}

	public void setDspDsUfConselhoProfissionalExec(NString value) {
		this.setValue("DSP_DS_UF_CONSELHO_PROFISSIONAL_EXEC", value.getValue());
	}

	public NString getDspDsTissConselhoProfiExecPf() {
		NString v = new NString((String) this.getValue("DSP_DS_TISS_CONSELHO_PROFI_EXEC_PF"));
		return v;
	}

	public void setDspDsTissConselhoProfiExecPf(NString value) {
		this.setValue("DSP_DS_TISS_CONSELHO_PROFI_EXEC_PF", value.getValue());
	}

	public NString getDspDsEspecialidadeExecutante() {
		NString v = new NString((String) this.getValue("DSP_DS_ESPECIALIDADE_EXECUTANTE"));
		return v;
	}

	public void setDspDsEspecialidadeExecutante(NString value) {
		this.setValue("DSP_DS_ESPECIALIDADE_EXECUTANTE", value.getValue());
	}

	public NString getDspCdEcog() {
		NString v = new NString((String) this.getValue("DSP_CD_ECOG"));
		return v;
	}

	public void setDspCdEcog(NString value) {
		this.setValue("DSP_CD_ECOG", value.getValue());
	}

	public NString getDsJustificativaOperadora() {
		NString v = new NString((String) this.getValue("DS_JUSTIFICATIVA_OPERADORA"));
		return v;
	}

	public void setDsJustificativaOperadora(NString value) {
		this.setValue("DS_JUSTIFICATIVA_OPERADORA", value.getValue());
	}
	
	public NString getDsPlanoTerapeutico() {
		NString v = new NString((String) this.getValue("DS_PLANO_TERAPEUTICO"));
		return v;
	}

	public void setDsPlanoTerapeutico(NString value) {
		this.setValue("DS_PLANO_TERAPEUTICO", value.getValue());
	}


	public NString getDsPlano() {
		NString v = new NString((String) this.getValue("DS_PLANO"));
		return v;
	}

	public void setDsPlano(NString value) {
		this.setValue("DS_PLANO", value.getValue());
	}

	public NString getNmEmpresa() {
		NString v = new NString((String) this.getValue("NM_EMPRESA"));
		return v;
	}

	public void setNmEmpresa(NString value) {
		this.setValue("NM_EMPRESA", value.getValue());
	}

	public NString getNrTelefoneBenef() {
		NString v = new NString((String) this.getValue("NR_TELEFONE_BENEF"));
		return v;
	}

	public void setNrTelefoneBenef(NString value) {
		this.setValue("NR_TELEFONE_BENEF", value.getValue());
	}

	public NString getNmTitular() {
		NString v = new NString((String) this.getValue("NM_TITULAR"));
		return v;
	}

	public void setNmTitular(NString value) {
		this.setValue("NM_TITULAR", value.getValue());
	}

	public NString getNrRegistroAnsAnexo() {
		NString v = new NString((String) this.getValue("NR_REGISTRO_ANS_ANEXO"));
		return v;
	}

	public void setNrRegistroAnsAnexo(NString value) {
		this.setValue("NR_REGISTRO_ANS_ANEXO", value.getValue());
	}

	public NNumber getNrGuiaAnexo() {
		NNumber v = new NNumber((BigDecimal) this.getValue("NR_GUIA_ANEXO"));
		return v;
	}

	public void setNrGuiaAnexo(NNumber value) {
		this.setValue("NR_GUIA_ANEXO", value.getValue());
	}

	public NString getNrGuiaReferenciadaAnexo() {
		NString v = new NString((String) this.getValue("NR_GUIA_REFERENCIADA_ANEXO"));
		return v;
	}

	public void setNrGuiaReferenciadaAnexo(NString value) {
		this.setValue("NR_GUIA_REFERENCIADA_ANEXO", value.getValue());
	}

	public NNumber getNrGuiaOperadoraAnexo() {
		NNumber v = new NNumber((BigDecimal) this.getValue("NR_GUIA_OPERADORA_ANEXO"));
		return v;
	}

	public void setNrGuiaOperadoraAnexo(NNumber value) {
		this.setValue("NR_GUIA_OPERADORA_ANEXO", value.getValue());
	}

	public NString getNmBeneficiarioAnexo() {
		NString v = new NString((String) this.getValue("NM_BENEFICIARIO_ANEXO"));
		return v;
	}

	public void setNmBeneficiarioAnexo(NString value) {
		this.setValue("NM_BENEFICIARIO_ANEXO", value.getValue());
	}

	public NString getNrCarteiraAnexo() {
		NString v = new NString((String) this.getValue("NR_CARTEIRA_ANEXO"));
		return v;
	}

	public void setNrCarteiraAnexo(NString value) {
		this.setValue("NR_CARTEIRA_ANEXO", value.getValue());
	}

	public NString getSnDoencaPeriodontal() {
		NString v = new NString((String) this.getValue("SN_DOENCA_PERIODONTAL"));
		return v;
	}

	public void setSnDoencaPeriodontal(NString value) {
		this.setValue("SN_DOENCA_PERIODONTAL", value.getValue());
	}

	public NString getSnAlteracaoTecidoMole() {
		NString v = new NString((String) this.getValue("SN_ALTERACAO_TECIDO_MOLE"));
		return v;
	}

	public void setSnAlteracaoTecidoMole(NString value) {
		this.setValue("SN_ALTERACAO_TECIDO_MOLE", value.getValue());
	}

	public NString getDsObservacaoAnexo() {
		NString v = new NString((String) this.getValue("DS_OBSERVACAO_ANEXO"));
		return v;
	}

	public void setDsObservacaoAnexo(NString value) {
		this.setValue("DS_OBSERVACAO_ANEXO", value.getValue());
	}

	public NString getTpSituacao() {
		NString v = new NString((String) this.getValue("TP_SITUACAO"));
		return v;
	}

	public void setTpSituacao(NString value) {
		this.setValue("TP_SITUACAO", value.getValue());
	}

}

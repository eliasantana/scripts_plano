package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import java.math.BigDecimal;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class ItguiasAssociadasAdapter extends BaseRowAdapter {

	public ItguiasAssociadasAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getNrGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA"));
		return v;
	}
	
	public void setNrGuia(NNumber value) {
		this.setValue("NR_GUIA", value.getValue());
	}

	public NString getCdProcedimento() {
		NString v = new NString((String)this.getValue("CD_PROCEDIMENTO"));
		return v;
	}
	
	public void setCdProcedimento(NString value) {
		this.setValue("CD_PROCEDIMENTO", value.getValue());
	}

	public NString getDsProcedimento() {
		NString v = new NString((String)this.getValue("DS_PROCEDIMENTO"));
		return v;
	}
	
	public void setDsProcedimento(NString value) {
		this.setValue("DS_PROCEDIMENTO", value.getValue());
	}

	public NNumber getQtSolicitado() {
		NNumber v = new NNumber((BigDecimal) this.getValue("QT_SOLICITADO"));
		return v;
	}
	
	public void setQtSolicitado(NNumber value) {
		this.setValue("QT_SOLICITADO", value.getValue());
	}

	public NNumber getQtAutorizado() {
		NNumber v = new NNumber((BigDecimal) this.getValue("QT_AUTORIZADO"));
		return v;
	}
	
	public void setQtAutorizado(NNumber value) {
		this.setValue("QT_AUTORIZADO", value.getValue());
	}

	public NNumber getVlProcedimento() {
		NNumber v = new NNumber((BigDecimal) this.getValue("VL_PROCEDIMENTO"));
		return v;
	}
	
	public void setVlProcedimento(NNumber value) {
		this.setValue("VL_PROCEDIMENTO", value.getValue());
	}
	
}

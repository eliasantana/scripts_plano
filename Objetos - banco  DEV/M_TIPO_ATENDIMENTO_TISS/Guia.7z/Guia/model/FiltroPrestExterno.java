package br.com.mv.soul.mvsaude.forms.Guia.model;

import morphis.foundations.core.appsupportlib.model.SimpleBusinessObject;
import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.*;
import static morphis.foundations.core.types.Types.*;

public class FiltroPrestExterno extends morphis.foundations.core.appsupportlib.model.SimpleBusinessObject {

	public FiltroPrestExterno() {
		super();
	}

	public FiltroPrestExterno(SimpleBusinessObjectConfiguration configuration, String name) {
		super(configuration, name);
	}
	
	public NString getCdPrestExterno() {
		return toStr(super.getValue("CD_PREST_EXTERNO"));
	}
	
	public void setCdPrestExterno(NString value) {
		super.setValue("CD_PREST_EXTERNO", value);
	}

	public NString getDsPrestExterno() {
		return toStr(super.getValue("DS_PREST_EXTERNO"));
	}

	public void setDsPrestExterno(NString value) {
		super.setValue("DS_PREST_EXTERNO", value);
	}
}
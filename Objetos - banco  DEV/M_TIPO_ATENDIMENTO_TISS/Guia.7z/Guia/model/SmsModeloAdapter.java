package br.com.mv.soul.mvsaude.forms.Guia.model;

import java.util.Date;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class SmsModeloAdapter extends BaseRowAdapter {

	public SmsModeloAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getCdSmsModelo() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_SMS_MODELO"));
		return v;
	}
	
	public void setCdSmsModelo(NNumber value) {
		this.setValue("CD_SMS_MODELO", value.getValue());
	}

	public NString getDsSmsModelo() {
		NString v = new NString((String)this.getValue("DS_SMS_MODELO"));
		return v;
	}
	
	public void setDsSmsModelo(NString value) {
		this.setValue("DS_SMS_MODELO", value.getValue());
	}

	public NNumber getCdTipoAtendimento() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_TIPO_ATENDIMENTO"));
		return v;
	}
	
	public void setCdTipoAtendimento(NNumber value) {
		this.setValue("CD_TIPO_ATENDIMENTO", value.getValue());
	}

	public NNumber getCdPrestador() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PRESTADOR"));
		return v;
	}
	
	public void setCdPrestador(NNumber value) {
		this.setValue("CD_PRESTADOR", value.getValue());
	}

	public NNumber getCdMotivoAutorizacao() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_MOTIVO_AUTORIZACAO"));
		return v;
	}
	
	public void setCdMotivoAutorizacao(NNumber value) {
		this.setValue("CD_MOTIVO_AUTORIZACAO", value.getValue());
	}

	public NString getDsMensagem() {
		NString v = new NString((String)this.getValue("DS_MENSAGEM"));
		return v;
	}
	
	public void setDsMensagem(NString value) {
		this.setValue("DS_MENSAGEM", value.getValue());
	}
	
	public NString getSnSelecionado() {

		NString v = new NString((String) this.getValue("SN_SELECIONADO"));
		return v;
	}

	public void setSnSelecionado(NString value) {

		this.setValue("SN_SELECIONADO", value.getValue());
	}

	public NString getDspDsMensagem() {
		NString v = new NString((String) this.getValue("DSP_DS_MENSAGEM"));
		return v;
	}

	public void setDspDsMensagem(NString value) {
		this.setValue("DSP_DS_MENSAGEM", value.getValue());
	}

	public NDate getDtInativacao() {
		NDate v = new NDate((Date) this.getValue("DT_INATIVACAO"));
		return v;
	}

	public void setDtInativacao(NDate value) {

		this.setValue("DT_INATIVACAO", value.getValue());
	}

}

package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class GuiaAnexoAdapter extends BaseRowAdapter {

	public GuiaAnexoAdapter(DataRow row, IDBBusinessObject businessObject) {
		 super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getCdGuiaAnexo() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_GUIA_ANEXO"));
		return v;
	}
	
	public void setCdGuiaAnexo(NNumber value) {
		this.setValue("CD_GUIA_ANEXO", value.getValue());
	}

	public NNumber getNrGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA"));
		return v;
	}
	
	public void setNrGuia(NNumber value) {
		this.setValue("NR_GUIA", value.getValue());
	}

	public NString getDsCaminho() {
		NString v = new NString((String)this.getValue("DS_CAMINHO"));
		return v;
	}
	
	public void setDsCaminho(NString value) {
		this.setValue("DS_CAMINHO", value.getValue());
	}

	public NString getDsArquivo() {
		NString v = new NString((String)this.getValue("DS_ARQUIVO"));
		return v;
	}
	
	public void setDsArquivo(NString value) {
		this.setValue("DS_ARQUIVO", value.getValue());
	}
	
	public NString getBtnUploadAnexo() {
		NString v = new NString((String) this.getValue("BTN_UPLOAD_ANEXO"));
		return v;
	}

	public void setBtnUploadAnexo(NString value) {
		this.setValue("BTN_UPLOAD_ANEXO", value.getValue());
	}

	public NString getDsFile() {
		NString v = new NString((String) this.getValue("DS_FILE"));
		return v;
	}

	public void setDsFile(NString value) {
		this.setValue("DS_FILE", value.getValue());
	}

	public NString getNmFile() {
		NString v = new NString((String) this.getValue("NM_FILE"));
		return v;
	}

	public void setNmFile(NString value) {
		this.setValue("NM_FILE", value.getValue());
	}

	

	

	public NDate getDtCadastro() {

		NDate v = new NDate((java.util.Date) this.getValue("DT_CADASTRO"));
		return v;
	}

	public void setDtCadastro(NDate value) {

		this.setValue("DT_CADASTRO", value.getValue());
	}

}

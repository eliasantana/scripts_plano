package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class ChatMensagemAdapter extends BaseRowAdapter {

	public ChatMensagemAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getCdChatMensagem() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_CHAT_MENSAGEM"));
		return v;
	}
	
	public void setCdChatMensagem(NNumber value) {
		this.setValue("CD_CHAT_MENSAGEM", value.getValue());
	}

	public NNumber getCdChat() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_CHAT"));
		return v;
	}
	
	public void setCdChat(NNumber value) {
		this.setValue("CD_CHAT", value.getValue());
	}

	public NString getDsMensagem() {
		NString v = new NString((String)this.getValue("DS_MENSAGEM"));
		return v;
	}
	
	public void setDsMensagem(NString value) {
		this.setValue("DS_MENSAGEM", value.getValue());
	}

	public NString getTpOrigem() {
		NString v = new NString((String)this.getValue("TP_ORIGEM"));
		return v;
	}
	
	public void setTpOrigem(NString value) {
		this.setValue("TP_ORIGEM", value.getValue());
	}

	public NString getSnAtendido() {
		NString v = new NString((String)this.getValue("SN_ATENDIDO"));
		return v;
	}
	
	public void setSnAtendido(NString value) {
		this.setValue("SN_ATENDIDO", value.getValue());
	}

	public NDate getTsCriacao() {
		NDate v = new NDate((java.util.Date)this.getValue("TS_CRIACAO"));
		return v;
	}
	
	public void setTsCriacao(NDate value) {
		this.setValue("TS_CRIACAO", value.getValue());
	}

	public NDate getTsVisualizacao() {
		NDate v = new NDate((java.util.Date)this.getValue("TS_VISUALIZACAO"));
		return v;
	}
	
	public void setTsVisualizacao(NDate value) {
		this.setValue("TS_VISUALIZACAO", value.getValue());
	}

	public NNumber getCdAutorizador() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_AUTORIZADOR"));
		return v;
	}
	
	public void setCdAutorizador(NNumber value) {
		this.setValue("CD_AUTORIZADOR", value.getValue());
	}

	public NString getCdUsuario() {
		NString v = new NString((String)this.getValue("CD_USUARIO"));
		return v;
	}
	
	public void setCdUsuario(NString value) {
		this.setValue("CD_USUARIO", value.getValue());
	}
	
	public NString getDsArquivo() {

		NString v = new NString((String) this.getValue("DS_ARQUIVO"));
		return v;
	}

	public void setDsArquivo(NString value) {

		this.setValue("DS_ARQUIVO", value.getValue());
	}

	public NString getBtnAnexo() {

		NString v = new NString((String) this.getValue("BTN_ANEXO"));
		return v;
	}

	public void setBtnAnexo(NString value) {

		this.setValue("BTN_ANEXO", value.getValue());
	}

	public NString getDspSnAnexo() {

		NString v = new NString((String) this.getValue("DSP_SN_ANEXO"));
		return v;
	}

	public void setDspSnAnexo(NString value) {

		this.setValue("DSP_SN_ANEXO", value.getValue());
	}

}

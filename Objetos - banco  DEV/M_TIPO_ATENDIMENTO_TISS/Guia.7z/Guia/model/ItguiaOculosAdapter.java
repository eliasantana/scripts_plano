package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class ItguiaOculosAdapter extends BaseRowAdapter {

	public ItguiaOculosAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getNrGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA"));
		return v;
	}
	
	public void setNrGuia(NNumber value) {
		this.setValue("NR_GUIA", value.getValue());
	}

	public NNumber getCdItguia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_ITGUIA"));
		return v;
	}
	
	public void setCdItguia(NNumber value) {
		this.setValue("CD_ITGUIA", value.getValue());
	}

	public NNumber getCdMatricula() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_MATRICULA"));
		return v;
	}
	
	public void setCdMatricula(NNumber value) {
		this.setValue("CD_MATRICULA", value.getValue());
	}

	public NString getDsJustificativa() {
		NString v = new NString((String)this.getValue("DS_JUSTIFICATIVA"));
		return v;
	}
	
	public void setDsJustificativa(NString value) {
		this.setValue("DS_JUSTIFICATIVA", value.getValue());
	}

	public NString getTpLongeEsfericoDireito() {
		NString v = new NString((String)this.getValue("TP_LONGE_ESFERICO_DIREITO"));
		return v;
	}
	
	public void setTpLongeEsfericoDireito(NString value) {
		this.setValue("TP_LONGE_ESFERICO_DIREITO", value.getValue());
	}

	public NString getTpLongeEsfericoEsquerdo() {
		NString v = new NString((String)this.getValue("TP_LONGE_ESFERICO_ESQUERDO"));
		return v;
	}
	
	public void setTpLongeEsfericoEsquerdo(NString value) {
		this.setValue("TP_LONGE_ESFERICO_ESQUERDO", value.getValue());
	}

	public NNumber getVlLongeEsfericoDireito() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_LONGE_ESFERICO_DIREITO"));
		return v;
	}
	
	public void setVlLongeEsfericoDireito(NNumber value) {
		this.setValue("VL_LONGE_ESFERICO_DIREITO", value.getValue());
	}

	public NNumber getVlLongeEsfericoEsquerdo() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_LONGE_ESFERICO_ESQUERDO"));
		return v;
	}
	
	public void setVlLongeEsfericoEsquerdo(NNumber value) {
		this.setValue("VL_LONGE_ESFERICO_ESQUERDO", value.getValue());
	}

	public NString getTpLongeCilindroDireito() {
		NString v = new NString((String)this.getValue("TP_LONGE_CILINDRO_DIREITO"));
		return v;
	}
	
	public void setTpLongeCilindroDireito(NString value) {
		this.setValue("TP_LONGE_CILINDRO_DIREITO", value.getValue());
	}

	public NString getTpLongeCilindroEsquerdo() {
		NString v = new NString((String)this.getValue("TP_LONGE_CILINDRO_ESQUERDO"));
		return v;
	}
	
	public void setTpLongeCilindroEsquerdo(NString value) {
		this.setValue("TP_LONGE_CILINDRO_ESQUERDO", value.getValue());
	}

	public NNumber getVlLongeCilindroDireito() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_LONGE_CILINDRO_DIREITO"));
		return v;
	}
	
	public void setVlLongeCilindroDireito(NNumber value) {
		this.setValue("VL_LONGE_CILINDRO_DIREITO", value.getValue());
	}

	public NNumber getVlLongeCilindroEsquerdo() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_LONGE_CILINDRO_ESQUERDO"));
		return v;
	}
	
	public void setVlLongeCilindroEsquerdo(NNumber value) {
		this.setValue("VL_LONGE_CILINDRO_ESQUERDO", value.getValue());
	}

	public NNumber getVlLongeEixoDireito() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_LONGE_EIXO_DIREITO"));
		return v;
	}
	
	public void setVlLongeEixoDireito(NNumber value) {
		this.setValue("VL_LONGE_EIXO_DIREITO", value.getValue());
	}

	public NNumber getVlLongeEixoEsquerdo() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_LONGE_EIXO_ESQUERDO"));
		return v;
	}
	
	public void setVlLongeEixoEsquerdo(NNumber value) {
		this.setValue("VL_LONGE_EIXO_ESQUERDO", value.getValue());
	}

	public NString getTpPertoEsfericoDireito() {
		NString v = new NString((String)this.getValue("TP_PERTO_ESFERICO_DIREITO"));
		return v;
	}
	
	public void setTpPertoEsfericoDireito(NString value) {
		this.setValue("TP_PERTO_ESFERICO_DIREITO", value.getValue());
	}

	public NString getTpPertoEsfericoEsquerdo() {
		NString v = new NString((String)this.getValue("TP_PERTO_ESFERICO_ESQUERDO"));
		return v;
	}
	
	public void setTpPertoEsfericoEsquerdo(NString value) {
		this.setValue("TP_PERTO_ESFERICO_ESQUERDO", value.getValue());
	}

	public NNumber getVlPertoEsfericoDireito() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_PERTO_ESFERICO_DIREITO"));
		return v;
	}
	
	public void setVlPertoEsfericoDireito(NNumber value) {
		this.setValue("VL_PERTO_ESFERICO_DIREITO", value.getValue());
	}

	public NNumber getVlPertoEsfericoEsquerdo() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_PERTO_ESFERICO_ESQUERDO"));
		return v;
	}
	
	public void setVlPertoEsfericoEsquerdo(NNumber value) {
		this.setValue("VL_PERTO_ESFERICO_ESQUERDO", value.getValue());
	}

	public NString getTpPertoCilindroDireito() {
		NString v = new NString((String)this.getValue("TP_PERTO_CILINDRO_DIREITO"));
		return v;
	}
	
	public void setTpPertoCilindroDireito(NString value) {
		this.setValue("TP_PERTO_CILINDRO_DIREITO", value.getValue());
	}

	public NString getTpPertoCilindroEsquerdo() {
		NString v = new NString((String)this.getValue("TP_PERTO_CILINDRO_ESQUERDO"));
		return v;
	}
	
	public void setTpPertoCilindroEsquerdo(NString value) {
		this.setValue("TP_PERTO_CILINDRO_ESQUERDO", value.getValue());
	}

	public NNumber getVlPertoCilindroDireito() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_PERTO_CILINDRO_DIREITO"));
		return v;
	}
	
	public void setVlPertoCilindroDireito(NNumber value) {
		this.setValue("VL_PERTO_CILINDRO_DIREITO", value.getValue());
	}

	public NNumber getVlPertoCilindroEsquerdo() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_PERTO_CILINDRO_ESQUERDO"));
		return v;
	}
	
	public void setVlPertoCilindroEsquerdo(NNumber value) {
		this.setValue("VL_PERTO_CILINDRO_ESQUERDO", value.getValue());
	}

	public NNumber getVlPertoEixoDireito() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_PERTO_EIXO_DIREITO"));
		return v;
	}
	
	public void setVlPertoEixoDireito(NNumber value) {
		this.setValue("VL_PERTO_EIXO_DIREITO", value.getValue());
	}

	public NNumber getVlPertoEixoEsquerdo() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_PERTO_EIXO_ESQUERDO"));
		return v;
	}
	
	public void setVlPertoEixoEsquerdo(NNumber value) {
		this.setValue("VL_PERTO_EIXO_ESQUERDO", value.getValue());
	}

	public NNumber getNrDistanciaPupilarDireito() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_DISTANCIA_PUPILAR_DIREITO"));
		return v;
	}
	
	public void setNrDistanciaPupilarDireito(NNumber value) {
		this.setValue("NR_DISTANCIA_PUPILAR_DIREITO", value.getValue());
	}

	public NNumber getNrDistanciaPupilarEsquerdo() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_DISTANCIA_PUPILAR_ESQUERDO"));
		return v;
	}
	
	public void setNrDistanciaPupilarEsquerdo(NNumber value) {
		this.setValue("NR_DISTANCIA_PUPILAR_ESQUERDO", value.getValue());
	}
	
}

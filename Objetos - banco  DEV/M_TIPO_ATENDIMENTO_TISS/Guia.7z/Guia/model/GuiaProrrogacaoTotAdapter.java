package br.com.mv.soul.mvsaude.forms.Guia.model;

import java.math.BigDecimal;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class GuiaProrrogacaoTotAdapter extends BaseRowAdapter {

	public GuiaProrrogacaoTotAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getNrGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA"));
		return v;
	}
	
	public void setNrGuia(NNumber value) {
		this.setValue("NR_GUIA", value.getValue());
	}

	public NString getCdTipAcomodacao() {
		NString v = new NString((String)this.getValue("CD_TIP_ACOMODACAO"));
		return v;
	}
	
	public void setCdTipAcomodacao(NString value) {
		this.setValue("CD_TIP_ACOMODACAO", value.getValue());
	}

	public NString getDsTipAcomodacao() {
		NString v = new NString((String)this.getValue("DS_TIP_ACOMODACAO"));
		return v;
	}
	
	public void setDsTipAcomodacao(NString value) {
		this.setValue("DS_TIP_ACOMODACAO", value.getValue());
	}

	public NNumber getTotalDiaAutori() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TOTAL_DIA_AUTORI"));
		return v;
	}
	
	public void setTotalDiaAutori(NNumber value) {
		this.setValue("TOTAL_DIA_AUTORI", value.getValue());
	}

	public NNumber getTotDiaNaoAutori() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TOT_DIA_NAO_AUTORI"));
		return v;
	}
	
	public void setTotDiaNaoAutori(NNumber value) {
		this.setValue("TOT_DIA_NAO_AUTORI", value.getValue());
	}

	public NNumber getTotal() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TOTAL"));
		return v;
	}
	
	public void setTotal(NNumber value) {
		this.setValue("TOTAL", value.getValue());
	}
	
	public NNumber getTotDiaAutori() {
		NNumber v = new NNumber((BigDecimal) this.getValue("TOT_DIA_AUTORI"));
		return v;
	}

	public void setTotDiaAutori(NNumber value) {
		this.setValue("TOT_DIA_AUTORI", value.getValue());
	}

	public NNumber getTotalDiaNaoAutori() {
		NNumber v = new NNumber((BigDecimal) this.getValue("TOTAL_DIA_NAO_AUTORI"));
		return v;
	}

	public void setTotalDiaNaoAutori(NNumber value) {
		this.setValue("TOTAL_DIA_NAO_AUTORI", value.getValue());
	}

	public NNumber getTotGeral() {
		NNumber v = new NNumber((BigDecimal) this.getValue("TOT_GERAL"));
		return v;
	}

	public void setTotGeral(NNumber value) {
		this.setValue("TOT_GERAL", value.getValue());
	}

}

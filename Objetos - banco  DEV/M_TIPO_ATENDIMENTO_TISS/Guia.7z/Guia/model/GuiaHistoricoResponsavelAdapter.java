package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class GuiaHistoricoResponsavelAdapter extends BaseRowAdapter {

	public GuiaHistoricoResponsavelAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NDate getDtCadastro() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_CADASTRO"));
		return v;
	}
	
	public void setDtCadastro(NDate value) {
		this.setValue("DT_CADASTRO", value.getValue());
	}

	public NNumber getCdAutorizador() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_AUTORIZADOR"));
		return v;
	}
	
	public void setCdAutorizador(NNumber value) {
		this.setValue("CD_AUTORIZADOR", value.getValue());
	}

	public NString getNmAutorizador() {
		NString v = new NString((String)this.getValue("NM_AUTORIZADOR"));
		return v;
	}
	
	public void setNmAutorizador(NString value) {
		this.setValue("NM_AUTORIZADOR", value.getValue());
	}

	public NNumber getNrGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA"));
		return v;
	}
	
	public void setNrGuia(NNumber value) {
		this.setValue("NR_GUIA", value.getValue());
	}
	
}

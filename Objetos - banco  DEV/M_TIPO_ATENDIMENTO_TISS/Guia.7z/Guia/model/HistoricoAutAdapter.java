package br.com.mv.soul.mvsaude.forms.Guia.model;

import java.math.BigDecimal;
import java.sql.Date;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class HistoricoAutAdapter extends BaseRowAdapter {

	public HistoricoAutAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}

	public NNumber getNrGuia() {

		NNumber v = new NNumber((java.math.BigDecimal) this.getValue("NR_GUIA"));
		return v;
	}

	public void setNrGuia(NNumber value) {

		this.setValue("NR_GUIA", value.getValue());
	}
	
	public NNumber getNrGuiaOriginal() {

		NNumber v = new NNumber((BigDecimal) this.getValue("NR_GUIA_ORIGINAL"));
		return v;
	}

	public void setNrGuiaOriginal(NNumber value) {

		this.setValue("NR_GUIA_ORIGINAL", value.getValue());
	}
	
	public NString getDspDsEspecialidade() {

		NString v = new NString((String) this.getValue("DSP_DS_ESPECIALIDADE"));
		return v;
	}

	public void setDspDsEspecialidade(NString value) {

		this.setValue("DSP_DS_ESPECIALIDADE", value.getValue());
	}
	
	public NString getDspNmPrestadorExecutor() {

		NString v = new NString((String) this.getValue("DSP_NM_PRESTADOR_EXECUTOR"));
		return v;
	}

	public void setDspNmPrestadorExecutor(NString value) {

		this.setValue("DSP_NM_PRESTADOR_EXECUTOR", value.getValue());
	}
	
	public NString getNrTransacao() {

		NString v = new NString((String) this.getValue("NR_TRANSACAO"));
		return v;
	}

	public void setNrTransacao(NString value) {

		this.setValue("NR_TRANSACAO", value.getValue());
	}
	
	public NDate getDtEmissaoHist() {
		NDate v = new NDate((java.util.Date) this.getValue("DT_EMISSAO_HIST"));
		return v;
	}

	public void setDtEmissaoHist(NDate value) {
		this.setValue("DT_EMISSAO_HIST", value.getValue());
	}	


	public NString getTpStatus() {
		NString v = new NString((String) this.getValue("TP_STATUS"));
		return v;
	}

	public void setTpStatus(NString value) {
		this.setValue("TP_STATUS", value.getValue());
	}

	public NString getCdUnimedSolicitante() {
		NString v = new NString((String) this.getValue("CD_UNIMED_SOLICITANTE"));
		return v;
	}

	public void setCdUnimedSolicitante(NString value) {
		this.setValue("CD_UNIMED_SOLICITANTE", value.getValue());
	}


	public NString getDspDsUnimedSolicitante() {
		NString v = new NString((String) this.getValue("DSP_DS_UNIMED_SOLICITANTE"));
		return v;
	}

	public void setDspDsUnimedSolicitante(NString value) {
		this.setValue("DSP_DS_UNIMED_SOLICITANTE", value.getValue());
	}
	
	
	public NNumber getCdEspecialidade() {

		NNumber v = new NNumber((java.math.BigDecimal) this.getValue("CD_ESPECIALIDADE"));
		return v;
	}

	public void setCdEspecialidade(NNumber value) {

		this.setValue("CD_ESPECIALIDADE", value.getValue());
	}

	public NNumber getCdPrestadorExecutor() {

		NNumber v = new NNumber((java.math.BigDecimal) this.getValue("CD_PRESTADOR_EXECUTOR"));
		return v;
	}

	public void setCdPrestadorExecutor(NNumber value) {

		this.setValue("CD_PRESTADOR_EXECUTOR", value.getValue());
	}
	
	public NString getSnValidaRestCarencia() {

		NString v = new NString((String) this.getValue("SN_VALIDA_REST_CARENCIA"));
		return v;
	}

	public void setSnValidaRestCarencia(NString value) {

		this.setValue("SN_VALIDA_REST_CARENCIA", value.getValue());
	}
	
	public NString getTpCaraterSolicInter() {

		NString v = new NString((String) this.getValue("TP_CARATER_SOLIC_INTER"));
		return v;
	}

	public void setTpCaraterSolicInter(NString value) {

		this.setValue("TP_CARATER_SOLIC_INTER", value.getValue());
	}
	
	public NDate getDtAutorizacao() {

		NDate v = new NDate((java.util.Date) this.getValue("DT_AUTORIZACAO"));
		return v;
	}

	public void setDtAutorizacao(NDate value) {

		this.setValue("DT_AUTORIZACAO", value.getValue());
	}
	
	public NString getSnAtendimentoRecemNato() {

		NString v = new NString((String) this.getValue("SN_ATENDIMENTO_RECEM_NATO"));
		return v;
	}

	public void setSnAtendimentoRecemNato(NString value) {

		this.setValue("SN_ATENDIMENTO_RECEM_NATO", value.getValue());
	}

	public NString getNrProtocolo() {

		NString v = new NString((String) this.getValue("NR_PROTOCOLO"));
		return v;
	}

	public void setNrProtocolo(NString value) {

		this.setValue("NR_PROTOCOLO", value.getValue());
	}
	
	public NString getDsDestinoCortesia() {

		NString v = new NString((String) this.getValue("DS_DESTINO_CORTESIA"));
		return v;
	}

	public void setDsDestinoCortesia(NString value) {

		this.setValue("DS_DESTINO_CORTESIA", value.getValue());
	}

	public NNumber getCdMatricula() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_MATRICULA"));
		return v;
	}

	public void setCdMatricula(NNumber value) {

		this.setValue("CD_MATRICULA", value.getValue());
	}

	public NString getNrCarteiraBeneficiario() {

		NString v = new NString((String) this.getValue("NR_CARTEIRA_BENEFICIARIO"));
		return v;
	}

	public void setNrCarteiraBeneficiario(NString value) {

		this.setValue("NR_CARTEIRA_BENEFICIARIO", value.getValue());
	}


	

	
	
	

		

}

package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
//import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;

public class ItguiaTaxaAdapter extends BaseRowAdapter {

	public ItguiaTaxaAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NString getCdProcedimento() {
		NString v = new NString((String)this.getValue("CD_PROCEDIMENTO"));
		return v;
	}
	
	public void setCdProcedimento(NString value) {
		this.setValue("CD_PROCEDIMENTO", value.getValue());
	}

	public NString getTpTaxa() {
		NString v = new NString((String)this.getValue("TP_TAXA"));
		return v;
	}
	
	public void setTpTaxa(NString value) {
		this.setValue("TP_TAXA", value.getValue());
	}

	public NNumber getVlTaxa() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_TAXA"));
		return v;
	}
	
	public void setVlTaxa(NNumber value) {
		this.setValue("VL_TAXA", value.getValue());
	}

	public NString getCdLctoMensalidade() {
		NString v = new NString((String)this.getValue("CD_LCTO_MENSALIDADE"));
		return v;
	}
	
	public void setCdLctoMensalidade(NString value) {
		this.setValue("CD_LCTO_MENSALIDADE", value.getValue());
	}

	public NString getDsLctoMensalidade() {
		NString v = new NString((String)this.getValue("DS_LCTO_MENSALIDADE"));
		return v;
	}
	
	public void setDsLctoMensalidade(NString value) {
		this.setValue("DS_LCTO_MENSALIDADE", value.getValue());
	}

	public NString getCdSetor() {
		NString v = new NString((String)this.getValue("CD_SETOR"));
		return v;
	}
	
	public void setCdSetor(NString value) {
		this.setValue("CD_SETOR", value.getValue());
	}

	public NString getNmSetor() {
		NString v = new NString((String)this.getValue("NM_SETOR"));
		return v;
	}
	
	public void setNmSetor(NString value) {
		this.setValue("NM_SETOR", value.getValue());
	}

	public NString getCdUsuarioInclusao() {
		NString v = new NString((String)this.getValue("CD_USUARIO_INCLUSAO"));
		return v;
	}
	
	public void setCdUsuarioInclusao(NString value) {
		this.setValue("CD_USUARIO_INCLUSAO", value.getValue());
	}

	public NDate getDtInclusao() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_INCLUSAO"));
		return v;
	}
	
	public void setDtInclusao(NDate value) {
		this.setValue("DT_INCLUSAO", value.getValue());
	}

}
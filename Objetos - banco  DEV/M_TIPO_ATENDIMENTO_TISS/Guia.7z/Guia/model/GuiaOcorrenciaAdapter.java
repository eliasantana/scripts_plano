package br.com.mv.soul.mvsaude.forms.Guia.model;

import java.math.BigDecimal;
import java.util.Date;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class GuiaOcorrenciaAdapter extends BaseRowAdapter {

	public GuiaOcorrenciaAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getCdGuiaOcorrencia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_GUIA_OCORRENCIA"));
		return v;
	}
	
	public void setCdGuiaOcorrencia(NNumber value) {
		 this.setValue("CD_GUIA_OCORRENCIA", value.getValue());
	}

	public NString getCdUsuario() {
		NString v = new NString((String)this.getValue("CD_USUARIO"));
		return v;
	}
	
	public void setCdUsuario(NString value) {
		this.setValue("CD_USUARIO", value.getValue());
	}

	public NNumber getCdClassificacaoOcorGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_CLASSIFICACAO_OCOR_GUIA"));
		return v;
	}
	
	public void setCdClassificacaoOcorGuia(NNumber value) {
		this.setValue("CD_CLASSIFICACAO_OCOR_GUIA", value.getValue());
	}

	public NString getDsObservacao() {
		NString v = new NString((String)this.getValue("DS_OBSERVACAO"));
		return v;
	}
	
	public void setDsObservacao(NString value) {
		this.setValue("DS_OBSERVACAO", value.getValue());
	}
	
	public NDate getDtInclusao()
    {
        NDate v = new NDate((Date) this.getValue("DT_INCLUSAO"));
        return v;
    }

    public void setDtInclusao(NDate value)
    {
        this.setValue("DT_INCLUSAO", value.getValue());
    }

    public NNumber getNrGuia()
    {
        NNumber v = new NNumber((BigDecimal) this.getValue("NR_GUIA"));
        return v;
    }

    public void setNrGuia(NNumber value)
    {
        this.setValue("NR_GUIA", value.getValue());
    }

    public NString getDsClassificacao()
    {
        NString v = new NString((String) this.getValue("DS_CLASSIFICACAO"));
        return v;
    }

    public void setDsClassificacao(NString value)
    {
        this.setValue("DS_CLASSIFICACAO", value.getValue());
    }

    public NString getAbreviacaoOcorrencia()
    {
        NString v = new NString(
                (String) this.getValue("ABREVIACAO_OCORRENCIA"));
        return v;
    }

    public void setAbreviacaoOcorrencia(NString value)
    {
        this.setValue("ABREVIACAO_OCORRENCIA", value.getValue());
    }

    public NString getTpOcorrencia() {

		NString v = new NString((String) this.getValue("TP_OCORRENCIA"));
		return v;
	}

	public void setTpOcorrencia(NString value) {

		this.setValue("TP_OCORRENCIA", value.getValue());
	}

}

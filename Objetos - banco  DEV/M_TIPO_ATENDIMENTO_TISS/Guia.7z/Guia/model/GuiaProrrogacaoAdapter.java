package  br.com.mv.soul.mvsaude.forms.Guia.model;

import java.math.BigDecimal;
import java.util.Date;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	



public class GuiaProrrogacaoAdapter extends BaseRowAdapter{
	

	public GuiaProrrogacaoAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}

	
	//Data Columns
		     
	
	public void setNrGuia(NNumber value){
		 this.setValue("NR_GUIA", value.getValue());
	}


	public NNumber getNrGuia(){
		NNumber v = new NNumber((BigDecimal)this.getValue("NR_GUIA"));
		return v;
	}


	
	
	public void setSqGuiaProrrogacao(NNumber value){
		this.setValue("SQ_GUIA_PRORROGACAO", value.getValue());
	}


	public NNumber getSqGuiaProrrogacao(){
		NNumber v = new NNumber((BigDecimal)this.getValue("SQ_GUIA_PRORROGACAO"));
		return v;
	}


	
	
	public void setDtProrrogacao(NDate value){
		this.setValue("DT_PRORROGACAO", value.getValue());
	}


	public NDate getDtProrrogacao(){
		NDate v = new NDate((Date)this.getValue("DT_PRORROGACAO"));
		return v;
	}


	
	
	public void setNrDiasProrrogados(NNumber value){
		this.setValue("NR_DIAS_PRORROGADOS", value.getValue());
	}


	public NNumber getNrDiasProrrogados(){
		NNumber v = new NNumber((BigDecimal)this.getValue("NR_DIAS_PRORROGADOS"));
		return v;
	}


	
	
	public void setCdTipAcomodacao(NNumber value){
		this.setValue("CD_TIP_ACOMODACAO", value.getValue());
	}


	public NNumber getCdTipAcomodacao(){
		NNumber v = new NNumber((BigDecimal)this.getValue("CD_TIP_ACOMODACAO"));
		return v;
	}


	
	
	public void setObsProrrogacao(NString value){
		this.setValue("OBS_PRORROGACAO", value.getValue());
	}


	public NString getObsProrrogacao(){
		NString v = new NString((String)this.getValue("OBS_PRORROGACAO"));
		return v;
	}


	
	
	public void setCdAutorizador(NNumber value){
		this.setValue("CD_AUTORIZADOR", value.getValue());
	}


	public NNumber getCdAutorizador(){
		NNumber v = new NNumber((BigDecimal)this.getValue("CD_AUTORIZADOR"));
		return v;
	}


	
	
	public void setCdMotCancelamentoGuia(NNumber value){
		this.setValue("CD_MOT_CANCELAMENTO_GUIA", value.getValue());
	}


	public NNumber getCdMotCancelamentoGuia(){
		NNumber v = new NNumber((BigDecimal)this.getValue("CD_MOT_CANCELAMENTO_GUIA"));
		return v;
	}


	
	
	public void setDspDsMotCancelamentoGuia(NString value){
		this.setValue("DSP_DS_MOT_CANCELAMENTO_GUIA", value.getValue());
	}


	public NString getDspDsMotCancelamentoGuia(){
		NString v = new NString((String)this.getValue("DSP_DS_MOT_CANCELAMENTO_GUIA"));
		return v;
	}


	
	
	public void setDspNmAutorizador(NString value){
		this.setValue("DSP_NM_AUTORIZADOR", value.getValue());
	}


	public NString getDspNmAutorizador(){
		NString v = new NString((String)this.getValue("DSP_NM_AUTORIZADOR"));
		return v;
	}


	
	
	public void setDspTipAcomodacao(NString value){
		this.setValue("DSP_TIP_ACOMODACAO", value.getValue());
	}


	public NString getDspTipAcomodacao(){
		NString v = new NString((String)this.getValue("DSP_TIP_ACOMODACAO"));
		return v;
	}


	
	
	public void setDspSnAutorizado(NString value){
		this.setValue("DSP_SN_AUTORIZADO", value.getValue());
	}


	public NString getDspSnAutorizado(){
		NString v = new NString((String)this.getValue("DSP_SN_AUTORIZADO"));
		return v;
	}


	
	
	public void setSnAutorizado(NString value){
		this.setValue("SN_AUTORIZADO", value.getValue());
	}


	public NString getSnAutorizado(){
		NString v = new NString((String)this.getValue("SN_AUTORIZADO"));
		return v;
	}


	

	public NString getDsJustificativaOperadora() {
		NString v = new NString(
				(String) this.getValue("DS_JUSTIFICATIVA_OPERADORA"));
		return v;
	}


	public void setDsJustificativaOperadora(NString value) {
		this.setValue("DS_JUSTIFICATIVA_OPERADORA", value.getValue());
	}


	public NString getDsIndicacaoClinica() {
		NString v = new NString(
				(String) this.getValue("DS_INDICACAO_CLINICA"));
		return v;
	}


	public void setDsIndicacaoClinica(NString value) {
		this.setValue("DS_INDICACAO_CLINICA", value.getValue());
	}


	
}

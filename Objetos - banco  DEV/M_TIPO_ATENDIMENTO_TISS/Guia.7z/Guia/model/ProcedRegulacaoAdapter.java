package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class ProcedRegulacaoAdapter extends BaseRowAdapter {

	public ProcedRegulacaoAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getCdProcedRegulacao() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PROCED_REGULACAO"));
		return v;
	}
	
	public void setCdProcedRegulacao(NNumber value) {
		this.setValue("CD_PROCED_REGULACAO", value.getValue());
	}

	public NNumber getCdProcedTipoRegulacao() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PROCED_TIPO_REGULACAO"));
		return v;
	}
	
	public void setCdProcedTipoRegulacao(NNumber value) {
		this.setValue("CD_PROCED_TIPO_REGULACAO", value.getValue());
	}

	public NString getCdProcedimento() {
		NString v = new NString((String)this.getValue("CD_PROCEDIMENTO"));
		return v;
	}
	
	public void setCdProcedimento(NString value) {
		this.setValue("CD_PROCEDIMENTO", value.getValue());
	}

	public NString getDsTipo() {
		NString v = new NString((String)this.getValue("DS_TIPO"));
		return v;
	}
	
	public void setDsTipo(NString value) {
		this.setValue("DS_TIPO", value.getValue());
	}

	public NDate getDtInicioVigencia() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_INICIO_VIGENCIA"));
		return v;
	}
	
	public void setDtInicioVigencia(NDate value) {
		this.setValue("DT_INICIO_VIGENCIA", value.getValue());
	}

	public NString getSnVisualizarWeb() {
		NString v = new NString((String)this.getValue("SN_VISUALIZAR_WEB"));
		return v;
	}
	
	public void setSnVisualizarWeb(NString value) {
		this.setValue("SN_VISUALIZAR_WEB", value.getValue());
	}
	
	public NString getDspDsProcedTipoRegulacao() {

	    NString v = new NString((String) this.getValue("DSP_DS_PROCED_TIPO_REGULACAO"));
	    return v;
    }

	public void setDspDsProcedTipoRegulacao(NString value) {

	    this.setValue("DSP_DS_PROCED_TIPO_REGULACAO", value.getValue());
    }

}

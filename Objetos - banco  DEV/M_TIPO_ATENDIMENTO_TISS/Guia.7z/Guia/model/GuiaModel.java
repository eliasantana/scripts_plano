package br.com.mv.soul.mvsaude.forms.Guia.model;

import java.util.Hashtable;
import morphis.foundations.core.appsupportlib.model.*;
import morphis.foundations.core.appsupportlib.runtime.*;
import br.com.mv.soul.common.forms.model.DefaultFormModel;


public class GuiaModel extends DefaultFormModel {
	
	public GuiaModel(ITask task, Hashtable parameters) {
		super(task, parameters);
	}

	public ImpGuia getImpGuia() {
		return (ImpGuia) getBusinessObject("IMP_GUIA");
	}

	public CgCtrl getCgCtrl() {
		return (CgCtrl) getBusinessObject("CG$CTRL");
	}

	public AlteracaoGuia getAlteracaoGuia() {
		return (AlteracaoGuia) getBusinessObject("ALTERACAO_GUIA");
	}

	public MConRecForms getMConRecForms() {
		return (MConRecForms) getBusinessObject("M_CON_REC_FORMS");
	}

	public NegacaoItem getNegacaoItem() {
		return (NegacaoItem) getBusinessObject("NEGACAO_ITEM");
	}

	public AnexoTextoGuia getAnexoTextoGuia() {
		return (AnexoTextoGuia) getBusinessObject("ANEXO_TEXTO_GUIA");
	}

	public FiltroHistoricoAut getFiltroHistoricoAut() {
		return (FiltroHistoricoAut) getBusinessObject("FILTRO_HISTORICO_AUT");
	}

	public FiltroPrestExterno getFiltroPrestExterno() {
		return (FiltroPrestExterno) getBusinessObject("FILTRO_PREST_EXTERNO");
	}
	
	public IDBBusinessObject getGuia() {
		return (IDBBusinessObject) getBusinessObject("GUIA");
	}

	public IDBBusinessObject getItguia() {
		return (IDBBusinessObject) getBusinessObject("ITGUIA");
	}

	public IDBBusinessObject getItguiaPro() {
		return (IDBBusinessObject) getBusinessObject("ITGUIA_PRO");
	}

	public IDBBusinessObject getLogAutoriza() {
		return (IDBBusinessObject) getBusinessObject("LOG_AUTORIZA");
	}

	public IDBBusinessObject getGuiaProrrogacao() {
		return (IDBBusinessObject) getBusinessObject("GUIA_PRORROGACAO");
	}

	public IDBBusinessObject getItguiaErros() {
		return (IDBBusinessObject) getBusinessObject("ITGUIA_ERROS");
	}

	public IDBBusinessObject getItguiaErrosPro() {
		return (IDBBusinessObject) getBusinessObject("ITGUIA_ERROS_PRO");
	}

	public IDBBusinessObject getMensContrato() {
		return (IDBBusinessObject) getBusinessObject("MENS_CONTRATO");
	}

	public IDBBusinessObject getEnviarEmail() {
		return (IDBBusinessObject) getBusinessObject("ENVIAR_EMAIL");
	}

	public IDBBusinessObject getGuiaAnexo() {
		return (IDBBusinessObject) getBusinessObject("GUIA_ANEXO");
	}

	public IDBBusinessObject getGuiaOcorrencia() {
		return (IDBBusinessObject) getBusinessObject("GUIA_OCORRENCIA");
	}

	public IDBBusinessObject getPacote() {
		return (IDBBusinessObject) getBusinessObject("PACOTE");
	}

	public IDBBusinessObject getProcedRegulacao() {
		return (IDBBusinessObject) getBusinessObject("PROCED_REGULACAO");
	}

	public IDBBusinessObject getGuiasAssociadas() {
		return (IDBBusinessObject) getBusinessObject("GUIAS_ASSOCIADAS");
	}

	public IDBBusinessObject getGuiaHonorario() {
		return (IDBBusinessObject) getBusinessObject("GUIA_HONORARIO");
	}

	public IDBBusinessObject getGuiaProrrogacaoTot() {
		return (IDBBusinessObject) getBusinessObject("GUIA_PRORROGACAO_TOT");
	}

	public IDBBusinessObject getSmsModelo() {
		return (IDBBusinessObject) getBusinessObject("SMS_MODELO");
	}

	public IDBBusinessObject getItguiaMensagemEspecifica() {
		return (IDBBusinessObject) getBusinessObject("ITGUIA_MENSAGEM_ESPECIFICA");
	}

	public IDBBusinessObject getItguiaAuditoria() {
		return (IDBBusinessObject) getBusinessObject("ITGUIA_AUDITORIA");
	}

	public IDBBusinessObject getItguiasAssociadas() {
		return (IDBBusinessObject) getBusinessObject("ITGUIAS_ASSOCIADAS");
	}

	public IDBBusinessObject getGuiaHistoricoResponsavel() {
		return (IDBBusinessObject) getBusinessObject("GUIA_HISTORICO_RESPONSAVEL");
	}

	public IDBBusinessObject getChatMensagem() {
		return (IDBBusinessObject) getBusinessObject("CHAT_MENSAGEM");
	}

	public IDBBusinessObject getItguiaExecucao() {
		return (IDBBusinessObject) getBusinessObject("ITGUIA_EXECUCAO");
	}

	public IDBBusinessObject getLogTransacaoPtuOnline() {
		return (IDBBusinessObject) getBusinessObject("LOG_TRANSACAO_PTU_ONLINE");
	}

	public IDBBusinessObject getItguiaOculos() {
		return (IDBBusinessObject) getBusinessObject("ITGUIA_OCULOS");
	}

	public IDBBusinessObject getHistoricoAut() {
		return (IDBBusinessObject) getBusinessObject("HISTORICO_AUT");
	}

	public IDBBusinessObject getItguiaPericia() {
		return (IDBBusinessObject) getBusinessObject("ITGUIA_PERICIA");
	}

	public IDBBusinessObject getItguiaTaxa() {
		return (IDBBusinessObject) getBusinessObject("ITGUIA_TAXA");
	}

	public IDBBusinessObject getItguiaRateioCopart() {
		return (IDBBusinessObject) getBusinessObject("ITGUIA_RATEIO_COPART");
	}

	public IDBBusinessObject getPrestExterno() {
		return (IDBBusinessObject) getBusinessObject("PREST_EXTERNO");
	}
}
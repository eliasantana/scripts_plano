package br.com.mv.soul.mvsaude.forms.Guia.model;

import java.math.BigDecimal;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class GuiasAssociadasAdapter extends BaseRowAdapter {

	public GuiasAssociadasAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getNrGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA"));
		return v;
	}
	
	public void setNrGuia(NNumber value) {
		this.setValue("NR_GUIA", value.getValue());
	}

	
	
	

	
	
	

	
	
	

	
	
	

	public NNumber getCdPrestadorExecutor() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_PRESTADOR_EXECUTOR"));
		return v;
	}
	
	public void setCdPrestadorExecutor(NNumber value) {
		this.setValue("CD_PRESTADOR_EXECUTOR", value.getValue());
	}

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	public NNumber getNrGuiaTem() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA_TEM"));
		return v;
	}
	
	public void setNrGuiaTem(NNumber value) {
		this.setValue("NR_GUIA_TEM", value.getValue());
	}

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	
	
	public NString getDspNmPrestador() {

		NString v = new NString((String) this.getValue("DSP_NM_PRESTADOR"));
		return v;
	}

	public void setDspNmPrestador(NString value) {

		this.setValue("DSP_NM_PRESTADOR", value.getValue());
	}

	public NString getDspDsTpGuia() {

		NString v = new NString((String) this.getValue("DSP_DS_TP_GUIA"));
		return v;
	}

	public void setDspDsTpGuia(NString value) {

		this.setValue("DSP_DS_TP_GUIA", value.getValue());
	}

	

	

	public NNumber getCdTipoAtendimento() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_TIPO_ATENDIMENTO"));
		return v;
	}

	public void setCdTipoAtendimento(NNumber value) {

		this.setValue("CD_TIPO_ATENDIMENTO", value.getValue());
	}

	public NString getSnValidaRestCarencia() {

		NString v = new NString((String) this.getValue("SN_VALIDA_REST_CARENCIA"));
		return v;
	}

	public void setSnValidaRestCarencia(NString value) {

		this.setValue("SN_VALIDA_REST_CARENCIA", value.getValue());
	}

	public NNumber getCdAutorizador() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_AUTORIZADOR"));
		return v;
	}

	public void setCdAutorizador(NNumber value) {

		this.setValue("CD_AUTORIZADOR", value.getValue());
	}

	public NString getDspNmAutorizador() {

		NString v = new NString((String) this.getValue("DSP_NM_AUTORIZADOR"));
		return v;
	}

	public void setDspNmAutorizador(NString value) {

		this.setValue("DSP_NM_AUTORIZADOR", value.getValue());
	}

	public NDate getDtAutorizacao() {

		NDate v = new NDate((java.util.Date) this.getValue("DT_AUTORIZACAO"));
		return v;
	}

	public void setDtAutorizacao(NDate value) {

		this.setValue("DT_AUTORIZACAO", value.getValue());
	}

	public NString getNrTransacao() {
		NString v = new NString((String) this.getValue("NR_TRANSACAO"));
		return v;
	}

	public void setNrTransacao(NString value) {

		this.setValue("NR_TRANSACAO", value.getValue());
	}

	public NNumber getNrGuiaProcedimento() {

		NNumber v = new NNumber((BigDecimal) this.getValue("NR_GUIA_PROCEDIMENTO"));
		return v;
	}

	public void setNrGuiaProcedimento(NNumber value) {

		this.setValue("NR_GUIA_PROCEDIMENTO", value.getValue());
	}

}

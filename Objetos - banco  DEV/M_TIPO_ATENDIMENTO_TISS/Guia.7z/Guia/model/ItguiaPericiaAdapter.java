package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class ItguiaPericiaAdapter extends BaseRowAdapter {

	public ItguiaPericiaAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getNrGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA"));
		return v;
	}
	
	public void setNrGuia(NNumber value) {
		this.setValue("NR_GUIA", value.getValue());
	}

	public NString getCdProcedimento() {
		NString v = new NString((String)this.getValue("CD_PROCEDIMENTO"));
		return v;
	}
	
	public void setCdProcedimento(NString value) {
		this.setValue("CD_PROCEDIMENTO", value.getValue());
	}

	public NString getSnRespostaPerito() {
		NString v = new NString((String)this.getValue("SN_RESPOSTA_PERITO"));
		return v;
	}
	
	public void setSnRespostaPerito(NString value) {
		this.setValue("SN_RESPOSTA_PERITO", value.getValue());
	}

	public NString getDsObservacaoPerito() {
		NString v = new NString((String)this.getValue("DS_OBSERVACAO_PERITO"));
		return v;
	}
	
	public void setDsObservacaoPerito(NString value) {
		this.setValue("DS_OBSERVACAO_PERITO", value.getValue());
	}
	
	public NString getDspDsProcedimento() {

		NString v = new NString((String) this.getValue("DSP_DS_PROCEDIMENTO"));
		return v;
	}

	public void setDspDsProcedimento(NString value) {

		this.setValue("DSP_DS_PROCEDIMENTO", value.getValue());
	}

}

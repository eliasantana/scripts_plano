package br.com.mv.soul.mvsaude.forms.Guia.model;

import static morphis.foundations.core.types.Types.toStr;

import morphis.foundations.core.appsupportlib.model.SimpleBusinessObject;
import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class MConRecForms extends SimpleBusinessObject {

	public MConRecForms() {
		super();
	}

	public MConRecForms(SimpleBusinessObjectConfiguration configuration, String name) {
		 super(configuration, name);
	}
	
	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

    public NString getDsUrlTelaForms()
    {
        return toStr(super.getValue("DS_URL_TELA_FORMS"));
    }

    public void setDsUrlTelaForms(NString value)
    {
        super.setValue("DS_URL_TELA_FORMS", value);
    }
}

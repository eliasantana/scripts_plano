package br.com.mv.soul.mvsaude.forms.Guia.model;

import java.math.BigDecimal;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class LogAutorizaAdapter extends BaseRowAdapter {

	public LogAutorizaAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getCdLogAutoriza() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_LOG_AUTORIZA"));
		 return v;
	}
	
	public void setCdLogAutoriza(NNumber value) {
		this.setValue("CD_LOG_AUTORIZA", value.getValue());
	}

	public NNumber getNrGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA"));
		return v;
	}
	
	public void setNrGuia(NNumber value) {
		this.setValue("NR_GUIA", value.getValue());
	}

	public NDate getDtAcao() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_ACAO"));
		return v;
	}
	
	public void setDtAcao(NDate value) {
		this.setValue("DT_ACAO", value.getValue());
	}

	public NString getDsFuncionalidade() {
		NString v = new NString((String)this.getValue("DS_FUNCIONALIDADE"));
		return v;
	}
	
	public void setDsFuncionalidade(NString value) {
		this.setValue("DS_FUNCIONALIDADE", value.getValue());
	}

	public NString getNmUsuarioOracle() {
		NString v = new NString((String)this.getValue("NM_USUARIO_ORACLE"));
		return v;
	}
	
	public void setNmUsuarioOracle(NString value) {
		this.setValue("NM_USUARIO_ORACLE", value.getValue());
	}

	public NNumber getCdAutorizadorLog() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_AUTORIZADOR"));
		return v;
	}
	
	public void setCdAutorizadorLog(NNumber value) {
		this.setValue("CD_AUTORIZADOR", value.getValue());
	}

	public NString getDspDsAutorizadorLog() {
		NString v = new NString((String)this.getValue("DSP_DS_AUTORIZADOR_LOG"));
		return v;
	}
	
	public void setDspDsAutorizadorLog(NString value) {
		this.setValue("DSP_DS_AUTORIZADOR_LOG", value.getValue());
	}
	
	public NString getCdProcedimento()
	{
		NString v = new NString((String) this.getValue("CD_PROCEDIMENTO"));
		return v;
	}

	public void setCdProcedimento(NString value)
	{
		this.setValue("CD_PROCEDIMENTO", value.getValue());
	}

	public NNumber getValorAnterior()
	{
		NNumber v = new NNumber((BigDecimal) this.getValue("VALOR_ANTERIOR"));
		return v;
	}

	public void setValorAnterior(NNumber value)
	{
		this.setValue("VALOR_ANTERIOR", value.getValue());
	}

	public NNumber getValorNovo()
	{
		NNumber v = new NNumber((BigDecimal) this.getValue("VALOR_NOVO"));
		return v;
	}

	public void setValorNovo(NNumber value)
	{
		this.setValue("VALOR_NOVO", value.getValue());
	}

	public NString getDsValorAntigo() {
		NString v = new NString((String) this.getValue("DS_VALOR_ANTIGO"));
		return v;
	}

	public void setDsValorAntigo(NString value) {
		this.setValue("DS_VALOR_ANTIGO", value.getValue());
	}

	public NString getDsValorNovo() {
		NString v = new NString((String) this.getValue("DS_VALOR_NOVO"));
		return v;
	}

	public void setDsValorNovo(NString value) {
		this.setValue("DS_VALOR_NOVO", value.getValue());
	}

	public NNumber getCdPrestador() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_PRESTADOR"));
		return v;
	}

	public void setCdPrestador(NNumber value) {

		this.setValue("CD_PRESTADOR", value.getValue());
	}

}

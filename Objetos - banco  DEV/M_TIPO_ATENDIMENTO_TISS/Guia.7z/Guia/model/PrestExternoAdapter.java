package br.com.mv.soul.mvsaude.forms.Guia.model;

import java.util.Date;
import java.math.BigDecimal;
import org.jdesktop.databuffer.DataRow;
//import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.types.*;
import morphis.foundations.core.appsupportlib.model.*;
import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;

public class PrestExternoAdapter extends BaseRowAdapter {

	public PrestExternoAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NString getCpfCnpj() {
		NString v = new NString((String)this.getValue("CPF_CNPJ"));
		return v;
	}
	
	public void setCpfCnpj(NString value) {
		this.setValue("CPF_CNPJ", value.getValue());
	}

	public NString getDsNome() {
		NString v = new NString((String)this.getValue("DS_NOME"));
		return v;
	}
	
	public void setDsNome(NString value) {
		this.setValue("DS_NOME", value.getValue());
	}

}
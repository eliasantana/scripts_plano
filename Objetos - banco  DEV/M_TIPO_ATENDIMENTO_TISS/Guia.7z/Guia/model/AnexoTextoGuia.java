package br.com.mv.soul.mvsaude.forms.Guia.model;

import morphis.foundations.core.appsupportlib.model.SimpleBusinessObject;
import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.*;
import static morphis.foundations.core.types.Types.*;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class AnexoTextoGuia extends SimpleBusinessObject {

	public AnexoTextoGuia() {
		super();
	}

	public AnexoTextoGuia(SimpleBusinessObjectConfiguration configuration, String name) {
		super(configuration, name);
	}
	
	public NString getDspDsAnexoTexto() {
		return toStr(super.getValue("DSP_DS_ANEXO_TEXTO"));
	}
	
	public void setDspDsAnexoTexto(NString value) {
		super.setValue("DSP_DS_ANEXO_TEXTO", value);
	}

	public NString getDspDsAnexoTextoAntigo() {

		return toStr(super.getValue("DSP_DS_ANEXO_TEXTO_ANTIGO"));
	}

	public void setDspDsAnexoTextoAntigo(NString value) {

		super.setValue("DSP_DS_ANEXO_TEXTO_ANTIGO", value);
	}
}

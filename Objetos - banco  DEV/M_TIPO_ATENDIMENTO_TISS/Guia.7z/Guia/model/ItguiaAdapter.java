package br.com.mv.soul.mvsaude.forms.Guia.model;

import java.math.BigDecimal;
import java.util.Date;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class ItguiaAdapter extends BaseRowAdapter {

	public ItguiaAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getNrGuia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA"));
		 return v;
	}
	
	public void setNrGuia(NNumber value) {
		this.setValue("NR_GUIA", value.getValue());
	}

	public NNumber getNrGuiaProrrogacao() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_GUIA_PRORROGACAO"));
		return v;
	}
	
	public void setNrGuiaProrrogacao(NNumber value) {
		this.setValue("NR_GUIA_PRORROGACAO", value.getValue());
	}

	public NNumber getSqGuiaProrrogacao() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("SQ_GUIA_PRORROGACAO"));
		return v;
	}
	
	public void setSqGuiaProrrogacao(NNumber value) {
		this.setValue("SQ_GUIA_PRORROGACAO", value.getValue());
	}

	public NString getCdProcedimento() {
		NString v = new NString((String)this.getValue("CD_PROCEDIMENTO"));
		return v;
	}
	
	public void setCdProcedimento(NString value) {
		this.setValue("CD_PROCEDIMENTO", value.getValue());
	}

	public NString getDspDsProcedimento() {
		NString v = new NString((String)this.getValue("DSP_DS_PROCEDIMENTO"));
		return v;
	}
	
	public void setDspDsProcedimento(NString value) {
		this.setValue("DSP_DS_PROCEDIMENTO", value.getValue());
	}

	public NNumber getDspCdGruCarencia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_CD_GRU_CARENCIA"));
		return v;
	}
	
	public void setDspCdGruCarencia(NNumber value) {
		this.setValue("DSP_CD_GRU_CARENCIA", value.getValue());
	}

	public NNumber getDspCdGruDireito() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_CD_GRU_DIREITO"));
		return v;
	}
	
	public void setDspCdGruDireito(NNumber value) {
		this.setValue("DSP_CD_GRU_DIREITO", value.getValue());
	}

	public NNumber getDspQtMaximaSolic() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_QT_MAXIMA_SOLIC"));
		return v;
	}
	
	public void setDspQtMaximaSolic(NNumber value) {
		this.setValue("DSP_QT_MAXIMA_SOLIC", value.getValue());
	}

	public NString getDspCdProcedimentoAuxiliar() {
		NString v = new NString((String)this.getValue("DSP_CD_PROCEDIMENTO_AUXILIAR"));
		return v;
	}
	
	public void setDspCdProcedimentoAuxiliar(NString value) {
		this.setValue("DSP_CD_PROCEDIMENTO_AUXILIAR", value.getValue());
	}

	public NString getDspTpGuia() {
		NString v = new NString((String)this.getValue("DSP_TP_GUIA"));
		return v;
	}
	
	public void setDspTpGuia(NString value) {
		this.setValue("DSP_TP_GUIA", value.getValue());
	}

	public NNumber getDspNrDiasInternacao() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_NR_DIAS_INTERNACAO"));
		return v;
	}
	
	public void setDspNrDiasInternacao(NNumber value) {
		this.setValue("DSP_NR_DIAS_INTERNACAO", value.getValue());
	}

	public NNumber getDspNrNivelAutorizacao() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_NR_NIVEL_AUTORIZACAO"));
		return v;
	}
	
	public void setDspNrNivelAutorizacao(NNumber value) {
		this.setValue("DSP_NR_NIVEL_AUTORIZACAO", value.getValue());
	}

	public NNumber getQtSolicPrest() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("QT_SOLIC_PREST"));
		return v;
	}
	
	public void setQtSolicPrest(NNumber value) {
		this.setValue("QT_SOLIC_PREST", value.getValue());
	}

	public NNumber getQtSolicitado() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("QT_SOLICITADO"));
		return v;
	}
	
	public void setQtSolicitado(NNumber value) {
		this.setValue("QT_SOLICITADO", value.getValue());
	}

	public NNumber getVlProcedimento() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_PROCEDIMENTO"));
		return v;
	}
	
	public void setVlProcedimento(NNumber value) {
		this.setValue("VL_PROCEDIMENTO", value.getValue());
	}

	public NNumber getDspVlTotalProcedimento() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_VL_TOTAL_PROCEDIMENTO"));
		return v;
	}
	
	public void setDspVlTotalProcedimento(NNumber value) {
		this.setValue("DSP_VL_TOTAL_PROCEDIMENTO", value.getValue());
	}

	public NNumber getVlFranquia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("VL_FRANQUIA"));
		return v;
	}
	
	public void setVlFranquia(NNumber value) {
		this.setValue("VL_FRANQUIA", value.getValue());
	}

	public NNumber getDspVlTotalFranquia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_VL_TOTAL_FRANQUIA"));
		return v;
	}
	
	public void setDspVlTotalFranquia(NNumber value) {
		this.setValue("DSP_VL_TOTAL_FRANQUIA", value.getValue());
	}

	public NDate getDtBaixado() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_BAIXADO"));
		return v;
	}
	
	public void setDtBaixado(NDate value) {
		this.setValue("DT_BAIXADO", value.getValue());
	}

	public NNumber getCdTabelaFaturamento() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_TABELA_FATURAMENTO"));
		return v;
	}
	
	public void setCdTabelaFaturamento(NNumber value) {
		this.setValue("CD_TABELA_FATURAMENTO", value.getValue());
	}

	public NNumber getCdItguia() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_ITGUIA"));
		return v;
	}
	
	public void setCdItguia(NNumber value) {
		this.setValue("CD_ITGUIA", value.getValue());
	}

	public NNumber getNrSenha() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("NR_SENHA"));
		return v;
	}
	
	public void setNrSenha(NNumber value) {
		this.setValue("NR_SENHA", value.getValue());
	}

	public NString getTpStatus() {
		NString v = new NString((String)this.getValue("TP_STATUS"));
		return v;
	}
	
	public void setTpStatus(NString value) {
		this.setValue("TP_STATUS", value.getValue());
	}

	public NString getDspTpStatus() {
		NString v = new NString((String)this.getValue("DSP_TP_STATUS"));
		return v;
	}
	
	public void setDspTpStatus(NString value) {
		this.setValue("DSP_TP_STATUS", value.getValue());
	}
	
	public NNumber getValorOriginalProcedimento() {
		NNumber v = new NNumber((BigDecimal) this.getValue("VALOR_ORIGINAL_PROCEDIMENTO"));
		return v;
	}

	public void setValorOriginalProcedimento(NNumber value) {
		this.setValue("VALOR_ORIGINAL_PROCEDIMENTO", value.getValue());
	}

	

	

	

	

	

	

	

	

	

	

	

	

	

	

	public NDate getDtRealizacao() {
		NDate v = new NDate((Date) this.getValue("DT_REALIZACAO"));
		return v;
	}

	public void setDtRealizacao(NDate value) {
		this.setValue("DT_REALIZACAO", value.getValue());
	}

	public NString getCdRegiaoDente() {
		NString v = new NString((String) this.getValue("CD_REGIAO_DENTE"));
		return v;
	}

	public void setCdRegiaoDente(NString value) {
		this.setValue("CD_REGIAO_DENTE", value.getValue());
	}

	

	

	

	

	

	

	public NString getDsRegiaoDente() {
		NString v = new NString((String) this.getValue("DS_REGIAO_DENTE"));
		return v;
	}

	public void setDsRegiaoDente(NString value) {
		this.setValue("DS_REGIAO_DENTE", value.getValue());
	}

	

	

	public NString getNrAnvisa() {
		NString v = new NString((String) this.getValue("NR_ANVISA"));
		return v;
	}

	public void setNrAnvisa(NString value) {
		this.setValue("NR_ANVISA", value.getValue());
	}

	public NString getCdMaterialFabricante() {
		NString v = new NString(
				(String) this.getValue("CD_MATERIAL_FABRICANTE"));
		return v;
	}

	public void setCdMaterialFabricante(NString value) {
		this.setValue("CD_MATERIAL_FABRICANTE", value.getValue());
	}

	public NString getNrAutorizacaoFuncionamento() {
		NString v = new NString(
				(String) this.getValue("NR_AUTORIZACAO_FUNCIONAMENTO"));
		return v;
	}

	public void setNrAutorizacaoFuncionamento(NString value) {
		this.setValue("NR_AUTORIZACAO_FUNCIONAMENTO", value.getValue());
	}

	public NNumber getCdViaAdministracao() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("CD_VIA_ADMINISTRACAO"));
		return v;
	}

	public void setCdViaAdministracao(NNumber value) {
		this.setValue("CD_VIA_ADMINISTRACAO", value.getValue());
	}

	public NDate getDtProvavel() {
		NDate v = new NDate((Date) this.getValue("DT_PROVAVEL"));
		return v;
	}

	public void setDtProvavel(NDate value) {
		this.setValue("DT_PROVAVEL", value.getValue());
	}

	public NNumber getQtSolicitadoDia() {
		NNumber v = new NNumber(
				(BigDecimal) this.getValue("QT_SOLICITADO_DIA"));
		return v;
	}

	public void setQtSolicitadoDia(NNumber value) {
		this.setValue("QT_SOLICITADO_DIA", value.getValue());
	}

	public NNumber getVlSolicitado() {
		NNumber v = new NNumber((BigDecimal) this.getValue("VL_SOLICITADO"));
		return v;
	}

	public void setVlSolicitado(NNumber value) {
		this.setValue("VL_SOLICITADO", value.getValue());
	}

	public NString getNrOrdemPreferencia() {
		NString v = new NString(
				(String) this.getValue("NR_ORDEM_PREFERENCIA"));
		return v;
	}

	public void setNrOrdemPreferencia(NString value) {
		this.setValue("NR_ORDEM_PREFERENCIA", value.getValue());
	}

	public NString getSnPrestadorExecutorOpme() {
		NString v = new NString(
				(String) this.getValue("SN_PRESTADOR_EXECUTOR_OPME"));
		return v;
	}

	public void setSnPrestadorExecutorOpme(NString value) {
		this.setValue("SN_PRESTADOR_EXECUTOR_OPME", value.getValue());
	}

	public NNumber getQtFranquia() {
		NNumber v = new NNumber((BigDecimal) this.getValue("QT_FRANQUIA"));
		return v;
	}

	public void setQtFranquia(NNumber value) {
		this.setValue("QT_FRANQUIA", value.getValue());
	}

	public NNumber getVlFranquiaCalculado() {

	    NNumber v = new NNumber((BigDecimal) this.getValue("VL_FRANQUIA_CALCULADO"));
	    return v;
    }

	public void setVlFranquiaCalculado(NNumber value) {

	    this.setValue("VL_FRANQUIA_CALCULADO", value.getValue());
    }

	public NDate getDtAlteracaoFranquia() {

	    NDate v = new NDate((Date) this.getValue("DT_ALTERACAO_FRANQUIA"));
	    return v;
    }

	public void setDtAlteracaoFranquia(NDate value) {

	    this.setValue("DT_ALTERACAO_FRANQUIA", value.getValue());
    }

	public NString getCdUsuarioAlteracaoFranquia() {

	    NString v = new NString((String) this.getValue("CD_USUARIO_ALTERACAO_FRANQUIA"));
	    return v;
    }

	public void setCdUsuarioAlteracaoFranquia(NString value) {

	    this.setValue("CD_USUARIO_ALTERACAO_FRANQUIA", value.getValue());
    }

	public NString getDsJustificativaAltFranq() {

	    NString v = new NString((String) this.getValue("DS_JUSTIFICATIVA_ALT_FRANQ"));
	    return v;
    }

	public void setDsJustificativaAltFranq(NString value) {

	    this.setValue("DS_JUSTIFICATIVA_ALT_FRANQ", value.getValue());
    }

	public NNumber getCdMotivo() {

	    NNumber v = new NNumber((BigDecimal) this.getValue("CD_MOTIVO"));
	    return v;
    }

	public void setCdMotivo(NNumber value) {

	    this.setValue("CD_MOTIVO", value.getValue());
    }

	public NDate getDtNegacao() {

	    NDate v = new NDate((Date) this.getValue("DT_NEGACAO"));
	    return v;
    }

	public void setDtNegacao(NDate value) {

	    this.setValue("DT_NEGACAO", value.getValue());
    }

	public NString getCdUsuarioNegacao() {

	    NString v = new NString((String) this.getValue("CD_USUARIO_NEGACAO"));
	    return v;
    }

	public void setCdUsuarioNegacao(NString value) {

	    this.setValue("CD_USUARIO_NEGACAO", value.getValue());
    }

	public NString getDspDsMotivo() {

	    NString v = new NString((String) this.getValue("DSP_DS_MOTIVO"));
	    return v;
    }

	public void setDspDsMotivo(NString value) {

	    this.setValue("DSP_DS_MOTIVO", value.getValue());
    }

	public NString getDsProcedimento() {

		NString v = new NString((String) this.getValue("DS_PROCEDIMENTO"));
		return v;
	}

	public void setDsProcedimento(NString value) {

		this.setValue("DS_PROCEDIMENTO", value.getValue());
	}

	public NString getCdUnidadeMedida() {
		NString v = new NString((String) this.getValue("CD_UNIDADE_MEDIDA"));
		return v;
	}

	public void setCdUnidadeMedida(NString value) {

		this.setValue("CD_UNIDADE_MEDIDA", value.getValue());
	}

	public NString getDspDsUnidadeMedida() {

		NString v = new NString((String) this.getValue("DSP_DS_UNIDADE_MEDIDA"));
		return v;
	}

	public void setDspDsUnidadeMedida(NString value) {

		this.setValue("DSP_DS_UNIDADE_MEDIDA", value.getValue());
	}

	public NString getDsTermoUnidadeMedida() {

		NString v = new NString((String) this.getValue("DS_TERMO_UNIDADE_MEDIDA"));
		return v;
	}

	public void setDsTermoUnidadeMedida(NString value) {

		this.setValue("DS_TERMO_UNIDADE_MEDIDA", value.getValue());
	}

	public NString getSnBaixoRisco() {

		NString v = new NString((String) this.getValue("SN_BAIXO_RISCO"));
		return v;
	}

	public void setSnBaixoRisco(NString value) {

		this.setValue("SN_BAIXO_RISCO", value.getValue());
	}

	public NString getSnCobraCusto() {

		NString v = new NString((String) this.getValue("SN_COBRA_CUSTO"));
		return v;
	}

	public void setSnCobraCusto(NString value) {

		this.setValue("SN_COBRA_CUSTO", value.getValue());
	}

	public NNumber getTpStatusPtuOs() {

		NNumber v = new NNumber((BigDecimal) this.getValue("TP_STATUS_PTU_OS"));
		return v;
	}

	public void setTpStatusPtuOs(NNumber value) {

		this.setValue("TP_STATUS_PTU_OS", value.getValue());
	}

	public NString getTpIndicadorAnexo() {

		NString v = new NString((String) this.getValue("TP_INDICADOR_ANEXO"));
		return v;
	}

	public void setTpIndicadorAnexo(NString value) {

		this.setValue("TP_INDICADOR_ANEXO", value.getValue());
	}

	public NNumber getQtTotalDosagemCiclo() {

		NNumber v = new NNumber((BigDecimal) this.getValue("QT_TOTAL_DOSAGEM_CICLO"));
		return v;
	}

	public void setQtTotalDosagemCiclo(NNumber value) {

		this.setValue("QT_TOTAL_DOSAGEM_CICLO", value.getValue());
	}

	public NString getSnPacotePtu() {

		NString v = new NString((String) this.getValue("SN_PACOTE_PTU"));
		return v;
	}

	public void setSnPacotePtu(NString value) {

		this.setValue("SN_PACOTE_PTU", value.getValue());
	}

	public NNumber getCdMotivoPtuOnline() {
		NNumber v = new NNumber((BigDecimal) this.getValue("CD_MOTIVO_PTU_ONLINE"));
		return v;
	}

	public void setCdMotivoPtuOnline(NNumber value) {

		this.setValue("CD_MOTIVO_PTU_ONLINE", value.getValue());
	}

	public NNumber getVlCobrado() {

		NNumber v = new NNumber((BigDecimal) this.getValue("VL_COBRADO"));
		return v;
	}

	public void setVlCobrado(NNumber value) {

		this.setValue("VL_COBRADO", value.getValue());
	}

	public NString getDspTpNatureza() {

		NString v = new NString((String) this.getValue("DSP_TP_NATUREZA"));
		return v;
	}

	public void setDspTpNatureza(NString value) {

		this.setValue("DSP_TP_NATUREZA", value.getValue());
	}

	public NString getCdFacesDentesOdonto() {

		NString v = new NString((String) this.getValue("CD_FACES_DENTES_ODONTO"));
		return v;
	}

	public void setCdFacesDentesOdonto(NString value) {

		this.setValue("CD_FACES_DENTES_ODONTO", value.getValue());
	}

	public NString getSnRespostaPerito() {

		NString v = new NString((String) this.getValue("SN_RESPOSTA_PERITO"));
		return v;
	}

	public void setSnRespostaPerito(NString value) {

		this.setValue("SN_RESPOSTA_PERITO", value.getValue());
	}

	public NString getDsObservacaoPerito() {

		NString v = new NString((String) this.getValue("DS_OBSERVACAO_PERITO"));
		return v;
	}

	public void setDsObservacaoPerito(NString value) {

		this.setValue("DS_OBSERVACAO_PERITO", value.getValue());
	}

	public NNumber getVlUnitarioAutorizado() {
		NNumber v = new NNumber((BigDecimal) this.getValue("VL_UNITARIO_AUTORIZADO"));
		return v;
	}

	public void setVlUnitarioAutorizado(NNumber value) {
		this.setValue("VL_UNITARIO_AUTORIZADO", value.getValue());
	}

	public NNumber getNrSqItemTiss() {

		NNumber v = new NNumber((BigDecimal) this.getValue("NR_SQ_ITEM_TISS"));
		return v;
	}

	public void setNrSqItemTiss(NNumber value) {

		this.setValue("NR_SQ_ITEM_TISS", value.getValue());
	}

	

	

}

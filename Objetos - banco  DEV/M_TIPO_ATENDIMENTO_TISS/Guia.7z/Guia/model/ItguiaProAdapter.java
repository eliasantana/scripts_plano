package  br.com.mv.soul.mvsaude.forms.Guia.model;

import java.math.BigDecimal;
import java.util.Date;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	



public class ItguiaProAdapter extends BaseRowAdapter{
	

	public ItguiaProAdapter(DataRow row, IDBBusinessObject businessObject) {
		 super(row, businessObject);
	}

	
	//Data Columns
		     
	
	public void setNrGuia(NNumber value){
		this.setValue("NR_GUIA", value.getValue());
	}


	public NNumber getNrGuia(){
		NNumber v = new NNumber((BigDecimal)this.getValue("NR_GUIA"));
		return v;
	}


	
	
	public void setNrGuiaProrrogacao(NNumber value){
		this.setValue("NR_GUIA_PRORROGACAO", value.getValue());
	}


	public NNumber getNrGuiaProrrogacao(){
		NNumber v = new NNumber((BigDecimal)this.getValue("NR_GUIA_PRORROGACAO"));
		return v;
	}


	
	
	public void setSqGuiaProrrogacao(NNumber value){
		this.setValue("SQ_GUIA_PRORROGACAO", value.getValue());
	}


	public NNumber getSqGuiaProrrogacao(){
		NNumber v = new NNumber((BigDecimal)this.getValue("SQ_GUIA_PRORROGACAO"));
		return v;
	}


	
	
	public void setCdProcedimento(NString value){
		this.setValue("CD_PROCEDIMENTO", value.getValue());
	}


	public NString getCdProcedimento(){
		NString v = new NString((String)this.getValue("CD_PROCEDIMENTO"));
		return v;
	}


	
	
	public void setDspDsProcedimento(NString value){
		this.setValue("DSP_DS_PROCEDIMENTO", value.getValue());
	}


	public NString getDspDsProcedimento(){
		NString v = new NString((String)this.getValue("DSP_DS_PROCEDIMENTO"));
		return v;
	}


	
	
	public void setDspCdGruCarencia(NNumber value){
		this.setValue("DSP_CD_GRU_CARENCIA", value.getValue());
	}


	public NNumber getDspCdGruCarencia(){
		NNumber v = new NNumber((BigDecimal)this.getValue("DSP_CD_GRU_CARENCIA"));
		return v;
	}


	
	
	public void setDspCdGruDireito(NNumber value){
		this.setValue("DSP_CD_GRU_DIREITO", value.getValue());
	}


	public NNumber getDspCdGruDireito(){
		NNumber v = new NNumber((BigDecimal)this.getValue("DSP_CD_GRU_DIREITO"));
		return v;
	}


	
	
	public void setDspQtMaximaSolic(NNumber value){
		this.setValue("DSP_QT_MAXIMA_SOLIC", value.getValue());
	}


	public NNumber getDspQtMaximaSolic(){
		NNumber v = new NNumber((BigDecimal)this.getValue("DSP_QT_MAXIMA_SOLIC"));
		return v;
	}


	
	
	public void setDspCdProcedimentoAuxiliar(NString value){
		this.setValue("DSP_CD_PROCEDIMENTO_AUXILIAR", value.getValue());
	}


	public NString getDspCdProcedimentoAuxiliar(){
		NString v = new NString((String)this.getValue("DSP_CD_PROCEDIMENTO_AUXILIAR"));
		return v;
	}


	
	
	public void setDspTpGuia(NString value){
		this.setValue("DSP_TP_GUIA", value.getValue());
	}


	public NString getDspTpGuia(){
		NString v = new NString((String)this.getValue("DSP_TP_GUIA"));
		return v;
	}


	
	
	public void setDspNrDiasInternacao(NNumber value){
		this.setValue("DSP_NR_DIAS_INTERNACAO", value.getValue());
	}


	public NNumber getDspNrDiasInternacao(){
		NNumber v = new NNumber((BigDecimal)this.getValue("DSP_NR_DIAS_INTERNACAO"));
		return v;
	}


	
	
	public void setDspNrNivelAutorizacao(NNumber value){
		this.setValue("DSP_NR_NIVEL_AUTORIZACAO", value.getValue());
	}


	public NNumber getDspNrNivelAutorizacao(){
		NNumber v = new NNumber((BigDecimal)this.getValue("DSP_NR_NIVEL_AUTORIZACAO"));
		return v;
	}


	
	
	public void setQtSolicPrest(NNumber value){
		this.setValue("QT_SOLIC_PREST", value.getValue());
	}


	public NNumber getQtSolicPrest(){
		NNumber v = new NNumber((BigDecimal)this.getValue("QT_SOLIC_PREST"));
		return v;
	}


	
	
	public void setQtSolicitado(NNumber value){
		this.setValue("QT_SOLICITADO", value.getValue());
	}


	public NNumber getQtSolicitado(){
		NNumber v = new NNumber((BigDecimal)this.getValue("QT_SOLICITADO"));
		return v;
	}


	
	
	public void setVlProcedimento(NNumber value){
		this.setValue("VL_PROCEDIMENTO", value.getValue());
	}


	public NNumber getVlProcedimento(){
		NNumber v = new NNumber((BigDecimal)this.getValue("VL_PROCEDIMENTO"));
		return v;
	}


	
	
	public void setDspVlTotalProcedimento(NNumber value){
		this.setValue("DSP_VL_TOTAL_PROCEDIMENTO", value.getValue());
	}


	public NNumber getDspVlTotalProcedimento(){
		NNumber v = new NNumber((BigDecimal)this.getValue("DSP_VL_TOTAL_PROCEDIMENTO"));
		return v;
	}


	
	
	public void setVlFranquia(NNumber value){
		this.setValue("VL_FRANQUIA", value.getValue());
	}


	public NNumber getVlFranquia(){
		NNumber v = new NNumber((BigDecimal)this.getValue("VL_FRANQUIA"));
		return v;
	}


	
	
	public void setDspVlTotalFranquia(NNumber value){
		this.setValue("DSP_VL_TOTAL_FRANQUIA", value.getValue());
	}


	public NNumber getDspVlTotalFranquia(){
		NNumber v = new NNumber((BigDecimal)this.getValue("DSP_VL_TOTAL_FRANQUIA"));
		return v;
	}


	
	
	public void setDtBaixado(NDate value){
		this.setValue("DT_BAIXADO", value.getValue());
	}


	public NDate getDtBaixado(){
		NDate v = new NDate((Date)this.getValue("DT_BAIXADO"));
		return v;
	}


	
	
	public void setCdTabelaFaturamento(NNumber value){
		this.setValue("CD_TABELA_FATURAMENTO", value.getValue());
	}


	public NNumber getCdTabelaFaturamento(){
		NNumber v = new NNumber((BigDecimal)this.getValue("CD_TABELA_FATURAMENTO"));
		return v;
	}


	
	
	public void setCdItguia(NNumber value){
		this.setValue("CD_ITGUIA", value.getValue());
	}


	public NNumber getCdItguia(){
		NNumber v = new NNumber((BigDecimal)this.getValue("CD_ITGUIA"));
		return v;
	}


	

	
}

package br.com.mv.soul.mvsaude.forms.Guia.model;

import morphis.foundations.core.appsupportlib.model.SimpleBusinessObject;
import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.*;
import static morphis.foundations.core.types.Types.*;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class NegacaoItem extends SimpleBusinessObject {

	public NegacaoItem() {
		super();
	}

	public NegacaoItem(SimpleBusinessObjectConfiguration configuration, String name) {
		super(configuration, name);
	}
	
	public NNumber getDspCdAutorizador() {
		return toNumber(super.getValue("DSP_CD_AUTORIZADOR"));
	}
	
	public void setDspCdAutorizador(NNumber value) {
		super.setValue("DSP_CD_AUTORIZADOR", value);
	}

	public NString getDspNmAutorizador() {
		return toStr(super.getValue("DSP_NM_AUTORIZADOR"));
	}
	
	public void setDspNmAutorizador(NString value) {
		super.setValue("DSP_NM_AUTORIZADOR", value);
	}

	public NString getDspDsSenha() {

	    return toStr(super.getValue("DSP_DS_SENHA"));
    }

	public void setDspDsSenha(NString value) {

	    super.setValue("DSP_DS_SENHA", value);
    }

	public NString getSnAplicarNegativaTodos() {

		return toStr(super.getValue("SN_APLICAR_NEGATIVA_TODOS"));
	}

	public void setSnAplicarNegativaTodos(NString value) {

		super.setValue("SN_APLICAR_NEGATIVA_TODOS", value);
	}

	
	
	
}

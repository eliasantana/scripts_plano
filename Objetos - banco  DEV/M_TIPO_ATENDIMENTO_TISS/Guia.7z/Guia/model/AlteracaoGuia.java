package br.com.mv.soul.mvsaude.forms.Guia.model;

import static morphis.foundations.core.types.Types.toNumber;
import static morphis.foundations.core.types.Types.toStr;

import morphis.foundations.core.appsupportlib.model.SimpleBusinessObject;
import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	


public class AlteracaoGuia extends SimpleBusinessObject
{
	public AlteracaoGuia() {
		super();
	}

	 public AlteracaoGuia(SimpleBusinessObjectConfiguration configuration, String name) {
		super(configuration, name);
	}
	

	



	public NNumber getCdPrestadorExecutorNovo() {
		return toNumber(super.getValue("CD_PRESTADOR_EXECUTOR_NOVO"));
	}
	
	public void setCdPrestadorExecutorNovo(NNumber value) {
		super.setValue("CD_PRESTADOR_EXECUTOR_NOVO", value);
	}
	


	public NString getDspNmPrestadorExecutorNovo() {
		return toStr(super.getValue("DSP_NM_PRESTADOR_EXECUTOR_NOVO"));
	}
	
	public void setDspNmPrestadorExecutorNovo(NString value) {
		super.setValue("DSP_NM_PRESTADOR_EXECUTOR_NOVO", value);
	}

	public NNumber getCdPrestadorEnderecoNovo() {
		return toNumber(super.getValue("CD_PRESTADOR_ENDERECO_NOVO"));
	}

	public void setCdPrestadorEnderecoNovo(NNumber value) {

		super.setValue("CD_PRESTADOR_ENDERECO_NOVO", value);
	}

	public NString getDspPrestadorEnderecoNovo() {

		return toStr(super.getValue("DSP_PRESTADOR_ENDERECO_NOVO"));
	}

	public void setDspPrestadorEnderecoNovo(NString value) {

		super.setValue("DSP_PRESTADOR_ENDERECO_NOVO", value);
	}
	



}





package br.com.mv.soul.mvsaude.forms.Guia.model;

import java.math.BigDecimal;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class GuiaHonorarioAdapter extends BaseRowAdapter {

	public GuiaHonorarioAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getDspCdPrestador() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_CD_PRESTADOR"));
		return v;
	}
	
	public void setDspCdPrestador(NNumber value) {
		this.setValue("DSP_CD_PRESTADOR", value.getValue());
	}

	public NString getDspNmPrestador() {
		NString v = new NString((String)this.getValue("DSP_NM_PRESTADOR"));
		return v;
	}
	
	public void setDspNmPrestador(NString value) {
		this.setValue("DSP_NM_PRESTADOR", value.getValue());
	}

	public NNumber getDspCdAtiMed() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("DSP_CD_ATI_MED"));
		return v;
	}
	
	public void setDspCdAtiMed(NNumber value) {
		this.setValue("DSP_CD_ATI_MED", value.getValue());
	}

	public NString getDspDsAtiMed() {
		NString v = new NString((String)this.getValue("DSP_DS_ATI_MED"));
		return v;
	}
	
	public void setDspDsAtiMed(NString value) {
		this.setValue("DSP_DS_ATI_MED", value.getValue());
	}
	
	public NNumber getDspCdEspecialidade() {

		NNumber v = new NNumber((BigDecimal) this.getValue("DSP_CD_ESPECIALIDADE"));
		return v;
	}

	public void setDspCdEspecialidade(NNumber value) {

		this.setValue("DSP_CD_ESPECIALIDADE", value.getValue());
	}

	public NString getDspDsEspecialidade() {

		NString v = new NString((String) this.getValue("DSP_DS_ESPECIALIDADE"));
		return v;
	}

	public void setDspDsEspecialidade(NString value) {

		this.setValue("DSP_DS_ESPECIALIDADE", value.getValue());
	}

}

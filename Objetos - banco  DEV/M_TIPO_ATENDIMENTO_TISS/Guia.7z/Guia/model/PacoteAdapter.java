package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class PacoteAdapter extends BaseRowAdapter {

	public PacoteAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NString getCdProcedimento() {
		NString v = new NString((String)this.getValue("CD_PROCEDIMENTO"));
		return v;
	}
	
	public void setCdProcedimento(NString value) {
		this.setValue("CD_PROCEDIMENTO", value.getValue());
	}

	public NString getCdItemProcedimento() {
		NString v = new NString((String)this.getValue("CD_ITEM_PROCEDIMENTO"));
		return v;
	}
	
	public void setCdItemProcedimento(NString value) {
		this.setValue("CD_ITEM_PROCEDIMENTO", value.getValue());
	}

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	

	
	
	
	
	public NString getDspDsProcedimento() {

	    NString v = new NString((String) this.getValue("DSP_DS_PROCEDIMENTO"));
	    return v;
    }

	public void setDspDsProcedimento(NString value) {

	    this.setValue("DSP_DS_PROCEDIMENTO", value.getValue());
    }

}

package br.com.mv.soul.mvsaude.forms.Guia.model;

import java.math.BigDecimal;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class LogTransacaoPtuOnlineAdapter extends BaseRowAdapter {

	public LogTransacaoPtuOnlineAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NString getTpTransacao() {
		NString v = new NString((String)this.getValue("TP_TRANSACAO"));
		return v;
	}
	
	public void setTpTransacao(NString value) {
		this.setValue("TP_TRANSACAO", value.getValue());
	}

	public NDate getDtTransacao() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_TRANSACAO"));
		return v;
	}
	
	public void setDtTransacao(NDate value) {
		this.setValue("DT_TRANSACAO", value.getValue());
	}

	public NString getCdUnimedOrigem() {
		NString v = new NString((String)this.getValue("CD_UNIMED_ORIGEM"));
		return v;
	}
	
	public void setCdUnimedOrigem(NString value) {
		this.setValue("CD_UNIMED_ORIGEM", value.getValue());
	}

	public NString getCdUnimedDestino() {
		NString v = new NString((String)this.getValue("CD_UNIMED_DESTINO"));
		return v;
	}
	
	public void setCdUnimedDestino(NString value) {
		this.setValue("CD_UNIMED_DESTINO", value.getValue());
	}
	
	

	

	public NNumber getCdPtuMensagem() {

		NNumber v = new NNumber((BigDecimal) this.getValue("CD_PTU_MENSAGEM"));
		return v;
	}

	public void setCdPtuMensagem(NNumber value) {

		this.setValue("CD_PTU_MENSAGEM", value.getValue());
	}

}

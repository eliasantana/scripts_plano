package br.com.mv.soul.mvsaude.forms.Guia.model;

import org.jdesktop.databuffer.DataRow;

import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.configuration.*;
import morphis.foundations.core.appdatalayer.configuration.*;
	

public class MensContratoAdapter extends BaseRowAdapter {

	public MensContratoAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getCdMensContrato() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_MENS_CONTRATO"));
		 return v;
	}
	
	public void setCdMensContrato(NNumber value) {
		this.setValue("CD_MENS_CONTRATO", value.getValue());
	}

	public NNumber getCdConRec() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_CON_REC"));
		return v;
	}
	
	public void setCdConRec(NNumber value) {
		this.setValue("CD_CON_REC", value.getValue());
	}
	
	public NString getTpQuitacao() {
		NString v = new NString((String) this.getValue("TP_QUITACAO"));
		return v;
	}

	public void setTpQuitacao(NString value) {
		this.setValue("TP_QUITACAO", value.getValue());
	}

}

package br.com.mv.soul.mvsaude.forms.Guia;

import java.util.Hashtable;
import br.com.mv.soul.common.forms.DefaultTask;

public class GuiaTask extends DefaultTask {
	public GuiaTask(String taskName) {
		super(taskName);
	}
	
	public GuiaTask(String taskName, Hashtable sharedLibraries, Hashtable parameters) {
		super(taskName, sharedLibraries, parameters);
	}
	
	@Override
	public br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel getModel() {
		return (br.com.mv.soul.mvsaude.forms.Guia.model.GuiaModel)super.getModel();
	}
	
	public br.com.mv.soul.mvsaude.forms.Guia.services.GuiaServices getServices() {
		return (br.com.mv.soul.mvsaude.forms.Guia.services.GuiaServices)getSupportCodeManager().getServices();
	}
	
	// Package Accessors
	
	public br.com.mv.soul.mvsaude.forms.Guia.services.Var getVar() {
		return (br.com.mv.soul.mvsaude.forms.Guia.services.Var)getSupportCodeManager().getPackage("VAR");
	}
	
	// Attached Libraries
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsPrestador.MPkgMvsPrestadorServices getMPkgMvsPrestador() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsPrestador.MPkgMvsPrestadorServices)getSupportCodeManager().getLibrary("M_PKG_MVS_PRESTADOR");
	}
	
	public br.com.mv.soul.common.libs.MvRegMaq.MvRegMaqServices getMvRegMaq() {
		return (br.com.mv.soul.common.libs.MvRegMaq.MvRegMaqServices)getSupportCodeManager().getLibrary("MV_REG_MAQ");
	}
	
	public br.com.mv.soul.common.libs.Ofgtel.OfgtelServices getOfgtel() {
		return (br.com.mv.soul.common.libs.Ofgtel.OfgtelServices)getSupportCodeManager().getLibrary("OFGTEL");
	}
	
	public br.com.mv.soul.common.libs.Ofgmes.OfgmesServices getOfgmes() {
		return (br.com.mv.soul.common.libs.Ofgmes.OfgmesServices)getSupportCodeManager().getLibrary("OFGMES");
	}
	
	public br.com.mv.soul.common.libs.MvAdm.MvAdmServices getMvAdm() {
		return (br.com.mv.soul.common.libs.MvAdm.MvAdmServices)getSupportCodeManager().getLibrary("MV_ADM");
	}
	
	public br.com.mv.soul.common.libs.Autentica.AutenticaServices getAutentica() {
		return (br.com.mv.soul.common.libs.Autentica.AutenticaServices)getSupportCodeManager().getLibrary("AUTENTICA");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsContrato.MPkgMvsContratoServices getMPkgMvsContrato() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsContrato.MPkgMvsContratoServices)getSupportCodeManager().getLibrary("M_PKG_MVS_CONTRATO");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsTabela.MPkgMvsTabelaServices getMPkgMvsTabela() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsTabela.MPkgMvsTabelaServices)getSupportCodeManager().getLibrary("M_PKG_MVS_TABELA");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsUsuario.MPkgMvsUsuarioServices getMPkgMvsUsuario() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsUsuario.MPkgMvsUsuarioServices)getSupportCodeManager().getLibrary("M_PKG_MVS_USUARIO");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsProcedimento.MPkgMvsProcedimentoServices getMPkgMvsProcedimento() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsProcedimento.MPkgMvsProcedimentoServices)getSupportCodeManager().getLibrary("M_PKG_MVS_PROCEDIMENTO");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsTipAcomodacao.MPkgMvsTipAcomodacaoServices getMPkgMvsTipAcomodacao() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsTipAcomodacao.MPkgMvsTipAcomodacaoServices)getSupportCodeManager().getLibrary("M_PKG_MVS_TIP_ACOMODACAO");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsGrupoFranquia.MPkgMvsGrupoFranquiaServices getMPkgMvsGrupoFranquia() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsGrupoFranquia.MPkgMvsGrupoFranquiaServices)getSupportCodeManager().getLibrary("M_PKG_MVS_GRUPO_FRANQUIA");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsCid.MPkgMvsCidServices getMPkgMvsCid() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsCid.MPkgMvsCidServices)getSupportCodeManager().getLibrary("M_PKG_MVS_CID");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsContasMedicas.MPkgMvsContasMedicasServices getMPkgMvsContasMedicas() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsContasMedicas.MPkgMvsContasMedicasServices)getSupportCodeManager().getLibrary("M_PKG_MVS_CONTAS_MEDICAS");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsMotCancelaGuia.MPkgMvsMotCancelaGuiaServices getMPkgMvsMotCancelaGuia() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsMotCancelaGuia.MPkgMvsMotCancelaGuiaServices)getSupportCodeManager().getLibrary("M_PKG_MVS_MOT_CANCELA_GUIA");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsCortesia.MPkgMvsCortesiaServices getMPkgMvsCortesia() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsCortesia.MPkgMvsCortesiaServices)getSupportCodeManager().getLibrary("M_PKG_MVS_CORTESIA");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsAutorizador.MPkgMvsAutorizadorServices getMPkgMvsAutorizador() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsAutorizador.MPkgMvsAutorizadorServices)getSupportCodeManager().getLibrary("M_PKG_MVS_AUTORIZADOR");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsTipoAtendimento.MPkgMvsTipoAtendimentoServices getMPkgMvsTipoAtendimento() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsTipoAtendimento.MPkgMvsTipoAtendimentoServices)getSupportCodeManager().getLibrary("M_PKG_MVS_TIPO_ATENDIMENTO");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsPlano.MPkgMvsPlanoServices getMPkgMvsPlano() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsPlano.MPkgMvsPlanoServices)getSupportCodeManager().getLibrary("M_PKG_MVS_PLANO");
	}
	
	public br.com.mv.soul.mvsaude.libs.MPkgMvsEspecialidade.MPkgMvsEspecialidadeServices getMPkgMvsEspecialidade() {
		return (br.com.mv.soul.mvsaude.libs.MPkgMvsEspecialidade.MPkgMvsEspecialidadeServices)getSupportCodeManager().getLibrary("M_PKG_MVS_ESPECIALIDADE");
	}
}

package br.com.mv.soul.mvsaude.forms.MTipoAtendimentoTiss.services;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.setItemValue;
import br.com.mv.soul.common.libs.DbUtils.XmlParameterFactory;
import br.com.mv.soul.mvsaude.forms.MTipoAtendimentoTiss.model.TipoAtendimentoTissAdapter;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.data.IDataCommand;
import morphis.foundations.core.appsupportlib.util.XmlTypeParameter;
import morphis.foundations.core.types.NNumber;

import static morphis.foundations.core.appsupportlib.Globals.getGlobal;

import java.sql.NClob;
public class PkgMvsaudeMTipoAtendimentoTiss {
	
	public static void pBPiTipoAtendimentoTiss(TipoAtendimentoTissAdapter tipoAtendimentoTissElement)
	{
		IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand("Pkg_MVS_M_TIPO_ATENDIME_TISS.P_B_PI_TIPO_ATENDIMENTO_TISS", DbManager.getDataBaseFactory());

		 XmlTypeParameter xml = XmlParameterFactory.CreateParameter();
		 
		 //adiciona parametros usuarios e multiEmpresa
		 xml.setField("usuario", getGlobal("USUARIO"));
		 xml.setField("multiEmpresa", getGlobal("VCD_MULTI_EMPRESA"));
		 
		 //adiciona restantes parametros
		 
		xml.setField("TIPO_ATENDIMENTO_TISS.CD_TIPO_ATENDIMENTO", tipoAtendimentoTissElement.getCdTipoAtendimento());
		//call to the database wrapper service
		cmd.addParameter("@IN_PARAMS", xml.getParameterClob());
		cmd.addParameter("@OUT_PARAMS", NClob.class);
		
		//executa rotina no banco
		cmd.execute();
		
		//extrai xml de resposta
		NClob outParams = cmd.getParameterValue("@OUT_PARAMS", NClob.class);
		xml.setParameterClob((morphis.foundations.core.types.NClob) outParams);
		
	
		//extrai parametros de saida
		
		setItemValue("TIPO_ATENDIMENTO_TISS.CD_TIPO_ATENDIMENTO", xml.getField("TIPO_ATENDIMENTO_TISS.CD_TIPO_ATENDIMENTO", NNumber.class));

		// trata mensagens
		xml.HandleMessages();
		
		//trata erros
        xml.HandleExceptions();
	
	}
}

package br.com.mv.soul.mvsaude.forms.MTipoAtendimentoTiss.model;

import java.util.Hashtable;
import morphis.foundations.core.appsupportlib.model.*;
import morphis.foundations.core.appsupportlib.runtime.*;
import br.com.mv.soul.common.forms.model.DefaultFormModel;


public class MTipoAtendimentoTissModel extends DefaultFormModel {
	
	public MTipoAtendimentoTissModel(ITask task, Hashtable parameters) {
		super(task, parameters);
	}

	
	public IDBBusinessObject getTipoAtendimentoTiss() {
		return (IDBBusinessObject) getBusinessObject("TIPO_ATENDIMENTO_TISS");
	}
}
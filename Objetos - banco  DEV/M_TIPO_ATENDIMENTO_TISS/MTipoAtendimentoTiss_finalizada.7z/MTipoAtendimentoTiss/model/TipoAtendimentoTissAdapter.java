package br.com.mv.soul.mvsaude.forms.MTipoAtendimentoTiss.model;

import java.util.Date;
import java.math.BigDecimal;
import org.jdesktop.databuffer.DataRow;
//import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.types.*;
import morphis.foundations.core.appsupportlib.model.*;
import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;

public class TipoAtendimentoTissAdapter extends BaseRowAdapter {

	public TipoAtendimentoTissAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getCdTipoAtendimento() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("CD_TIPO_ATENDIMENTO"));
		return v;
	}
	
	public void setCdTipoAtendimento(NNumber value) {
		this.setValue("CD_TIPO_ATENDIMENTO", value.getValue());
	}

	public NString getCdTiss() {
		NString v = new NString((String)this.getValue("CD_TISS"));
		return v;
	}
	
	public void setCdTiss(NString value) {
		this.setValue("CD_TISS", value.getValue());
	}

	public NString getDsTipoAtendimento() {
		NString v = new NString((String)this.getValue("DS_TIPO_ATENDIMENTO"));
		return v;
	}
	
	public void setDsTipoAtendimento(NString value) {
		this.setValue("DS_TIPO_ATENDIMENTO", value.getValue());
	}

	public NDate getDtFimVigencia() {
		NDate v = new NDate((java.util.Date)this.getValue("DT_FIM_VIGENCIA"));
		return v;
	}
	
	public void setDtFimVigencia(NDate value) {
		this.setValue("DT_FIM_VIGENCIA", value.getValue());
	}

}
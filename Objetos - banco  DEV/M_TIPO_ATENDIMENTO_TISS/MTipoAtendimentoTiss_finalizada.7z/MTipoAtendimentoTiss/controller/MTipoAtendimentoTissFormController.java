package br.com.mv.soul.mvsaude.forms.MTipoAtendimentoTiss.controller;

import morphis.foundations.core.appsupportlib.runtime.ITask;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import br.com.mv.soul.common.forms.controller.DefaultFormController;
import br.com.mv.soul.mvsaude.forms.MTipoAtendimentoTiss.MTipoAtendimentoTissTask;
import br.com.mv.soul.mvsaude.forms.MTipoAtendimentoTiss.model.MTipoAtendimentoTissModel;
import morphis.foundations.core.appsupportlib.runtime.events.TaskStarted;
import java.util.EventObject;

public class MTipoAtendimentoTissFormController extends DefaultFormController {

	public MTipoAtendimentoTissFormController(ITask task) {
		super(task);
	}

	@Override
	public MTipoAtendimentoTissTask getTask() {
		return (MTipoAtendimentoTissTask) super.getTask();
	}

	public MTipoAtendimentoTissModel getFormModel() {
		return getTask().getModel();
	}

	//action methods generated from triggers
	/* Original PL/SQL code code for TRIGGER M_TIPO_ATENDIMENTO_TISS.KEY-ENTQRY
	 Begin
	  If :System.Mode <> 'ENTER-QUERY' Then
		Antes_Query;
		Enter_Query;
		Apos_Query;
	  End If;
	End;
	*/
	/// <summary>
	/// </summary>
	/// <remarks>
	///	ID:102
	/// 
	/// 
	///</remarks>
	/// <TriggerInfo>M_TIPO_ATENDIMENTO_TISS.KEY-ENTQRY</TriggerInfo>
	

	
	/* Original PL/SQL code code for TRIGGER M_TIPO_ATENDIMENTO_TISS.WHEN-TIMER-EXPIRED
	 Hint.ShowButtonHelpHandler;

	*/
	/// <summary>
	/// </summary>
	/// <remarks>
	///	ID:105
	/// 
	/// F2N_NOT_SUPPORTED : There is no mapping of trigger M_TIPO_ATENDIMENTO_TISS.WHEN-TIMER-EXPIRED into a .Net Framework event. See documentation for details "file://T:\produtos_mv\src\Docs\M_TIPO_ATENDIMENTO_TISSF2NMigrationGuide.xml#Trigger.Default".
	///</remarks>
	/// <TriggerInfo>M_TIPO_ATENDIMENTO_TISS.WHEN-TIMER-EXPIRED</TriggerInfo>
	
	
	/* Original PL/SQL code code for TRIGGER M_TIPO_ATENDIMENTO_TISS.WHEN-NEW-FORM-INSTANCE
	 set_window_property(forms_mdi_window,window_state,maximize);
	set_window_property('root_window',window_state,maximize);
	
	:GLOBAL.CG$HP_HPATH := '\MV2000\SGPS\';
	:GLOBAL.CG$HP_HFILE := :GLOBAL.CG$HP_HPATH || 'SGPS.HLP';
	:GLOBAL.HELP_ID     := VE_AUTORIZACAO(NULL);

	*/
	/// <summary>
	/// </summary>
	/// <remarks>
	///	ID:106
	/// 
	/// 
	///</remarks>
	/// <param name="args"></param>
	/// <TriggerInfo>M_TIPO_ATENDIMENTO_TISS.WHEN-NEW-FORM-INSTANCE</TriggerInfo>
	
	@TaskStarted
	public void m_tipo_atendimento_tiss_TaskStarted(EventObject eventObject) {
		setGlobal("HELP_ID", getTask().getAutentica().veAutorizacao(toNumber(null)));
	}
	
	
		
}
package br.com.mv.soul.mvsaude.forms.MTipoAtendimentoTiss.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import br.com.mv.soul.common.forms.controller.DefaultBlockController;
import br.com.mv.soul.mvsaude.forms.MApropriacaoContabil.services.PkgMvsaudeMApropriacaoContabil;
import br.com.mv.soul.mvsaude.forms.MTipoAtendimentoTiss.MTipoAtendimentoTissTask;
import br.com.mv.soul.mvsaude.forms.MTipoAtendimentoTiss.model.MTipoAtendimentoTissModel;
import br.com.mv.soul.mvsaude.forms.MTipoAtendimentoTiss.model.TipoAtendimentoTissAdapter;
import br.com.mv.soul.mvsaude.forms.MTipoAtendimentoTiss.services.PkgMvsaudeMTipoAtendimentoTiss;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appdatalayer.events.BeforeRowInsert;


public class TipoAtendimentoTissController extends DefaultBlockController {

	public TipoAtendimentoTissController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public MTipoAtendimentoTissTask getTask() {
		return (MTipoAtendimentoTissTask) super.getTask();
	}

	public MTipoAtendimentoTissModel getFormModel() {
		return getTask().getModel();
	}

	
	//action methods generated from triggers
	/* Original PL/SQL code code for TRIGGER TIPO_ATENDIMENTO_TISS.PRE-INSERT
	 BEGIN
		IF (:TIPO_ATENDIMENTO_TISS.CD_TIPO_ATENDIMENTO IS NULL) THEN
		DECLARE
		CURSOR C IS
		  SELECT  dbaps.SEQ_TIPO_ATENDIMENTO_TISS.NEXTVAL
		  FROM    SYS.DUAL;
		BEGIN
		OPEN C;
		FETCH C
		INTO    :TIPO_ATENDIMENTO_TISS.CD_TIPO_ATENDIMENTO;
		IF C%NOTFOUND THEN
		  message('Erro Interno: Nenhuma linha na tabela SYS.DUAL');
		  RAISE FORM_TRIGGER_FAILURE;
		END IF;
		CLOSE C;
		END;
		END IF;
	END;

	*/
	/// <summary>
	/// </summary>
	/// <remarks>
	///	ID:42
	/// 
	/// 
	///</remarks>
	/// <param name="args"></param>
	/// <TriggerInfo>TIPO_ATENDIMENTO_TISS.PRE-INSERT</TriggerInfo>
	
	
	@BeforeRowInsert
	public void tipo_atendimento_tiss_BeforeRowInsert(RowAdapterEvent args) {
		
		TipoAtendimentoTissAdapter tipoAtendimentoTissElement = (TipoAtendimentoTissAdapter)args.getRow();
		PkgMvsaudeMTipoAtendimentoTiss.pBPiTipoAtendimentoTiss(tipoAtendimentoTissElement); 
	}
	
}